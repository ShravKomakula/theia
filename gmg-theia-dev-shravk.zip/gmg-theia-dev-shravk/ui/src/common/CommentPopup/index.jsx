import React, { useState,useEffect } from "react";
import { PropTypes } from "prop-types";
import Xcircle from "./../../assets/images/XCircle.svg";
import styled from "styled-components";
import "./comment.css";
import { CommentEndPoint } from "../api-config";
import axios from "axios";
import { FaThumbsDown } from "react-icons/fa";
import { ToastContainer, toast } from "react-toastify";

export const ModalContainer = styled.div`
  width: 100%;
  height: 100%;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  margin: auto;
  position: fixed;
  background-color: rgba(0, 0, 0, 0.2);
  transition: all 0.4s cubic-bezier(0.25, 0.8, 0.25, 1);
  z-index: 9999;
  outline: none;
`;

export const ModalWrapper = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  height: auto;
`;

export const StyledModalContainer = styled.div`
  display: flex;
  flex-direction: column;
  height: 280px;
  width: ${(props) => props.popupWidth};
  background-color: ${(props) =>
    props.backgroundColor ? props.backgroundColor : "#1e2d3d"};
  border: 1px solid
    ${(props) => (props.borderColor ? props.borderColor : "#54A03D")};
  padding: ${(props) => props.popupPadding};
  margin-top: 150px;
  border-radius: 4px;
`;

export const ModalContent = styled.div`
  display: flex;
  flex-direction: column;
  padding: 20px;
 
  color: ${(props) => (props.color ? props.color : "#54A03D")};
  & div:first-child {
    font-weight: 500;
    font-size: 14px;
    line-height: 20px;
  }
  & div:last-child {
    font-weight: normal;
    font-size: 14px;
    line-height: 21px;
    margin-top: 0px;

    .btn-primary {
      font-family: "Noto Sans", sans-serif;
      text-shadow: 0px 0px 0px rgb(0 0 0 / 0%);
      border-color: rgba(0, 0, 0, 0);
      // background-color: #003152;
      background-color: #1e2d3d;
      border-radius: 4px;
      font-style: normal;
      line-height: 20px;
      font-weight: 600;
      padding: 12px 20px;
      color: rgb(255, 255, 255);
      font-size: 14px;
      width: auto;
    }
    .btn-secondary {
      border: 1px solid white;
      color: white;
      font-weight: 600;
      font-family: "Noto Sans" !important;
      font-style: normal;
      box-sizing: border-box;
      border-radius: 4px;
      font-size: 14px;
      line-height: 32px;
      align-items: center;
      margin-left: 10px;
      background: #1e2d3d;
      text-shadow: 1px 1px 1px rgba(0, 0, 0, 0%);
      width: auto;
    }
  }
`;
export const ModalItem = styled.div``;

export const ModalTitle = styled.div`
  padding-top: 5px;
  fotn weight:20;
`;

export const ModalMessage = styled.div`
  padding: 10px 50px;
  color: ${(props) => (props.color ? props.color : "#54A03D")};
`;

export const ModalButtons = styled.div`
  padding: 5px;
  & button {
    float: right;
    margin-left: 10px;
    cursor: pointer;
    position: relative;
  }
`;

const Modal = ({
  openModal,

  type,
  close,
  popupPadding,
  popupWidth,
  queryList,
  setQueryList,
  id,

}) => {
  const [commentText, setCommentText] = useState("");
  useEffect(() => {
    // Reset commentText when the modal is opened
    if (openModal) {
      setCommentText("");
    }
  }, [openModal]);
  const submitComment = async (id) => {
    if (!commentText.trim()) {
      toast.warning("Comment text cannot be empty", {
        position: toast.POSITION.BOTTOM_CENTER,
        autoClose: 3000,
      });
      return;
    }
  
    try {
      const payload = {
        query_id: id,
        comment: commentText
      };
      
      console.log("Submitting comment with payload:", payload);
  
      const commentResponse = await axios.post(CommentEndPoint(), payload, {
        headers: {
          'Content-Type': 'application/json'
        }
      });
  
      console.log("comment Response:", commentResponse.data);
      
      const updateQueryList = queryList.map((item) =>
        item.query_id === id ? { ...item, comments: item.comments + 1 } : item
      );
      setQueryList(updateQueryList);
    } catch (commentError) {
      console.error("Error occurred while posting a comment", commentError.response ? commentError.response.data : commentError.message);
    }
    close();
  };
  
  
  if (!openModal) {
    return null;
  }
  let border_color = "#54A03D";
  let background_color = "#E3FCDC";
  let color = "#54A03D";
  switch (type) {
    case "theme":
      border_color = "#FFFFFF";
      background_color = "#FFFFFF";
      color = "#05322B";
      break;
    case "warning":
      border_color = "#96722E";
      background_color = "#FFF4DE";
      color = "#96722E";
      break;
    case "error":
      border_color = "#AB332F";
      background_color = "#FFF2E5";
      color = "#AB332F";
      break;
    case "info":
      border_color = "#4E82AD";
      background_color = "#24374a";
      color = "#4E82AD";
      break;

    default:
      break;
  }

  return (
    <ModalContainer>
      <ModalWrapper>
        <StyledModalContainer
          backgroundColor={"white"}
          borderColor={"white"}
          popupWidth={popupWidth}
          popupPadding={popupPadding}
        >
          <ModalContent color="#05322B">
            <div className="modal-container">
              <p>
                Thanks for your feedback,Please provide comments on how this
                could have been answered better
              </p>
              <img src={Xcircle} width={"20px"} onClick={() => close()}></img>
            </div>
            <hr />
            <div className="modal-container-1">
              <textarea
                style={{ height: "100px" }}
                placeholder="Type your comments here..."
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
                className="textarea-placeholder p-2"
              />
              <button
                className="submit-text-font mt-4 d-flex justify-content-center align-items-center align-self-end"
                onClick={() => submitComment(id)}
              >
                Submit
              </button>
            </div>
          </ModalContent>
        </StyledModalContainer>
      </ModalWrapper>
    </ModalContainer>
  );
};

export default Modal;
Modal.propTypes = {
  title: PropTypes.string,
  message: PropTypes.string,
  type: PropTypes.string,
  buttons: PropTypes.arrayOf(
    PropTypes.shape({
      label: PropTypes.string,
      onClick: PropTypes.func,
      className: PropTypes.string,
    })
  ),
  status: PropTypes.string,
};
