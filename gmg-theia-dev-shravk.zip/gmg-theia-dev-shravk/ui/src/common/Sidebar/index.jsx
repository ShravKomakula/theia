import React, { useState,useEffect } from 'react';
import './Sidebar.css'; // You can define your styles in this CSS file

import { CiBellOn, CiUser, CiHome, CiChat2 } from "react-icons/ci";

import { BsBarChart } from "react-icons/bs";
import { IoSettingsOutline } from "react-icons/io5";
import { useNavigate,useLocation } from 'react-router-dom';
const Sidebar = () => {

  const navigate = useNavigate();
  const location = useLocation();

  const isActive = (path) => location.pathname === path;
 
  return (
    <>
    
      <div className="profile">
        {/* Sidebar */}
        <div className="sidebarNav">
          <ul className="nav">
            <li>Main</li>
            <li
              className={`mainlink ${isActive('/') ? 'active' : ''}`}
              onClick={() => navigate('/')}
            >
              <CiHome />&nbsp;Home
            </li>
            <li className={`mainlink ${isActive('/dashboard') ? 'active' : ''}`} onClick={() => navigate('/dashboard')}>
              <CiUser />&nbsp;Dashboard
            </li>
            <li>APPS</li>
           {/*  <li className={`mainlink ${isActive('/grant') ? 'active' : ''}`} onClick={() => handleNavigation('grant','/grant')}>
              <HiOutlineDocumentText />&nbsp;Grant View
            </li> */}
            <li className={`mainlink ${isActive('/chat') ? 'active' : ''}`}onClick={() => navigate('/chat')}>
              <CiChat2 />&nbsp;Chat
            </li>
            <li className={`mainlink ${isActive('/OpsCompliance') ? 'active' : ''}`} onClick={() => navigate('/OpsCompliance')}>
              <BsBarChart />&nbsp;Ops Compliance
            </li>
            <li>DISCOVER</li>
            <li className={`mainlink ${isActive('/impacts') ? 'active' : ''}`} onClick={() => navigate('/impacts')}>
              <CiBellOn />&nbsp;Impact & Outcomes
            </li>
            <li className={`mainlink ${isActive('/ScientificProfilesPage') ? 'active' : ''}`} onClick={() => navigate('/ScientificProfilesPage')}>
              <IoSettingsOutline />&nbsp;Scientific Experts
            </li>
          </ul>
        </div>

        </div>
    </>
  );
};

export default Sidebar;
