import React,{useEffect} from 'react';
import { ReactFlowProvider } from 'reactflow';
import { createTheme, MantineProvider } from '@mantine/core';
import GrantsView from './components/GrantView';
import LoginView from './components/LoginView/LoginView';
import { ToastContainer } from 'react-toastify';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'react-toastify/dist/ReactToastify.css';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import './App.css';
import ImpactDetail from './components/ImpactDetail/ImpactDetail'
import ScientificProfilesPage from './components/GraphUI';
import { AuthProvider } from './components/AuthContext';
import AuthWrapper from './components/AuthWrapper';
import LandingPageNew from './components/LandingPageNew';
import History from './components/History/History';
import Dashboard from './components/Dashboard';
import HelpQA from './components/HelpQA/HelpQA';
import Chat from './components/Chat';
import '@mantine/core/styles.css';
import Impacts from "./components/Impact/impact"
import UnauthorisedPage from './components/Unauthorised/UnauthorisedPage'
import Home from './components/Home';
import OpsCompliance from './components/OpsCompliance';
import { ValidateSsoOauth2 } from './common/api-config';
function App() {
 /*  console.log(localStorage.getItem("authenticated"),"test1");
  useEffect(()=>{
    console.log(localStorage.getItem("authenticated"),"test2");
    if(localStorage.getItem("authenticated")== null){
      console.log(localStorage.getItem("authenticated"),"test");
     window.location.reload();
    }
    
  },[]) */
  useEffect(() => {
    let localStorageDetails = localStorage.getItem('user');
    localStorageDetails = JSON.parse(localStorageDetails);
    if (localStorageDetails && localStorageDetails.loginType === 'SSO' && localStorageDetails.tokenInfo) {
      const respValidateTokenReq = ValidateSsoOauth2({ token: localStorageDetails.tokenInfo.access_token });
      respValidateTokenReq.then((respToken) => {
        if (respToken.status !== 200) {
          localStorage.clear();
          window.location.reload();
        }
      });
    }
  }, []);
  
  
  const theme = createTheme({
    fontFamily: 'Open Sans, sans-serif',
    primaryColor: 'cyan',
  });
  return (
    <MantineProvider theme={theme}>
      <ReactFlowProvider>
        <AuthProvider>
          <Router>
            <Routes>

              <Route path="/login" element={
                <AuthWrapper>
                  <LoginView />
                </AuthWrapper>
              } />
              <Route path="/auth-redirect" element={
                <AuthWrapper>
                  <LoginView />
                </AuthWrapper>
              } />
              <Route path="/Chat" element={

                <AuthWrapper>
                  <LandingPageNew />
                </AuthWrapper>
              } />
              <Route path="/query" element={

                <AuthWrapper>
                  <Chat />
                </AuthWrapper>
              } />
                 <Route path="/grantview" element={

<AuthWrapper>
  <GrantsView />
</AuthWrapper>
} />
              <Route path="/ImpactDetail" element={

                <AuthWrapper>
                  <ImpactDetail />
                </AuthWrapper>
              } />

              <Route path="/impacts" element={
                <AuthWrapper>
                  <Impacts />
                </AuthWrapper>
              } />

              <Route path="/OpsCompliance" element={
                <AuthWrapper>
                  <OpsCompliance />
                </AuthWrapper>
              } />
              <Route path="/HelpQA" element={
                <AuthWrapper>
                  <HelpQA />
                </AuthWrapper>
              } />
              <Route path="/Dashboard" element={
                <AuthWrapper>
                  <Dashboard />
                </AuthWrapper>
              } />
              <Route path="/" element={
                <AuthWrapper>
                  <Home />
                </AuthWrapper>
              } />
              <Route path="/ScientificProfilesPage" element={
                <AuthWrapper>
                  <ScientificProfilesPage />
                </AuthWrapper>
              } />
              <Route path="/unauthorised" element={
                <AuthWrapper>
                  <UnauthorisedPage />
                </AuthWrapper>
              } />
              <Route path="/impact" element={
                <AuthWrapper>
                  <Impacts />
                </AuthWrapper>
              } />
              <Route path="/Chat" element={
                <AuthWrapper>
                  <Chat />
                </AuthWrapper>
              } />
            </Routes>
            <ToastContainer />
          </Router>
        </AuthProvider>
      </ReactFlowProvider>
    </MantineProvider>
  );
}

export default App;
