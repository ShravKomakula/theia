import React, { useState, useEffect } from 'react';
import './../../components/LoginView/LoginView.css';
import leftlogo from './../../assets/images/Search engines-rafiki 1.svg';
import logo from './../../assets/images/Pfizer-Logo-Color-RGB 1.svg';
import { useAuth } from '../AuthContext';
import { useNavigate } from "react-router-dom";
import { GetSsoTokenOauth2, ValidateSsoOauth2 } from '../../common/api-config';
import { useSearchParams } from 'react-router-dom';
import axios from 'axios';
import { ThreeDots } from 'react-loader-spinner';

function LoginView() {
    const [params, setParams] = useSearchParams();
    const { login } = useAuth();
    const navigate = useNavigate();
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [showPassword, setShowPassword] = useState(false);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        const code = params.get('code');
        if (code) {
            handleSsoLogin(code);
        }
    }, [params]);

    const handleSsoLogin = async (code) => {
        setLoading(true);
        try {
            const ssoTokenResponse = await axios.post(GetSsoTokenOauth2(code), { code: code });
            if (ssoTokenResponse && ssoTokenResponse.status === 200) {
                const validateTokenResponse = await axios.post(ValidateSsoOauth2(ssoTokenResponse.data.data.access_token), {});
                localStorage.setItem("access_token", JSON.stringify({
                    loginType: 'SSO',
                    tokenInfo: ssoTokenResponse.data.data,
                    userInfo: validateTokenResponse.data.data,
                }));
                setLoading(false);
                console.log("Login successful, navigating to /",validateTokenResponse);
                login(validateTokenResponse.data.data.access_token.mail, "ssologin", navigate, validateTokenResponse.data.data.access_token.firstname);
                
            } else {
                console.error("Error in SSO token response");
                setLoading(false);
            }
        } catch (error) {
            console.error("Error", error);
            setLoading(false);
        }
    };

    const togglePasswordVisibility = () => {
        setShowPassword(!showPassword);
    };

    const handleLoginWithAd = () => {
        console.log("SSO button clicked");
        const oauthUrl = `https://devfederate.pfizer.com/as/authorization.oauth2?client_id=theia_client&grant_type=authorization_code&response_type=code&scope=edit`;
        window.location.href = oauthUrl;
    };

    const handleLogin = () => {
        login(email, password, navigate);
    }

    return (
        <div className="login-lemnt-wrapper">
            {loading ? (
                <div className="loader-container">
                    <ThreeDots color="#00BFFF" height={80} width={80} />
                </div>
            ) : (
                <div className="container">
                    <div className="image-login-wg white">
                        <div className="texts">
                            <h5>
                                Discover the best of <a href="#">Pfizer</a> with{" "}
                                <a href="#">Pfizer Search</a>
                            </h5>
                            <p>
                                The AI Assistant that guides you to be Faster,{" "}
                                <p> Stronger and Better</p>
                            </p>
                        </div>
                        <img src={leftlogo} className="w-100" alt="" />
                    </div>
                    <div className="card-login">
                        <div className="login-contact-wrapper px-5">
                            <div className="form-heading-area mb-3 text-center">
                                <img className="mx-auto d-block p-4" src={logo} alt="Logo" />
                            </div>
                            <div className="wap-formcontact">
                                <h2 className="heading-title-login">
                                    <span>Login...</span>
                                </h2>
                                <form className="contact-login-action">
                                    <div className="form-group mb-3">
                                        <label className="txt-label-mt">Email</label>
                                        <input
                                            type="text"
                                            placeholder='Ex abc@email.com'
                                            className="form-control input-item-fill"
                                            onChange={(event) => setEmail(event.target.value)} value={email}
                                        />
                                    </div>
                                    <div className="form-group mb-3">
                                        <label className="txt-label-mt">Password</label>
                                        <input
                                            type={showPassword ? "text" : "password"}
                                            placeholder='**********'
                                            className="form-control input-item-fill"
                                            onChange={(event) => setPassword(event.target.value)} value={password}
                                        />
                                    </div>
                                    <div className="form-group mb-4">
                                        <div className="row">
                                            <div className="col-12 col-md-6">
                                                <div className="" style={{ paddingLeft: '20px' }}>
                                                    <button
                                                        type="button"
                                                        className="btn btn-linkfoget p-0"
                                                    >
                                                        <input
                                                            className="form-check-input"
                                                            type="checkbox"
                                                            name="remember"
                                                        />{" "}
                                                        Remember me
                                                    </button>
                                                </div>
                                            </div>
                                            <div className="col-12 col-md-6">
                                                <div className="text-end">
                                                    <a className="forgot-pwd">
                                                        Forgot password?
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="form-group mb-4">
                                        <button
                                            type="button"
                                            className="btn btn-primary btn-lg btn-block"
                                            onClick={handleLogin}
                                        >
                                            Login
                                        </button>
                                        <button
                                            type="button"
                                            className="btn btn-primary btn-lg btn-block"
                                            onClick={handleLoginWithAd}
                                        >
                                            Single Sign On
                                        </button>
                                    </div>

                                    <div className="form-group text-center">
                                        <span className="account-an-txt">
                                            Don't have an account?
                                        </span>
                                        <button
                                            type="button"
                                            className="button-signup"
                                        >
                                            Sign Up
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}

export default LoginView;
