import React, { useState, useEffect } from "react";
import { Card, Container, Row, Col, Button } from "react-bootstrap";
import "./impact.css";
import binoculars from "../../assets/images/Binoculars.svg";
import coinsIcon from "../../assets/images/Coins.svg";
import FirstAidIcon from "../../assets/images/FirstAid.svg";
import globalicon from "../../assets/images/GlobeHemisphereEast.svg";
import worldIcon from "../../assets/images/world.svg";
import drugIcon from "../../assets/images/Pill.svg";
import handshakeIcon from "../../assets/images/Handshake.svg";
import axios from "axios";
import { RFPdataEndpoint, RFPSearchEndpoint, RFPTileEndpoint } from "../../common/api-config"; // Assuming you have defined RFPTileEndpoint in api-config
import ImpactDetail1 from "../ImpactDetail/impactDetail1";
import DOMPurify from 'dompurify';

const Impacts1 = ({ onCardClick }) => {
  const [cards, setCards] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [searchResults, setSearchResults] = useState([]);
  const [searchInput, setSearchInput] = useState({
    focus_area: "",
    geographic_scope: "",
    partner: "",
  });
  const [dropdownData, setDropdownData] = useState({
    focus_area: ["Oncology", "Internal Medicine", "I&I", "Hospital", "Rare Disease", "Vaccines", "Other", "Health Equity", "Support for Health Outcomes"],
    partner: [
      "Conquer Cancer, The ASCO Foundation",
      "Bristol-Myers Squibb",
      "International Society for Infectious Diseases",
      "Myovant Sciences",
      "Lilly",
      "Mayo Clinic Global Bridges Oncology",
      "American Cancer Society",
      "The International Society for Infectious Diseases (ISID)",
      "National Comprehensive Cancer Network",
      "Prostate Cancer Foundation",
      "Merck KGaA Darmstadt, Germany and EMD Serono",
      "Global Bridges at Mayo Clinic",
      "Merck KGaA, Darmstadt, Germany and EMD Serono",
      "PROTEUS Consortium",
      "BSAC",
      "Japan Society of Clinical Oncology",
      "Sharing Progress in Cancer Care (SPCC)",
      "Rethink Breast Cancer",
      "Merck KGaA",
      "Mayo Clinic",
      "Lilly and European Pain Federation",
      "International Society of Amyloidosis",
      "Stanford",
      "The Japan College of Rheumatology",
      "EMD Serono and Merck KGaA",
      "The Institute for Healthcare Improvement",
      "International Myeloma Foundation",
      "Skin of Color Society",
      "The International Society of Amyloidosis (ISA)",
      "International Coalition of Organizations Supporting Endocrine Patients (ICOSEP)",
      "British Medical Journal (BMJ)",
      "American Society of Gene + Cell Therapy",
      "Merck Serono",
      "National Medical Association",
      "Japan Society of Clinical Oncology",
      "Crohn's & Colitis Foundation",
      "National Comprehensive Cancer Network and EMD Serono",
      "RCNi (The Royal College of Nursing)",
      "American College of Allergy, Asthma & Immunology (ACAAI)",
      "ASTRO and Myovant Sciences",
      "Bladder Cancer Canada and EMD Serono",
      "Versus Arthritis",
      "Prostate Cancer Foundation and Myovant Sciences",
      "Lung Health Foundation, Lung Cancer Canada, Quebec Lung Association",
      "National Comprehensive Cancer Network and Myovant",
      "UK Sepsis Trust",
      "Association of Community Cancer Centers (ACCC)",
      "International Pharmaceutical Federation (FIP)",
      "Amyloidosis Foundation",
      "Japanese Dermatological Association",
      "The Japanese Society for Pediatric Endocrinology",
      "BMS-Pfizer Alliance",
      "Duke University",
      "Japanese Society for Inflammatory Bowel Disease",
      "Japanese Society of Chemotherapy",
      "GE Healthcare",
      "RCNi (Royal College of Nursing)",
      "The Japanese Society for Pediatric Endocrinology",
      "The Japan Spondyloarthritis Society",
      "Bristol Myers Squibb",
    ],// Add your partner options here
    geographic_scope: [
     "United States",
"Latin America",
"Chile, Colombia, Argentina and Brazil",
"United Kingdom",
"Global (excluding the US)",
"Japan",
"United States, Canada, Japan, Europe",
"EM Asia Markets (Hong Kong, India, Indonesia, Malaysia, Pakistan, Philippines, Singapore, Taiwan, Thailand, Vietnam)",
"Asia (excluding Japan and Korea), Latin America, the Middle East & Africa",
"European countries",
"Global",
"Global excluding US",
"Africa, Middle East, Latin America, and Asia Pacific Countries (except China, Japan, South Korea, Australia, and New Zealand)",
"United States, Canada, Andorra, Austria, Belgium, Denmark, Finland, France, Germany, Greece, Iceland, Ireland, Italy, Liechtenstein, Luxembourg, Malta, Monaco, Netherlands, Norway, Portugal, San Marino, Spain, Sweden, Switzerland, United Kingdom",
"Europe",
"Canada",
"United States, Canada, France, Germany, Italy, Spain, Switzerland, United Kingdom, Japan, Brazil, Argentina",
"Senegal",
"Global (excluding U.S.)",
"United States, Canada, France, Germany, Italy, Spain, Switzerland, UK, Japan, Brazil, Argentina",
"French-speaking African Countries",
"United States, Canada",
"Global (except United States)",
"US",
"Italy, Spain, Japan, Australia, United Kingdom",
"Latin America, Africa & Middle East, Turkey, Russia & CauCar",
"Austria, Belgium, Cyprus, Denmark, Finland, France, Germany, Greece, Iceland, Ireland, Italy, Lichtenstein, Luxembourg, Netherlands, Norway, Portugal, Spain, Sweden, Switzerland, United Kingdom",
"Global (not including the US)",
"Select European countries, Canada, South Korea, Australia, New Zealand, Israel",
"US and Canada",
"Argentina, Brazil, India, Singapore, Saudi Arabia, UAE, Turkey, Russia",
"Ghana, Senegal, Uganda, Zimbabwe, Ethiopia, Mozambique, Malawi, Rwanda, Zambia, Tanzania, Democratic Republic of Congo, Mali",
"Africa Middle East, Asia-Pacific, Latin America",
"Africa and Middle East",
"Middle East and North Africa (MENA) - Iraq, Jordan, Lebanon, Egypt, Saudi Arabia, Oman, Bahrain, Qatar, UAE, Kuwait, Libya, Tunisia, Algeria, Morocco",
"Africa and Middle East: Lebanon, Egypt, Algeria, Tunisia; Asia: Philippines, Vietnam, Thailand, Indonesia",
"China",
"Africa",
"Australia, New Zealand, India, Japan, Singapore, Taiwan",
"Sub-Saharan Africa",
"USA, Canada, Europe ",
"Hong Kong, India, Indonesia, Malaysia, Pakistan, Philippines, Singapore, Taiwan, Thailand, Vietnam",
"Europe, Canada, Japan, South Korea, Australia, New Zealand, Israel",
"Latin America (LATAM): Argentina, Brazil, Mexico, Colombia Middle East: Saudi Arabia, United Arab Emirates, Kuwait, Qatar, Lebanon, Algeria, and Iraq",
"Saudi Arabia, Egypt, South Africa and Gulf Markets (UAE, Kuwait, Qatar, Bahrain, Oman)",
"Brazil, Turkey, India, Argentina, Singapore, Taiwan, and Saudi Arabia.",
"Asia, Africa, Latin America, and Middle East",
"USA",
"United States, Canada, and Western Europe",
"Europe, Australia, New Zealand, Korea and Japan",
"USA, Europe, Japan, South Korea, Australia and New Zealand",
"United States, Canada, Austria, France, Germany, Italy, Spain, Switzerland, United Kingdom, Netherlands, Belgium, Portugal, Greece, Denmark, Norway, Sweden, Finland and Ireland",
"Spain",
"Italy",
"Western Europe, Canada, Japan",
"The Republic of Ireland",
"UK",
"India",
"Europe, Israel, Turkey, Russia, Canada, Australia, New Zealand and Japan",
"Africa, Asia (excluding Japan and Korea), Latin America and the Middle East",
"China, Taiwan, Malaysia and Thailand",
"Europe (except Germany), Israel, Turkey, Russia, Australia, New Zealand, Japan and South Korea",
"United States, France, Germany, Italy, Spain, United Kingdom",
"United States, Canada, Europe, South Korea, Japan, China, New Zealand, Australia",
"Senegal, Malawi, Rwanda",
"Kazakhstan",
"Canada only",
"South East Asia (Indonesia, Malaysia, Burma (Myanmar), Philippines, Singapore, Thailand, Vietnam, Papua New Guinea, Solomon Islands, Hong Kong, Taiwan)",
"Australia",
"Europe, Canada, Australia, New Zealand, Japan, Israel and Turkey",
"Kenya, Kingdom of Eswatini (formerly Swaziland), and/or Lesotho",
"Global (excluding United States)",
"USA (global learning potential OK)",
"United States, Canada, Europe",
"Global (ex-US)",
"United States, France, Germany, Italy, Spain, UK",
"Austria, Belgium, Canada, Denmark, Finland, France, Germany, Greece, Ireland, Italy, Liechtenstein, Luxembourg, Mexico, Monaco, Netherlands, Norway, Portugal, Spain, Sweden, Switzerland, United States, United Kingdom",
"France, Germany",
"Low-income countries in sub-Saharan Africa",
"Latin America, Africa, Middle East, and Asia Pacific Countries (except China, Japan, South Korea, Australia, and New Zealand)", 
"Latin America, Africa, Middle East and Asia-Pacific*(except China)",
"Asia, AfME, Latin America and China",
"North America and Europe",
"Africa-Middle East, Asia Pacific, China and Latin America",
"Africa, Asia, Middle East and Latin America",
"please refer to the RFP as the country list exceeds to the character limitation",
"UK, France, Spain, Italy, Germany, Japan",
"Global except USA",
"United States ",
"Emerging Markets (Asia, Latin America, Africa, and Middle East)", 
"Global (not including the United States)",
"United States and Europe",
"Latin America, Africa, Middle East and Asia-Pacific (except South Korea, Japan, China, New Zealand & Australia).",
"Global except for the United States",
"Hong Kong, Indonesia, Malaysia, Philippines, Taiwan, Thailand, Singapore, Vietnam",
"Portugal",
"United States, Western Europe, Japan, Singapore, Canada, Brazil",
"Canada, France, Germany, Italy, Japan, Spain, USA, United Kingdom",
"Low-income countries and/or under resourced settings in middle-income countries where limited capital and human resources create barriers to meeting outpatient antimicrobial prescribing needs of the population being served",
"Asia, Africa, Middle East, Latin America",
"Argentina, Brazil, Chile, Colombia and Mexico",
"Global, excluding US",
"Israel"
    ], // Add your location options here
  });
  const [filteredSuggestions, setFilteredSuggestions] = useState({
    focus_area: [],
    partner: [],
    geographic_scope: [],
  });
  const [selectedCard, setSelectedCard] = useState(null);
  const [showDetail, setShowDetail] = useState(false);
  const cardsPerPage = 4;
  const [isExpanded, setIsExpanded] = useState({
    OBJECTIVE: false
  });

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(RFPdataEndpoint());
        setCards(response.data.records);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, []);

  const [activeButton, setActiveButton] = useState("yourGrants");

  const handleButtonClick = (buttonName) => {
    setActiveButton(buttonName);
  };

  const handleSearchInputChange = (event, field) => {
    const value = event.target.value;
    setSearchInput({
      ...searchInput,
      [field]: value,
    });
    setFilteredSuggestions({
      ...filteredSuggestions,
      [field]: dropdownData[field].filter((item) => item.toLowerCase().includes(value.toLowerCase())),
    });
  };

  const handleSuggestionClick = (field, suggestion) => {
    setSearchInput({
      ...searchInput,
      [field]: suggestion,
    });
    setFilteredSuggestions({
      ...filteredSuggestions,
      [field]: [],
    });
  };

  const handleSearch = async () => {
    const { focus_area, geographic_scope, partner } = searchInput;
    try {
      const response = await axios.post(RFPSearchEndpoint(), {
        focus_area: focus_area.trim() !== "" ? focus_area : undefined,
        geographic_scope: geographic_scope.trim() !== "" ? geographic_scope : undefined,
        partner: partner.trim() !== "" ? partner : undefined,
      });
      setSearchResults(response.data.records);

      if (response.data.records.length === 0) {
        alert("No matching records found");
      }

      // Clear the input values
      setSearchInput({
        focus_area: "",
        geographic_scope: "",
        partner: "",
      });
    } catch (error) {
      console.error("Error searching data:", error);
    }
  };

  const indexOfLastCard = currentPage * cardsPerPage;
  const indexOfFirstCard = indexOfLastCard - cardsPerPage;
  const currentCardsFiltered = searchResults.length > 0
  ? searchResults.filter(card => card.BUDGET_AMOUNT !== null && card.BUDGET_AMOUNT !== "null" && card.BUDGET_AMOUNT !== "Not Available")
  : cards.filter(card => card.BUDGET_AMOUNT !== null && card.BUDGET_AMOUNT !== "null" && card.BUDGET_AMOUNT !== "Not Available");

// Slice cards for pagination
const currentCards = currentCardsFiltered.slice(indexOfFirstCard, indexOfLastCard);

  const totalPages = Math.ceil((currentCardsFiltered.length > 0 ? currentCardsFiltered.length : cards.length) / cardsPerPage);

  const handleNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  const handlePrevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const fetchImpactDetails = async (title) => {
    try {
      const response = await axios.post(RFPTileEndpoint(), { title });
      setSelectedCard(response.data.records); // Assuming response is an array
      setShowDetail(true);
    } catch (error) {
      console.error("Error fetching card details:", error);
    }
  };

  const formatText = (text) => {
    if (!text) return '';
    return text
      .replace(/\n\n/g, '<br/> ')
      .replace(/\n/g, ' <br/>')
      .replace(/\t/g, ' &nbsp;&nbsp;&nbsp;');
  };




  if (showDetail && selectedCard) {
    return (
      <ImpactDetail1
        selectedCard={selectedCard}
      
        cards={cards}
      />
    );
  }

  return (
    <>
   
     <div className="Impact-content">
     <Col xs={12} md={6} className="p-2">
        <div>
          <span
            className={`btn ${activeButton === "yourGrants" ? "btn-add-Grant-actives" : "btn-add-projects"}`}
            onClick={() => handleButtonClick("yourGrants")}
          >
            {activeButton === "yourGrants" ? <div className="dot"></div> : <></>}
            Request for Proposal
          </span>
          <span
            className={`btn ${activeButton === "pendingApprovals" ? "btn-add-Grant-actives" : "btn-add-projects"}`}
            onClick={() => handleButtonClick("pendingApprovals")}
          >
            {activeButton === "pendingApprovals" ? <div className="dot"></div> : <></>}
            Non Request for Proposal
          </span>
        </div>
      </Col>
      <Card className="card-box-area mb-3 mt-3">
        <Card.Body className="card-content-wap d-flex justify-content-between p-2">
          <Col xs={12} md={4} lg={4}>
            <div>
              <Card.Text>
                <h6>
                  <img
                    src={worldIcon}
                    className="p-1"
                    width={"35px"}
                    alt="location icon"
                  />
                  Explore Location
                </h6>
              </Card.Text>
              <div className="search-containers p-2">
                <div className="search-wrapper">
                  <input
                    className="col-12 col-md-12 col-lg-12 impact-search-input no-focus-outline"
                    type="text"
                    placeholder="Search"
                    value={searchInput.geographic_scope}
                    onChange={(event) => handleSearchInputChange(event, 'geographic_scope')}
                    onKeyDown={(event) => {
                      if (event.key === 'Enter') {
                        handleSearch();
                      }
                    }}
                  />
                  {filteredSuggestions.geographic_scope.length > 0 && (
                    <ul className="suggestions-list">
                      {filteredSuggestions.geographic_scope.map((suggestion, index) => (
                        <li key={index} onClick={() => handleSuggestionClick("geographic_scope", suggestion)}>
                          {suggestion}
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
                <div className="dropdown-icon">&#x25BC;</div>
              </div>
            </div>
          </Col>
          <Col xs={12} md={4} lg={4}>
            <div>
              <Card.Text>
                <h6>
                  <img
                    src={drugIcon}
                    className="p-1"
                    width={"35px"}
                    alt="drug icon"
                  />
                  Disease
                </h6>
              </Card.Text>
              <div className="search-containers p-2">
                <div className="search-wrapper">
                  <input
                    className="col-12 col-md-12 col-lg-12 impact-search-input no-focus-outline"
                    type="text"
                    placeholder="Search"
                    value={searchInput.focus_area}
                    onChange={(event) => handleSearchInputChange(event, 'focus_area')}
                    onKeyDown={(event) => {
                      if (event.key === 'Enter') {
                        handleSearch();
                      }
                    }}
                  />
                  {filteredSuggestions.focus_area.length > 0 && (
                    <ul className="suggestions-list">
                      {filteredSuggestions.focus_area.map((suggestion, index) => (
                        <li key={index} onClick={() => handleSuggestionClick("focus_area", suggestion)}>
                          {suggestion}
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
                <div className="dropdown-icon">&#x25BC;</div>
              </div>
            </div>
          </Col>
          <Col xs={12} md={4} lg={4}>
            <div>
              <Card.Text>
                <h6>
                  <img
                    src={handshakeIcon}
                    className="p-1"
                    width={"35px"}
                    alt="partner icon"
                  />
                  Partner
                </h6>
              </Card.Text>
              <div className="search-containers p-2">
                <div className="search-wrapper">
                  <input
                    className="col-12 col-md-12 col-lg-12 impact-search-input no-focus-outline"
                    type="text"
                    placeholder="Search"
                    value={searchInput.partner}
                    onChange={(event) => handleSearchInputChange(event, 'partner')}
                    onKeyDown={(event) => {
                      if (event.key === 'Enter') {
                        handleSearch();
                      }
                    }}
                  />
                  {filteredSuggestions.partner.length > 0 && (
                    <ul className="suggestions-list">
                      {filteredSuggestions.partner.map((suggestion, index) => (
                        <li key={index} onClick={() => handleSuggestionClick("partner", suggestion)}>
                          {suggestion}
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
                <div className="dropdown-icon">&#x25BC;</div>
              </div>
            </div>
          </Col>
        </Card.Body>
      </Card>

      <Row className="rfp-row">
        {currentCards.map((card, index) => (
          
          <div className="card-container" key={index}>
            <div className="card-box" onClick={() => fetchImpactDetails(card.TITLE)}>
              <div className="card-header d-flex justify-content-between align-items-center">
              <h5 className="rfp-title" style={{ cursor: 'pointer' }}>{card.TITLE}</h5>
                <span className="item-navtab-menu rfp-partner">
                  {card.PARTNER ? card.PARTNER : "N/A"}
                </span>
              </div>
              <div className="card-body">
                <div className="card-section d-flex">
                  <div className="card-item">
                    <img src={binoculars} alt="Grant Type Icon" />
                    <div className="pl-2">
                      <div className="card-text-heading">Grant Type</div>
                      <div className="card-text-ans">{card["GRANT TYPE"]?card["GRANT TYPE"]:"N/A"}</div>
                    </div>
                  </div>
                  <div className="card-item">
                    <img src={coinsIcon} alt="Budget Amount Icon" />
                    <div className="pl-2">
                      <div className="card-text-heading">Budget Amount</div>
                      <div className="card-text-ans">${card.BUDGET_AMOUNT?card.BUDGET_AMOUNT:"null"}</div>
                 </div>
               </div>
             </div>
             <div className="card-section d-flex">
               <div className="card-item">
                 <img src={FirstAidIcon} alt="Clinical Area Icon" />
                 <div className="pl-2">
                   <div className="card-text-heading">Clinical Area</div>
                   <div className="card-text-ans">{card["FOCUS AREA"]?card["FOCUS AREA"]:"N/A"}</div>
                 </div>
               </div>
               <div className="card-item">
                 <img src={globalicon} alt="Geography Icon" />
                 <div className="pl-2">
                   <div className="card-text-heading">Geographic Scope</div>
                   <div className="card-text-ans">{card["GEOGRAPHIC SCOPE"] ? card["GEOGRAPHIC SCOPE"]:"N/A"}</div>
                 </div>
               </div>
             </div>
             <div className="card-objectives">
               <div className="card-sub-container">
                 <div className="card-sub-header">Objectives</div>
               <p className="impact-objective-text">
                 <div className="card-text card-objective"
  dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(card.OBJECTIVE.replace(/\n/g, '<br/>')) }}
></div>
                    </p>
                 </div>
              
             </div>
             <div className="card-footer d-flex justify-content-between align-items-center">
               <div className="footer-item d-flex justify-content-between align-items-center">
                 <p className="text-muted">Approval Rate : <span>{card.APPROVAL_RATE ? card.APPROVAL_RATE : "N/A"}%</span></p>
                
               </div>
               <div className="footer-item d-flex justify-content-between align-items-center">
                 <p className="text-muted">Publications : <span>{card.TOTAL_PUBLICATION?card.TOTAL_PUBLICATION : "N/A"}</span></p>
                 
               </div>
             </div>
           </div>
         </div>
       </div>
          
        ))}
      </Row>
      <div className="pagination-container">
        <Button
          className="pagination-button"
          onClick={handlePrevPage}
          disabled={currentPage === 1}
        >
          Prev
        </Button>
        <span className="pagination-info">
          &nbsp; {currentPage} / {totalPages} &nbsp;
        </span>
        <Button
          className="pagination-button"
          onClick={handleNextPage}
          disabled={currentPage === totalPages}
        >
          Next
        </Button>
      </div>
     </div>
    
    </>
  );
};

export default Impacts1;