// GrantsView.js

import React from 'react';
import TopbarNew from "../../common/TopbarNew";
import Sidebar from "../../common/Sidebar";
const GrantsView = () => {
  return (
    <div className="homepage-container">
    <TopbarNew />
    
    <div className="sidebar-and-content">
      <Sidebar />

      <div className="homepage-content">
    <div className="grants-view-container">
      <h1 className="grant-view-heading">Grant View</h1>
    </div>
    </div>
    </div>
    </div>
  );
}

export default GrantsView;
