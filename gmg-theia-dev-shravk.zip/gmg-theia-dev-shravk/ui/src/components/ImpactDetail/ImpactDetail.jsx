import React, { useState, useEffect } from 'react';
import Container from 'react-bootstrap/Container';
import './impactDetails.css';
import ArrowLeft from '../../assets/images/ArrowLeft.svg';
import ReactApexChart from 'react-apexcharts';
import Table from 'react-bootstrap/Table';
import downArrow from '../../assets/images/arrow-down.svg';
import Impacts1 from '../Impact/impact1';
import GrantTile from './GrantTile';
import TopbarNew from '../../common/TopbarNew';
import Sidebar from '../../common/Sidebar';
const ImpactDetails = ({ selectedCard }) => {
  const [showImpact, setShowImpact] = useState(true); // State to control visibility of Impact or ImpactDetails
  const [activeTab, setActiveTab] = useState('newest'); // State to track active tab

  const hasData = Array.isArray(selectedCard) && selectedCard.length > 0;

  useEffect(() => {
    console.log('selectedCard:', selectedCard[0]?.NEWEST_OUTCOMES);
  }, [selectedCard]);

  const series = hasData ? selectedCard.map(record => parseFloat(record.APPROVED_AMOUNT)) : [];

  const options = {
    legend: {
      position: 'right',
      horizontalAlign: 'center',
    },
    chart: {
      type: 'donut',
    },
    plotOptions: {
      pie: {
        startAngle: -90,
        endAngle: 270,
        offsetY: 0,
        offsetX: 0,
        donut: {
          size: '65%',
        },
      },
    },
    dataLabels: {
      enabled: false,
    },
    fill: {
      type: 'gradient',
    },
    labels: hasData ? selectedCard.map(record => record.REQUEST_ID) : [],
    responsive: [
      {
        breakpoint: 480,
        options: {
          chart: {},
          legend: {
            position: 'bottom',
          },
        },
      },
    ],
    tooltip: {
      enabled: true,
      y: {
        formatter: function (val) {
          return "$" + val.toFixed(2);
        }
      },
      formatter: function (val, opts) {
        const index = opts.seriesIndex;
        const requestId = selectedCard[index].REQUEST_ID;
        const approvedAmount = selectedCard[index].APPROVED_AMOUNT;
        return `${val} - Request ID: ${requestId}, Approved Amount: $${approvedAmount}`;
      }
    },
    title: {
      text: hasData ? `$${series.reduce((total, amount) => total + amount, 0).toFixed(2)}` : '',
      align: 'center',
      margin: 20,
      style: {
        fontSize: '12px',
        fontWeight: 'bold',
        color: '#333',
      }
    }
  };

  const handleBack = () => {
    setShowImpact(true); // Set showImpact to true to show the Impact page
  };

  const formatText = (text) => {
    if (!text) return '';
    return text
      .replace(/\n\n/g, '<br /><br />')
      .replace(/\n/g, '<br />')
      .replace(/\t/g, '&nbsp;&nbsp;&nbsp;&nbsp;');
  };

  const tabContent = {
    newest: selectedCard[0]?.NEWEST_OUTCOMES,
    differ: selectedCard[0]?.HOW_DO_THESE_DIFFER,
    impact: selectedCard[0]?.HINTS_OF_HIGH_IMPACT,
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'newest':
        return (
          <p className='paragraph-text' dangerouslySetInnerHTML={{ __html: formatText(tabContent.newest) }}></p>
        );
      case 'differ':
        return (
          <p className='paragraph-text' dangerouslySetInnerHTML={{ __html: formatText(tabContent.differ) }}></p>
        );
      case 'impact':
        return (
          <p className='paragraph-text' dangerouslySetInnerHTML={{ __html: formatText(tabContent.impact) }}></p>
        );
      default:
        return null;
    }
  };

  return (
    <div className="homepage-container">
    <TopbarNew />
    <div className="sidebar-and-content">
      <Sidebar />
      <div className="homepage-content">
    <div className='impactDetails-container'>
      {showImpact ? (
        <div className="layout-wrapper impact-wrapper-body d-flex">
          <div className="impact-content py-3">
            <div className='page-content'>
              <Container fluid>
                <div className='content-waplay'>
                  <div className='content-box'>
                    <div style={{ display: 'flex', flexDirection: 'row', margin: '10px 0px' }}>
                      <img src={ArrowLeft} className='image-space' onClick={() => setShowImpact(false)} alt='Back' />
                      <div>
                        <h1 className='title-text'>{hasData && selectedCard[0]?.TITLE}</h1>
                      </div>
                    </div>
                    <hr />
                    <div className='impact-main-container'>
                      <h1 className='header-text'>Gen AI Summary</h1>
                      <ul className="nav nav-tabs">
                        <li className="nav-item">
                          <a className={`nav-link ${activeTab === 'newest' ? 'active' : ''}`} onClick={() => setActiveTab('newest')}>Newest Outcomes</a>
                        </li>
                        <li className="nav-item">
                          <a className={`nav-link ${activeTab === 'differ' ? 'active' : ''}`} onClick={() => setActiveTab('differ')}>How do these differ?</a>
                        </li>
                        <li className="nav-item">
                          <a className={`nav-link ${activeTab === 'impact' ? 'active' : ''}`} onClick={() => setActiveTab('impact')}>Hints of High Impact</a>
                        </li>
                      </ul>
                      <div className='tab-content'>
                        {renderTabContent()}
                      </div>
                    </div>
                    <div style={{ margin: '35px 0px', display: 'flex', flexDirection: 'row' }}>
                      <div className='cost-metrics fixed-height scrollable-content' style={{ marginRight: '20px', width: '40%' }}>
                        <h1 className='chart-heading'>Cost Metrics</h1>
                        <hr />
                        {hasData && (
                          <ReactApexChart options={options} series={series} type='donut' />
                        )}
                      </div>
                      <div className='card-publications fixed-height scrollable-content' style={{ width: '60%' }}>
                        <h1 className='chart-heading'>Publications</h1>
                        <hr />
                        <Table responsive className='table-lits-wap-pground mb-0'>
                          <thead className='custom-table-header'>
                            <tr>
                              <th className='table-header-text' style={{ color: '#667085' }}>
                                Name of Publication<img src={downArrow} alt='downArrow' />
                              </th>
                              <th className='table-header-text' style={{ color: '#667085' }}>
                                Journal <img src={downArrow} alt='downArrow' />
                              </th>
                              <th className='table-header-text' style={{ color: '#667085' }}>
                                Description <img src={downArrow} alt='downArrow' />
                              </th>
                              <th className='table-header-text' style={{ color: '#667085' }}>
                                Published Date<img src={downArrow} alt='downArrow' />
                              </th>
                            </tr>
                          </thead>
                          <tbody className='tbody-element--wp'>
                            {hasData ? selectedCard.map(record => (
                              <tr key={record.REQUEST_ID}>
                                <td className='table-body-text'>{record.PROJECT_TITLE}</td>
                                <td className='table-body-text'>{record.JOURNAL_TARGET ? record.JOURNAL_TARGET : " N/A"}</td>
                                <td className='table-body-text'>{record.PUBLICATION_DESCRIPTION ? record.PUBLICATION_DESCRIPTION : "N/A"}</td>
                                <td className='table-body-text'>{record.PUBLICATION_DATE ? record.PUBLICATION_DATE : "N/A"}</td>
                              </tr>
                            )) : (
                              <tr>
                                <td colSpan="4" className='table-body-text'>No publications available</td>
                              </tr>
                            )}
                          </tbody>
                        </Table>
                      </div>
                    </div>
                    <div className='impact-tiles'>
                      <GrantTile selectedCard={selectedCard} />
                    </div>
                  </div>
                </div>
              </Container>
            </div>
          </div>
        </div>
      ) : (
        <div className="impact-page">
          <Impacts1 />
        </div>
      )}
    </div></div></div></div>
  );
}

export default ImpactDetails;
