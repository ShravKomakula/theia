import React, { useState } from "react";
import "./GrantTile.css"; // Your CSS file for styling
import totalpayment from "../../assets/totalpayment.svg";
import pendingpayment from "../../assets/pendingpayment.svg";
import method from "../../assets/method.svg";
import disease from "../../assets/disease.svg";
import drug from "../../assets/drug.svg";
import DOMPurify from "dompurify";
import duration from "../../assets/durations.svg";
import { FaArrowAltCircleRight,FaArrowAltCircleLeft } from "react-icons/fa";
import location from "../../assets/location.svg";
import { IoIosArrowDropdownCircle } from "react-icons/io";
import { GoDotFill } from "react-icons/go";
import { LuDot } from "react-icons/lu";
import pending from "../../assets/pending.svg";
import success from "../../assets/success.svg";
import error from '../../assets/error.svg';
import ProgressBar from 'react-bootstrap/ProgressBar';
import 'bootstrap/dist/css/bootstrap.min.css'; // Import Bootstrap CSS

// Define a function to get the background color based on the status
const getStatusColor = (status) => {
  switch (status) {
    case 'Pending':
      return '#FFC000';
    case 'Rejected':
    case 'Canceled':
    case 'Terminated – Post Approval':
      return '#FFA18B';
    case 'Review':
    case 'Sent to Org':
    case 'Other contracting status':
      return '#CCFF99';
    case 'Approved':
      return '#C5E0B4';
    case 'Completed':
      return '#3366FF';
    default:
      return '#FFFFFF'; // default color if status doesn't match any case
  }
};
const GrantTile = ({ status,selectedCard }) => {
  // Get the background color for the current status
  const backgroundColor = getStatusColor(status);

  console.log("GrantTile selectedCard:", selectedCard); // Check data received
  // Rest of the component code

  



  const [expandedCard, setExpandedCard] = useState(null);
  const toggleCard = (index) => {
    setExpandedCard(expandedCard === index ? null : index);
  };
  const [loadingFiles, setLoadingFiles] = useState({});
  const [dropdownVisible, setDropdownVisible] = useState({}); // Track dropdown visibility per record

  const [isExpanded, setIsExpanded] = useState({
    PROJECT_OUTCOME_SUMMARY: false
  });
  const formatText = (text) => {
    if (!text) return '';
    return text
      .replace(/\n\n/g, '<br />')
      .replace(/\n/g, '<br />')
      .replace(/\t/g, '&nbsp;&nbsp;&nbsp;&nbsp;');
  };

  // Function to toggle the text expansion
  const toggleTextExpansion = (field) => {
    setIsExpanded((prevState) => ({
      ...prevState,
      [field]: !prevState[field],
    }));
  };
  const formatDate = (dateString) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'numeric' });
  };
  const handleOutcomeReportClick = async (document_Key, fileIndex, recordIndex) => {
    console.log(document_Key, "clicked filename");

    if (!document_Key) {
      alert("No outcome report available");
      return;
    }
    setLoadingFiles((prev) => ({
      ...prev,
      [`${recordIndex}-${fileIndex}`]: true
    }));
    try {
      // Extracting the filename from the document key
      const filename = document_Key.replace("s3://gmg-llm-poc/", "");

      const response = await fetch(
        `http://10.11.185.89:8010/outcomereport/${filename}`,
        {
          method: "GET",
          headers: {
            Accept:
              "application/pdf, application/vnd.openxmlformats-officedocument.wordprocessingml.document, application/vnd.openxmlformats-officedocument.presentationml.presentation, application/msword, application/vnd.ms-excel, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, text/csv",
          },
        }
      );

      if (response.ok) {
        const contentType = response.headers.get("content-type");

        const blob = await response.blob();
        const url = URL.createObjectURL(blob);

        // Check if the content type indicates a document type
        if (
          contentType.includes("application/pdf") ||
          contentType.includes(
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
          ) ||
          contentType.includes(
            "application/vnd.openxmlformats-officedocument.presentationml.presentation"
          ) ||
          contentType.includes("application/msword") ||
          contentType.includes("application/vnd.ms-excel") ||
          contentType.includes(
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
          ) ||
          contentType.includes("text/csv") ||
          contentType.includes("application/vnd.ms-powerpoint")
        ) {
          // Render the document in a new tab
          window.open(url, "_blank");
        } else if (contentType.includes("text/html")) {
          // Show the HTML content in a new tab
          window.open(url, "_blank");
        } else {
          console.error("Unsupported document type:", contentType);
          alert("Unsupported document type");
        }
      } else {
        console.error("Error fetching document URL:", response.status);
        alert("No outcome report available");
      }
    } catch (error) {
      console.error("Error:", error);
      alert("An error occurred while fetching the outcome report");
    } finally {
      setTimeout(() => {
        // Reset loading for the specific file
        setLoadingFiles((prev) => ({
          ...prev,
          [`${recordIndex}-${fileIndex}`]: false
        }));
        /*    alert(`Outcome Report loaded successfully`); */
      }, 2000);
    }
  };
  const toggleDropdown = (recordIndex) => {
    setDropdownVisible((prev) => ({
      ...prev,
      [recordIndex]: !prev[recordIndex]
    }));
  };
  const renderText = (text, field) => {
    const formattedText = formatText(text);
    const isTextExpanded = isExpanded[field];
    const buttonText = isTextExpanded ? 'Show Less' : 'Show More';
    const numberOfLines = 3; // Number of lines to display initially

    const toggleClass = isTextExpanded ? 'expanded' : 'collapsed';

    // Split text into lines and decide whether to show more/less
    const lines = formattedText.split('<br />');
    const displayText = isTextExpanded ? formattedText : lines.slice(0, numberOfLines).join('<br />');

    return (
      <div>
        <p
          className={`paragraph-text ${toggleClass}`}
          dangerouslySetInnerHTML={{ __html: displayText }}
        ></p>
        {lines.length > numberOfLines && (
          <button onClick={() => toggleTextExpansion(field)} className="show-more-button">
            {buttonText}
          </button>
        )}
      </div>
    );
  };

  return (
    <>
      <div className="tile-container">
        {selectedCard.length === 0 ? (
          <div className="no-data-message">No data available</div>
        ) : (
          selectedCard.map((item, index) => {
            const currentValue = item[22] || item.TOTAL_SUBJECT_ENROLLMENT || 'null';
            const now = (parseFloat(currentValue) / 10000) * 100; // Adjust max value as necessary

            // Determine the variant based on the condition
            const variant = currentValue ? "primary" : "secondary";
            // Split S3FILENAME into an array if it's a string
            const filenames = typeof item.S3FILENAME === 'string'
              ? item.S3FILENAME.split(',').filter(Boolean)
              : [];

            return (
              <div
                key={index}
            className="card"
            style={{
              width: "100%",
              padding: "10px",
              borderRadius: "10px",
              border: "none",
              marginBottom: "20px",
            }}
          >
          
            <div className="card-body tile-body">
              {/* 1st row */}
              <div className="row align-items-center">
                <div className="col-1 logo">
                
                    <img src={item.LOGO_URL} alt="Logo" style={{ width: "100%" }} />
               
                </div>
                <div className="col-6 project-title">
                  {/* Project Title */}
                  <p>
                    {item.PROJECT_TITLE}<br />
                 <span className="text-darkgrey"> #{item.REQUEST_ID}</span><LuDot size={10} /><span className="org-name">Organization - <span className="org-value">{item.ORGANIZATION_NAME}</span></span>
                  </p>
                </div>
                <div className="col-2 location">
               
  <p>
    <img
      src={location}
      alt="location"
      style={{ width: "20px", marginRight: "5px" }}
    />
   
   <span className="text-darkgrey">{item.CITY}&nbsp;,&nbsp;{item.COUNTRY} </span>
   
   
  </p>
</div>
<div className="col-2 status-text" >
                      <p className="grant-status" style={{ backgroundColor: getStatusColor(item.DISPOSITION_GRANT_STATUS || item[37]) }}>
                        {(item.DISPOSITION_GRANT_STATUS === 'Approved' || item[37] === 'Approved') && <img src={success} alt="Approved" style={{ height: '16px' }} />}
                        {(item.DISPOSITION_GRANT_STATUS === 'Completed' || item[37] === 'Completed') && <img src={success} alt="Completed" style={{ height: '16px' }} />}
                        {(item.DISPOSITION_GRANT_STATUS === 'Rejected' || item[37] === 'Rejected') && <img src={error} alt="Rejected" style={{ height: '16px' }} />}
                        {(item.DISPOSITION_GRANT_STATUS === 'Canceled' || item[37] === 'Canceled') && <img src={error} alt="Canceled Icon" style={{ height: '16px' }} />}
                        {(item.DISPOSITION_GRANT_STATUS === 'Terminated – Post Approval' || item[37] === 'Terminated – Post Approval') && <img src={error} alt="Terminated Icon" style={{ height: '16px' }} />}
                        {(item.DISPOSITION_GRANT_STATUS === 'Pending' || item[37] === 'Pending') && <img src={pending} alt="Pending Icon" style={{ height: '16px' }} />}
                        {(item.DISPOSITION_GRANT_STATUS === 'Review' || item[37] === 'Review') && <img src={pending} alt="Review Icon" style={{ height: '16px' }} />}
                        {(item.DISPOSITION_GRANT_STATUS === 'Sent to Org' || item[37] === 'Sent to Org') && <img src={pending} alt="Sent to Org Icon" style={{ height: '16px' }} />}
                        &nbsp;&nbsp;
                        {item.DISPOSITION_GRANT_STATUS || item[37]}
                      </p>

                    </div>


              </div>

              {/* 2nd row */}
           
<div className="row align-items-center secondrow">
  {/* Total Payment */}
  <div className="col-1.5">
    <div className="d-flex align-items-center">
      <img
        src={totalpayment}
        alt="total payment"
        className="tileicon"
      />
      <span>
      <span className="text-grey">Grant Amount:</span> <br />
        ${item.APPROVED_AMOUNT}
      </span>
    </div>
  </div>

  {/* Pending Payment */}
  <div className="col-1.5">
    <div className="d-flex align-items-center">
      <img
        src={pendingpayment}
        alt="pending payment"
        className="tileicon"
      />
      <span>
      <span className="text-grey"> Pending:</span> <br />
        ${item.PAYMENT_REMAINING}
      </span>
    </div>
  </div>

  {/* Method */}
  <div className="col-2">
    <div className="d-flex align-items-center">
      <img src={method} alt="method" className="tileicon" />
      <span>
      <span className="text-grey">Type: </span><br />
      {item.PROPOSAL_TYPE}
      </span>
    </div>
  </div>

  {/* Disease */}
  <div className="col-2">
    <div className="d-flex align-items-center">
      <img src={disease} alt="disease" className="tileicon" />
      <span>
      <span className="text-grey">Disease: </span><br />
        {item.PRIMARY_AREA_OF_INTERST_DISEASE} 
      </span>
    </div>
  </div>

   {/* Drug Name */}
{( item.PROPOSAL_TYPE === 'Research Grant') && (
  <div className="col-1.5">
    <div className="d-flex align-items-center">
      <img src={drug} alt="drug" className="tileicon" />
      
      <span>
      <span className="text-grey">Drug Name: </span><br />
        {item.PRIMARY_PFIZER_DRUG
        }
      </span>
    </div>
  </div>
)}

 

  {/* Duration */}
  <div className="col-2">
    <div className="d-flex align-items-center">
      <img src={duration} alt="duration" className="tileicon" />
      <span>
      <span className="text-grey">Duration: </span><br />
       {item.DURATION}
      </span>
    </div>
  </div>
</div>

              {/* 3rd row */}
              <div className="row align-items-center">
                {/* Study Design */}
                {!(
                  item.PROPOSAL_TYPE === "Medical Education" ||
                  item.PROPOSAL_TYPE === "Quality Improvement" 
               
                ) && (
                  <div className="col-4">
                    <div className="input-group-prepend">
                      <span
                        className="input-group-text spanblock"
                        id="inputGroup-sizing-sm"
                      >
                        Study Design
                      </span>
                      <input
                        type="text"
                        className="form-control custom-input studyinput"
                        aria-label="Small"
                        aria-describedby="inputGroup-sizing-sm"
                        value={item.Study_Design}
                        readOnly
                      />
                    </div>
                  </div>
                )}

                {/* Population */}
                {!(
                  item.PROPOSAL_TYPE === "Medical Education" ||
                  item.PROPOSAL_TYPE === "Quality Improvement"
              
                ) && (
                  <div className="col-3">
                    <div className="input-group-prepend">
                      <span
                        className="input-group-text spanblock"
                        id="inputGroup-sizing-sm"
                      >
                        Population
                      </span>
                      <input
                        type="text"
                        className="form-control custom-input studyinput"
                        aria-label="Small"
                        aria-describedby="inputGroup-sizing-sm"
                        value={item.Population}
                        readOnly
                      />
                    </div>
                  </div>
                )}

                {/* Patients Enrolled */}
                {!(
                  item.PROPOSAL_TYPE === "Medical Education" ||
                  item.PROPOSAL_TYPE === "Quality Improvement" 
                 
                ) && (
                  <div className="col-4">
                    <div className="input-group-prepend">
                      <span
                        className="input-group-text spanblock"
                        id="inputGroup-sizing-sm"
                      >
                        Patients Enrolled
                      </span>
                      <div className="progress-container" >
                              <span className="max-enrollment"  >   {item.LATEST_ENROLLMENT_NUMBER ||item[62] || 'null'}</span>
                              <ProgressBar
                                className="progressbar"
                                now={now}
                                max={100} // Adjust max value as necessary

                                variant={variant}
                              />
                              <span className="max-enrollment">{item.Target_enrollment|| item[72]|| 'null'}</span>
                            </div>
                    </div>
                  </div>
                )}

                {/* Additional fields for specific methods */}
                {(item.PROPOSAL_TYPE === "Medical Education" ||
                  item.PROPOSAL_TYPE === "Quality Improvement" ) && (
                  <>
                    {/* Add your additional fields for Medical Education and Quality Improvement here */}
                    <div className="col-3">
                      {/* Target Learner Group */}
                      <div className="input-group-prepend">
                        <span
                          className="input-group-text spanblock"
                          id="inputGroup-sizing-sm"
                        >
                          Target Learner Group
                        </span>
                        <input
                          type="text"
                          className="form-control custom-input studyinput"
                          aria-label="Small"
                          aria-describedby="inputGroup-sizing-sm"
                          value={item.TARGETED_LEARNER_GROUP}
                          readOnly
                        />
                      </div>
                    </div>
                    <div className="col-3">
                      {/* Specialty */}
                      <div className="input-group-prepend">
                        <span
                          className="input-group-text spanblock"
                          id="inputGroup-sizing-sm"
                        >
                          Specialty
                        </span>
                        <input
                          type="text"
                          className="form-control custom-input studyinput"
                          aria-label="Small"
                          aria-describedby="inputGroup-sizing-sm"
                          value={item.SPECIALITY}
                          readOnly
                        />
                      </div>
                    </div>
                   
                      {/* Target Learners */}
                      <div className="col-4">
                    <div className="input-group-prepend">
                      <span
                        className="input-group-text spanblock"
                        id="inputGroup-sizing-sm"
                      >
                       Target Learners
                      </span>
                      <div className="progress-container" >
                              <span className="max-enrollment"  >   {item.Total_Learners_Reached |item[71]|| 'null'}</span>
                              <ProgressBar
                                className="progressbar"
                                now={now}
                                max={100} // Adjust max value as necessary

                                variant={variant}
                              />
                              <span className="max-enrollment">{item.Target_Learner|| item[33] || 'null'}</span>
                            </div>
                    </div>
                  </div>

                  
                  </>
                )}
              </div>

              {/* 4th row */}
              <div
                className="row align-items-center"
                style={{ paddingTop: "20px" }}
              >
                <div className="col-2 status">
                  {/* Status */}

                  <p>
                    Status Insights : 
                    {item.STATUS_INSIGHT}
                  </p>
                </div>
                <div className="col-2 enrollment">
                  {/* Insight */}

                  <p>
                    Enrollment Insight: 
                    {item.PATIENT_INSIGHT}
                  </p>
                </div>
                <div className="col-2 upcoming">
                  {/* Completed */}
                  <p>
                    Upcoming: {item.NEXT_MILESTONE}
                  </p>
                </div>
                <div className="col-1.5 link">
                      {filenames.length > 0 ? (
                        filenames.length > 1 ? (
                          <div className="dropdown">
                            <button
                              className="btn outcome-report-btn dropdown-toggle"
                              type="button"
                              id={`dropdownMenuButton-${index}`}
                              onClick={() => toggleDropdown(index)}
                              aria-haspopup="true"
                              aria-expanded={dropdownVisible[index] ? 'true' : 'false'}
                            >
                              Outcome Reports
                            </button>

                            {dropdownVisible[index] && (
                              <div
                                className="dropdown-menu"
                                aria-labelledby={`dropdownMenuButton-${index}`}
                              >
                                {filenames.map((file, fileIndex) => (
                                  <a
                                    key={fileIndex}
                                    className="dropdown-item"
                                    href="#!"
                                    onClick={(e) => {
                                      e.preventDefault();
                                      handleOutcomeReportClick(file, fileIndex, index);
                                    }}
                                  >
                                    {loadingFiles[`${index}-${fileIndex}`] ? 'Loading...' : `Outcome Report ${fileIndex + 1}`}
                                  </a>
                                ))}
                              </div>
                            )}
                          </div>
                        ) : (
                          <a
                            className="btn outcome-report-btn"
                            href="#!"
                            onClick={(e) => {
                              e.preventDefault();
                              handleOutcomeReportClick(filenames[0], 0, index);
                            }}
                            disabled={loadingFiles[`${index}-0`]} // Disable the button while loading for the current file
                          >
                            {loadingFiles[`${index}-0`] ? 'Loading...' : 'Outcome Report'}
                          </a>
                        )
                      ) : (
                        <span className="text-grey">
                          Outcome Report
                        </span>
                      )}

                    </div>
                <div className="col-1.5 link">
  {/* Publication Link */}
  {Array.isArray(item.PUBLICATION_LINK ) && (item.PUBLICATION_LINK ).length > 0 ? (
    <div className="dropdown">
      <button
        className="btn btn-link dropdown-toggle"
        type="button"
        id={`dropdownMenuButton-${index}`}
        data-toggle="dropdown"
        aria-haspopup="true"
        aria-expanded="false"
      >
        Publication Links
      </button>
      <div className="dropdown-menu" aria-labelledby={`dropdownMenuButton-${index}`}>
        {(item.PUBLICATION_LINK ).split(';').map((link, i) => (
          <a
            className="dropdown-item"
            href={link.trim()} // Trim to remove any leading/trailing spaces
            target="_blank"
            rel="noopener noreferrer"
            key={i}
          >
            Link {i + 1}
          </a>
        ))}
      </div>
    </div>
  ) : (item.PUBLICATION_LINK || item[35]) ? (
    <a
      href={(item.PUBLICATION_LINK || item[35]).split(';')[0].trim()} // Extracting the first URL
      target="_blank"
      rel="noopener noreferrer"
    >
      Publication Link
    </a>
  ) : (
    <span className="text-grey">Publication Link</span>
  )}
</div>


                <div className="col-2.5 link">
                  <a
                    href="#"
                    onClick={(e) => {
                      e.preventDefault();
                      toggleCard(index);
                    }}
                  >
                    View GenAI Summary <IoIosArrowDropdownCircle />
                  </a>
                </div>
              </div>
              {expandedCard === index && (
                <div className="genAI-Summary">
                  <div className="row">
                    <div className="col-6 leftsummary">
                      <h6>
                        <GoDotFill className="icon-blue" /> Research Summary
                      </h6>
                      <p>
                      This section will be populated in the future..
                      </p>
                      <div className="btn-group buttonblock">
                        <button
                          type="button"
                          className="btn bluebg mr-2 rounded-pill"
                        >
                         Placeholder Tag
                        </button>
                        <button
                          type="button"
                          className="btn bluebg mr-2 rounded-pill"
                        >
                          Placeholder Tag
                        </button>
                        <button
                          type="button"
                          className="btn bluebg mr-2 rounded-pill"
                        >
                          Placeholder Tag
                        </button>
                      {/*   <button
                          type="button"
                          className="btn greenbg rounded-pill"
                        >
                          Higher Learners Reached
                        </button> */}
                      </div>
                    </div>
                    <div className="col-5 rightsummary">
                          <h6>
                            <GoDotFill className="icon-blue" /> Outcomes Highlights
                          </h6>
                          <p>
                            {item.PROJECT_OUTCOME_SUMMARY || item[36] ? item.PROJECT_OUTCOME_SUMMARY || item[36] : "null"}
                          </p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>
   

    </>
  );
}

export default GrantTile;
