import React, { useState } from "react";
import { toast } from "react-toastify";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../components/AuthContext";
import "./LandingPageNew.css";
import docicon from "../../assets/doc-icon.svg";
import { Select, MenuItem, InputLabel, FormControl } from "@mui/material";
import { IoMdSend } from "react-icons/io";
import TopbarNew from "../../common/TopbarNew";
import Sidebar from "../../common/Sidebar";
import { GrRobot } from "react-icons/gr";
import SpeechRecognition, {
  useSpeechRecognition,
} from "react-speech-recognition";

const LandingPageNew = () => {
  const navigate = useNavigate();
  const [question, setQuestion] = useState("");
  const [selectedDropdown, setSelectedDropdown] = useState("Select Source");
  const [transcript, setTranscript] = useState("");
  const [isListening, setIsListening] = useState(false);
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  const recognition = new SpeechRecognition();
  
  const commands = [
    {
      command: ["clear", "clear field"],
      callback: () => setTranscript(""),
    },
    {
      command: ["search *"],
      callback: (searchQuery) => {
        setTranscript(searchQuery);
        searchQuestions();
      },
    },
  ];


  const selectQuestion = (event) => {
    setQuestion(event.target.value);
  };

  const handleDropdownChange = (event) => {
    setSelectedDropdown(event.target.value);
  };

  const searchQuestions = () => {
    let searchQuery = transcript || question;
    if (selectedDropdown === "Select Source") {
      toast.warning("Please select a source.", {
        position: toast.POSITION.TOP_CENTER,
      });
      return;
    }

    if (searchQuery.trim() !== "") {
      navigate("/query", {
        state: { question: searchQuery, sourceType: selectedDropdown },
      });
      localStorage.setItem("queryQuestion", JSON.stringify(searchQuery));
    } else {
      toast.warning("Please enter a question.", {
        position: toast.POSITION.TOP_CENTER,
      });
    }
  };

  const handleKeyDown = (event) => {
    if (event.key === "Enter") {
      searchQuestions();
    }
  };

  const handlePopularQueryClick = (query) => {
    setTranscript(query);
  };

  const popularQueries = [
    "What is the trend of grant approvals by country in the year 2024?",
    "What are the top 10 countries that have highest total number of grant approvals?",
    "Explain about GMGS Job Aid User Access Management?",
    "What is the trend of grant approvals by country in the year 2024?",
    "How to request to add for a new user to grant?",
  ];
  const textFileUrl = `${process.env.PUBLIC_URL}/pdfLinks.txt`;
  const startListening = () => {
    recognition.start();
    recognition.onresult = event => {
      const current = event.resultIndex;
      const transcript = event.results[current][0].transcript;
      setTranscript(transcript);
      setQuestion(transcript); // Automatically set the question from voice input
    //  setTranscript(searchQuery)
    };
    setIsListening(true);
  };

  const stopListening = () => {
    recognition.stop();
    setIsListening(false);
  };

  return (
    <div className="homepage-container">
      <TopbarNew />

      <div className="sidebar-and-content">
        <Sidebar />

        <div className="homepage-content chatpage">
          <h6 className="theia-assist">
            <GrRobot className="Robot" /> &nbsp;Theia Assistant
          </h6>
          <span>
              {selectedDropdown === "GNT01 SOPs and JobAids" ? (
                <a href={textFileUrl} target="_blank" rel="noopener noreferrer">
                  SOP JobAids Documents List
                </a>
              ) : (
                ''
              )}
            </span>
          <div className="welcome-section">
            <h4 className="greeting">
              Hello {localStorage.getItem("userName")}
              <span className="blackc">,</span>
            </h4>
            <h6 className="help-text">How can I help you?</h6>
            <p className="plain-text">Here are some popular Queries to start</p>
            <div className="popular-questions">
              {popularQueries.map((query, index) => (
                <div
                  key={index}
                  className="popular-question-card"
                  onClick={() => handlePopularQueryClick(query)}
                >
                  <img src={docicon} className="doc-icon" alt="doc-icon" />
                  <p>{query}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="search-bar-container">
            <FormControl variant="outlined" className="select-dropdown">
              <InputLabel id="dropdown-label">Select Source</InputLabel>
              <Select
                labelId="dropdown-label"
                id="dropdown-basic"
                value={selectedDropdown}
                onChange={handleDropdownChange}
                label="Select Source"
                MenuProps={{
                  anchorOrigin: {
                    vertical: "top",
                    horizontal: "center",
                  },
                  transformOrigin: {
                    vertical: "bottom",
                    horizontal: "center",
                  },
                  getContentAnchorEl: null, // Remove default anchor positioning
                  elevation: 8, // Adjust elevation for the dropdown
                }}
              >
                <MenuItem value="Select Source">Select Source</MenuItem>
                <MenuItem value="GNT01 SOPs and JobAids">GNT01 SOPs and JobAids</MenuItem>
                <MenuItem value="Grant Details">Grant Details</MenuItem>
              </Select>
            </FormControl>

            <input
              className="search-bar"
              type="text"
              placeholder="Enter Your Query"
              value={transcript || question}
              onChange={(event) => setTranscript(event.target.value)}
              onKeyDown={handleKeyDown}
            />
            <div  onClick={isListening ? stopListening : startListening}>
              <img
                className="voice-icon"
                src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e8/Google_mic.svg/716px-Google_mic.svg.png"
                alt="Voice Search"
              />
            </div>
            <IoMdSend
              className="send-icon"
              onClick={searchQuestions}
              src="send-icon-url"
              alt="Send"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default LandingPageNew;
