import React, { useEffect, useState } from 'react';
import { DataGrid } from '@mui/x-data-grid';
import axios from 'axios';
import success from "../../assets/success.svg";
import error from '../../assets/error.svg';
import pending from "../../assets/pending.svg";
import { InsightsEndPoint } from '../../common/api-config';

const DataGridTable = () => {
  const [data, setData] = useState([]);
  const [columns, setColumns] = useState([]);

  useEffect(() => {
    axios.get(InsightsEndPoint())
      .then(response => {
        const apiColumns = [];

        if (response.data.length > 0) {
          const firstItem = response.data[0];

          // Dynamically create columns from the first item's keys
          Object.keys(firstItem).forEach(field => {
            apiColumns.push({
              field: field,
              headerName: capitalizeFirstLetter(field.replace(/_/g, ' ')),
              width: 150,
              renderCell: (params) => {
                let imageSrc, text;
                switch (params.value) {
                  case 'OK':
                    imageSrc = success;
                    text = 'OK';
                    break;
                  case 'Rejected: Status Error':
                    imageSrc = error;
                    text = 'Error';
                    break;
                  case 'Pending Refund':
                  case 'Incorrect Final Report Available Date':
                  case 'Payments Missing':
                  case 'Check Recommended Funding Amount':
                  case 'Contract Signed before Med Approval':
                  case 'Patient Enrollment missing':
                  case 'GMG MedEd progress report missing':
                  case 'Final Report Approval Missing':
                  case 'RSD missing':
                  case 'Last payment amount too small':
                  case 'First payment amount too large':
                  case 'Start Date before Contract':
                  case 'Payment before Contract Execution':
                  case 'Check LMR Section':
                  case 'Overall Recommendation Missing':
                  case 'IRB/IEC renewal missing':
                    imageSrc = pending;
                    text = 'Pending';
                    break;
                  default:
                    text = params.value;
                    break;
                }
                return (
                  <div>
                    {imageSrc && <img src={imageSrc} alt="Status Icon" style={{ marginRight: '8px', verticalAlign: 'middle' }} />}
                    {text}
                  </div>
                );
              }
            });
          });

          setColumns(apiColumns);
          setData(response.data);
        }
      })
      .catch(error => {
        console.error('Error fetching data:', error);
      });
  }, []);

  // Helper function to capitalize the first letter of a string
  const capitalizeFirstLetter = (string) => {
    return string.charAt(0).toUpperCase() + string.slice(1);
  };

  return (
    <div style={{ height: 400, width: '100%' }}>
      <DataGrid
        rows={data}
        columns={columns}
        pageSize={5}
        rowsPerPageOptions={[5, 10, 25, 50, 100]}
        getRowId={(row) => row.REQUEST_ID} // Use REQUEST_ID as the unique identifier
      />
    </div>
  );
};

export default DataGridTable;
