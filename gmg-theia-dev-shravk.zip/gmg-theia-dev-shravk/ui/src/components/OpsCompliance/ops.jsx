import React, { useEffect, useState } from 'react';
import { Bar, Doughnut } from 'react-chartjs-2';
import { DataGrid } from '@mui/x-data-grid';
import axios from 'axios';
import { Box, Grid, Container } from '@mui/material';
import './ops.css';
import { InsightsEndPoint } from '../../common/api-config';
import success from "../../assets/success.svg";
import error from '../../assets/error.svg';
import pending from "../../assets/pending.svg";
import Chart from 'chart.js/auto'; // Import Chart.js for customizing tooltips and legends

const ResponsiveDashboard = () => {
  const [data, setData] = useState([]);
  const [columns, setColumns] = useState([]);

  useEffect(() => {
    axios.get(InsightsEndPoint())
      .then(response => {
        const dataWithIds = response.data.map((item, index) => ({
          ...item,
          id: index + 1,
        }));
        setData(dataWithIds);

        if (response.data.length > 0) {
          const firstItem = response.data[0];
          const dynamicColumns = Object.keys(firstItem).map(field => ({
            field: field,
            width: 200,
            renderCell: (params) => {
              let imageSrc, text;
              if (['REQUEST_ID', 'OWNER_NAME', 'OWNER_TITLE', 'COUNTRY'].includes(params.field)) {
                return <span>{params.value}</span>;
                
              } else {
                switch (params.value) {
                  case 'OK':
                    imageSrc = success;
                    text = params.value;
                    break;
                  case 'Rejected: Status Error':
                    imageSrc = error;
                    text = params.value;
                    break;
                  default:
                    imageSrc = pending;
                    text = params.value;
                    break;
                }
                return (
                  <div style={{ display: 'flex', alignItems: 'center' }}>
                    {imageSrc && <img src={imageSrc} alt="Status Icon" style={{ marginRight: '8px', verticalAlign: 'middle', width: '18px', height: '18px' }} />}
                    <span>{text}</span>
                  </div>
                );
              }
            }
          }));
          setColumns(dynamicColumns);
        }
      })
      .catch(error => {
        console.error('Error fetching data:', error);
      });
  }, []);

  const processDonutData = (data) => {
    const errorCounts = {
      'Review': 0,
      'MAPP': 0,
      'Contracts': 0,
      'Payments': 0,
      'Impact Reports': 0,
      'Study Status': 0,
      'Closure': 0
    };

    data.forEach(row => {
      if (row.MEDICAL_REVIEW_STATUS !== 'OK') errorCounts['Review'] += 1;
      if (row.MAPP_DATES_STATUS !== 'OK' || row.MAPP_SECTION_STATUS !== 'OK') errorCounts['MAPP'] += 1;
      if (row.CONTRACT_DATES_STATUS !== 'OK') errorCounts['Contracts'] += 1;
      if (row.PAYMENT_STATUS !== 'OK' || row.PAYMENT_AMOUNT_STATUS !== 'OK') errorCounts['Payments'] += 1;
      if (row.IMPACT_REPORT_STATUS !== 'OK') errorCounts['Impact Reports'] += 1;
      if (row.STUDY_STATUS !== 'OK') errorCounts['Study Status'] += 1;
      if (row.FINAL_REPORT_STATUS !== 'OK' || row.PROJECT_CLOSURE_STATUS !== 'OK') errorCounts['Closure'] += 1;
    });

    return {
      labels: Object.keys(errorCounts),
      datasets: [{
        data: Object.values(errorCounts),
        backgroundColor: ['#36A2EB', '#FF6384', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40', '#FF6384']
      }]
    };
  };

  const processBarData1 = (data) => {
    let okCount = 0;
    let notOkCount = 0;

    data.forEach(row => {
      Object.keys(row).forEach(key => {
        if (row[key] === 'OK') okCount += 1;
        else notOkCount += 1;
      });
    });

    const totalCount = okCount + notOkCount;
    const okPercentage = (okCount / totalCount) * 100;
    const notOkPercentage = (notOkCount / totalCount) * 100;

    return {
      labels: ['Status'],
      datasets: [
        {
          label: 'OK',
          data: [okPercentage],
          backgroundColor: '#36A2EB',
          barThickness: 20
        },
        {
          label: 'NOT OK',
          data: [notOkPercentage],
          backgroundColor: '#FF6384',
          barThickness: 20
        }
      ]
    };
  };

  const processBarChart2 = (data) => {
    let errorCount = 0;
    let warningCount = 0;
    let okCount = 0;

    data.forEach(row => {
      const hasError = Object.values(row).includes('Error');
      const hasWarning = Object.values(row).includes('Warning');

      if (hasError) errorCount += 1;
      else if (hasWarning) warningCount += 1;
      else okCount += 1;
    });

    return {
      labels: ['Errors', 'Warnings', 'OK'],
      datasets: [
        {
          label: ' Quality',
          data: [errorCount, warningCount, okCount],
          backgroundColor: ['#FF6384', '#FFCE56', '#36A2EB']
        }
      ]
    };
  };

  const processStackedBarData = (data) => {
    const countryStats = {};

    data.forEach(row => {
      const country = row.COUNTRY; // Adjust according to your data
      if (!countryStats[country]) {
        countryStats[country] = { error: 0, warning: 0, ok: 0 };
      }

      const hasError = Object.values(row).includes('Rejected: Status Error');
      const hasWarning = Object.values(row).includes('Warning');
      const allOK = Object.values(row).every(value => value === 'OK');

      if (hasError) countryStats[country].error += 1;
      else if (hasWarning) countryStats[country].warning += 1;
      else if (allOK) countryStats[country].ok += 1;
    });

    const countries = Object.keys(countryStats);
    return {
      labels: countries,
      datasets: [
        {
          label: 'Errors',
          data: countries.map(country => countryStats[country].error),
          backgroundColor: '#FF6384'
        },
        {
          label: 'Warnings',
          data: countries.map(country => countryStats[country].warning),
          backgroundColor: '#FFCE56'
        },
        {
          label: 'All OK',
          data: countries.map(country => countryStats[country].ok),
          backgroundColor: '#36A2EB'
        }
      ]
    };
  };

  const barOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'left',
        align: 'start',
        labels: {
          boxWidth: 5,
          padding: 10
        }
      },
      tooltip: {
        callbacks: {
          label: function (context) {
            return `${context.dataset.label}: ${context.raw.toFixed(2)}%`;
          }
        }
      },
      datalabels: {
        display: true,
        formatter: (value) => `${value.toFixed(2)}%`,
        color: '#000',
        anchor: 'end',
        align: 'top'
      }
    },
    scales: {
      x: {
        stacked: true,
        display: false // Hide x-axis
      },
      y: {
        stacked: true,
        display: false // Hide y-axis
      }
    }
  };

  const donutOptions = {
    plugins: {
      legend: {
        position: 'left',
        align: 'start',
        labels: {
          boxWidth: 10,
          padding: 10
        }
      },
      tooltip: {
        callbacks: {
          label: function (context) {
            return `${context.label}: ${context.raw}`;
          }
        }
      }
    }
  };

  const barOptionsBasic = {
    responsive: true,
    plugins: {
      legend: {
        position: 'left',
        align: 'start',
        labels: {
          boxWidth: 10,
          padding: 10
        }
      },
      tooltip: {
        callbacks: {
          label: function (context) {
            return `${context.dataset.label}: ${context.raw}`;
          }
        }
      }
    },
    scales: {
      x: {
        title: {
          display: true,
          text: 'Status'
        }
      },
      y: {
        title: {
          display: true,
          text: 'Count'
        }
      }
    }
  };

  return (
    <Container className='ops-container'>

      <Grid container spacing={3}>
        <Grid item xs={12} sm={6} md={5}>
       
          <Grid container spacing={1} className='first-chart'>
        
            <Grid item xs={8} md={8}>
            <h3 className='chart-header'>Status Overview</h3>
              <Doughnut data={processDonutData(data)} className='doughnut' options={donutOptions} />
            </Grid>
            <Grid item xs={4} md={4}>
              <Bar data={processBarData1(data)} className="bar1" options={barOptions} />
            </Grid>
          </Grid>
          </Grid>
          <Grid item xs={12} sm={6} md={7}>
       
          <Grid container spacing={1} className='second-chart'>
            <Grid item xs={8} md={6}>
            <h3 className='chart-header'>Grant Quality </h3>
            <Bar data={processBarChart2(data)} className="bar2"options={barOptionsBasic} />
            </Grid>
            <Grid item xs={4} md={6}>
            <h3 className='chart-header'>Statistics per Country </h3>
            <Bar data={processStackedBarData(data)}className="bar3"  options={barOptions} />
            </Grid>
          </Grid>
          </Grid>
         {/*  <Grid item xs={12} sm={6} md={3}>
            <h3 className='chart-header'>Quality Assurance</h3>
            <Bar data={processBarChart2(data)} options={barOptionsBasic} />
          </Grid>
          <Grid item xs={12} sm={12} md={4}>
            <h3 className='chart-header'>Geographical Performance</h3>
            <Bar data={processStackedBarData(data)} options={barOptions} />
          </Grid> */}
        </Grid>

        <Box sx={{ height: 400, width: '100%', marginTop: '2rem' ,backgroundColor:'#fff'}}>
          <h3 >Data Grid</h3>
          <DataGrid
            rows={data}
            columns={columns}
            pageSize={5}
            rowsPerPageOptions={[5, 10, 20]}
            getRowId={(row) => row.REQUEST_ID}
          />
        </Box>
    </Container>
  );
};

export default ResponsiveDashboard;
