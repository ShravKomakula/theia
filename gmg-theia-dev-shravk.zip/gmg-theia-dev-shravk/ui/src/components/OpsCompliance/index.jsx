import React from 'react';
import './OpsCompliance.css';
import TopbarNew from "../../common/TopbarNew";
import Sidebar from "../../common/Sidebar";
import ResponsiveDashboard from './ops';

const OpsCompliance = () => {
  return (
    <div className="homepage-container">
      <TopbarNew />
      <div className="sidebar-and-content">
        <Sidebar />
        <div className="homepage-content">
          <div className="ops-compliance-container">
            <h2>Ops Compliance</h2>
            <div className='ops-container'>
              <ResponsiveDashboard />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OpsCompliance;
