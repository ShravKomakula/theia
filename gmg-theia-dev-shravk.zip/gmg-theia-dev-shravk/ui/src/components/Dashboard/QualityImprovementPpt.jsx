
import PptxGenJS from 'pptxgenjs';
import logo from '../../assets/images/Pfizer-Logo-Color-RGB 1.svg';
const generateQualityPPT = (pptx,selectedData) => {

  console.log("selectedDataQuality",selectedData);
  // Slide 1: Create a slide
  const slide = pptx.addSlide();
  const data = selectedData; // Access the first array in selectedData

  const formatDate = (dateString) => {
    if (!dateString) return 'null'; // Handle null or undefined dates gracefully
    const date = new Date(dateString);
    return date.toLocaleDateString(); // Format as per locale
  };
  // Example usage: accessing specific fields
  const requestId = data[0] || data.REQUEST_ID || 'null';
  const projectTitle = data[1] || data.PROJECT_TITLE || 'null';
  const organization=data[6]||data.ORGANIZATION_NAME||'null';
  const piname=data[7]||data.PI_NAME|| 'null';
  const grantamount=data[3]||data.APPROVED_AMOUNT|| 'null';
  const pending=data[4]||data.PAYMENT_REMAINING || 'null';
  const bu=data[38]||data.PFIZER_BUSINESS_UNIT_BU_CLUSTER||'null';
  const pai=data[18]||data.PRIMARY_AREA_OF_INTERST_DISEASE||'null';
  const targetlearnergroup = data[31] ||data.TARGETED_LEARNER_GROUP|| 'null';
  const speciality = data[32]||data.SPECIALITY || 'null';
  const abstractsummary = data[8] ||data.ABSTARCT_SUMMARY|| 'null';
  const submitDate = formatDate(data[41] || data.GRANT_REQUEST_SUBMIT_DATE) || 'null';
  const projectStartDate =formatDate(data[54] || data.PROJECT_START_DATE)  || 'null';
  const projectEndDate = formatDate(data[55] || data.PROJECT_END_DATE) || 'null';
  const finalApprovalDate = formatDate(data[56] || data.FINAL_APPROVAL_DATE )|| 'null';
  const executedContractDate =formatDate( data[57] || data.EXECUTED_CONTRACT_DT) || 'null';
  const finalReportOutcomeDate = formatDate(data[58] || data.FINAL_REPORT_OUTCOME_DATE) || 'null';
  const statusinsights=data[23]||data.STATUS_INSIGHT||'null';
  const population=data[28]||data.Population||'null';
  const lastupdate=formatDate(data[10]||data.LAST_UPDATE)||'null';
  const primarycountry=data[50]||data.PRIMARY_COUNTRY_SITE||'null';
  const numofsites=data[51]||data.NUMBER_OF_SITES||'null';
  const projectbarriers=data[11]||data.PROJECT_BARRIERS||'null';
  const nextprojectupdate=data[72]||data.NEXT_PROJECT_UPDATE||'null';
 // Define common options
 const textOptions = { fontSize: 10, color: '000', align: 'left',fontFace: 'Pfizer Diatype Office Light'  };
 const borderOptions = { line: { color: '000000', width: 1 }, fill: 'FFFFFF',fontFace: 'Pfizer Diatype Office Light'  };
 const footerOptions = { fontSize: 8, color: '000000', align: 'left',fontFace: 'Pfizer Diatype Office Light'  };

 const addBorderedTextGroup = (slide, x, y, width, height, text1, text2, bgColor, borderRadius = 10) => {
   slide.addShape(pptx.ShapeType.rect, { x, y, w: width, h: height, fill: bgColor, radius: borderRadius });
   slide.addText(`${text1}\n${text2}`, { x: x + 0.1, y: y + 0.1, w: width - 0.1, h: height - 0.1, ...textOptions,fontFace: 'Pfizer Diatype Office Light'  });
 };

 const addHeader = (slide) => {
   slide.addText(`Approved – Projects – Quality Improvement `, { x: 0.5, y: 0.2, w: 9, h: 0.5, fontSize: 18, color: 'FF0000', align: 'left' ,fontFace: 'Pfizer Diatype Office Light' });
   slide.addText(`Time stamp `, { x: 8.7, y: 0.2, w: 9, h: 0.3, fontSize: 8, color: 'FF0000' ,fontFace: 'Pfizer Diatype Office Light' });
 };

 const addFooter = (slide) => {
   slide.addImage({ path: logo, x: 0.5, y: 5, w: 1.5, h: 0.3 });
   slide.addText('Business Group Business Subgroup', { x: 2.5, y: 5.1, w: 3.5, h: 0.2, ...footerOptions, color: '0056b3',fontFace: 'Pfizer Diatype Office Light'  });
 };

 const addAbstractSummary = (slide, abstractsummary) => {
  const maxSentences = 1;
  const sentences = abstractsummary.split('.'); // Split into sentences
  let summary = '';

  if (sentences.length > maxSentences) {
    summary = sentences.slice(0, maxSentences).join('. ') + '.'; // Join the first sentence and add period
  } else {
    summary = abstractsummary; // If less than 2 sentences, show the entire summary
  }

  slide.addShape(pptx.ShapeType.rect, { x: 0.5, y: 2.7, w: 9, h: 0.5, fill: 'f8f7f7', radius: 10 }); // Add background shape
  slide.addText(`Abstract: ${summary}`, { x: 0.5, y: 2.7, w: 9, h: 0.5, ...textOptions }); // Add text
};

 
 // Add all the elements to the slide
 addBorderedTextGroup(slide, 0.5, 0.7, 1.5, 0.4, `GrantId: ${requestId}`, '','f8f7f7');
 addBorderedTextGroup(slide, 2.5, 0.7, 7, 0.4, `Title: ${projectTitle}`, ``,'f8f7f7');
 
 addBorderedTextGroup(slide, 0.5, 1.2, 9, 0.4, `BU: ${bu} + Primary Area Of Interest: ${pai}`,`Org: ${organization}`,'f8f7f7');
 addBorderedTextGroup(slide, 0.5, 1.7, 4, 0.4, `$${grantamount}-$${pending}`, `PI name: ${piname}`,'f8f7f7');
 addBorderedTextGroup(slide, 4.5, 1.7, 4, 0.4, `No.of sites${numofsites}`, ``,'f8f7f7');

 addBorderedTextGroup(slide, 0.5, 2.2, 2, 0.4, `Primary Site Country ${primarycountry}`, ``,'f8f7f7');
 addBorderedTextGroup(slide, 3.5, 2.2, 4, 0.4, `Project Team Details: target learner group ${targetlearnergroup}`, ``,'f8f7f7');
 addBorderedTextGroup(slide, 7.5, 2.2, 2, 0.4, `Patient:${population}`, `speciality:${speciality}`,'f8f7f7');
 addAbstractSummary(slide, abstractsummary);
 slide.addNotes(`Abstract Summart ${abstractsummary}`);
 addBorderedTextGroup(slide, 0.5, 3.3, 2, 0.4, `Last Update: ${lastupdate}`, '','f8f7f7');
 addBorderedTextGroup(slide, 3.5, 3.3, 3, 0.4, `Theia Insights: status :${statusinsights}`, '', 'f8f7f7', 30);
 addBorderedTextGroup(slide, 6.5, 3.3, 3, 0.4, `Progress Info $ Latest Update ${projectbarriers}`, '', 'f8f7f7', 30);
 addBorderedTextGroup(slide, 0.5, 3.8, 1.4, 0.5, `Timeline: ${submitDate}`, '', '68D1FF', 30);
 addBorderedTextGroup(slide, 2, 3.8,1.4, 0.5, `Final Approval Date: ${finalApprovalDate}`, '', '68D1FF', 30);
 addBorderedTextGroup(slide, 3.5, 3.8, 1.4, 0.5, `Contract Executed Date: ${executedContractDate}`, '', '68D1FF', 40);
 addBorderedTextGroup(slide, 5, 3.8, 1.4, 0.5, `Project Start Date: ${projectStartDate}`, '', '68D1FF', 40);
 addBorderedTextGroup(slide, 6.5, 3.8, 1.4, 0.5, `Project End Date: ${projectEndDate}`, '', '68D1FF', 40);
 addBorderedTextGroup(slide, 8, 3.8, 1.4, 0.5, `Expected Final Report Date: ${finalReportOutcomeDate}`, '', '68D1FF', 40);
 
 addBorderedTextGroup(slide, 0.5, 4.5, 9, 0.3, `Next Expected Update:${nextprojectupdate}`, '','f8f7f7');

 addHeader(slide); // Add header to slide 1
  addFooter(slide); // Add footer to slide 1


};

export { generateQualityPPT };
