
import logo from '../../assets/images/Pfizer-Logo-Color-RGB 1.svg';

const generateMedicalPPT = (pptx,selectedData) => {
  console.log("selectedDatamedical",selectedData);
  // Ensure selectedData has the expected structure
  if (!selectedData || !selectedData.length) {
    console.error('Selected data is empty or invalid');
    return;
  }
  const formatDate = (dateString) => {
    if (!dateString) return 'null'; // Handle null or undefined dates gracefully
    const date = new Date(dateString);
    return date.toLocaleDateString(); // Format as per locale
  };
  // Example usage: accessing specific fields
  const data = selectedData; // Access the first array in selectedData
const requestId=data[0]||data.REQUEST_ID || 'null';
  const projectTitle = data[1] || data.PROJECT_TITLE || 'null';
  const organization=data[6]||data.ORGANIZATION_NAME||'null';
  const grantamount=data[3]||data.APPROVED_AMOUNT|| 'null';
  const pending=data[4]||data.PAYMENT_REMAINING || 'null';
  const bu=data[38]||data.PFIZER_BUSINESS_UNIT_BU_CLUSTER||'null';
  const pai=data[18]||data.PRIMARY_AREA_OF_INTERST_DISEASE||'null';
  const proposaltype = data[19]||data.PROPOSAL_TYPE || 'null';
  const typeofrequest = data[39]||data.TYPE_OF_REQUEST_DER || 'null';
  const targetlearners=data[33]||data.TARGET_LEARNER||'null';
  const targetlearnergroup = data[31] ||data.TARGETED_LEARNER_GROUP|| 'null';
  const speciality = data[32]||data.SPECIALITY || 'null';
  const submitDate = formatDate(data[41] || data.GRANT_REQUEST_SUBMIT_DATE) || 'null';
  const projectStartDate =formatDate(data[54] || data.PROJECT_START_DATE)  || 'null';
  const projectEndDate = formatDate(data[55] || data.PROJECT_END_DATE) || 'null';
  const finalApprovalDate = formatDate(data[56] || data.FINAL_APPROVAL_DATE )|| 'null';
  const executedContractDate =formatDate( data[57] || data.EXECUTED_CONTRACT_DT) || 'null';
  const finalReportOutcomeDate = formatDate(data[58] || data.FINAL_REPORT_OUTCOME_DATE) || 'null';
  const venuetype = data[40] ||data.MEDICAL_EDUCATION_MEDED_VENUE_TYPE|| 'null';
  const Accreditations=data[67]||data.ACCREDIATION||'null';
  const venuelocation=data[66]||data.EVENT_CITY||'null';
const venuename=data[68]||data.EVENT_LOCATION||'null'
const programobjectives=data[69]|| data.PROGRAM_OBJECTIVES||'null';
const executivesummary=data[70]||data.EXECUTIVE_SUMMARY||'null';
const uniquereached=data[71]||data.TOTAL_LEARNERS_REACHED||'null';



  // Slide 1: Create a slide
  const slide = pptx.addSlide();

  // Define common options
  const textOptions = { fontSize: 8, color: '000000', align: 'left' ,fontFace: 'Pfizer Diatype Office Light' };
  const borderOptions = { line: { color: '000000', width: 1 }, fill: 'FFFFFF' ,fontFace: 'Pfizer Diatype Office Light' };
  const footerOptions = { fontSize: 8, color: '000000', align: 'left' ,fontFace: 'Pfizer Diatype Office Light' };

  const addBorderedTextGroup = (slide, x, y, width, height, text1, text2, bgColor, borderRadius = 10) => {
    slide.addShape(pptx.ShapeType.rect, { x, y, w: width, h: height, fill: bgColor, radius: borderRadius }); // Corrected 'radius' spelling
    slide.addText(`${text1}\n${text2}`, { x: x + 0.1, y: y + 0.1, w: width - 0.1, h: height - 0.1, ...textOptions });
  };
  
  const addHeader = (slide) => {
    slide.addText(`Approved – Projects – Medical Education Grant `, { x: 0.5, y: 0.2, w: 9, h: 0.5, fontSize: 18, color: 'FF0000', align: 'left',fontFace: 'Pfizer Diatype Office Light'  });
    slide.addText(`Time stamp `, { x: 8.7, y: 0.2, w: 9, h: 0.3, fontSize: 8, color: 'FF0000',fontFace: 'Pfizer Diatype Office Light'  });
  };

  const addFooter = (slide) => {
    slide.addImage({ path: logo, x: 0.5, y: 5, w: 1.5, h: 0.3 }); // Adjust y position as needed
    slide.addText('Business Group Business Subgroup', { x: 2.5, y: 5.1, w: 3.5, h: 0.2, ...footerOptions, color: '0056b3',fontFace: 'Pfizer Diatype Office Light'  });
  };

  addBorderedTextGroup(slide, 0.5, 0.7, 1.5, 0.4, `GrantId: ${requestId}`, ``,'f8f7f7',20);
  
  addBorderedTextGroup(slide, 2.3, 0.7, 5, 0.4, `Title: ${projectTitle}`, `Org: ${organization}`,'f8f7f7',10);
  addBorderedTextGroup(slide, 7.5, 0.7, 2, 0.4, `$${grantamount}-$${pending}`, '$ Cost Per Learner','f8f7f7');
  addBorderedTextGroup(slide, 0.5, 1.2, 3.5, 0.4, `BU:${bu} + Primary Area Of Interest:${pai}`, '','f8f7f7');
  addBorderedTextGroup(slide, 5.5, 1.2, 4, 0.4, `Proposal Type: ${proposaltype}`, `Type Of Request: ${typeofrequest}`,'f8f7f7');
  addBorderedTextGroup(slide, 0.5, 1.7, 4, 0.4, `Target Learner Group:${targetlearnergroup}`, '','f8f7f7',5);
  addBorderedTextGroup(slide, 5.5, 1.7, 4, 0.4, `Speciality: ${speciality}`, '','f8f7f7');
  addBorderedTextGroup(slide, 0.5, 2.2, 4.5, 0.4, `Venue: ${venuetype} - ${venuename}`, `Venue Location: ${venuelocation}`,'f8f7f7');
  addBorderedTextGroup(slide, 5.5, 2.2, 4, 0.4, `Accreditations: ${Accreditations}`, '','f8f7f7');
  addBorderedTextGroup(slide, 0.5, 2.7, 9, 0.6, `Project Objective/Goal: ${programobjectives}`, '','f8f7f7');
  addBorderedTextGroup(slide, 0.5, 3.4, 1.4, 0.6, `Timeline: ${submitDate}`  ,'','68D1FF',30);
  addBorderedTextGroup(slide, 2, 3.4, 1.4, 0.6,`Final Approval Date:${finalApprovalDate}`,``,'68D1FF','30');
  addBorderedTextGroup(slide, 3.5, 3.4, 1.4, 0.6,`Contract Executed Date:${executedContractDate}`,``,'68D1FF',40);
  addBorderedTextGroup(slide, 5, 3.4, 1.4, 0.6,`Project Start Date:${projectStartDate}`,``,'68D1FF',40);
  addBorderedTextGroup(slide, 6.5, 3.4, 1.4, 0.6,`Project End Date:${projectEndDate}`,``,'68D1FF',40,);
  addBorderedTextGroup(slide, 8, 3.4, 1.4, 0.6,`expected Final Report Date:${finalReportOutcomeDate}`,``,'68D1FF',40);
  
  addBorderedTextGroup(slide,0.5,4.1,9,0.3,`MedEd Progress Info from Report : <URLs to any online learning or other materials>`,'','f8f7f7');
  addBorderedTextGroup(slide, 0.5, 4.5, 9, 0.5, `Executive sumamry: ${executivesummary}`,'','f8f7f7');
  addBorderedTextGroup(slide, 6.5, 4.5, 3, 0.5, `Target learer: ${targetlearners},${uniquereached}`,'','f8f7f7');
  
  addHeader(slide); // Add header to slide 1
  addFooter(slide); // Add footer to slide 1

 
};

export { generateMedicalPPT };
