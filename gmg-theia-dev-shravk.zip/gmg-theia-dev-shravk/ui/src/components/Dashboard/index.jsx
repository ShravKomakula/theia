import React, { useState, useEffect } from "react";
import "./Dashboard.css";
import logo from '../../assets/images/Pfizer-Logo-Color-RGB 1.svg';
import axios from "axios";
import Mapwithsummary from "./Mapwithsummary";
import { CiGrid2H } from "react-icons/ci";
import { MdGridOn } from "react-icons/md";
import { DataGrid } from '@mui/x-data-grid';
import { DashboardRoles } from "../../common/DashboardRoles";
import { useNavigate } from "react-router-dom";
import { IoMdMicrophone } from "react-icons/io"
import logoicon from './pfizer-logo.png';
import { FetchSnowFlakeData, mainsearchEndpoint, abstractsummaryEndpoint, recommendedviewEndpoint } from "../../common/api-config";
import { format, isValid } from 'date-fns';
import TileView from "./TileView";
import Overview from "./Overview";
import PptxGenJS from 'pptxgenjs';
import { GoArrowDown, GoDownload } from "react-icons/go";
import pending from "../../assets/pending.svg";
import success from "../../assets/success.svg";
import error from '../../assets/error.svg';
import { AiOutlineFilePpt } from "react-icons/ai";
import { RiFileExcel2Fill } from "react-icons/ri";
import { generateResearchISRPPT } from "./ResearchISRPpt";

import { generateQualityPPT } from "./QualityImprovementPpt";
import { generateResearchPPT } from './ResearchPpt';
import { generateMedicalPPT } from './MedicalPpt';
import { generateFellowshipPPt } from "./FellowshipPpt";

import TopbarNew from '../../common/TopbarNew';
import Sidebar from '../../common/Sidebar';
import { IoMdSend } from "react-icons/io";
import { base16AteliersulphurpoolLight } from "react-syntax-highlighter/dist/cjs/styles/prism";
function Dashboard() {
  const [grantedViewActive, setGrantedViewActive] = useState(true);
  const [selectedRecords, setSelectedRecords] = useState([]);
  const [selectedData, setSelectedData] = useState([]);
  const [allViewActive, setAllViewActive] = useState(false);
  const [data, setData] = useState([]);
  const [rows, setRows] = useState([]);
  const [columns, setColumns] = useState([]);
  const [isGridView, setIsGridView] = useState(false);
  const [isTileView, setIsTileView] = useState(true);
  const [searchResults, setSearchResults] = useState([]);
  const [abstractSummaryResults, setAbstractSummaryResults] = useState([]);
  const [isLoadingAbstractSummary, setIsLoadingAbstractSummary] = useState(false);
  const [showCheckboxes, setShowCheckboxes] = useState(false);
  const [currentPage, setCurrentPage] = useState(1); // Start from page 1
  const [formattedFilteredData, setFormattedFilteredData] = useState([]);
  const [recommendedViewData, setRecommendedViewData] = useState([]);

  const [query, setQuery] = useState({
    pi_name: '',
    organization_name: '',
    primary_area_of_interest_disease: '',
    abstract_summary: '',

    top_k: 100
  });

  const [searchCriterion, setSearchCriterion] = useState('pi_name');
  const userC = JSON.parse(localStorage.getItem('access_token'));
  const userCountryCode = userC.userInfo.LOCATION_CODE_ISO2;
  const navigate = useNavigate();
  const [isListening, setIsListening] = useState(false);


  const toggleCheckboxes = () => {
    setShowCheckboxes((prev) => !prev);
  };
  useEffect(() => {

    fetchRecommendedviewData();
    setIsGridView(false);
    setIsTileView(true);
    setShowCheckboxes(false);

  }, []);
  const fetchRecommendedviewData = async () => {
    try {
      const storedData = localStorage.getItem("access_token");
      const parsedData = JSON.parse(storedData);
      const ntid = parsedData.userInfo.access_token.NTID;
      //const ntid = "HARBOK";

      const response = await fetch(recommendedviewEndpoint(), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ user_ntid: ntid }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! stsatus: ${response.status}`);
      }

      const result = await response.json();

      const columnNames = result.column;
      const filteredColumns = columnNames.map((fieldName) => ({
        field: fieldName,
        headerName: fieldName
          .replace(/_/g, ' ')
          .toLowerCase()
          .replace(/\b(\w)/g, (char) => char.toUpperCase()),
        width: 150,
        valueFormatter: (params) => {
          const value = params.value;
          if (['LAST_UPDATE', 'GRANT_REQUEST_SUBMIT_DATE', 'PROJECT_START_DATE', 'PROJECT_END_DATE', 'FINAL_APPROVAL_DATE', 'EXECUTED_CONTRACT_DT', 'FINAL_REPORT_OUTCOME_DATE', 'NEXT_PROJECT_UPDATE', 'PUBLICATION_DATE'].includes(fieldName)) {
            const date = new Date(value);
            return isValid(date) ? format(date, 'MM/dd/yyyy') : '';
          }
          if (['APPROVED_AMOUNT', 'PAYMENT_REMAINING'].includes(fieldName)) {
            return `$${value != null ? value.toFixed(2) : '0.00'}`;
          }
          return value != null ? value : 'Null';
        },
      }));

      setColumns(filteredColumns);
      // console.log("filteredColumns",filteredColumns);
      const formattedRows = result.records.map((row, index) => {
        const rowObject = {};
        columnNames.forEach((name, i) => {
          rowObject[name] = row[i];
        });
        rowObject.id = index;  // Ensure each row has a unique id
        return rowObject;
      });

      // console.log("rows of recommended view:", formattedRows);

      setRecommendedViewData(result.records);
      setRows(formattedRows);

      //console.log("Result of recommended view:", result);

    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  const fetchData = async () => {
    try {
      const response = await fetch(FetchSnowFlakeData());
      const result = await response.json();

      const columnNames = result.columns;
      const filteredColumns = columnNames.map((fieldName) => ({
        field: fieldName,
        headerName: fieldName
          .replace(/_/g, ' ')
          .toLowerCase()
          .replace(/\b(\w)/g, (char) => char.toUpperCase()),
        width: 150,
        valueFormatter: (params) => {
          const value = params.value;
          if (fieldName === 'LAST_UPDATE' || fieldName === 'GRANT_REQUEST_SUBMIT_DATE' ||
            fieldName === 'PROJECT_START_DATE' || fieldName === 'PROJECT_END_DATE' ||
            fieldName === 'FINAL_APPROVAL_DATE' || fieldName === 'EXECUTED_CONTRACT_DT' ||
            fieldName === 'FINAL_REPORT_OUTCOME_DATE' || fieldName === 'NEXT_PROJECT_UPDATE' || fieldName === 'PUBLICATION_DATE') {
            const date = new Date(value);
            return isValid(date) ? format(date, 'MM/dd/yyyy') : '';
          }
          if (fieldName === 'APPROVED_AMOUNT' || fieldName === 'PAYMENT_REMAINING') {
            return `$${value != null ? value.toFixed(2) : '0.00'}`;
          }
          /* return value; */
          return value != null ? value : 'Null';
        },
      }));

      setColumns(filteredColumns);

      const formattedRows = result.results.map((row, index) => {
        const rowObject = {};
        columnNames.forEach((name, i) => {
          rowObject[name] = row[i];
        });
        rowObject.id = index;  // Ensure each row has a unique id
        return rowObject;
      });

      setData(result);
      setRows(formattedRows);
      /*       console.log("All rows", result.results);
                console.log("Formatted rows", formattedRows);  */
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };
  const formatRows = (data, columns, columnNames) => {
    return data.map((row, index) => {
      const rowObject = {};
      columnNames.forEach((name, i) => {
        rowObject[name] = row[i];
      });
      rowObject.id = index; // Ensure each row has a unique id
      return rowObject;
    });
  };


  /*   const handleGrantedViewClick = () => {
      if (searchResults.length === 0) {
        setGrantedViewActive(true);
        setAllViewActive(false);
        setSearchResults([]);
      } else {
        setSearchResults([]); // Reset search results when switching back to the recommended view
        setGrantedViewActive(true);
        setAllViewActive(false);
  
      }
    }; */
  const handleGrantedViewClick = () => {
    fetchRecommendedviewData();
    setGrantedViewActive(true);
    setAllViewActive(false);
    setSearchResults([]);
    setAbstractSummaryResults([])
    setIsGridView(false)
    setCurrentPage(1);
  }


  const handleAllViewClick = () => {
    fetchData();
    setGrantedViewActive(false);
    setAllViewActive(true);
    setIsGridView(false);
    setShowCheckboxes(false);
    setSelectedRecords([]);
  };

  const handleTileViewClick = () => {
    setIsGridView(false);
    setIsTileView(true);
    setShowCheckboxes(false);
    setSelectedRecords([]);
  };
  const handleDownloadPPT = () => {
    if (selectedRecords.length === 0) {
      alert("Please select at least one record to generate the presentation.");
      return; // Exit the function if no checkboxes are selected
    }
    const pptx = new PptxGenJS(); // Initialize PptxGenJS instance
    const footerOptions = { fontSize: 8, color: '000000', align: 'left' };
    const addFirstSlide = () => {
      const slide1 = pptx.addSlide();

      const addFooter = (slide1) => {
        slide1.addImage({ path: logo, x: 0.5, y: 5, w: 1.5, h: 0.3 });
        slide1.addText('Business Group Business Subgroup', { x: 3.5, y: 8, w: 3.5, h: 0.3, ...footerOptions, color: '0056b3', fontFace: 'Pfizer Tomorrow' });
      };
      slide1.addText(`Theia – Study Snapshot Templates`, { x: 1, y: 2, fontSize: 20, color: '000000', fontFace: 'Pfizer Tomorrow' });
      slide1.addImage({ path: logoicon, x: 5, y: 0.2, w: 5, h: 5.5 });
      addFooter(slide1);

    };

    const addLastSlide = () => {
      const slideLast = pptx.addSlide();
      const addFooter = (slideLast) => {
        slideLast.addImage({ path: logo, x: 0.5, y: 5, w: 1.5, h: 0.3 });
        slideLast.addText('Business Group Business Subgroup', { x: 3.5, y: 5, w: 3.5, h: 0.3, ...footerOptions, color: '0056b3', fontFace: 'Pfizer Tomorrow' });
      };
      // Add text in the last slide
      slideLast.addText('Thank You...', { x: 1, y: 1, fontSize: 50, color: '0000FF', fontFace: 'Pfizer Tomorrow' });

      addFooter(slideLast);

    };


    addFirstSlide(); // Add the first slide at the beginning of the presentation

    // Process each selected record and generate slides accordingly
    selectedRecords.forEach(index => {
      console.log("dataToShow", dataToShow);
      
      const data = dataToShow.find((i) => {
       
        return i[0] === index || i.REQUEST_ID === index;
      
      })
     
      console.log(data, "data");
      switch (data.PROPOSAL_TYPE || data[19]) {
        case 'Quality Improvement (QI)':
          generateQualityPPT(pptx, data); // Modify generateQualityPPT to accept pptx instance
          break;
        case 'Fellowship':
          generateFellowshipPPt(pptx, data); // Modify generateFellowshipPPt to accept pptx instance
          break;
        case 'Research Collaborations (RC) LOI':
          generateResearchPPT(pptx, data); // Modify generateResearchPPT to accept pptx instance
          break;
        case 'Medical Education':
          generateMedicalPPT(pptx, data); // Modify generateMedicalPPT to accept pptx instance
          break;
        case 'Research Grant':
          generateResearchISRPPT(pptx, data); // Modify generateMedicalPPT to accept pptx instance
          break;
        default:
          generateResearchPPT(pptx, data);//default
          //console.error('Unknown proposal_type:', data.PROPOSAL_TYPE || data[19]);
          break;
      }
    });

    addLastSlide(); // Add the last slide at the end of the presentation

    pptx.writeFile({ fileName: 'Sample Presentation' }); // Save the merged presentation
  };
  //console.log(selectedRecords,"selectedRecords");
  const handleDownloadButtonClick = () => {
    if (!showCheckboxes) {
      // Toggle checkboxes on first click
      toggleCheckboxes();
    } else {
      // If checkboxes are already shown, directly download PPT on subsequent clicks
      handleDownloadPPT();
      setShowCheckboxes(false);
      setSelectedRecords([]);
    }
  };

  const handleGridViewClick = () => {
    setIsGridView(true);
    setIsTileView(false);

    const formattedFilteredData = formatRows(dataToShow, columns, columns.map(col => col.field));

    setFormattedFilteredData(formattedFilteredData);
  };

  console.log("formattedFilteredData", formattedFilteredData);
  /* console.log("recommendedViewData",recommendedViewData);
  console.log("data.results ",data.results ); */

  const filteredData = (recommendedViewData && grantedViewActive)
    ? recommendedViewData
    : (data.results || []);

  //   const filteredData = (data.results && grantedViewActive)
  //   ? data.results.filter(row => row[data.columns.indexOf('COUNTRY_CODE')] === userCountryCode)
  //   : data.results || [];
  console.log("filteredData ", filteredData);

  useEffect(() => {
    const accessTokenInfo = JSON.parse(localStorage.getItem('access_token'));
    const userInfo = accessTokenInfo.userInfo;
    if (userInfo && !DashboardRoles.includes(userInfo.DEPARTMENT_5_DESC)) {
      navigate('/unauthorised')
    }
  }, [])
  const fetchAbstractSummaryData = async () => {
    try {
      setIsLoadingAbstractSummary(true);
      const response = await axios.post(abstractsummaryEndpoint(), null, {
        params: {
          abstract_summary: query.abstract_summary || '',
          top_k: 6
        }
      });
      setAbstractSummaryResults(response.data.snowflake_records); // Assuming the response structure is handled correctly
      console.log("abs", response.data.snowflake_records);
      setIsLoadingAbstractSummary(false);
      setSearchResults([]);
      setIsGridView(false);
      setShowCheckboxes(false);
      setCurrentPage(1);
    } catch (error) {
      console.error('Error fetching abstract summary data:', error);
      setIsLoadingAbstractSummary(false);
      if (error.response && error.response.status === 422) {
        console.error('Validation error:', error.response.data); // Log the validation error details
        // Handle validation errors (e.g., display error messages to the user)
      } else {
        // Handle other types of errors (e.g., network issues)
      }
    }
  };


  const handleSearch = async () => {
    try {


      // Determine which endpoint to call based on search criterion
      if (searchCriterion === 'abstract_summary') {
        await fetchAbstractSummaryData(query);
      } else {
        const response = await axios.post(mainsearchEndpoint(), null, {
          params: query
        });
        /*   console.log("Search Response:", response.data); */

        if (response.data && response.data.snowflake_records) {
          const searchResults = response.data.snowflake_records.map((row) => {
            const result = {};
            response.data.columns.forEach((columnName, index) => {
              result[columnName] = row[index];
            });
            return result;
          });
          /*  console.log("Formatted Search Results:", searchResults); */
          setAbstractSummaryResults([]);
          setSearchResults(searchResults);
          setIsGridView(false);

          setCurrentPage(1);
          setShowCheckboxes(false);
          setSelectedData([]);
          if (searchResults.length === 0) {
            alert("No data found, please search another");
          }
        } else {
          console.warn("Search response is empty or incorrectly formatted", response.data);
          setSearchResults([]);
          alert("No data found");

        }
      }

      // Reset the search query after performing the search
      setQuery({
        pi_name: '',
        organization_name: '',
        primary_area_of_interest_disease: '',
        abstract_summary: '',
        top_k: 100
      });
    } catch (error) {
      console.error('Error fetching search data:', error);
    }
  };

  const handleVoiceSearch = () => {
    const recognition = new window.webkitSpeechRecognition();
    recognition.lang = 'en-US';
    recognition.interimResults = true;

    recognition.onresult = (event) => {
      let interimTranscript = Array.from(event.results)
        .map(result => result[0].transcript)
        .join('');

      // Remove trailing period if it exists
      interimTranscript = interimTranscript.trim().replace(/\.$/, '');

      setQuery({ ...query, [searchCriterion]: interimTranscript });

      if (event.results[0].isFinal) {
        recognition.stop(); // Stop recognition after final result
        // handleSearch({ ...query, [searchCriterion]: interimTranscript }); // Trigger search with voice query
      }
    };

    recognition.start();

    recognition.onend = () => {
      setIsListening(false); // Set isListening to false when recognition ends
    };

    recognition.onerror = (event) => {
      console.error('Error occurred in recognition:', event.error);
      setIsListening(false); // Set isListening to false if an error occurs
    };
  };


  const handleCriterionChange = (e) => {
    setSearchCriterion(e.target.value);
    setQuery({
      ...query,
      pi_name: '',
      organization_name: '',
      primary_area_of_interest_disease: '',
      abstract_summary: ''
    });
  };

  const handleDownload = () => {
    // Determine the data source based on the active view
    let activeData = [];
    if (searchResults.length > 0) {
      activeData = searchResults;
    } else if (allViewActive) {
      activeData = rows;
    } else if (grantedViewActive) {
      activeData = formattedFilteredData.length > 0 ? formattedFilteredData : rows;
    }

    // Check if abstractSummaryResults is populated and use it for download
    if (abstractSummaryResults && abstractSummaryResults.length > 0) {
      activeData = formattedFilteredData;
    }

    // Extract column headers from the columns array
    const columnHeaders = columns.map((column) => column.field);

    // Generate the CSV content
    const csvContent = [
      columnHeaders.map((header) => `"${header}"`).join(','), // Add column headers as the first row
      ...activeData.map((row) =>
        columnHeaders
          .map((header) => {
            let cellValue = row[header];

            // Handle null values
            if (cellValue === null || cellValue === undefined) {
              cellValue = 'Null';
            } else if (typeof cellValue === 'object' && cellValue !== null) {
              cellValue = JSON.stringify(cellValue);
            } else {
              cellValue = cellValue.toString().replace(/"/g, '""');
            }

            return `"${cellValue}"`; // Encode special characters in the cell value
          })
          .join(',')
      ),
    ].join('\n');

    // Create a Blob containing the CSV content
    const blob = new Blob([csvContent], { type: 'text/csv' });

    // Create a temporary link element to trigger the download
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'tabledata.csv';
    link.click();
  };


  let dataToShow;

  if (abstractSummaryResults.length > 0) {
    dataToShow = abstractSummaryResults;
  } else if (searchResults.length > 0) {
    dataToShow = searchResults;
  } else {
    dataToShow = filteredData;
    //dataToShow = formattedFilteredData;
  }

  return (
    <div className="homepage-container">
      <TopbarNew />
      <div className="sidebar-and-content">
        <Sidebar />
        <div className="homepage-content">
          <div className="Dashboard">
            <h4 className="dashboard-heading">Grants Dashboard</h4>
            <Overview />
            <div className="section1">
              <div className="buttons-section">
                <button
                  type="button"
                  className={`btn rbtn ${grantedViewActive ? "active" : ""}`}
                  onClick={handleGrantedViewClick}
                >
                  Recommended View
                </button>
                <button
                  type="button"
                  className={`btn abtn ${allViewActive ? "active" : ""}`}
                  onClick={handleAllViewClick}
                >
                  Discover
                </button>
              </div>
              {allViewActive && (
                <div className="inputsection">
                  <div className="searchh-container">
                    <div className="select-wrapper">
                      <select
                        value={searchCriterion}
                        onChange={handleCriterionChange}
                      >
                        <option value="pi_name">PI Name</option>
                        <option value="organization_name">Organization Name</option>
                        <option value="primary_area_of_interest_disease">Primary Area of Interest/Disease</option>
                        <option value="abstract_summary">Abstract Summary</option>
                      </select>
                    </div>
                    <input
                      type="text"
                      className="no-focus-outline"
                      placeholder="Search"
                      value={query[searchCriterion]}
                      onChange={(e) => setQuery({ ...query, [searchCriterion]: e.target.value })}
                      onKeyPress={(e) => {
                        if (e.key === 'Enter') {
                          handleSearch(); // Trigger search on Enter key press
                        }
                      }}
                    />

                    <IoMdMicrophone
                      className={`microphone-icon ${isListening ? 'listening' : ''}`}
                      onClick={() => {
                        if (!isListening) {
                          setIsListening(true);
                          handleVoiceSearch();
                        }
                      }}
                    />
                    <div className="search-icon">
                      <button onClick={handleSearch}><IoMdSend /></button>
                    </div></div>
                </div>

              )}
              <div className="section2">

                <Mapwithsummary
                  data={dataToShow}
                  userCountryCode={userCountryCode}
                />


              </div>
              <div className="section3">

                <div className="icon-section">
                  <CiGrid2H
                    className={`Tileview ${!isGridView ? "active" : ""}`}
                    onClick={handleTileViewClick}
                  />
                  <MdGridOn
                    className={`Gridview ${isGridView ? "active" : ""}`}
                    onClick={handleGridViewClick}
                  />

                  {isGridView && (
                    <button className="download-button" onClick={handleDownload}><GoArrowDown /> Download <RiFileExcel2Fill className="excel-icon" /></button>
                  )}
                  {!isGridView &&
                    <button className="download-button" onClick={handleDownloadButtonClick}>
                      <GoArrowDown /> Download {showCheckboxes ? <AiOutlineFilePpt className="ppt-icon" /> : ""}

                    </button>
                  }
                </div>


                <div className="content-section">

                {!isGridView && (
  <div className="tileview-section w-100">
    <TileView 
      data={dataToShow} 
      setCurrentPage={setCurrentPage} 
      currentPage={currentPage} 
      handleDownloadPPT={handleDownloadPPT} 
      userCountryCode={userCountryCode} 
      showCheckboxes={showCheckboxes} 
      selectedData={selectedData} 
      setSelectedRecords={setSelectedRecords} 
      selectedRecords={selectedRecords} 
    />
  </div>
)}
{isGridView && (
  <div className="datagrid-container col-lg-12 col-md-12 col-12" style={{ flex: '1 1 auto' }}>
    <DataGrid
      rows={searchResults.length > 0 ? searchResults : formattedFilteredData}
      columns={[
        ...columns.filter(
          (column) =>
            column.field !== 'APPROVED_AMOUNT' &&
            column.field !== 'PAYMENT_REMAINING'
        ),
        {
          field: 'APPROVED_AMOUNT',
          headerName: 'Grant Amount',
          renderCell: (params) => (
            <div style={{ display: 'flex', alignItems: 'center' }}>
              {params.value != null && (
                <img
                  src={success}
                  alt="Success"
                  style={{ marginRight: '5px', width: '20px' }}
                />
              )}
              {params.value != null ? `$${params.value.toFixed(2)}` : ''}
            </div>
          ),
        },
        {
          field: 'PAYMENT_REMAINING',
          headerName: 'Pending',
          renderCell: (params) => (
            <div style={{ display: 'flex', alignItems: 'center' }}>
              {params.value != null && (
                <img
                  src={pending}
                  alt="Pending"
                  style={{ marginRight: '5px', width: '20px' }}
                />
              )}
              {params.value != null ? `$${params.value.toFixed(2)}` : ''}
            </div>
          ),
        },
        {
          field: 'cybar_grants_link',
          headerName: 'Link',
          renderCell: (params) => (
            <a
              href={params.row.LINK}
              target="_blank"
              rel="noopener noreferrer"
              style={{ textDecoration: 'underline', color: 'blue', cursor: 'pointer', wordWrap: 'break-word' }}
            >
              Cybar Grants
            </a>
          ),
        },
      ]}
      disablePagination
      className="gridtable"
      style={{ width: '100%', height: '100%', minWidth: '300px' }}
      rowsPerPageOptions={[25, 50, 100]}
      getRowId={(row) => row.REQUEST_ID}
    />
  </div>
)}

                </div>

              </div>

            </div>

          </div>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;
