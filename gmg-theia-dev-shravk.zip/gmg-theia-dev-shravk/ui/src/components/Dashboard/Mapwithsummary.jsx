import React, { useState } from "react";
import {
  GoogleMap,
  LoadScript,
  Marker,
  InfoWindow,
} from "@react-google-maps/api";
import "./Mapwithsummary.css";
import Globe from "../../assets/images/globeIcon.svg";
import usericon from "../../assets/images/user.svg";
import handwave from "../../assets/images/handwave.svg";
import bullets from "../../assets/images/bulletpoints.svg";
import diseaseicon from "../../assets/diseaseicon.svg";
import smallMarkerIcon from "../../assets/images/smallmarker.png"; // Add your small marker icon here
const apiKey = "AIzaSyDx1t1xehKETxiCv0KPsGUGVzo0YXra8ZU"; // Replace with your Google Maps API key

const Mapwithsummary = ({ data, userCountryCode }) => {

  const BU = data && data.length > 0 ? data[0][75] : '';
  const role = data && data.length > 0 ? data[0][78] : '';
  const Disease = data && data.length > 0 ? data[0][76] : '';
  const [selectedMarker, setSelectedMarker] = useState(null);

  const handleMarkerClick = (marker) => {
    setSelectedMarker(marker);
  };

  const transformData = (data) => {
    return data.map((item) => {
      return {
        ...item,
        latitude: item.LATITUDE || item[16],
        longitude: item.LONGITUDE || item[17],
      };
    });
  };

  const transformedData = transformData(data);

  return (
    <div className="summary-container">
      <div className="summary">
        <div className="column-summary">
          <div className="profile-header">
            <h2>Summary</h2>
          </div>
          <div className="summary-row">
            <div className="summary-column">
              <div className="summary-item">
                
                <div className="summary-text">
                  <h3><img src={Globe} alt="country" />Country</h3>
                  <span>{userCountryCode}</span>
                </div>
              </div>
            </div>
            <div className="summary-column">
              <div className="summary-item">
               
                <div className="summary-text">
                 <h3> <img src={diseaseicon} alt="disease icon" /> </h3>
                  <span><strong>Pfizer BU:</strong>{BU} |<strong>Disease:</strong>{Disease}</span>
                </div>
              </div>
            </div>
            <div className="summary-column">
              <div className="summary-item">
              
                <div className="summary-text">
                  <h3>  <img src={usericon} alt="user icon" />Role</h3>
                  <span>{role}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="profile-summary">
          <h5>High Level Summary</h5>
          <hr />
          <h6>
            <img src={handwave} className="imgicon" alt="Handwave" />
            Hi {localStorage.getItem("userName")}, Welcome back
          </h6>
          <p className="small">Here are the latest updates</p>
          <ul>
            <li>
              <img src={bullets} className="imgicon" alt="Bullet points" />
              In the last week 12 grants have been approved with the funding
              total of $2.3M.
            </li>
            <li>
              <img src={bullets} className="imgicon" alt="Bullet points" />
              There are 4 grants that closed last week with outcomes report and
              publications below.
            </li>
            <li>
              <img src={bullets} className="imgicon" alt="Bullet points" />
              Currently 5 grants ongoing need your attention and are flagged by
              our AI for your review.
            </li>
          </ul>
        </div>
      </div>
      <div className="map">
  <LoadScript googleMapsApiKey={apiKey}>
    <GoogleMap
      mapContainerStyle={{ width: "100%", height: "440px" ,borderRadius:'10px'}} 
      center={{
        lat: transformedData[0] ? parseFloat(transformedData[0].latitude) : 0,
        lng: transformedData[0] ? parseFloat(transformedData[0].longitude) : 0,
      }}
      zoom={2}
    >
      {transformedData.map((row, index) => (
        <Marker
          key={index}
          position={{
            lat: parseFloat(row.latitude),
            lng: parseFloat(row.longitude),
          }}
          onClick={() => handleMarkerClick(row)}
          icon={{
            url: smallMarkerIcon,
            scaledSize: new window.google.maps.Size(20, 20), // Adjust the size as needed
          }}
        />
      ))}
      {selectedMarker && (
        <InfoWindow
          position={{
            lat: parseFloat(selectedMarker.latitude),
            lng: parseFloat(selectedMarker.longitude),
          }}
          onCloseClick={() => setSelectedMarker(null)}
        >
          <div>{selectedMarker.REQUEST_ID || selectedMarker[0]}</div>
        </InfoWindow>
      )}
    </GoogleMap>
  </LoadScript>
</div>

    </div>
  );
};

export default Mapwithsummary;
