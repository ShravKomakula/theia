
import logo from '../../assets/images/Pfizer-Logo-Color-RGB 1.svg';
import { abstractsummaryEndpoint } from '../../common/api-config';

const generateFellowshipPPt = (pptx,selectedData) => {


  // Slide 1: Create a slide
  const slide = pptx.addSlide();
  const data = selectedData; // Access the first array in selectedData

    
  const formatDate = (dateString) => {
    if (!dateString) return 'null'; // Handle null or undefined dates gracefully
    const date = new Date(dateString);
    return date.toLocaleDateString(); // Format as per locale
  };
  // Example usage: accessing specific fields
  const requestId = data[0] || data.REQUEST_ID || 'null';
  const projectTitle = data[1] || data.PROJECT_TITLE || 'null';
  const piName = data[7] || data.PI_NAME || 'null';
  const organization = data[6] || data.ORGANIZATION_NAME || 'null';
  const grantAmount = data[3] || data.APPROVED_AMOUNT || 'null';
  const pending = data[4] || data.PAYMENT_REMAINING || 'null';
  const bu = data[38] || data.PFIZER_BUSINESS_UNIT_BU_CLUSTER || 'null';
  const pai = data[18] || data.PRIMARY_AREA_OF_INTERST_DISEASE || 'null';
  const abstractSummary = data[8] || data.ABSTRACT_SUMMARY || 'null';
  const lastUpdate=formatDate(data[10]||data.LAST_UPDATE)||'null';
  const submitDate = formatDate(data[41] || data.GRANT_REQUEST_SUBMIT_DATE) || 'null';
  const projectStartDate =formatDate(data[54] || data.PROJECT_START_DATE)  || 'null';
  const projectEndDate = formatDate(data[55] || data.PROJECT_END_DATE) || 'null';
  const finalApprovalDate = formatDate(data[56] || data.FINAL_APPROVAL_DATE )|| 'null';
  const executedContractDate =formatDate( data[57] || data.EXECUTED_CONTRACT_DT) || 'null';
  const finalReportOutcomeDate = formatDate(data[58] || data.FINAL_REPORT_OUTCOME_DATE) || 'null';
  const studyDesign = data[30] || data.study_design || 'null';
  const researchSetting = data[49] || data.RESEARCH_SETTING || 'null';
  const approver = data[53] || data.APPROVER || 'null';

  // Define common options
  const textOptions = { fontSize: 10, color: '000', align: 'left',fontFace: 'Pfizer Diatype Office Light'  };
  const borderOptions = { line: { color: '000000', width: 1 }, fill: 'FFFFFF' };
  const footerOptions = { fontSize: 8, color: '000000', align: 'left' ,fontFace: 'Pfizer Diatype Office Light' };

  const addBorderedTextGroup = (slide, x, y, width, height, text1, text2, bgColor, borderRadius = 10) => {
    slide.addShape(pptx.ShapeType.rect, { x, y, w: width, h: height, fill: bgColor, radius: borderRadius });
    slide.addText(`${text1}\n${text2}`, { x: x + 0.1, y: y + 0.1, w: width - 0.1, h: height - 0.1, ...textOptions });
  };

  const addHeader = (slide) => {
    slide.addText(`Approved – Projects – Research Fellowship `, { x: 0.5, y: 0.2, w: 9, h: 0.5, fontSize: 18, color: 'FF0000', align: 'left',fontFace: 'Pfizer Diatype Office Light'  });
    slide.addText(`Time stamp `, { x: 8.7, y: 0.2, w: 9, h: 0.3, fontSize: 8, color: 'FF0000' ,fontFace: 'Pfizer Diatype Office Light' });
  };

  const addFooter = (slide) => {
    slide.addImage({ path: logo, x: 0.5, y: 5, w: 1.5, h: 0.3 });
    slide.addText('Business Group Business Subgroup', { x: 2.5, y: 5.1, w: 3.5, h: 0.2, ...footerOptions, color: '0056b3',fontFace: 'Pfizer Diatype Office Light'  });
  };

  const addAbstractSummary = (slide, abstractSummary) => {
    const maxSentences = 1;
    const sentences = abstractSummary.split('.'); // Split into sentences
    let summary = '';
  
    if (sentences.length > maxSentences) {
      summary = sentences.slice(0, maxSentences).join('. ') + '.'; // Join the first sentence and add period
    } else {
      summary = abstractSummary; // If less than 2 sentences, show the entire summary
    }
  
    slide.addShape(pptx.ShapeType.rect, { x: 0.5, y: 1.9, w: 9, h: 1, fill: 'f8f7f7', radius: 10 }); // Add background shape
    slide.addText(`Abstract: ${summary}`, { x: 0.5, y: 1.9, w: 9, h: 1, ...textOptions }); // Add text
  };
  
  
  // Add all the elements to the slide
  addBorderedTextGroup(slide, 0.5, 0.7, 1.5, 0.4, `GrantId: ${requestId}`, '','f8f7f7');
  addBorderedTextGroup(slide, 2.3, 0.7, 5, 0.4, `Title: ${projectTitle}`, `Org: ${organization}`,'f8f7f7');
  addBorderedTextGroup(slide, 7.5, 0.7, 2, 0.4, `$${grantAmount}-$${pending}`, `PI name: ${piName}`,'f8f7f7');
  addBorderedTextGroup(slide, 0.5, 1.3, 3.5, 0.4, `BU: ${bu} + Primary Area Of Interest: ${pai}`,'','f8f7f7');
  addBorderedTextGroup(slide, 5.5, 1.3, 4, 0.4, `Study Details: Study design ${studyDesign}`, `Research Setting: ${researchSetting}`,'f8f7f7');
  addAbstractSummary(slide, abstractSummary);
  slide.addNotes(`Abstract Summart ${abstractSummary}`);
  addBorderedTextGroup(slide, 0.5, 3.2, 1.4, 0.6, `Timeline: ${submitDate}`, '', '68D1FF', 30);
  addBorderedTextGroup(slide, 2, 3.2, 1.4, 0.6, `Final Approval Date: ${finalApprovalDate}`, '', '68D1FF', 30);
  addBorderedTextGroup(slide, 3.5, 3.2, 1.4, 0.6, `Contract Executed Date: ${executedContractDate}`, '', '68D1FF', 40);
  addBorderedTextGroup(slide, 5, 3.2, 1.4, 0.6, `Project Start Date: ${projectStartDate}`, '', '68D1FF', 40);
  addBorderedTextGroup(slide, 6.5, 3.2, 1.4, 0.6, `Project End Date: ${projectEndDate}`, '', '68D1FF', 40);
  addBorderedTextGroup(slide, 8, 3.2, 1.4, 0.6, `Expected Final Report Date: ${finalReportOutcomeDate}`, '', '68D1FF', 40);
 
  addBorderedTextGroup(slide, 0.5, 4, 9, 0.3, `Approver: ${approver}`, '','f8f7f7');
  addBorderedTextGroup(slide, 0.5, 4.4, 9, 0.3, `Last Update: ${lastUpdate}`, '','f8f7f7');

  addHeader(slide); // Add header to slide 1
  addFooter(slide); // Add footer to slide 1


};

export { generateFellowshipPPt };
