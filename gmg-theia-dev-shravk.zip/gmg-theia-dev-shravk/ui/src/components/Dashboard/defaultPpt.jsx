

import logo from '../../assets/images/Pfizer-Logo-Color-RGB 1.svg';
const generateResearchPPT = (pptx,selectedData) => {

  console.log("selectedData-research general",selectedData);
  // Slide 1: Create a slide
  const slide = pptx.addSlide();
  const data = selectedData; // Access the first array in selectedData

  const formatDate = (dateString) => {
    if (!dateString) return 'null'; // Handle null or undefined dates gracefully
    const date = new Date(dateString);
    return date.toLocaleDateString(); // Format as per locale
  };
  // Example usage: accessing specific fields
  const requestId = data.REQUEST_ID || data[0] || 'null'; // Assuming the first field is Request ID
  const projectTitle = data[1] || data.PROJECT_TITLE || 'null';
  const piname=data[7]||data.PI_NAME|| 'null';
  const organization=data[6]||data.ORGANIZATION_NAME||'null';
  const COPI=data[42]||data.PROJECT_LEAD_FULL_NAME_OR_CO_PI||'null';
  const grantamount=data[3]||data.APPROVED_AMOUNT|| 'null';
  const pending=data[4]||data.PAYMENT_REMAINING || 'null';
  const bu=data[38]||data.PFIZER_BUSINESS_UNIT_BU_CLUSTER||'null';
  const pai=data[18]||data.PRIMARY_AREA_OF_INTERST_DISEASE||'null';

  const projecttype=data[44]||data.PROJECT_TYPE_DER||'null';

  const abstarctsummary=data[8]||data.ABSTRACT_SUMMARY||'null';
  const lastupdate=formatDate(data[10]||data.LAST_UPDATE)||'null';
  const statusinsights=data[23]||data.STATUS_INSIGHT||'null';
  const Patientinsights=data[24]||data.PATIENT_INSIGHT ||'null';
  const population=data[28]||data.Population||'null';

  const submitDate = formatDate(data[41] || data.GRANT_REQUEST_SUBMIT_DATE) || 'null';
  const projectStartDate =formatDate(data[54] || data.PROJECT_START_DATE)  || 'null';
  const projectEndDate = formatDate(data[55] || data.PROJECT_END_DATE) || 'null';
  const finalApprovalDate = formatDate(data[56] || data.FINAL_APPROVAL_DATE )|| 'null';
  const executedContractDate =formatDate( data[57] || data.EXECUTED_CONTRACT_DT) || 'null';
  const finalReportOutcomeDate = formatDate(data[58] || data.FINAL_REPORT_OUTCOME_DATE) || 'null';
  const studyDesign = data[30] || data.study_design || 'null';
  const researchSetting = data[49] || data.RESEARCH_SETTING || 'null';
  const approver = data[53] || data.APPROVER || 'null';
const fsv=formatDate(data[59]||data.ESTIMATED_FIRST_PATIENT_ENROLLMENT)||'null';
const lpv=formatDate(data[62]||data.ESTIMATED_LAST_PATIENT_ENROLLMENT)||'null';
const fsvdate=formatDate(data[60]||data.FIRST_PATIENT_ENROLLMENT)||'null';
const lpvdate=formatDate(data[61]||data.LAST_PATIENT_ENROLLMENT)||'null';
const latesterollment=data[63]||data.LATEST_ENROLLMENT_NUMBER||'null';
const primarycountry=data[50]||data.PRIMARY_COUNTRY_SITE||'null';
const numofsites=data[51]||data.NUMBER_OF_SITES||'null';
const duration=data[21]||data.DURATION||'null';
const totalsubjectenrollment=data[22]||data.TOTAL_SUBJECT_ENROLLMENT||'null';
const projectbarriers=data[11]||data.PROJECT_BARRIERS||'null';
const nextprojectupdate=formatDate(data[72]||data.NEXT_PROJECT_UPDATE)||'null';
  // Define common options
  const textOptions = { fontSize: 10, color: '000', align: 'left' ,fontFace: 'Pfizer Diatype Office Light' };
  const borderOptions = { line: { color: '000000', width: 1 }, fill: 'FFFFFF' ,fontFace: 'Pfizer Diatype Office Light' };
  const footerOptions = { fontSize: 8, color: '000000', align: 'left',fontFace: 'Pfizer Diatype Office Light'  };

  const addBorderedTextGroup = (slide, x, y, width, height, text1, text2, bgColor, borderRadius = 10) => {
    slide.addShape(pptx.ShapeType.rect, { x, y, w: width, h: height, fill: bgColor, radius: borderRadius });
    slide.addText(`${text1}\n${text2}`, { x: x + 0.1, y: y + 0.1, w: width - 0.1, h: height - 0.1, ...textOptions });
  };

  const addHeader = (slide) => {
    slide.addText(`Approved – Projects `, { x: 0.5, y: 0.2, w: 9, h: 0.2, fontSize: 18, color: 'FF0000', align: 'left' });
    slide.addText(`Time stamp `, { x: 8.7, y: 0.2, w: 9, h: 0.2, fontSize: 8, color: 'FF0000',fontFace: 'Pfizer Diatype Office Light' ,fontFace: 'Pfizer Diatype Office Light'  });
  };

  const addFooter = (slide) => {
    slide.addImage({ path: logo, x: 0.55, y: 5.3, w: 1.5, h: 0.3 });
    slide.addText('Business Group Business Subgroup', { x: 3.5, y: 5.3, w: 3.5, h: 0.3, ...footerOptions, color: '0056b3',fontFace: 'Pfizer Diatype Office Light'  });
  };

  const addAbstractSummary = (slide, abstractSummary) => {
    const maxSentences = 1;
    const sentences = abstractSummary.split('.'); // Split into sentences
    let summary = '';
  
    if (sentences.length > maxSentences) {
      summary = sentences.slice(0, maxSentences).join('. ') + '.'; // Join the first sentence and add period
    } else {
      summary = abstractSummary; // If less than 2 sentences, show the entire summary
    }
  
    slide.addShape(pptx.ShapeType.rect, { x: 0.5, y: 2.5, w: 9, h: 0.5, fill: 'f8f7f7', radius: 10 }); // Add background shape
    slide.addText(`Abstract: ${summary}`, { x: 0.5, y: 2.5, w: 9, h: 0.5, ...textOptions }); // Add text
  };
  const addLatestUpdate = (slide, projectbarriers) => {
    const maxSentences = 1;
    const sentences = projectbarriers.split('.'); // Split into sentences
    let Lupdate = '';
  
    if (sentences.length > maxSentences) {
      Lupdate = sentences.slice(0, maxSentences).join('. ') + '.'; // Join the first sentence and add period
    } else {
      Lupdate = projectbarriers; // If less than 2 sentences, show the entire summary
    }
    slide.addShape(pptx.ShapeType.rect, { x: 0.5, y: 4.3, w: 3, h: 0.3, fill: 'f8f7f7', radius: 10 }); // Add background shape
    slide.addText(`Progress info & Latest Update: ${Lupdate}`, { x: 0.5, y: 4.3, w: 3, h: 0.3, ...textOptions }); // Add text
  };
 
  const addEnrollmentDetails = (slide, x, y, width, texts) => {
    // Add background shape for the entire block
    slide.addShape(pptx.ShapeType.rect, { x, y, w: width, h:1.4, fill: 'f8f7f7', radius: 10 });
  
    // Add each bullet point
    let startY = y + 0.2; // Start slightly below the top to leave space
    texts.forEach((text, index) => {
      slide.addText(`• ${text}`, { x: x + 0.1, y: startY, w: width - 0.1, h: 0.2, ...textOptions });
      startY += 0.2; // Increase Y position for the next bullet point
    });
  };
  
  // Modify slide section for Enrollment Details
 
  // Slide 1: Add bordered text group for 'Title' and 'Org'
  addBorderedTextGroup(slide, 0.5, 0.4, 1.5, 0.4, `GrantId: ${requestId}`, '','f8f7f7');
  addBorderedTextGroup(slide, 2.5, 0.4, 7, 0.4, `Title: ${projectTitle}`, ``,'f8f7f7');
  
  addBorderedTextGroup(slide, 0.5, 0.9, 3, 0.4, `BU: ${bu} + Primary Area Of Interest: ${pai}`,'','f8f7f7');
  addBorderedTextGroup(slide, 4.5, 0.9, 2, 0.4, `$${grantamount}-$${pending}`, ``,'f8f7f7');
  addBorderedTextGroup(slide, 7.5, 0.9, 2, 0.4, `CO PI${COPI}`, `PI name: ${piname}`,'f8f7f7');

  
  addBorderedTextGroup(slide, 0.5,1.4, 4, 0.4, `Organization: ${organization}`,``,'f8f7f7');

  addBorderedTextGroup(slide, 5.5,1.4, 4, 0.4, `Study Details: ${projecttype},${studyDesign}`,`research setting:${researchSetting}`,'f8f7f7');

 
  addBorderedTextGroup(slide, 0.5, 1.9, 4, 0.5, `Primary Site Country:${primarycountry} ,Number of Sites:${numofsites}`,'','f8f7f7');
  addBorderedTextGroup(slide, 6.5, 1.9, 3, 0.5, `patients Info ${population}`, ' ','f8f7f7');

  addAbstractSummary(slide, abstarctsummary);
  slide.addNotes(`Abstract Summary ${abstarctsummary}`);
  addBorderedTextGroup(slide, 0.5, 3.1, 9, 0.5, `Primary&Secondary Enpoint,last update:${lastupdate}`,'','f8f7f7');

  addBorderedTextGroup(slide, 0.5, 3.7, 1.4, 0.5, `Timeline: ${submitDate}`  ,'','68D1FF',30);
  addBorderedTextGroup(slide, 2, 3.7, 1.4, 0.5,`Final Approval Date:${finalApprovalDate}`,``,'68D1FF','30');
  addBorderedTextGroup(slide, 3.5, 3.7, 1.4, 0.5,`Contract Executed Date:${executedContractDate}`,'','68D1FF',40);
  addBorderedTextGroup(slide, 5, 3.7, 1.4, 0.5,`Project Start Date:${projectStartDate}`,'','68D1FF',40);
  addBorderedTextGroup(slide, 6.5, 3.7, 1.4, 0.5,`Project End Date:${projectEndDate}`,'','68D1FF',40,);
  addBorderedTextGroup(slide, 8,3.7, 1.4, 0.5,`expected Final Report Date:${finalReportOutcomeDate}`,'','68D1FF',40);
  addAbstractSummary(slide, projectbarriers);
  slide.addNotes(`latest update:- ${projectbarriers}`);
  
  addBorderedTextGroup(slide, 5.5, 4.2, 4, 1.4, 'Enrollment Details', '', 'f8f7f7'); // Adjusted height for the whole block
  addEnrollmentDetails(slide, 5.5, 4.2, 4, [
    `Estimated first Patient Enrollment FSV date: ${fsv}`,
    `Estimated Last Patient Visit Date: ${lpv}`,
    `Actual: FPV: <${fsvdate}> to LPV: ${lpvdate}`,
    `Last update: ${lastupdate}`,
    `Latest enrollment ${latesterollment}/${totalsubjectenrollment} Patient insights`,
    `Theia Enrollment Insights: ${Patientinsights}`
  ]);
  
  
  addBorderedTextGroup(slide, 0.5,4.3, 4, 0.3,`Dutration :${duration}`,`insights status:${statusinsights}`,'f8f7f7',40);
  addBorderedTextGroup(slide, 0.5,4.7, 4, 0.2,`Approver ${approver}`,``,'f8f7f7',40);
  addBorderedTextGroup(slide, 0.5,5.1, 4, 0.2,`next expected update${nextprojectupdate}`,'','f8f7f7',40);
  
  addHeader(slide); // Add header to slide 1
  addFooter(slide); // Add footer to slide 1
 /*  // Save the presentation
  pptx.writeFile({ fileName: 'General Research Grant' }); */
};

export { generateResearchPPT };
