import React, { useState } from 'react';
import './Graph.css'; // You can define your styles in this CSS file
import TopbarNew from '../../common/TopbarNew';
import { CiBellOn,CiUser,CiHome,CiChat2 } from "react-icons/ci";
import { HiOutlineDocumentText } from "react-icons/hi2";
import { BsBarChart} from "react-icons/bs";
import { IoSettingsOutline } from "react-icons/io5";
import ScientificProfilesPage from '../GraphUI';
import HomePage from '../Home';

const Graph = () => {
  const [selectedNavItem, setSelectedNavItem] = useState('home');

  const handleNavItemClick = (item) => {
    setSelectedNavItem(item);
  };

  return (
    <>
    <TopbarNew />
    <div className="profile">
      {/* Sidebar */}
      <div className="sidebarNav">
       
        <ul className="nav">
        <li>MAIN
          <li className={selectedNavItem === 'home' ? 'active' : ''} onClick={() => handleNavItemClick('home')}>
           <CiHome/>&nbsp;Home
          </li>
          <li className={selectedNavItem === 'dashboard' ? 'active' : ''} onClick={() => handleNavItemClick('dashboard')}>
          <CiUser/>&nbsp;Dashboard
          </li>
          </li>
          <li >
            APPS
         
              <li className={selectedNavItem === 'grant' ? 'active' : ''} onClick={() => handleNavItemClick('grant')}>
              <HiOutlineDocumentText/>&nbsp;Grant View
              </li>
              <li className={selectedNavItem === 'chart' ? 'active' : ''} onClick={() => handleNavItemClick('chart')}>
               <CiChat2/>&nbsp;Chat
              </li>
              <li className={selectedNavItem === 'draft' ? 'active' : ''} onClick={() => handleNavItemClick('draft')}>
               <BsBarChart/>&nbsp;Draft Outcomes
              </li>
      
          </li>
          <li >
            DISCOVER
       
              <li className={selectedNavItem === 'impact' ? 'active' : ''} onClick={() => handleNavItemClick('impact')}>
               <CiBellOn className='svg'/>&nbsp;Impact & Outcomes
              </li>
              <li className={selectedNavItem === 'experts' ? 'active' : ''} onClick={() => handleNavItemClick('experts')}>
               <IoSettingsOutline/>&nbsp;Scientific Experts
              </li>
         
          </li>
        </ul>
      </div>
      
      {/* Main Content */}
      <div className="Graphmain-content">
        {/* Content for each selected nav item */}
        {selectedNavItem === 'home' && <div><HomePage /></div>}
        {/* {selectedNavItem === 'dashboard' && <div><Dashbaord /></div>} */}
        {selectedNavItem === 'grant' && <div>Grant View Content</div>}
        {selectedNavItem === 'chart' && <div>Chart Content</div>}
        {selectedNavItem === 'draft' && <div>Draft Outcomes Content</div>}
        {selectedNavItem === 'impact' && <div>Impact Outcomes Content</div>}
        {selectedNavItem === 'experts' && <div><ScientificProfilesPage/></div>}
        {/* {selectedNavItem === 'experts' && <GraphUI />} */}
      </div>
    </div>
    </>
  
  );
};

export default Graph;
