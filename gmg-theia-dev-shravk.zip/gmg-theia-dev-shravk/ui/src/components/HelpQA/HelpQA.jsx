import React from 'react';

import History from '../History/History';
import { useNavigate } from "react-router-dom";
import "./helpqa.css"
const HelpQA = () => {
const navigate=useNavigate();
   const gotoHistory= () => {
    navigate("/History");
  };
    return (
        <>
            <div className='topbar'>
             
            </div>
<div className='helpqa-content'>
<h1 className='main-heading' onClick={gotoHistory}>Theia AI History and Feedback Log</h1>
</div>
          
           
        </>
    )
}

export default HelpQA;
