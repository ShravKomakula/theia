import React, { useState, useEffect } from "react";
import "./ScientificProfilesPage.css"; // You can define your styles in this CSS file
import { CiLocationOn, CiSearch } from "react-icons/ci";
import { MdClose } from "react-icons/md"; // Import close icon
import axios from "axios"; // Import axios for HTTP requests
import { ScientificProfileData } from "../../common/api-config";
import { FaUser } from "react-icons/fa";
import GoogleMapReact from "google-map-react"; // Import Google Map React library

const ScientificProfilesPage = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [profiles, setProfiles] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [profilesPerPage, setProfilesPerPage] = useState(8);
  const [isMapView, setIsMapView] = useState(false); // State to track map or grid view

  useEffect(() => {
    // Fetch data from the API when the component mounts
    axios
      .get(ScientificProfileData(), {})
      .then((response) => {
        setProfiles(response.data);
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
      });
  }, []); // Empty dependency array ensures the effect runs only once when the component mounts

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  const toggleView = () => {
    setIsMapView(!isMapView);
  };

  // Logic to get profiles for the current page
  const indexOfLastProfile = currentPage * profilesPerPage;
  const indexOfFirstProfile = indexOfLastProfile - profilesPerPage;
  const currentProfiles = profiles.slice(
    indexOfFirstProfile,
    indexOfLastProfile
  );

  // Change page
  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  return (
    <div className="container">
      <h4>Scientific Experts</h4>
      <div className="search-filter">
        <input
          type="text"
          placeholder="Search Scientists"
          className="search-bar"
        />
        <div className="gap"></div>
        <button className="filter-option" onClick={toggleSidebar}>
          Filter (0) None
        </button>
        <button className="view-map-btn" onClick={toggleView}>
          <CiLocationOn /> {isMapView ? "View on Grid" : "View on Map"}

        </button>
      </div>
      {isMapView ? (
        <div className="Gmap">
          <GoogleMapReact
            // Set your Google Maps API key here
            bootstrapURLKeys={{ key: "AIzaSyDx1t1xehKETxiCv0KPsGUGVzo0YXra8ZU" }}
            defaultCenter={{ lat: 59.95, lng: 30.33 }}
            defaultZoom={11}
          >
            {/* Add markers for each profile */}
            {currentProfiles.map((profile) => (
              <div
                key={profile.SE_ID}
                lat={profile.latitude} // Assuming latitude and longitude are available in your profile data
                lng={profile.longitude}
                text="My Marker"
              />
            ))}
          </GoogleMapReact>
        </div>
      ) : (
        <div className="card-container">
          {currentProfiles.map((profile) => (
            <ProfileCard
              key={profile.SE_ID}
              name={`${profile.FIRST_NAME} ${profile.LAST_NAME}`}
              degree={profile.DEGREE_S_}
              profession={profile.PROFESSION}
              speciality={profile.SPECIALTY}
              scientificReach={profile.SCIENTIFIC_REACH}
              emergingExpert={profile.EMERGING_EXPERT}
              congressContributions={profile.CONGRESS_CONTRIBUTIONS}
              publications={profile.PUBLICATIONS}
              clinicalTrials={profile.CLINICAL_TRIALS}
              digitalEngagement={profile.DIGITAL_ENGAGEMENT}
            />

          ))}
          <Pagination
            profilesPerPage={profilesPerPage}
            totalProfiles={profiles.length}
            paginate={paginate}
          />
        </div>
      )}

      <Sidebar isOpen={isSidebarOpen} toggleSidebar={toggleSidebar} />
    </div>
  );
};

const ProfileCard = ({
  name,
  speciality,
  degree,
  profession,
  scientificReach,
  emergingExpert,
  congressContributions,
  publications,
  clinicalTrials,
  digitalEngagement,
}) => {
  // Function to generate filled and unfilled dots based on the provided value
  const generateDots = (filledCount, label) => {
    const maxDots = 5;
    const filledDots = Math.min(filledCount, maxDots);
    const unfilledDots = maxDots - filledDots;

    const dots = [];

    // Push filled dots
    for (let i = 0; i < filledDots; i++) {
      dots.push(<span className="filled-dot" key={`filled-dot-${i}`} />);
    }

    // Push unfilled dots
    for (let i = 0; i < unfilledDots; i++) {
      dots.push(<span className="unfilled-dot" key={`unfilled-dot-${i}`} />);
    }

    return (
      <div className="dots">
        {dots}
        <p>
          <strong>{label}</strong>
        </p>
      </div>
    );
  };

  return (
    <div className="profile-card">
      <div className="profile-info">
        <FaUser className="profile-image" /> &nbsp;&nbsp;
        <h6 className="profile-name">{name}</h6>
        <div>
          {" "}
          <p className="degree">{degree}</p>
        </div>
        <p className="speciality">{profession}</p>
      </div>
      <div className="additional-info">
        <div className="reach-expert">
          <p>
            <span className="Sreach">{scientificReach} Reach</span> &nbsp;&nbsp;
            {emergingExpert === "Y" && (
              <span className="emerging-expert">Emerging Expert</span>
            )}
          </p>
        </div>
        <div className="activities">
          <h5>Activities:</h5>
          <div className="activity-line">
            {generateDots(congressContributions, "Congress Contributions")}
            {generateDots(publications, "Publications")}
          </div>
          <div className="activity-line2">
            {generateDots(clinicalTrials, "Clinical Trials")}
            {generateDots(digitalEngagement, "Digital Engagement")}
          </div>
        </div>
      </div>
    </div>
  );
};

const Sidebar = ({ isOpen, toggleSidebar }) => {
  return (
    <div className={`sidebarRight ${isOpen ? "open" : ""}`}>
      <div className="sidebar-content">
        <h5>Filters</h5>

        <h6>Country:</h6>
        <select className="dropdown">
          <option value="country1">Country 1</option>
          <option value="country2">Country 2</option>
          <option value="country3">Country 3</option>
        </select>

        <h6>Organization:</h6>
        <select className="dropdown">
          <option value="org1">Organization 1</option>
          <option value="org2">Organization 2</option>
          <option value="org3">Organization 3</option>
        </select>

        <h6>Scientific Leader</h6>
        <input
          type="search"
          title="Scientific Leader Search"
          className="leaderSearch"
        />
        <h6>Digital Leader</h6>
        <input
          type="search"
          title="Digital Leader Search"
          className="leaderSearch"
        />

        <h6>Emerging Expert</h6>

        <div className="radio">
          <input type="radio" id="yes" name="emergingExpert" value="yes" />
          <label htmlFor="yes" className="emerging">Yes</label>
          <input type="radio" id="no" name="emergingExpert" value="no" />
          <label htmlFor="no" className="emerging">No</label>
        </div>

        <h6>Scientific Reach</h6>
        <div className="check-box">
          <input type="checkbox" id="Local" />
          <label htmlFor="Local">Local Reach</label>
          <input type="checkbox" id="National" />
          <label htmlFor="National">National Reach</label>
        </div>
        <div className="check-box">
          <input type="checkbox" id="regional" />
          <label htmlFor="regional">Regional Reach</label>
          <input type="checkbox" id="global" />
          <label htmlFor="global">Global Reach</label>
        </div>

        <button className="btn-apply" type="submit">
          Apply Filters
        </button>
      </div>
      <MdClose className="close-icon" onClick={toggleSidebar} />
    </div>
  );
};

const Pagination = ({ profilesPerPage, totalProfiles, paginate }) => {
  const pageNumbers = [];

  for (let i = 1; i <= Math.ceil(totalProfiles / profilesPerPage); i++) {
    pageNumbers.push(i);
  }

  return (
    <nav>
      <ul className="pagination">
        {pageNumbers.map((number) => (
          <li key={number} className="page-item">
            <button onClick={() => paginate(number)} className="page-link">
              {number}
            </button>
          </li>
        ))}
      </ul>
    </nav>
  );
};

export default ScientificProfilesPage;
