import { Card, Group, Text, Image, Button, Box, ScrollArea } from '@mantine/core';
import styled from '@emotion/styled'
import copyIconSvg from '../../assets/svg/copy-icon.svg'

const StyleNodeProperty = styled(Card)`
    .text-title {
        font-family: 'Product Sans';
        font-size: 16px;
        font-weight: 400;
        color: #000000;
    }
    .org-button {
        padding: 8px;
        gap: 10px;
        border-radius: 100px;
        border: 1px;
        opacity: 0px;
        background: #0190FF1A;
        border: 1px solid #0190FF;
        color: #000000;
    }
    .text-column-name {
        font-family: Product Sans;
        padding-top: 10px;
        font-size: 14px;
        font-weight: 400;
        line-height: 20px;
        text-align: center;
        color: #00000080;
    }
    .text-column-value {
        font-family: Product Sans;
        font-size: 14px;
        font-weight: 400;
        line-height: 20px;
        text-align: center;
        color: #000000;
    }
`

const NodeProperty = ({ isOpen, toggleSidebar }) => {
    return (
        <ScrollArea h={'100vh'}>
            <StyleNodeProperty withBorder inheritPadding shadow="sm" radius="md">
                <Card.Section withBorder inheritPadding py="xs">
                    <Group justify="space-between">
                        <Text fw={500} className='text-title'>Node Property</Text>
                        <Button size="xs" type='button' className='org-button'>Organization</Button>
                    </Group>
                </Card.Section>
                <Card inheritPadding py="sm" mt={10}>
                    <Card.Section inheritPadding py="sm">
                        <Box>
                            <Group>
                                <Text className='text-column-name'>{`<id>`}</Text>
                            </Group>
                            <Group justify={'space-between'}>
                                <Text className='text-column-value'>{`80896457`}</Text>
                                <Image
                                    src={copyIconSvg}
                                    alt="Frame"
                                    height={12}
                                />
                            </Group>
                        </Box>
                        <Box>
                            <Group>
                                <Text className='text-column-name'>{`facility_golden_id`}</Text>
                            </Group>
                            <Group justify={'space-between'}>
                                <Text className='text-column-value'>{`DD282353`}</Text>
                                <Image
                                    src={copyIconSvg}
                                    alt="Frame"
                                    height={12}
                                />
                            </Group>
                        </Box>
                        <Box>
                            <Group>
                                <Text className='text-column-name'>{`facility_name`}</Text>
                            </Group>
                            <Group justify={'space-between'}>
                                <Text className='text-column-value'>{`Kaiser Permanente-O`}</Text>
                                <Image
                                    src={copyIconSvg}
                                    alt="Frame"
                                    height={12}
                                />
                            </Group>
                        </Box>
                    </Card.Section>
                </Card>
            </StyleNodeProperty>
        </ScrollArea>
    );
}

export default NodeProperty;