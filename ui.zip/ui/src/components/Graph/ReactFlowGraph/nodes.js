import { Node } from 'reactflow';

export const nodes = [
  {
    id: 'a',
    data: {
      label: 'Publication(10)',
      // we need unique ids for the handles (called 'ports' in elkjs) for the layouting
      // an id is structured like: nodeid-source/target-id
      sourceHandles: [{ id: 'a-s-a' }, { id: 'a-s-b' }, { id: 'a-s-c' }],
      targetHandles: [],
    },
    position: { x: 0, y: 0 },
    type: 'elk',
    sourcePosition: 'left',
    style: {
      // padding: '13.17px',
      // gap: '13.17px',
      borderRadius: '6.58px',
      border: 'rgba(0, 0, 0, 0.1)',
      stroke: '#fff', 
      color: '#0041d0',
      borderColor: '#0041d0',
      backgroundColor: 'rgba(255, 255, 255, 1)', 
      boxShadow: '0px 3.29px 13.17px 0px #0000001A'
    },
  },
  {
    id: 'b',
    data: {
      label: 'Association(08)',
      sourceHandles: [{ id: 'b-s-a' }, { id: 'b-s-b' }],
      targetHandles: [{ id: 'b-t-a' }, { id: 'b-t-b' }, { id: 'b-t-c' }],
    },
    position: { x: 0, y: 0 },
    type: 'elk',
    sourcePosition: 'left',
    style: {
      // padding: '13.17px',
      // gap: '13.17px',
      borderRadius: '6.58px',
      border: 'rgba(0, 0, 0, 0.1)',
      stroke: '#fff', 
      color: '#0041d0',
      borderColor: '#0041d0',
      backgroundColor: 'rgba(255, 255, 255, 1)', 
      boxShadow: '0px 3.29px 13.17px 0px #0000001A'
    },
  },
  {
    id: 'c',
    data: {
      label: 'Digital Reach focus area (04)',
      sourceHandles: [{ id: 'c-s-a' }, { id: 'c-s-b' }],
      targetHandles: [{ id: 'c-t-a' }, { id: 'c-t-b' }, { id: 'c-t-c' }],
    },
    position: { x: 0, y: 0 },
    type: 'elk',
    sourcePosition: 'left',
    style: {
      // padding: '13.17px',
      // gap: '13.17px',
      borderRadius: '6.58px',
      border: 'rgba(0, 0, 0, 0.1)',
      stroke: '#fff', 
      color: '#0041d0',
      borderColor: '#0041d0',
      backgroundColor: 'rgba(255, 255, 255, 1)', 
      boxShadow: '0px 3.29px 13.17px 0px #0000001A'
    },
  },
  {
    id: 'd',
    data: {
      label: 'Scientific Focus Area(12)',
      sourceHandles: [{ id: 'd-s-a' }],
      targetHandles: [{ id: 'd-t-a' }, { id: 'd-t-b' }, { id: 'd-t-c' }],
    },
    position: { x: 0, y: 0 },
    type: 'elk',
    sourcePosition: 'left',
    style: {
      // padding: '13.17px',
      // gap: '13.17px',
      borderRadius: '6.58px',
      border: 'rgba(0, 0, 0, 0.1)',
      stroke: '#fff', 
      color: '#0041d0',
      borderColor: '#0041d0',
      backgroundColor: 'rgba(255, 255, 255, 1)', 
      boxShadow: '0px 3.29px 13.17px 0px #0000001A'
    },
  },
  {
    id: 'e',
    data: {
      label: 'Speciality(04)',
      sourceHandles: [{ id: 'e-s-a' }],
      targetHandles: [{ id: 'e-t-a' }],
    },
    position: { x: 0, y: 0 },
    type: 'elk',
    sourcePosition: 'left',
    style: {
      // padding: '13.17px',
      // gap: '13.17px',
      borderRadius: '6.58px',
      border: 'rgba(0, 0, 0, 0.1)',
      stroke: '#fff', 
      color: '#0041d0',
      borderColor: '#0041d0',
      backgroundColor: 'rgba(255, 255, 255, 1)', 
      boxShadow: '0px 3.29px 13.17px 0px #0000001A'
    },
  },
  {
    id: 'f',
    data: {
      label: 'Medical Event(28)',
      sourceHandles: [{ id: 'f-s-a' }],
      targetHandles: [{ id: 'f-t-a' }, { id: 'f-t-b' }],
    },
    position: { x: 0, y: 0 },
    type: 'elk',
    sourcePosition: 'left',
    style: {
      // padding: '13.17px',
      // gap: '13.17px',
      borderRadius: '6.58px',
      border: 'rgba(0, 0, 0, 0.1)',
      stroke: '#fff', 
      color: '#0041d0',
      borderColor: '#0041d0',
      backgroundColor: 'rgba(255, 255, 255, 1)', 
      boxShadow: '0px 3.29px 13.17px 0px #0000001A'
    },
  },
  {
    id: 'g',
    data: {
      label: 'Payment(12)',
      sourceHandles: [{ id: 'g-s-a' }],
      targetHandles: [{ id: 'g-t-a' }, { id: 'g-t-b' }],
    },
    position: { x: 0, y: 0 },
    type: 'elk',
    sourcePosition: 'left',
    style: {
      // padding: '13.17px',
      // gap: '13.17px',
      borderRadius: '6.58px',
      border: 'rgba(0, 0, 0, 0.1)',
      stroke: '#fff', 
      color: '#0041d0',
      borderColor: '#0041d0',
      backgroundColor: 'rgba(255, 255, 255, 1)', 
      boxShadow: '0px 3.29px 13.17px 0px #0000001A'
    },
  },
];
