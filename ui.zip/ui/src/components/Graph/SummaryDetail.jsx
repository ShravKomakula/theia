import {
    Flex, Card,
    Text, Group,
    Avatar,
    Input,
    Select,
    SimpleGrid,
    ScrollArea
} from '@mantine/core';
import { BarChart } from '@mantine/charts';
import styled from '@emotion/styled'
import ellipseSvg from '../../assets/svg/Ellipse.svg'
import { data } from './data';

const images = [
    ellipseSvg,
    ellipseSvg,
    ellipseSvg,
    ellipseSvg,
    ellipseSvg,
    ellipseSvg,
    ellipseSvg,
    ellipseSvg
];

const StyleRightSection = styled(Card)`
    .text-title {
        font-family: Product Sans;
        padding-top: 5px;
        font-size: 14px;
        font-weight: 400;
        color: #161616;
    }
    .text-desc {
        font-family: Product Sans;
        font-size: 14px;
        font-weight: 400;
        color: #16161680;
    }
    .text-payment-value {
        font-family: Product Sans;
        font-size: 14px;
        font-weight: 400;
        line-height: 24.26px;
        text-align: left;
        color: #344BFD;
    }
    .text-initiatives {
        font-family: Product Sans;
        padding-top: 10px;
        font-size: 14px;
        font-weight: 400;
        color: #2B01BE;
    }
    .related-scientists {
        color: #2B01BE1A;
    }
`

const SummaryDetail = () => {
    return (
        <ScrollArea h={'100vh'}>
            <StyleRightSection withBorder shadow="sm" radius="md">
                <Card.Section withBorder inheritPadding py="xs">
                    <Group>
                        <Avatar radius="xl" />
                        <Text fw={500}>Silvio Danese, MD,Phd</Text>
                    </Group>
                </Card.Section>
                <Text size="sm" className='text-title'>Career Summary</Text>
                <Text mt="5" c="dimmed" size="sm" className='text-desc' mb={'sm'}>
                    Career A dedicated and accomplished Medical Scientist with extensive experience in biomedical research and clinical laboratory investigations.
                </Text>
                <Card.Section withBorder inheritPadding py="xs">
                    <Group pb={10}>
                        <Text size="sm" className='text-title'>Total Engagements/Payments</Text>
                        <Text size="sm" className='text-payment-value'>$4650</Text>
                    </Group>
                    <Flex
                        direction={{ base: 'column', sm: 'row' }}
                    // gap={{ base: 'sm', sm: 'lg' }}
                    // justify={{ sm: 'center' }}
                    >
                        <Input placeholder="$9458" />
                        <Select
                            placeholder="2023"
                            value={'2023'}
                            data={['2023', '2022', '2021', '2020']}
                        />
                    </Flex>
                    <BarChart
                        h={200}
                        data={data}
                        pt={20}
                        withBarValueLabel
                        dataKey="month"
                        series={[
                            { name: 'Smartphones', color: 'violet.6' },
                            { name: 'Laptops', color: 'blue.6' },
                            { name: 'Tablets', color: 'teal.6' },
                        ]}
                        tickLine="none"
                        withYAxis={false}
                    />
                </Card.Section>
                <Card.Section withBorder inheritPadding py="xs">
                    <Group pb={5}>
                        <Text size="sm" className='text-title'>Recent Pfizer Engagements/Initiatives</Text>
                    </Group>
                    <Card withBorder shadow="sm" radius="md">
                        <Card.Section withBorder inheritPadding py="xs">
                            <Text size="sm" className='text-title'>Grant Request 01</Text>
                        </Card.Section>
                        <Text size="sm" className='text-initiatives'>Finding payments of a scientist from 2023</Text>
                    </Card>
                </Card.Section>
                <Card.Section withBorder inheritPadding py="xs">
                    <Group pb={5}>
                        <Text size="sm" className='text-title'>Related Scientists (09)</Text>
                    </Group>
                    <Card.Section inheritPadding mt="sm" pb="md">
                        <SimpleGrid cols={4} className='related-scientists'>
                            {images.map((image) => (
                                <Avatar src={image} radius="xl" />
                            ))}
                        </SimpleGrid>
                    </Card.Section>
                </Card.Section>
            </StyleRightSection>
        </ScrollArea>
    )
}

export default SummaryDetail