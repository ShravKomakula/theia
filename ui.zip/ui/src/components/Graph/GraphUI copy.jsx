import React, { Fragment, useMemo, useState } from 'react'
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import Stack from 'react-bootstrap/Stack';
import ReactFlow, {
    Controls,
    Background,
    BackgroundVariant,
    MiniMap,
    useNodesState,
    useEdgesState,
} from 'reactflow';

import ElkNode from './ReactFlowGraph/ElkNode';
import { nodes as initNodes } from './ReactFlowGraph/nodes';
import { edges as initEdges } from './ReactFlowGraph/edges';
import useLayoutNodes from './ReactFlowGraph/useLayoutNodes';
import 'reactflow/dist/style.css';
import NodeProperty from './NodeProperty';

const GraphUI = () => {
    const [nodes, , onNodesChange] = useNodesState(initNodes);
    const [edges, , onEdgesChange] = useEdgesState(initEdges);
    const [isSidebarOpen, setIsSidebarOpen] = useState(false);
    const proOptions = { hideAttribution: true };

    useLayoutNodes();

    const nodeTypes = useMemo(
        () => ({
            elk: ElkNode,
        }),
        [],
    );

    const onNodeClick = (event, node) => { toggleSidebar(); console.log('click node', node) };
    const onPaneClick = (event) => console.log('onPaneClick', event);

    const toggleSidebar = () => {
        setIsSidebarOpen(!isSidebarOpen);
    };

    const toggleView = () => {

    };

    return (
        <Container fluid>
            <Row>
                <Col>
                    <div className="search-filter">
                        <input
                            type="text"
                            placeholder="Search Scientists"
                            className="search-bar" />
                        <div className="gap"></div>
                        <button className="filter-option" onClick={toggleSidebar}>
                            Filter (0) None
                        </button>
                    </div>
                </Col>
                <Col>
                    <ReactFlow
                        nodes={nodes}
                        edges={edges}
                        onNodesChange={onNodesChange}
                        onEdgesChange={onEdgesChange}
                        fitView
                        nodeTypes={nodeTypes}
                        style={{ background: '#ffff' }}
                        // connectionLineStyle={connectionLineStyle}
                        // snapToGrid={true}
                        // snapGrid={snapGrid}
                        // defaultViewport={defaultViewport}
                        attributionPosition="bottom-left"
                        onNodeClick={onNodeClick}
                        onPaneClick={onPaneClick}
                        proOptions={proOptions}
                    >
                        {/* <Background color="#f1f1f1" variant={BackgroundVariant.Cross} /> */}
                        <Controls />
                        <MiniMap />
                    </ReactFlow>
                    <NodeProperty isOpen={isSidebarOpen} toggleSidebar={toggleSidebar} />
                </Col>
            </Row>
        </Container >
    );
};

export default GraphUI;
