import axiosInstance from "./AxiosInstance";

export const apiRequest = async (request) => {
    // let localStorageDetails = localStorage.getItem('user');
    // localStorageDetails = JSON.parse(localStorageDetails);
    // if(localStorageDetails && localStorageDetails.loginType === 'SSO') {
    //   const respValidateTokenReq = validateAuthTokenRequest({token: localStorageDetails.tokenInfo.access_token});
    //   respValidateTokenReq.then((respToken) => {
    //     if(respToken.status !== 200) {
    //       localStorage.clear();
    //       window.location.reload();
    //     }
    //   });
    // }
    return await axiosInstance.post('', request).then((result) => {
        return result.data;
    }).catch((err) => {
        if (err.response) {
            return err.response;
        }
        return [];
    });
}

export const getOrganization = async () => {
    return await apiRequest({
        "statements": [
            {
                "statement": `MATCH (se:ScientificExpert) 
            WHERE se.name='Felicia Cosman'
            MATCH (se)-[:CONDUCTED]->(tw:TrialWork)<-[:CONDUCTED]-(org:Organization)
            RETURN DISTINCT {
              facility_citeline_id:org.facility_citeline_id,
              facility_golden_id: org.facility_golden_id,
              facility_name:org.facility_name
            } AS organization`
            }
        ]
    });
}

export const getPublications = async () => {
    return await apiRequest({
        "statements": [
            {
                "statement": `MATCH (se:ScientificExpert) WHERE se.name='Felicia Cosman'
            MATCH (se)-[:PUBLISHED]->(pn:Publication)
            RETURN DISTINCT {
              date:pn.date,
              publication_id:pn.publication_id,
              journal: pn.journal,
              title:pn.title
            } AS publication`
            }
        ]
    });
}

export const getAssociation = async () => {
    return await apiRequest({
        "statements": [
            {
                "statement": `MATCH (se:ScientificExpert) WHERE se.name='Felicia Cosman'
            MATCH (se)-[:ASSOCIATED_IN]->(an:Association)
            RETURN DISTINCT {
              association_name: an.association_name,
              association_type: an.association_type,
              association_id:an.association_id
            } AS association`
            }
        ]
    });
}
