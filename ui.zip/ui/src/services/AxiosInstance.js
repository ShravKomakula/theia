import axios from 'axios'
//QA bolt://10.11.182.205:7687
//Dev https://10.11.163.118:7473/db/neo4j/tx/commit
const axiosInstance = axios.create({
  baseURL: 'https://10.11.163.118:7473/db/neo4j/tx/commit', // Replace with your API base URL
});

// Request interceptor
axiosInstance.interceptors.request.use(
  (config) => {
    if(!config) {
      config = {};
    }
    if(!config.headers) {
      config.headers = {};
    }
    // Modify the request config here (e.g., add headers, authentication tokens)
    // const accessToken = JSON.parse(localStorage.getItem("token"));

    // ** If token is present add it to request's Authorization Header
    // if (accessToken) {
    //   if (config.headers) config.headers.Authorization = `${'Bearer' + ' ' + accessToken}`;
    // }
    const username = 'neo4j';//neo4j
    const password = 'neo4j123';//neo4j@312//neo4j123
    var basicAuth = 'Basic ' + btoa(username + ':' + password);
    config.headers = { 'Content-Type': 'application/json', 'Authorization': + 'Basic ' + basicAuth }
    return config;
  },
  (error) => {
    // Handle request errors here
    return Promise.reject(error);
  }
);

axiosInstance.interceptors.response.use(
  (response) => response,
  (error) => {
    return Promise.reject(error)
  }
)
export default axiosInstance;