import React from 'react';
import { ReactFlowProvider } from 'reactflow';
import { createTheme, MantineProvider } from '@mantine/core';
import Login from '../src/components/LoginPage';
import Queries from '../src/components/Queries';
import Topbar from '../src/common/Topbar';
import LoginView from './components/LoginView/LoginView';
import { ToastContainer } from 'react-toastify';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'react-toastify/dist/ReactToastify.css';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import './App.css';
import Insights from './components/Insights';
import { AuthProvider } from './components/AuthContext';
import AuthWrapper from './components/AuthWrapper';
import LandingPageNew from './components/LandingPageNew';
import History from './components/History/History';
import MyDashboard from './components/MyDashboard/MyDashboard';
import HelpQA from './components/HelpQA/HelpQA';
import Main from './components/Main'
import Graph from './components/Graph'
import '@mantine/core/styles.css';

function App() {
  const theme = createTheme({
    fontFamily: 'Open Sans, sans-serif',
    primaryColor: 'cyan',
  });

  return (
    <MantineProvider theme={theme}>
    <ReactFlowProvider>
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/landing-page" element={
            <AuthWrapper>
              <LandingPageNew />
            </AuthWrapper>
          } />

          <Route path="/" element={
            <AuthWrapper>
              <LoginView />
            </AuthWrapper>
          } />
          <Route path="/auth-redirect" element={
            <AuthWrapper>
              <LoginView />
            </AuthWrapper>
          } />

          <Route path="/queries" element={

            <AuthWrapper>
              <Queries />
            </AuthWrapper>
          } />

          <Route path="/my-dashboard" element={
            <AuthWrapper>
              <MyDashboard />
            </AuthWrapper>
          } />

          <Route path="/insights" element={
            <AuthWrapper>
              <Insights />
            </AuthWrapper>
          } />
          <Route path="/HelpQA" element={
            <AuthWrapper>
              <HelpQA />
            </AuthWrapper>
          } />
          <Route path="/main" element={
            <AuthWrapper>
              <Main />
            </AuthWrapper>
          } />
          <Route path="/graph" element={
            <AuthWrapper>
              <Graph />
            </AuthWrapper>
          } />
          <Route path="/History" element={

            <AuthWrapper>
              <History />
            </AuthWrapper>
          } />


        </Routes>
        <ToastContainer />
      </Router>
    </AuthProvider>
    </ReactFlowProvider>
    </MantineProvider>
  );
}

export default App;
