import React from 'react';
import Chart from 'react-apexcharts';

const BarGraph = () => {
  const chartData = {
    series: [{
      data: [1200, 1500, 450, 700 ]
    }],
    options: {
      chart: {
        type: 'bar',
        height: 350,
        toolbar: {
            show: false
          },
      },
      plotOptions: {
        bar: {
          horizontal: false,
          columnWidth: '55%',
          endingShape: 'rounded'
        },
      },
      dataLabels: {
        enabled: false
      },
      stroke: {
        show: true,
        width: 2,
        colors: ['transparent']
      },
      xaxis: {
        categories: ['Med Ed', 'Research', 'Quality Improvement', 'Fellowship'],
      },
      yaxis: {
        title: {
          text: '',
        },
      },
      fill: {
        opacity: 1
      },
      tooltip: {
        y: {
          formatter: function (val) {
            return "$" + val + "k"
          }
        }
      }
    },
  };

  return (
    <div className="bar-chart">
      <Chart options={chartData.options} series={chartData.series} type="bar" height={350} />
    </div>
  );
};

export default BarGraph;