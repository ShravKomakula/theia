import React, { useState, useEffect } from 'react';
import Chart from 'react-apexcharts';
import './graph.css';

const generateRandomData = () => {
  return Array.from({ length: 7 }, () => Math.floor(Math.random() * 71) + 30); 
};

const PlainBarGraph = ({ icons }) => {
  const [chartData, setChartData] = useState({
    series: [{
      data: generateRandomData()
    }],
    options: {
      chart: {
        type: 'bar',
        height: 350,
        toolbar: {
          show: false
        },
      },
      plotOptions: {
        bar: {
          horizontal: false,
          columnWidth: '75%',
          borderRadius: 4,
          dataLabels: {
            position: 'top'
          },
        },
      },
      colors: ['#2235BA'],
      dataLabels: {
        enabled: true,
        formatter: function (val) {
          return "$" + val + "k";
        },
        offsetY: -320,
        padding: '20px',
        style: {
          fontSize: '12px',
          colors: ["#000"]
        }
      },
      xaxis: {
        categories: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
        labels: {
          show: false,
        },
        axisBorder: {
          show: false,
        },
        axisTicks: {
          show: false,
        },
      },
      yaxis: {
        labels: {
          show: false,
        },
        axisBorder: {
          show: false,
        },
        axisTicks: {
          show: false,
        },
        title: {
          text: undefined,
        },
      },
      fill: {
        opacity: 1
      },
      grid: {
        show: false
      }
    },
  });

  useEffect(() => {
      setChartData((prevState) => ({
        ...prevState,
        series: [{ data: generateRandomData() }]
      }));

    return () => clearInterval(); 
  }, []);

  return (
    <div className="bar-chart-container">
      <div className="bar-chart">
        <Chart options={chartData.options} series={chartData.series} type="bar" height={300} />
      </div>
      <div className="custom-x-axis-labels" style={{ display: 'flex', justifyContent: 'space-around', margin: '0px 1px 0px 15px' }}>
        {icons.map((icon, index) => (
          <div key={index} className="icon-label">
            <img src={icon} alt={`icon-${index}`} style={{ width: '30px', height: '30px' }} />
          </div>
        ))}
      </div>
    </div>
  );
};

export default PlainBarGraph;
