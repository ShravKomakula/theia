
// import Logo from "../../assets/images/logo.png";
import iconMenu1 from '../../assets/images/icons/home-icon.svg';
import iconMenu2 from '../../assets/images/icons/dashboard-icon.svg';
import iconMenu3 from '../../assets/images/icons/file-review-icon.svg';
import iconMenu4 from '../../assets/images/icons/chat-icon.svg';
import iconMenu5 from '../../assets/images/icons/graph-icon.svg';
import iconMenu6 from '../../assets/images/icons/bell-icon.svg';
import iconMenu7 from '../../assets/images/icons/setting-icon.svg';
import { useNavigate } from "react-router-dom";
import { useLocation } from 'react-router-dom';



let SideBar = ({ activeTab }) => {
  let location = useLocation();
  const navigate = useNavigate();

  const isActive = (tabName) => activeTab === tabName;
  const isActiveClass = (tabName) => isActive(tabName) ? 'link-menu-items active' : 'link-menu-items'


  return (
    <div className="asside-menu">
      <div className="menu-side-flex pb-4">
        <div className="menu-wap-area">
          <ul className="menu-items-aside">
            <li className="mt-3"><span className="title-menu-wp">MAIN</span></li>
            <li onClick={() => navigate('/home')} className="menu-side-mnt"><button type="button" className={`btn btn-linkmenu-wb ${location.pathname.includes('home') ? 'active' : ''}`} ><span className="icon-wgt--tems"><img src={iconMenu1} alt="icon" /></span><span className="item-nv-lst">Home</span></button></li>
            <li onClick={() => navigate('/dashboard')} className="menu-side-mnt"><button type="button" className={`btn btn-linkmenu-wb ${location.pathname.includes('dashboard') ? 'active' : ''}`} ><span className="icon-wgt--tems"><img src={iconMenu2} alt="icon" /></span><span className="item-nv-lst">Dashboard</span></button></li>
            <li className="mt-3"><span className="title-menu-wp" >APPS</span></li>
            <li onClick={() => navigate('/review')} className="menu-side-mnt"><button type="button" className={`btn btn-linkmenu-wb ${location.pathname.includes('review') ? 'active' : ''}`} ><span className="icon-wgt--tems"><img src={iconMenu3} alt="icon" /></span><span className="item-nv-lst">Grant review</span></button></li>
            <li onClick={() => navigate('/chat')} className="menu-side-mnt"><button type="button"  className={`btn btn-linkmenu-wb ${location.pathname.includes('chat') ? 'active' : ''}`}><span className="icon-wgt--tems"><img src={iconMenu4} alt="icon" /></span><span className="item-nv-lst">Chat</span></button></li>
            <li   onClick={() => navigate('/compliance')}   className="menu-side-mnt"><button type="button" className={`btn btn-linkmenu-wb ${location.pathname.includes('compliance') ? 'active' : ''}`}><span className="icon-wgt--tems"><img src={iconMenu5} alt="icon" /></span><span className="item-nv-lst">Ops Compliance</span></button></li>
            <li className="mt-3"><span className="title-menu-wp">DISCOVER</span></li>
            <li onClick={() => navigate('/impact')} className="menu-side-mnt"><button type="button" className={`btn btn-linkmenu-wb ${location.pathname.includes('impact') ? 'active' : ''}`}><span className="icon-wgt--tems"><img src={iconMenu6} alt="icon" /></span><span className="item-nv-lst">Impact & Outcomes</span></button></li>
            <li onClick={() => navigate('/scientific-expert')} className="menu-side-mnt"><button type="button" className={`btn btn-linkmenu-wb ${location.pathname.includes('scientific') ? 'active' : ''}`}><span className="icon-wgt--tems"><img src={iconMenu7} alt="icon" /></span><span className="item-nv-lst">Scientific Experts</span></button></li>
          </ul>
        </div>
      </div>
    </div>

  );
}

export default SideBar;
