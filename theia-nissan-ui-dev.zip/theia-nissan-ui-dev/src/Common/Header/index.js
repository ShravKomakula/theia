
import { useNavigate } from "react-router-dom";
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';

import logoCompany from '../../assets/images/pfizerLogo1.svg';
import notifiTopIcon from '../../assets/images/icons/notification-icon.svg';
import serachTopIcon from '../../assets/images/icons/search-icon.svg';
import userPlaceIcon from '../../assets/images/icons/user-place-login.svg';



let Header = ({ activeTab }) => {
  const navigate = useNavigate();


  return (
    <>
       <header className='header-layout'>
          <Container fluid>
            <Row className='align-items-center'>
              <Col xs="4" md="3">
                <div className='logo-brand' >
                  <span className='logo-link-brand'><img src={logoCompany}  /></span>
                </div>
              </Col>
              <Col xs="8" md="9">
                <div className='right-side-nv-areas text-end'>
                  <ul className='items-rght'>
                    <li className='rgt-area-wnt'>
                      <span className='link-icon-wt'>
                        <img src={notifiTopIcon} alt='icon' />
                      </span>
                    </li>
                    <li className='rgt-area-wnt'>
                      <span className='link-icon-wt'>
                        <img src={serachTopIcon} alt='icon' />
                      </span>
                    </li>
                    <li className='rgt-area-wnt'>
                      <span className='link-icon-wt'>
                        Akash
                        <span class="img-user-lg d-inline-block ms-2"><img src={userPlaceIcon} alt='icon' /></span>
                      </span>
                    </li>
                  </ul>
                </div>
              </Col>
            </Row>
          </Container>
        </header>
    
    </>

  );
}

export default Header;
