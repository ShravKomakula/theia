import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import "./assets/css/style.css";
import "./assets/css/responsive.css";
import { Routes, Route, Navigate } from "react-router-dom";
import { Provider } from 'react-redux';
import { Store } from './Redux/Store';

import Home from "./Views/Home"
import Dashboard from "./Views/Dashboard"
import Review from './Views/Review';
import Chat from './Views/Chat';
import Compliance from './Views/Compliance';
import Impact from './Views/Impact';
import Scientific from './Views/Scientifics';
import 'react-toastify/dist/ReactToastify.css';
import { ToastContainer } from 'react-toastify';
import ScientificExpert from './Views/ScentificExpert';
import ImpactDetails from './Views/ImpactDetails';
import Node from './Views/Node'
import DetailPage from './Views/Review/DetailPage';



function App() {
  return (
    <Provider store={Store}>
      <div className="App">
        <Routes>
          <Route path="/" element={<Navigate to="/home" replace />} />
          <Route path="/home" element={<Home />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/review" element={<Review />} />
          <Route path="/review/:id" element={<DetailPage/>} />
          <Route path="/chat" element={<Chat />} />
          <Route path="/compliance" element={<Compliance />} />
          <Route path="/impact" element={<Impact />} />
          <Route path="/impact/:id" element={<ImpactDetails />} />
          <Route path="/scientific-map" element={<Scientific />} />
          <Route path="/scientific-expert" element={<ScientificExpert/>} />
          <Route path="/scientific-node" element={<Node/>} />



        </Routes>
        <ToastContainer />
      </div>
    </Provider>
  );
}

export default App;