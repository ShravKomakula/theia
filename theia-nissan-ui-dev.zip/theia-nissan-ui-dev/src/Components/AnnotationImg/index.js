import React from 'react';
import PropTypes from 'prop-types';
import styled from "styled-components";

// Layers in map
import ImageLayer from "ol/layer/Image";
// import VectorLayer from "ol/layer/Vector";
import VectorImage from 'ol/layer/VectorImage';
import LayerGroup from 'ol/layer/Group';
// to create actual map
import Map from "ol/Map";

// to create a view on map
import View from 'ol/View';

// for image layer
import Projection from "ol/proj/Projection";
import Static from "ol/source/ImageStatic.js";
import { getCenter } from "ol/extent";

// for providing features for the VectorLayer
import VectorSource from "ol/source/Vector";
import { GeoJSON } from 'ol/format';


// for styling
import { Fill, Stroke, Style } from 'ol/style';
// to handle interactions on the map
import { defaults as defaultInteractions, Select } from 'ol/interaction.js'

const IMAGE_LAYER_NAME = "IMAGE_LAYER";
const TEXT_LAYER_NAME = "TEXT_LAYER";
// const VECTOR_LAYER_SELECTED_NAME ="VECTOR_LAYER_SELECTED";
// const VECTOR_LAYER_HOVER_NAME ="VECTOR_LAYER_HOVER";

// selectable boxes
const DEFAULT_FEATURE_OVERLAY_COLOR = 'rgb(234, 237, 237)';
const DEFAULT_FEATURE_OVERLAY_FILL_COLOR = 'rgba(241, 250, 255,0.1)';
const DEFAULT_WIDTH = 0;

// selected boxes
const DEFAULT_HIGHLIGHT_COLOR = '#3399CC';
const DEFAULT_HIGHLIGHT_FILL_COLOR = 'rgba(255,255,255,0.1)';
const DEFAULT_HIGHLIGHT_WIDTH = 3;

// hover on items such as tags
const DEFAULT_HOVER_COLOR = 'rgb(255, 0, 0)';
const DEFAULT_HOVER_FILL_COLOR = 'rgba(241, 250, 255,0.2)';
const DEFAULT_HOVER_WIDTH = 3;

const DEFAULT_FEATURE_JSON = {
  'type': 'FeatureCollection',
  'crs': {
    'type': 'name',
    'properties': {
      'name': 'EPSG:3857',
    },
  },
  'features': []
}

const createStyle = (color, fillColor, width) => {
  return new Style({
    stroke: new Stroke({
      color: color ? color : DEFAULT_FEATURE_OVERLAY_COLOR,
      width: width ? width : DEFAULT_WIDTH,
    }),
    fill: new Fill({
      color: fillColor ? fillColor : DEFAULT_FEATURE_OVERLAY_FILL_COLOR,
    }),
  })
}

export default class OCR extends React.Component {

  constructor(props) {
    super(props);
    this.mapElement = React.createRef();
    this.imageExtent = [0, 0, 1024, 968];// default image_width, image_height
    this.select = new Select();
    this.selectedFeatures = [];
    this.image = new Image();
    this.layers = [];
    // this.state = {
    //     mounted: false
    // }

  }

  // functionalities on map
  zoomIn = () => {
    this.map.getView().setZoom(this.map.getView().getZoom() + 0.3);
  }

  zoomOut = () => {
    this.map.getView().setZoom(this.map.getView().getZoom() - 0.3);
  }

  resetZoom = () => {
    this.map.getView().setZoom(2);
  }

  rotateLeft = () => {
    this.map.getView().animate({
      rotation: this.map.getView().getRotation() + Math.PI / 2,
    })
  }

  rotateRight = () => {
    this.map.getView().animate({
      rotation: this.map.getView().getRotation() - Math.PI / 2,
    })
  }

  clearSelected = () => {
    // eslint-disable-next-line
    this.selectedFeatures.map(f => {
      f.setStyle(undefined);
    })
    this.selectedFeatures = [];

    if (this.props.sendSelectedFeatures) {
      this.props.sendSelectedFeatures([]);
    }
    this.props.clearSelectedTagsOCRComplete();
    // add existing selected tags
    if (this.props.tagSelected) {
      let data = this.props.tagSelected;
      if (data.values && Array.isArray(data.values) && data.values.length > 0) {
        // eslint-disable-next-line
        this.vectorLayer.getSource().getFeatures().map(feature => {
          for (let index = 0; index < data.values.length; index++) {
            const tag = data.values[index];
            const id = feature.id_;
            if (id === tag.id) {
              this.selectedFeatures.push(feature);
            }
          }
        })
      }
      this.showSelectedFeatures();
      this.sendSelectedFeatures();
    }
  }

  componentDidMount() {

    setTimeout(() => {
      this.initiateComponent();
    }, 1000)
  }

  componentWillUnmount() {

    if (this.map !== undefined) {
      this.map.setLayerGroup(new LayerGroup());
      // let layers = this.map.getLayers().getArray();
      // layers.forEach((layer) =>{
      //     console.log(layer)
      //     this.map.removeLayer(layer);
      // });

      // if(this.vectorLayer !== undefined){
      //     this.vectorLayer.getSource().getFeatures().map(feature => {
      //         this.vectorLayer.getSource().removeFeature(feature);
      //     });

      //     this.map.removeLayer(this.vectorLayer);
      // }

    }
  }

  initiateComponent = () => {
    this.image.onload = () => {
      this.imageExtent = [0, 0, this.image.width, this.image.height];
      this.initializeMap();
    };
    this.image.src = this.props.imgSrc;
  }

  // this is a projection for the static image.
  createProjection = (imageExtend) => {
    return new Projection({
      code: "xkcd-image",
      units: "pixels",
      extent: imageExtend,
    });
  }

  // create a map view (for image)
  createMapView = (projection, imageExtend) => {
    return new View({
      projection,
      center: getCenter(imageExtend),
      zoom: 1.5,
    });
  }

  // creating image source for a image layer
  createImageSource = (imageUri, projection, imageExtend) => {
    return new Static({
      url: imageUri,
      projection,
      imageExtent: imageExtend,
    });
  }

  // creating image layer
  initializeImageLayer = (projection) => {
    return new ImageLayer({
      source: this.createImageSource(this.props.imgSrc, projection, this.imageExtent),
      name: IMAGE_LAYER_NAME,
    });
  }

  // initialize the creation of the map
  initializeMap = () => {
    // create projection for the image
    let keyValue = this.props.keyValue !== undefined ? this.props.keyValue.toString() : "";
    const targetKey = "map" + keyValue;
    const projection = this.createProjection(this.imageExtent);
    this.layers.push(this.initializeImageLayer(projection));
    this.map = new Map({
      controls: [],// with no controls 
      interactions: defaultInteractions({
        shiftDragZoom: false,
        doubleClickZoom: false,
        pinchRotate: false,
      }),
      target: targetKey,
      layers: this.layers,
      view: this.createMapView(projection, this.imageExtent),
    });
    // if ocr data is updated
    this.addTextLayer();

    // add click events
    this.map.on('singleclick', this.mapFeatureSelection);

    // console.log(document.getElementsByClassName("ol-viewport"))
    let olViewportElements = document.getElementsByClassName("ol-viewport");
    if (olViewportElements.length > 1) {
      // console.log(olViewportElements[0])
      olViewportElements[0].style.display = "none"
    }
  }

  addTextLayer = () => {
    if (this.map && this.props.OCRData !== undefined && this.props.OCRData !== null) {
      this.featuresJSON = Object.create(DEFAULT_FEATURE_JSON);
      this.featuresJSON.features = [];// very important line  && block.BlockType !== "QUERY_RESULT"
      for (const block of this.props.OCRData.Blocks) {

        // if (block.BlockType !== "WORD" && block.BlockType !== "LINE") {
        //     continue; // ignoring other data
        // }

        // generate coordinates to render the blocks of word


        let coordinates = [];
        for (let index = 0; index < block.Geometry.Polygon.length; index++) {
          const element = block.Geometry.Polygon[index];
          coordinates.push([(element.X) * this.image.width, (1 - element.Y) * this.image.height])
        }
        this.featuresJSON.features.push({
          'type': 'Feature',
          "id": block.Id,
          "properties": {
            "Text": block.Text ? block.Text : "",
            "Geometry": block.Geometry,
            "Relationships": block.Relationships ? block.Relationships : [],
            "BlockType": block.BlockType,
            "id": block.Id,
          },
          'geometry': {
            'type': 'Polygon',
            'coordinates': [coordinates],
          }
        })


      }

      const vectorSource = new VectorSource({
        features: new GeoJSON().readFeatures(this.featuresJSON),
      });

      this.vectorLayer = new VectorImage({
        source: vectorSource,
        name: TEXT_LAYER_NAME,
        style: createStyle('', '', DEFAULT_WIDTH),
      })
      this.map.addLayer(this.vectorLayer)

    }
  }

  componentDidUpdate(prevProps, prevState) {

    if (this.props.hoveredId !== prevProps.hoveredId) {
      this.hoverSelected(this.props.hoveredId)
    }

    this.hoverOnTags(this.props.hoverOnTags)

    // TODO OCR UPDATE
    // this.addTextLayer(); // CHECK IT IS NEEDED for every prop change or state change TODO
    if (this.props.hoverOffTags) {
      this.hoverOffTags(this.props.hoverOffTags)
    }
    if (this.props.hoverOnTags) {
      this.hoverOnTags(this.props.hoverOnTags)
    }
    if (this.props.clearSelected) {
      this.clearSelected();
    }
  }

  render() {
    // if(this.state.mounted === true){
    //     return "Loading...."
    // }

    let keyValue = this.props.keyValue !== undefined ? this.props.keyValue.toString() : "";
    const targetKey = "map" + keyValue;
    return (
      <MainContainer>
        <MapContainer ref={this.mapElement} id={targetKey} style={{ height: '600px' }}></MapContainer>
      </MainContainer>
    );
  }

  // feature outline i.e texts that can be selected
  // featureOverlay = new VectorLayer({
  //     source: new VectorSource(),
  //     map: this.map,
  //     style: createStyle(this.props.featureOverlayColor, this.props.featureOverlayFillColor),
  // });

  findTextValue = (data, relationshipIds) => {
    const result = [];
    data.forEach(item => {
      if (item.BlockType === "LINE" && item.Relationships && item.Relationships[0].Ids.every(id => relationshipIds.includes(id))) {
        result.push(item.Text);
      }
    });
    return result;
  }

  findIds = (data) => {
    const ids = [];
    data.forEach(obj => {
      if (obj.Ids) {
        obj.Ids.forEach(id => {
          ids.push(id);
        });
      }
    });
    return ids;
  }


  hoverSelected = (id) => {
    if (this.vectorLayer == undefined) return
    this.vectorLayer.getSource().getFeatures().map(async feature => {
      let properties = await feature.getProperties();
      if (properties.id == id) {
        feature.setStyle(createStyle(DEFAULT_HIGHLIGHT_COLOR, DEFAULT_HIGHLIGHT_FILL_COLOR, DEFAULT_HIGHLIGHT_WIDTH));
      }else{
        feature.setStyle(undefined); 
      }
    })
  }

  mapFeatureSelection = async (e) => {
    
    if (this.props.enableFeatureSelection === false)
      return
    await this.map.forEachFeatureAtPixel(e.pixel, async (f) => {
      const selIndex = this.selectedFeatures.indexOf(f);
      if (selIndex < 0) {

        this.selectedFeatures.push(f);
        let properties = await f.getProperties();
        let text = this.props.getChild([], properties.id)
        this.props.setText(text)
        if (properties["BlockType"] && properties["BlockType"] === "WORD") {

          //  f.setStyle(createStyle(DEFAULT_HIGHLIGHT_COLOR, DEFAULT_HIGHLIGHT_FILL_COLOR, DEFAULT_HIGHLIGHT_WIDTH));
        }
      } else {

        this.selectedFeatures.splice(selIndex, 1);
           f.setStyle(undefined);

      }
    });
    this.sendSelectedFeatures();

  }

  sendSelectedFeatures = async () => {
    if (this.props.sendSelectedFeatures) {
      var features = [];
      await this.selectedFeatures.map(async feature => {
        let properties = await feature.getProperties();
        features.push(Object.create(properties))
      })
      this.props.sendSelectedFeatures(features);
    }
  }

  showSelectedFeatures = () => {
    for (let index = 0; index < this.selectedFeatures.length; index++) {
      const feature = this.selectedFeatures[index];
      feature.setStyle(createStyle(DEFAULT_HIGHLIGHT_COLOR, DEFAULT_HIGHLIGHT_FILL_COLOR, DEFAULT_HIGHLIGHT_WIDTH));
    }
  }



  hoverOnTags = (data) => {
    if (data && data.values && Array.isArray(data.values) && data.values.length > 0) {
      if (this.vectorLayer !== undefined) {
        // eslint-disable-next-line
        this.vectorLayer.getSource().getFeatures().map(feature => {
          for (let index = 0; index < data.values.length; index++) {
            const tag = data.values[index];
            const id = feature.id_;
            if (id === tag.id) {
              feature.setStyle(createStyle(DEFAULT_HOVER_COLOR, DEFAULT_HOVER_FILL_COLOR, DEFAULT_HOVER_WIDTH));
            }

          }
        })
      }
    }

  }

  hoverOffTags = (data) => {
    if (data && data.values && Array.isArray(data.values) && data.values.length > 0) {
      if (this.vectorLayer !== undefined) {
        // eslint-disable-next-line
        this.vectorLayer.getSource().getFeatures().map(feature => {
          feature.setStyle(undefined);
          // for (let index = 0; index < data.values.length; index++) {
          //     const tag = data.values[index];
          //     const id = feature.id_;
          //     if(id === tag.id){

          //     }


          // }
        })
      }
      this.showSelectedFeatures();
    }
  }
}

OCR.propTypes = {
  imgSrc: PropTypes.string.isRequired,
  OCRData: PropTypes.object, // Object of TODO
  featureOverlayColor: PropTypes.string,
  featureOverlayFillColor: PropTypes.string,
  showControls: PropTypes.bool,
  sendSelectedFeatures: PropTypes.func,
  enableFeatureSelection: PropTypes.bool,
  hideClearSelectedIcon: PropTypes.bool,
  goToPrevPage: PropTypes.func,
  goToNextPage: PropTypes.func,
  BlockType: PropTypes.string
}

const MainContainer = styled.div`
width:100%;
height:100%;
`

const MapContainer = styled.div`
width:100%;
height:100%
`


const ControlsMainContainer = styled.div`
display:flex;
width:100%;
justify-content:space-around;
& div:nth-child(2){
    justify-content:center;
}
& div:nth-child(3){
    justify-content:right;
}
`;

const ControlsContainer = styled.div`
display:flex;
width:100%;
`;

const ControlItem = styled.div`
background: #FFFFFF;
border-radius:12px;
margin: 5px;
width: 24px;
height: 24px;
text-align:center;
cursor:pointer;
color:#616161;
`;
