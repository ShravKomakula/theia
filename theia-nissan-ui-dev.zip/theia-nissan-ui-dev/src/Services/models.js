export const createModel = (payload) => client.post(`model/create`, payload);
export const getModelDetails = (payload) => client.post(`model/info`, payload);