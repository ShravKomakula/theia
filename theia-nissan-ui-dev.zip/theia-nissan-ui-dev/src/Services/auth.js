import { client } from "./index";

export const signUp = (payload) => client.post(`usermanagment/signup`, payload);
export const login = (payload) => client.post(`usermanagment/signin`, payload);


