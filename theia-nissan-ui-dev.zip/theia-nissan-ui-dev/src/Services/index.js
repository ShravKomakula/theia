import axios from "axios";
export const client = axios.create({
  baseURL: 'http://20.112.233.197:8000/api/v1/'
});



client.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response.status === 500) {
      localStorage.clear();
      window.location.href = "/";
    }
    else if (error.response.status == 401) {
      localStorage.clear()
      window.location.href = "/login";
    }
    else {
      return error.response
    }
  }

);


