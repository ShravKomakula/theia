import { configureStore } from '@reduxjs/toolkit'
import counterReducer from './Slice/counterSlice'
import authReducer from './Slice/authSlice'


export const Store = configureStore({
  reducer: {
    counter: counterReducer,
    auth : authReducer,
  },
})