import React, { useState,useEffect } from 'react';
import { useNavigate } from 'react-router-dom'
import {Container,Col,Row,Card} from 'react-bootstrap';
import SideBar from '../../Common/SideBar';
import Header from '../../Common/Header';
import './index.scss'
import searchIcon from '../../assets/images/MagnifyingGlass (2).svg'
import viewOnMap from '../../assets/images/map (2).svg'
import DocIcon from '../../assets/images/docIcon.svg'
import prson1 from '../../assets/images/expert-person-1.png';
import prson2 from '../../assets/images/expert-person-2.png';
import prson3 from '../../assets/images/expert-person-3.png';
import prson4 from '../../assets/images/expert-person-4.png';
import prson5 from '../../assets/images/expert-person-5.png';
import prson6 from '../../assets/images/expert-person-6.png';
import prson7 from '../../assets/images/expert-person-7.png';
import prson8 from '../../assets/images/expert-person-8.png';
import prson9 from '../../assets/images/expert-person-9.png';
import prson10 from '../../assets/images/expert-person-10.png';
import prson11 from '../../assets/images/expert-person-11.png';
import prson12 from '../../assets/images/expert-person-12.png';






import dentalIcon from '../../assets/images/Tooth.svg'
import oneDotCircl from '../../assets/images/oneDot.svg'
import twoDotCircl from '../../assets/images/twodots.svg'
import threeDotCircl from '../../assets/images/threedots.svg'
import fourCircl from '../../assets/images/fourdots.svg'
import { ReactComponent as PersonIcon } from "../../assets/images/personIcon.svg";
import { ComposableMap, Geographies, Geography, Marker } from 'react-simple-maps';




let ScientificExpert = () => {
  const navigate = useNavigate()
  const [view, setView] = useState('grid')
  const geoUrl = "https://raw.githubusercontent.com/xoolive/topojson/master/world-countries.json";

  const locations = [
    { name: "New York", coordinates: [-74.006, 40.7128] },
    { name: "London", coordinates: [-0.1276, 51.5074] },
    { name: "Tokyo", coordinates: [2,47] },
    { name: "Sydney", coordinates: [151.2093, -33.8688] },
    { name: "India", coordinates: [13,-12] },
    { name: "dd", coordinates: [-64,53] },
    { name: "India", coordinates: [-8,10] },
    { name: "New York", coordinates: [21366,13435] },
    { name: "London", coordinates: [23,42] },
    { name: "Tokyo", coordinates: [-92,54] },
    { name: "Sydney", coordinates: [53,47] },
    // { name: "India", coordinates: [-46,70] },
  ];

  const multipleMarkers = [
    { name: "New York", coordinates: [-74.006, 40.7128] },
    { name: "New York", coordinates: [-74.0061, 40.7129] },
    { name: "New York", coordinates: [-74.0059, 40.7127] },
  ];

    const [cardData, setCardData] = useState([
        {
          id: 1,
          personUrl: prson1,
          title: 'Silvio Danese',
          reference: 'B.D, M.D, PhD',
          Occupation:'Dentist',
          center:'Global Reach',
          expert:'Emergency Expert',
          approvedPayment: 'Congress Contributions',
          pendingPayment: 'Publications',
          duration: 'Clinical Trials',
          location: 'Digital Engagement',
        },
        {
            id: 2,
            personUrl:prson2,
            title: 'Arthur Glen',
            reference: 'B.D, M.D, PhD',
            Occupation:'Dentist',
            center:'Regional Reach',
            expert:'',
            approvedPayment: 'Congress Contributions',
            pendingPayment: 'Publications',
            duration: 'Clinical Trials',
            location: 'Digital Engagement',
          },
          {
            id: 3,
            personUrl:prson3,
            title: 'Mia Moore',
            reference: 'B.D, M.D, PhD',
            Occupation:'Dentist',
            center:'Global Reach',
            expert:'Emergency Expert',
            approvedPayment: 'Congress Contributions',
            pendingPayment: 'Publications',
            duration: 'Clinical Trials',
            location: 'Digital Engagement',
          },
          {
            id: 4,
            personUrl:prson4,
            title: 'Isabella Thomas',
            reference: 'B.D, M.D, PhD',
            Occupation:'Dentist',
            center:'National Reach',
            expert:'Emergency Expert',
            approvedPayment: 'Congress Contributions',
            pendingPayment: 'Publications',
            duration: 'Clinical Trials',
            location: 'Digital Engagement',
          },
          {
            id: 5,
            personUrl:prson5,
            title: 'Sophia Wilson',
            reference: 'B.D, M.D, PhD',
            Occupation:'Dentist',
            center:'Global Reach',
            expert:'Emergency Expert',
            approvedPayment: 'Congress Contributions',
            pendingPayment: 'Publications',
            duration: 'Clinical Trials',
            location: 'Digital Engagement',
          },
          {
            id: 6,
            personUrl:prson6,
            title: 'Ava Martinez',
            reference: 'B.D, M.D, PhD',
            Occupation:'Dentist',
            center:'Regional Reach',
            expert:'',
            approvedPayment: 'Congress Contributions',
            pendingPayment: 'Publications',
            duration: 'Clinical Trials',
            location: 'Digital Engagement',
          },
          {
            id: 7,
            personUrl:prson7,
            title: 'Olivia Brown',
            reference: 'B.D, M.D, PhD',
            Occupation:'Dentist',
            center:'Global Reach',
            expert:'Emerging Expert',
            approvedPayment: 'Congress Contributions',
            pendingPayment: 'Publications',
            duration: 'Clinical Trials',
            location: 'Digital Engagement',
          },
          {
            id: 8,
            personUrl:prson8,
            title: 'Emily Johnson',
            reference: 'B.D, M.D, PhD',
            Occupation:'Dentist',
            enter:'National Reach',
            expert:'Emerging Expert',
            approvedPayment: 'Congress Contributions',
            pendingPayment: 'Publications',
            duration: 'Clinical Trials',
            location: 'Digital Engagement',
          },
          {
            id: 9,
            personUrl:prson9,
            title: 'Alexander White',
            reference: 'B.D, M.D, PhD',
            Occupation:'Dentist',
            enter:'Global Reach',
            expert:'Emerging Expert',
            approvedPayment: 'Congress Contributions',
            pendingPayment: 'Publications',
            duration: 'Clinical Trials',
            location: 'Digital Engagement',
          },
          {
            id: 10,
            personUrl:prson10,
            title: 'Michael Smith',
            reference: 'B.D, M.D, PhD',
            Occupation:'Dentist',
            enter:'Regional Reach',
            expert:'',
            approvedPayment: 'Congress Contributions',
            pendingPayment: 'Publications',
            duration: 'Clinical Trials',
            location: 'Digital Engagement',
          },
          {
            id: 11,
            personUrl:prson11,
            title: 'William Garcia',
            reference: 'B.D, M.D, PhD',
            Occupation:'Dentist',
            enter:'Global Reach',
            expert:'Emerging Expert',
            approvedPayment: 'Congress Contributions',
            pendingPayment: 'Publications',
            duration: 'Clinical Trials',
            location: 'Digital Engagement',
          },
          {
            id: 12,
            personUrl:prson12,
            title: 'Ethan Taylor',
            reference: 'B.D, M.D, PhD',
            Occupation:'Dentist',
            enter:'Global Reach',
            expert:'Emerging Expert',
            approvedPayment: 'Congress Contributions',
            pendingPayment: 'Publications',
            duration: 'Clinical Trials',
            location: 'Digital Engagement',
          },

       
      ]);

      const handleCardClick = (data) => {
        const { personUrl, title, reference, Occupation } = data;
        localStorage.setItem('selectedCard', JSON.stringify({ personUrl, title, reference, Occupation }));
        navigate('/scientific-node');
      };

  return (
    <div className='wrapper'>
    <Header></Header>
    <div className="layout-wrapper main-wrapper-body d-flex">
      <SideBar activeTab={'Marketplace'} />
      <div className="main-content py-3">
        <div className='page-content'>
          <Container fluid>
              <h5>
              Scientific Experts
              </h5>
              <Col xs={12} md={12} className='mt-3'>
                <div className="search-container">
                  <div className="search-wrapper">
                    <img src={searchIcon} alt="Search Icon" className="search-icon" />
                    <input className="col-12 col-md-10 col-lg-10 search-input" type="text" placeholder="Search Scientists"></input>
                  </div>
                  <div className='btn-basic-container'>
                    <button type='button' className='btn btn-add-project'>Filters(0)</button>
                    <button type='button' className='btn btn-add-project'>None</button>
                  </div>
                  <div className='btn-basic-container-map'>
                    {
                      view == 'grid' ?
                      <button onClick = {() => setView('map')}  type='button' className='btn btn-add-project-map'><img src= {viewOnMap} className='pe-2'></img>View On Map</button>
                      :
                      <button onClick = {() => setView('grid')}   type='button' className='btn btn-add-project-map'><img src= {viewOnMap} className='pe-2'></img>View as Grid</button>

                    }
                  </div>
                </div>
              </Col>
              {
                view == 'grid' ? 
                <Row className="mt-3">
                {cardData.map((data) => (
                    <Col md={4} key={data.id} className="mb-4">
                      <Card onClick={() => handleCardClick(data)} className="p-3 shadow-sm" style={{ cursor: 'pointer' }}>
                            <Card.Body className='p-0'>
                                <Col className='d-flex flex-wrap align-items-center justify-content-between'>
                                    <div className="d-flex align-items-start">
                                      <img src={data.personUrl} alt="Document Icon" className="img-fluid me-3 mt-1 pers-imgwt" />
                                      <div>
                                        <h5 className='title-text mb-1'>{data.title}</h5>
                                        <p className="text-muted">{data.reference}</p>
                                      </div>
                                    </div>
                                    <div className='d-flex align-items-center align-items-center'>
                                      <img src={dentalIcon} className="img-fluid me-1"></img>
                                      <h5 className='title-text d-flex align-items-center mb-0' >{data.Occupation}</h5>
                                    </div>
                                </Col>
                                <Col className='d-flex align-items-center mt-3' >
                                <div className='dot-gold'></div>
                                <span className="card-font-text-gold">{data.center}</span>
                                <div className='dot-pink'></div>
                                <span className="card-font-text-pink">{data.expert}</span>
                                </Col>
                                <Col className='mt-3 d-flex align-items-start'>
                                <p className="card-font-text-dull">Activities</p>
                                </Col>
                                <div className='d-flex justify-content-between'>
                                    <div className="mt-3">
                                        <img src={oneDotCircl}></img>
                                        <p className="card-font-text">{data.approvedPayment}</p>
                                    </div>
                                    <div className="mt-3 me-5">
                                        <img src={twoDotCircl}></img>
                                        <p className="card-font-text">{data.pendingPayment}</p>
                                    </div>
                                </div>
                                <div className="d-flex justify-content-between mt-3">
                                    <div>
                                        <img src={threeDotCircl}></img>
                                        <p className='card-font-text'>{data.duration}</p>
                                    </div>
                                    <div className='footer-right-container'>
                                        <img src={fourCircl}></img>
                                        <p className='card-font-text'>{data.location}</p>
                                    </div>
                                </div>
                            </Card.Body>
                        </Card>
                    </Col>
                ))}
</Row>
:
<>

<Row className="mt-3 p-2">
  <Card>
  <button type='button' className='experts '>Experts Panel</button>
  <ComposableMap>
      <Geographies geography={geoUrl}>
        {({ geographies }) =>
          geographies.map((geo) => (
            <Geography
              key={geo.rsmKey}
              geography={geo}
              style={{
                default: { fill: "#D6D6DA", outline: "none" },
                hover: { fill: "#0000FF", outline: "none" },
                pressed: { fill: "#E42", outline: "none" },
              }}
            />
          ))
        }
      </Geographies>

      {locations.slice(0, cardData.length).map(({ name, coordinates }, index) => (
        <Marker key={name} coordinates={coordinates}>
          <image
            href={cardData[index].personUrl}
            width={30}
            height={30}
            x={-15}
            y={-15}
            style={{ pointerEvents: 'none' }} // Ensure the image does not interfere with map interaction
          />
        </Marker>
      ))}

      {multipleMarkers.slice(0, cardData.length).map(({ name, coordinates }, index) => (
        <Marker key={`${name}-${index}`} coordinates={coordinates}>
          <image
            href={cardData[index].personUrl}
            width={30}
            height={30}
            x={-15}
            y={-15}
            style={{ pointerEvents: 'none' }} // Ensure the image does not interfere with map interaction
          />
        </Marker>
      ))}
    </ComposableMap>
              {/* <ComposableMap>
      <Geographies geography="/path/to/your/topojson-or-geojson-file.json">
        {({ geographies }) =>
          geographies.map((geo) => (
            <Geography key={geo.rsmKey} geography={geo} />
          ))
        }
      </Geographies>
      {locations.map(({ name, coordinates }) => (
        <Marker key={name} coordinates={coordinates}>
          {cardData.map((item) => (
            <g key={item.id}>
              <PersonIcon width={30} height={30} alt="Person Icon" />
              <image
                href={item.personUrl}
                width={30}
                height={30}
                x={-15}
                y={-15}
                style={{ pointerEvents: 'none' }} // Ensure the image does not interfere with map interaction
              />
            </g>
          ))}
        </Marker>
      ))}
      {multipleMarkers.map(({ name, coordinates }, index) => (
        <Marker key={`${name}-${index}`} coordinates={coordinates}>
          {cardData.map((item) => (
            <g key={item.id}>
              <PersonIcon width={30} height={30} alt="Person Icon" />
              <image
                href={item.personUrl}
                width={30}
                height={30}
                x={-15}
                y={-15}
                style={{ pointerEvents: 'none' }} 
              />
            </g>
          ))}
        </Marker>
      ))}
    </ComposableMap> */}
              </Card>
</Row>
</>
              }
        
          </Container>
        </div>
      </div>
    </div>
  </div>
  );
}

export default ScientificExpert;
