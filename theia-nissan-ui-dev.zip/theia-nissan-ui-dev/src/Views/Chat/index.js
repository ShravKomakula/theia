import React, { useState, useEffect, useRef } from 'react';
import Dropdown from 'react-bootstrap/Dropdown';
import Form from 'react-bootstrap/Form';
import SideBar from '../../Common/SideBar';
import Header from '../../Common/Header';
import { ToastContainer, toast } from 'react-toastify';
import axios from 'axios'

import './index.scss'
import msgChatPerson from "../../assets/images/icons/person-icon.svg";
import msgChatRobot from "../../assets/images/icons/robot-icon.svg";
import snowFlakeIcon from "../../assets/images/icons/snowflake-icon.svg";
import azureIcon from "../../assets/images/icons/azure-icon.svg";
import icon from "../../assets/images/icons/azure-icon.svg";
import likeIcon from "../../assets/images/icons/like-icon.svg";
import dislikeIcon from "../../assets/images/icons/dislike-icon.svg";
import copyIcon from "../../assets/images/icons/copy-icon.svg";
import postgresqlIcon from "../../assets/images/icons/postgresql-img.svg";
import groupIcon from "../../assets/images/icons/group-icon.svg";
import searchIcon from "../../assets/images/icons/search-icon-grey.svg";
import micIcon from "../../assets/images/icons/mic-icon.svg";
import uploadIcon from "../../assets/images/icons/upload-icon.svg";
import sendIcon from "../../assets/images/icons/send-icon.svg";
import infoIconLg from "../../assets/images/icons/info-icon-large.svg";
import openAiIcon from "../../assets/images/icons/openai-icon.svg";
import infoIconCircle from "../../assets/images/icons/info-icon-circle.svg";
import cloudIcon from '../../assets/images/icons/cloud-add.svg'



let Chat = () => {
  const [selectedFile, setSelectedFile] = useState(null);
  const [newChat, setNewChat] = useState(true);
  const [newchat, setNewchat] = useState(true);
  const [questions, setQuestions] = useState([]);
  const [inputValue, setInputValue] = useState('');
  const [showInitial, setShowInitial] = useState(true);
  const [chatLoading, setChatLoading] = useState(false);

  const [preChat, setsetPreChat] = useState(
    [
      {
        query: 'Hi',
        response: 'Hello , how may I help you ?',
        reference: []
      },
      {
        query: '.pdf',
        response: 'Current therapies for Transthyretin amyloidosis (ATTR)  target the misfolded protein but do not address tissue damage by the already deposited amyloid. We have demonstrated that increased abundance of proteins within cardiac (and renal) amyloid plaques is associated with improved outcomes, which suggests that the amount of deposited proteins, may merely be a surrogate for indolent disease biology.',
        reference: ['Data Gaps', 'Health Quality', 'Digital Health & AI', 'Published'],
        title: ["High Level Summary of this document"]
      },
      {
        query: 'Give a brief explanation about medical grants',
        response: 'Medical grants are financial awards given to individuals or institutions to support research, education, treatment, or other health-related projects. These grants are typically funded by government agencies, private foundations, corporations, or charitable organizations. The purpose of medical grants is to advance medical knowledge, improve healthcare services, and promote public health.',
        reference: ['Snowflake (Finance)']
      },
      {
        query: 'Explain about compliance and scientific experts briefly.',
        response: 'Compliance and scientific expertise are two critical components in the medical field, ensuring the safety, efficacy, and ethical standards of medical practices, products, and research. Compliance refers to the adherence to laws, regulations, guidelines, and standards applicable to the medical field. Scientific experts in the medical field are professionals who possess specialized knowledge and skills in various areas of medical science.',
        reference: ['Neo4j(Scientific Experts)', ' Snowflake (Finance)']

      },
      {
        query: 'Who are the top 10 PIs with the most number of approved requests?',
        response: `The Data table provided lists the top 10 Principal Investigators(PIs) with the highest number of approved requests.
 
      Here’s a plain English description of the top 10 from the provided list:
       
      The PI with the most approved requests with a toatl of 10,071, is not named in this data.
      In second place. Manjunath Krishnappa has had 25 requests approved.
      In third place, Jon Hobson has had 32 requests approved
      In the fourth place, Scott Killian has had 22 requests approved.
      In fifth place, Manjunath has had 20 requests approved.
      In sixth place, Brandy Winer Andrews has had 14 requests approved.
      In the seventh place, Vincent Devereux has had 11 requests approved
      In seventh place, Kate Barnett has had 10 requests approved.
      In the ninth place, Joel Pugh has had 9 requests approved.
      In the tenth place, Diane Lacaille has had 8 requests approved.

      These figures represent the number of requests these individuals have had approved, as per the current data.`,
        reference: ['Neo4j(Scientific Experts)']
      },

      {
        query: 'Based on the document uploaded, can you compare the reports with previous grants and give a brief explanation on whether I can approve this grant or not?',
        response: `
        In summary, you cant proceed to approve based on the Score from the scorecard of the scientific expert mentioned in the document which has less than 50 which is not match the
      Grant research topic and you can look for further explore experts outside our community list.
 
      After examining the document uploaded, it is not viable to approve this grant to this scientific expert.
      `,
        reference: ['blob Storage (Grant)']
      },
      {
        query: 'How to Login to CyberGrants ?',
        response: `
      Theia:
 
Hello I’m here to help you with your questions. To Logon to CyberGrants. you can follow these steps:
 
Go to the CyberGrants website and click on the “Logon: button.
Enter your username and password in the designated fields.
Click the Logon button to access your account.
 
If you dont know your username or password, you can click on the “Forgot Username” or Forgot Password” link to reset them.
 
I hope this helps! Let me know if you have any other questions.`,
        reference: ['Setting_up_GMG_portal.pdf( blob )']
      },
      {
        query: 'Give me a brief explanation of the Grant uploaded',
        response: `
      Medical grants uploaded are financial awards given to individuals or institutions to support research, education, treatment, or other health-related projects. These grants are typically funded by government agencies, private foundations, corporations, or charitable organizations. The purpose of medical grants is to advance medical knowledge, improve healthcare services, and promote public health.`,
        reference: ['Snowflake (Finance)']
      },
      {
        query: 'Explain about compliance and scientific experts briefly mentioned related to the document.',
        response: 'Compliance and scientific expertise are two critical components in the medical field, ensuring the safety, efficacy, and ethical standards of medical practices, products, and research. Compliance refers to the adherence to laws, regulations, guidelines, and standards applicable to the medical field. Scientific experts in the medical field are professionals who possess specialized knowledge and skills in various areas of medical science.',
        reference: ['Neo4j(Scientific Experts)']
      },
      {
        query: 'Can you provide me explanations to have the grant approved based on the data provided',
        response: `
      NIH monitors grants carefully. Active monitoring includes reports and correspondence from the grantee, audit reports, site visits, and other information
Applicants who have scored well submit “just-in-time” information1. Final administrative reviews are conducted and Notice of Award documents are sent to successful applicants1.
Applications compliant with NIH policies are assigned to an NIH Institute or Center and a scientific review group for evaluation of scientific and technical merit1. 
Applications undergo a rigorous two-stage review1.
 
In summary you can proceed to approve based on the Score from the scorecard of the scientific expert mentioned in the document which is Scott Killian he has 87/100 which matches the
Grant research topic on successful submissions and has dedicated lab
 
After examining the document uploaded, it is viable that we approve this grant. It is found to be economical when compared with existing approved and pending grants.
After further analysis on the previous report submitted for this grant, it is furthermore clear that there are far better enhancements involved in the latest report submitted by the expert.
As there are many new improvements than the 2020 grant report, it is self-explanatory for the hike in the grant requested. Therefore, it is advisable that you approve this grant
      `,
        reference: ['Neo4j(Scientific Experts)', 'Snowflake (Finance)', 'blob Storage (Grant)', 'Postgres(Compliance)']

      },

    ]
  );


  const [chat, setChat] = useState([]);

  useEffect(() => {
    let div1 = document.getElementById('chat-loading-id');
    let div2 = document.getElementById('footer-chat');
    let div4 = document.getElementById('chat-message-id');

    if (div1 && div2) {

      let div1Bottom = div1.getBoundingClientRect().bottom;
      let div2Top = div2.getBoundingClientRect().top;
      let heightBetween = div2Top - div1Bottom;

      if (heightBetween < 20) {
        console.log("heightBetween =->", div1Bottom, heightBetween)
        let div3 = document.getElementById('chat-container-id');
        div3.scrollTop = div1Bottom + 100;

      }
    }

    if (div4) {
      console.log("he00->", div4.offsetHeight)
    }

  }, [chat.length,  document.getElementById('chat-message-id')]);



  function updateResponse(arr, query, newResponse, newReference, newTitle) {
    for (let i = 0; i < arr.length; i++) {
      // console.log("arr[i].query.toLowerCase()", arr[i].query.toLowerCase())
      console.log("query.toLowerCase(", query.toLowerCase())
      if (arr[i].query.toLowerCase() == query.toLowerCase()) {
        arr[i].response = newResponse;
        arr[i].reference = newReference;
        arr[i].title = newTitle
        break;
      }
    }
  }


  const handleExamples = async (value) => {
    setShowInitial(false)
    setChatLoading(true)
    setInputValue("");
    let temp = [...chat]

    let obj = {
      query: value,
      response: "",
      reference: "",
      title: ""

    };
    temp.push(obj);
    setChat(temp);

    let res = await axios.get(`http://34.44.61.158:8059/qa/chat?input_query=${value}`)
    if (res.data.status_code == 200) {
      temp[temp.length - 1].response = res.data.response_body.response
      temp[temp.length - 1].reference = res.data.response_body.reference
      setChat(temp);
    }
    setSelectedFile(null);
    setChatLoading(false)

  };

  const handleAddQuestion = async () => {
    setShowInitial(false)
    setChatLoading(true)
    setInputValue("");
    let temp = [...chat]

    let obj = {
      query: inputValue,
      response: "",
      reference: "",
      title: ""

    };
    temp.push(obj);
    setChat(temp);

    let res = await axios.get(`http://34.44.61.158:8059/qa/chat?input_query=${inputValue}`)
    if (res.data.status_code == 200) {
      temp[temp.length - 1].response = res.data.response_body.response
      temp[temp.length - 1].reference = res.data.response_body.reference
      setChat(temp);
    }
    setSelectedFile(null);
    setChatLoading(false)

  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleAddQuestion();
    }
  };
  const [selectedItem, setSelectedItem] = useState('Open AI');

  const handleSelect = (eventKey) => {
    setSelectedItem(eventKey);
  };


  const [maxTokens, setMaxTokens] = useState('');

  const handleMaxtokens = (event) => {
    setMaxTokens(event.target.value);
  };
  const [minTokens, setMinTokens] = useState('');

  const handleMintokens = (event) => {
    setMinTokens(event.target.value);
  };

  const [temp, setTemp] = useState('');

  const handleTemp = (event) => {
    setTemp(event.target.value);
  };

  const [topP, setTopP] = useState('');

  const handleTopP = (event) => {
    setTopP(event.target.value);
  };
  const handleReset = () => {
    setMinTokens('')
    setMaxTokens('')
    setTemp('')
    setTopP('')
  }
  const [selectedSources, setSelectedSources] = useState([]);

  const handleSourceChange = (source) => {
    setSelectedSources(prevSelectedSources =>
      prevSelectedSources.includes(source)
        ? prevSelectedSources.filter(s => s !== source)
        : [...prevSelectedSources, source]
    );
  };

  const handleResetSources = () => {
    setSelectedSources([]);
  };

  const fileUploadRef = useRef(null);

  const handleImageUpload = (event) => {
    event.preventDefault();
    fileUploadRef.current.click();

  }

  const fileInputRef = useRef(null);

  const handleClick = () => {
    fileInputRef.current.click();
  };

  const toBase64 = file => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const base64String = reader.result.split(',')[1];
      resolve(base64String);
    };
    reader.onerror = error => reject(error);
  });



  const handleFileChange = async (event) => {

    const files = event.target.files;
    const updatedImages = [];
    const handleFiles = async () => {
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const base64 = await toBase64(file);
        updatedImages.push({ name: file.name, base64 });
      }
      const formData = new FormData();
      formData.append("file", files[0], files[0].name);

      setShowInitial(false)
      setChatLoading(true)
      setInputValue("");
      let temp = [...chat]

      let obj = {
        query: files[0].name,
        response: "",
        reference: "",
        title: ""

      };
      temp.push(obj);
      setChat(temp);



      axios.post("http://34.44.61.158:8059/upload", formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      })
        .then(async response => {
          console.log("ress", response.data.response_body.pdf_path);
          let payload = {
            "file_path": response.data.response_body.pdf_path
          }
          let res = await axios.post(`http://34.44.61.158:8059/summarize`, payload)

          if (res.data.status_code == 200) {
            updateResponse(temp, files[0].name, res.data.response_body, res.data.response_body.reference, res.data.response_body.title);
            setChat(temp);
          } else {
            let index = temp.findIndex(item => item.query == files[0].name);
            temp[index].response = "I do not understand , please try again !"
            setChat(temp);

          }

          setChatLoading(false)

        })
        .catch(error => {
          console.error(error);
          setChatLoading(false)

        });

    };

    handleFiles();

    // if (files) {
    //   setSelectedFile(files[0]);
    //   setInputValue(files[0].name);
    // }

  };

  const renderTextWithNewLines = (text) => {
    return text.split('\n').map((line, index) => (
      <React.Fragment key={index}>
        {line}
        <br />
      </React.Fragment>
    ));
  };



  return (
    <div className='wrapper'>
      <ToastContainer />

      <Header></Header>
      <div className="layout-wrapper main-wrapper-body d-flex">
        <SideBar activeTab={'Marketplace'} />
        <div className="main-content p-0">
          <div className='page-content bg-white'>
            <div class="chat-wrapper-box">
              <div className='chat-flex-content d-flex flex-wrap'>
                <div className='chat-flex--column position-relative'>
                  <div className='chat-header-wigit d-flex flex-wrap align-items-center justify-content-between p-4'>
                    <div className='chat-title-section'>
                      <h1 className='heading-top-h1 mb-0'>Chat</h1>
                    </div>
                    <div className='chat-wgt-newt'>
                      <button type='button' className='btn btn-chat-nw' onClick={() => setChat([])}>+ New Chat</button>
                    </div>
                  </div>
                  {newChat ?
                    <div className='chat-body-wrapper' id="chat-container-id">
                      <div className='chat-middle-content'>
                        {
                          chat.length > 0 || showInitial == false ?

                            null
                            :
                            <div className="container">
                              <div className="header">
                                <h1 className="main-header">Hello ,</h1>
                                <span className="sub-header">How can we help you today?</span>
                              </div>
                              <div className="upload-box" onClick={handleClick}>
                                <div className="icon">
                                  <img src={cloudIcon} alt="cloud icon" />
                                </div>
                                <p className="instructions">Choose a file or drag & drop it here</p>
                                <p className="file-types">JPEG, PNG, PDG, and MP4 formats, up to 50MB</p>
                                <button className="browse-button" onClick={(e) => { e.stopPropagation(); handleClick(); }}>Browse File</button>
                              </div>
                              <input
                                type="file"
                                ref={fileInputRef}
                                style={{ display: 'none' }}
                                onChange={handleFileChange}
                              />
                            </div>
                        }
                        {
                          chat.map((ele, i) => (
                            <React.Fragment key={i}>
                              <div className='chatright-layout'>
                                <div className='d-flex flex-wrap chatlst-content'>
                                  <div className='chatuser-img'>
                                    <img src={msgChatPerson} alt='chat person' />
                                  </div>
                                  <div className='chat-msgmtr'>
                                    <p className='msgwgt-txtcont-wt'>{ele.query}</p>
                                  </div>
                                </div>
                              </div>
                              {
                                chatLoading && i == (chat.length - 1) ?
                                  <div className='chatleft-layout position-relative' id="chat-loading-id">
                                    <div className='d-flex flex-wrap chatlst-content' style={{ width: 'fit-content' }}>
                                      <div className='chatuser-img'>
                                        <img src={msgChatRobot} alt='chat robot' />
                                      </div>
                                      <p className='msgwgt-txtcont-wt'>
                                        <div className="loading-container">
                                          <div className="loading-dot"></div>
                                          <div className="loading-dot"></div>
                                          <div className="loading-dot"></div>
                                        </div>
                                      </p>
                                    </div>
                                  </div>
                                  :
                                  <div className='chatleft-layout position-relative' id="chat-message-id">
                                    <div className='d-flex flex-wrap chatlst-content'>
                                      <div className='chatuser-img'>
                                        <img src={msgChatRobot} alt='chat robot' />
                                      </div>
                                      <div className='chat-msgmtr'>
                                        {ele.title ?
                                          <>
                                            <h4>{ele.title}</h4>
                                            <hr></hr>
                                          </>
                                          : null
                                        }
                                        {/* <p className='msgwgt-txtcont-wt'>{ele.response}</p> */}
                                        <p className='msgwgt-txtcont-wt'>{renderTextWithNewLines(ele.response)}</p>

                                        {/* renderTextWithNewLines */}

                                        {
                                          ele.reference ?
                                            <div className='chat-file-view mt-3 d-flex'>
                                              <ul className='itemlst--cht'>
                                                <li className='list-file-elemnt'>
                                                  <button type='button' className='btn btn-file-mtr'>{ele.reference}</button>
                                                </li>
                                              </ul>
                                              {/* {
                                            ele.reference.length > 0 &&
                                            ele.reference.map((item, index) => (
                                              <ul key={index} className='itemlst--cht'>
                                                <li className='list-file-elemnt'>
                                                  <button type='button' className='btn btn-file-mtr'>{item}</button>
                                                </li>
                                              </ul>
                                            ))
                                          } */}
                                            </div>
                                            :
                                            null
                                        }

                                      </div>
                                    </div>
                                    <div className='elemnt-share-icon'>
                                      <div className='d-flex flex-wrap mult-w-sharelst'>
                                        <span className='wrt-rm-button'><button type='button' className='btn btn-shr-web'><img src={likeIcon} alt='icon' /></button></span>
                                        <span className='wrt-rm-button'><button type='button' className='btn btn-shr-web'><img src={dislikeIcon} alt='icon' /></button></span>
                                        <span className='wrt-rm-button'><button type='button' className='btn btn-shr-web'><img src={copyIcon} alt='icon' /></button></span>
                                      </div>
                                    </div>
                                  </div>

                              }



                            </React.Fragment>
                          ))
                        }
                      </div>
                    </div>
                    : <></>}
                  <div className='chat-footer-wapper' id="footer-chat">
                    <div className='suggest-chat-items text-end py-2 px-4'>
                    <span className='sugstbutton-chat'>
                        <button onClick = {() => handleExamples('Hi')}  className='btn btn-suggest-view'>Hi</button>
                      </span>

                      <span className='sugstbutton-chat'>
                        <button onClick = {() => handleExamples('what are medical grants?')} className='btn btn-suggest-view'>What are medical grants?</button>
                      </span>

                      {/* <span className='sugstbutton-chat'>
                        <button onClick = {() => handleExamples('Can you explain the uploaded grant?')}  className='btn btn-suggest-view'>Can you explain the uploaded grant?</button>
                      </span> */}

                      {/* <span className='sugstbutton-chat'>
                        <button onClick = {() => handleExamples('Is it viable to approve the RSV infection grant?')}  className='btn btn-suggest-view'>Is it viable to approve the RSV infection grant?</button>
                      </span> */}

               


                      {/* <span className='sugstbutton-chat'>
                        <button className='btn btn-suggest-view'>Examples of grants</button>
                      </span> */}
                    </div>
                    <div className='txt-msgbox py-2 px-4'>
                      <div className='d-flex flex-wrap msg--input-wgtyt'>
                        <div className='input-chatmsg-filed position-relative'>
                          <input
                            type='text'
                            className='form-control msgwrite-txt-field'
                            placeholder='Type the question'
                            value={inputValue}
                            onChange={(e) => setInputValue(e.target.value)}
                            onKeyDown={handleKeyPress}
                          />
                          <button type='button' className='btn btn-search-chatmsg' onClick={handleAddQuestion}>
                            <img src={searchIcon} alt='icon' />
                          </button>
                        </div>
                        <div className='d-flex flex-wrap align-items-center button-chat-action justify-content-end'>
                          <span className='chatcol-button-items'>
                            <button type='button' className='btn btn-chat-btnview'>
                              <img src={micIcon} alt='icon' />
                            </button>
                          </span>
                          <div>
                            <button
                              type='button'
                              onClick={handleImageUpload}
                              className='flex-center absolute bottom-12 right-14 h-9 w-9 rounded-full inputbutton'>
                              <img
                                src={uploadIcon}
                                alt="Edit"
                                width={"20px"}
                                className='object-cover' />
                            </button>
                            <input
                              type="file"
                              id="file"
                              onChange={handleFileChange}
                              ref={fileUploadRef}
                              hidden />
                          </div>
                          <span className='chatcol-button-items'>
                            <button type='button' className='btn btn-chat-btnview' onClick={handleAddQuestion}>
                              <img src={sendIcon} alt='icon' />
                            </button>
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className='flex-modal-configure'>
                  <div className='mdl-elemnt-areawgt'>
                    <div class="config-side-area">
                      <div className='heading-config-md d-flex flex-wrap align-items-center justify-content-between py-4'>
                        <h3 className='title-md-confg'>Model Configuration</h3>
                        <div className='iconwgt--notinf'><span className='not-infowgt'><img src={infoIconLg} /></span></div>
                      </div>
                      <div className='config-form-wgt'>
                        <div className='form-grup-confg'>
                          <Dropdown className='dropselect-ai' onSelect={handleSelect}>
                            <Dropdown.Toggle variant="light" className='select-opti-ai'>
                              <img src={openAiIcon} className='me-2' alt='icon' />{selectedItem}
                            </Dropdown.Toggle>

                            <Dropdown.Menu className='multi-ai-dropdown'>
                              <Dropdown.Item eventKey="Open AI" href="#/action-1">Open AI</Dropdown.Item>
                              <Dropdown.Item eventKey="Another action" href="#/action-2">Another action</Dropdown.Item>
                              <Dropdown.Item eventKey="Something else" href="#/action-3">Something else</Dropdown.Item>
                            </Dropdown.Menu>
                          </Dropdown>
                        </div>
                        <div className='form-grup-confg'>
                          <div className='grp-field--rt'>
                            <label className='txt-lbl-wt'>Max New Tokens</label>
                            <div className='prog-token-bar'>
                              <div class="flx-num-tt"><span className='txt-count--numb'>1</span></div>
                              <div className='progress-percent-wt'>
                                <span className='progs-bar-count'></span>
                              </div>
                              <div class="flx-num-tt"><span className='txt-count--numb'>4095</span></div>
                            </div>
                          </div>
                          <div className='grp-field--rt'>
                            <label className='txt-lbl-wt'>or type the max tokens</label>
                            <Form.Control type="text" placeholder="" className='form-input-mdl' value={maxTokens} onChange={handleMaxtokens} />
                          </div>
                        </div>
                        <div className='form-grup-confg'>
                          <div className='grp-field--rt'>
                            <label className='txt-lbl-wt'>Min New Tokens</label>
                            <div className='prog-token-bar'>
                              <div class="flx-num-tt"><span className='txt-count--numb'>1</span></div>
                              <div className='progress-percent-wt'>
                                <span className='progs-bar-count'></span>
                              </div>
                              <div class="flx-num-tt"><span className='txt-count--numb'>4095</span></div>
                            </div>
                          </div>
                          <div className='grp-field--rt'>
                            <label className='txt-lbl-wt'>or type the min tokens</label>
                            <Form.Control type="text" placeholder="" className='form-input-mdl' value={minTokens} onChange={handleMintokens} />
                          </div>
                        </div>
                        <div className='form-grup-confg'>
                          <div className='grp-field--rt'>
                            <label className='txt-lbl-wt'>Temperature</label>
                            <div className='prog-token-bar'>
                              <div class="flx-num-tt"><span className='txt-count--numb'>1</span></div>
                              <div className='progress-percent-wt'>
                                <span className='progs-bar-count'></span>
                              </div>
                              <div class="flx-num-tt"><span className='txt-count--numb'>4095</span></div>
                            </div>
                          </div>
                          <div className='grp-field--rt'>
                            <label className='txt-lbl-wt'>or type the temperature</label>
                            <Form.Control type="text" placeholder="" className='form-input-mdl' value={temp} onChange={handleTemp} />
                          </div>
                        </div>
                        <div className='form-grup-confg'>
                          <div className='grp-field--rt'>
                            <label className='txt-lbl-wt'>Top P</label>
                            <div className='prog-token-bar'>
                              <div class="flx-num-tt"><span className='txt-count--numb'>1</span></div>
                              <div className='progress-percent-wt'>
                                <span className='progs-bar-count'></span>
                              </div>
                              <div class="flx-num-tt"><span className='txt-count--numb'>4095</span></div>
                            </div>
                          </div>
                          <div className='grp-field--rt'>
                            <label className='txt-lbl-wt'>or type Top P</label>
                            <Form.Control type="text" placeholder="" className='form-input-mdl' value={topP} onChange={handleTopP} />
                          </div>
                        </div>
                        <div className='form-grup-confg d-flex flex-wrap align-items-center mb-3'>
                          <div className='w-50'>
                            <button type='button' className='btn btn-reset-mdl' onClick={handleReset}>Reset</button>
                          </div>
                          {/* <div className='w-50 text-end'>
                            <button type='button' className='btn btn-save-mdl'>Save Changes</button>
                          </div> */}
                        </div>

                      </div>
                    </div>
                    <div className='source-select-wgt'>
                      <h3 className='title-md-confg mb-3'>Select Source</h3>
                      <div className='d-flex flex-wrap'>
                        <div className='w-50 flex-source-wgt mb-4'>
                          <div className='d-flex flex-wrap st--wgtsource'>
                            <div className='checkelmnt-flx'>
                              <Form.Check
                                aria-label="option1"
                                checked
                                // checked={selectedSources.includes('Blob Storage')}
                                onChange={() => handleSourceChange('Blob Storage')}
                              />
                            </div>
                            <div className='right-slct--wtr'>
                              <h3 className='head-ytm-swnt'>Blob Storage</h3>
                              <p className='werytr--tpn'>Grant<span><img src={infoIconCircle} alt='Info Circle' className='ms-2' /></span></p>
                            </div>
                          </div>
                        </div>
                        <div className='w-50 flex-source-wgt mb-4'>
                          <div className='d-flex flex-wrap st--wgtsource'>
                            <div className='checkelmnt-flx'>
                              <Form.Check
                                aria-label="option2"
                                checked
                                // checked={selectedSources.includes('Neo4j')}
                                onChange={() => handleSourceChange('Neo4j')}
                              />
                            </div>
                            <div className='right-slct--wtr'>
                              <h3 className='head-ytm-swnt'>Neo4j</h3>
                              <p className='werytr--tpn'>Scientific Experts<span><img src={infoIconCircle} alt='Info Circle' className='ms-2' /></span></p>
                            </div>
                          </div>
                        </div>
                        <div className='w-50 flex-source-wgt mb-4'>
                          <div className='d-flex flex-wrap st--wgtsource'>
                            <div className='checkelmnt-flx'>
                              <Form.Check
                                aria-label="option3"
                                checked
                                // checked={selectedSources.includes('Snowflake')}
                                onChange={() => handleSourceChange('Snowflake')}
                              />
                            </div>
                            <div className='right-slct--wtr'>
                              <h3 className='head-ytm-swnt'>Snowflake</h3>
                              <p className='werytr--tpn'>Finance<span><img src={infoIconCircle} alt='Info Circle' className='ms-2' /></span></p>
                            </div>
                          </div>
                        </div>
                        <div className='w-50 flex-source-wgt mb-4'>
                          <div className='d-flex flex-wrap st--wgtsource'>
                            <div className='checkelmnt-flx'>
                              <Form.Check
                                aria-label="option4"
                                checked
                                // checked={selectedSources.includes('Postgres')}
                                onChange={() => handleSourceChange('Postgres')}
                              />
                            </div>
                            <div className='right-slct--wtr'>
                              <h3 className='head-ytm-swnt'>Postgres</h3>
                              <p className='werytr--tpn'>Compliance<span><img src={infoIconCircle} alt='Info Circle' className='ms-2' /></span></p>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className='form-grup-confg d-flex flex-wrap align-items-center mb-0'>
                        <div className='w-50'>
                          <button type='button' className='btn btn-reset-mdl' onClick={handleResetSources}>Reset</button>
                        </div>
                        {/* <div className='w-50 text-end'>
                          <button type='button' className='btn btn-save-mdl' onClick={() => console.log('Selected Sources:', selectedSources)}>Save Changes</button>
                        </div> */}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Chat;
