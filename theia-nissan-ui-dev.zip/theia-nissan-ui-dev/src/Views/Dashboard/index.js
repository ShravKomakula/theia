import React, { useState } from 'react';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Card from 'react-bootstrap/Card';
import Nav from 'react-bootstrap/Nav';
import Tab from 'react-bootstrap/Tab';
import { Form, Modal, Button } from 'react-bootstrap';
import SideBar from '../../Common/SideBar';
import Header from '../../Common/Header';
import './index.scss'
import searchIcon from '../../assets/images/MagnifyingGlass (2).svg'
import userIcon1 from '../../assets/images/icons/user-icon-1.svg';
import userIcon2 from '../../assets/images/icons/user-icon-2.svg';
import userIcon3 from '../../assets/images/icons/user-icon-3.svg';
import userIcon4 from '../../assets/images/icons/user-icon-4.svg';
import userIcon5 from '../../assets/images/icons/user-icon-5.svg';
import userIcon6 from '../../assets/images/icons/user-icon-6.svg';
import arrowDireaction from '../../assets/images/icons/arrow-chart-line.svg';
import mapChartImg from '../../assets/images/mapmore-chart.jpg';
import iconGlobWb from '../../assets/images/icons/globe-map-circle-icon.svg';
import iconLocation from '../../assets/images/icons/location-sum-icon.svg';
import iconCorona from '../../assets/images/icons/Coronavirus.svg';
import iconPeople from '../../assets/images/icons/people-sum-icon.svg';
import handIcon from '../../assets/images/icons/hand-icon.svg';
import crossIcon from '../../assets/images/cross.svg';
import pfizerIcon from '../../assets/images/pfizerlogo.svg';
import locationWebIcon from '../../assets/images/icons/location-icon-web.svg';
import brandLogo1 from '../../assets/images/logobrand-img-1.png';
import brandLogo2 from '../../assets/images/logobrand-img-2.png';
import iconweb1 from '../../assets/images/icons/coins-icon.svg';
import iconweb2 from '../../assets/images/icons/pending-hand-icon.svg';
import iconweb3 from '../../assets/images/icons/method-icon.svg';
import iconweb4 from '../../assets/images/icons/virus-icon.svg';
import iconweb5 from '../../assets/images/icons/pills-icon.svg';
import iconweb6 from '../../assets/images/icons/timer-icon.svg';
import completedIcon from '../../assets/images/icons/check-icon-circle-dark.svg';
import pendingEnollIcon from '../../assets/images/icons/hour-glass-icon.svg';
import circleDown from '../../assets/images/icons/circle-arrow-down-blue.svg';
import circleIconRound from '../../assets/images/icons/circle-icon-web.svg';
import downloadIcon from '../../assets/images/icons/download-icon.svg';
import { ReactComponent as FilterGridIcon } from "../../assets/images/icons/filter-grid-icon.svg";
import { ReactComponent as FilterListIcon } from "../../assets/images/icons/filter-list-icon.svg";
import icon from './../../assets/images/Icon.svg';
import vector3 from './../../assets/images/Vector(3).svg';
import vector4 from './../../assets/images/Vector(4).svg';






let Dashboard = () => {


  const [modalIsOpen, setModalIsOpen] = useState(false);
  const [orgName, setOrgName] = useState('');
  const [piName, setPiName] = useState('');
  const [grantTitle, setGrantTitle] = useState('');
  const [pizerBU, setPizerBU] = useState('');
  const [diseaseArea, setDiseaseArea] = useState('');
  const [pfizerDrug, setPfizerDrug] = useState('');

  const [orgNameList, setOrgNameList] = useState([]);
  const [piNameList, setPiNameList] = useState([]);
  const [grantTitleList, setGrantTitleList] = useState([]);
  const [pizerBUList, setPizerBUList] = useState([]);
  const [diseaseAreaList, setDiseaseAreaList] = useState([]);
  const [pfizerDrugList, setPfizerDrugList] = useState([]);
  const [inSight, setInSight] = useState(true);
  const [viewType, setViewType] = useState('grid');


  const handleKeyPress = (e, value, setValue, list, setList) => {
    if (e.key === 'Enter' && value.trim()) {
      setList([...list, value]);
      setValue('');
    }
  };

  const removeItem = (index, list, setList) => {
    setList(list.filter((_, i) => i !== index));
  };



  const openModal = () => {
    setModalIsOpen(true);
  };

  const closeModal = () => {
    resetAllFields();
    setModalIsOpen(false);
  };

  const resetAllFields = () => {
    setOrgName('');
    setPiName('');
    setGrantTitle('');
    setPizerBU('');
    setDiseaseArea('');
    setPfizerDrug('');

    setOrgNameList([]);
    setPiNameList([]);
    setGrantTitleList([]);
    setPizerBUList([]);
    setDiseaseAreaList([]);
    setPfizerDrugList([]);
  };

  const [showToggle, setShowToggle] = React.useState(false);

  const tdata = [
    {
      requestID: "76089911",
      projectTitle: "The use of insights from the covid-19 pandemic",
      status: "contract Executed",
      approvedAmount: "$120,560",
      remainingPayment: "$89,950",
      milestoneMet: "0",
      organizationName: "Soroko University Medical Center",
      PIName: "Dana Danino",
      abstractSummary: "The Covid-19 pandemic generate a unique ",
      internalNotes: "Add royzman, Iren to the workflow on 21-09-2023"
    },
    {
      requestID: "76089912",
      projectTitle: "The use of insights from the covid-19 pandemic",
      status: "contract Executed",
      approvedAmount: "$90,000",
      remainingPayment: "$40,950",
      milestoneMet: "0",
      organizationName: "Soroko University Medical Center",
      PIName: "Dana Danino",
      abstractSummary: "The Covid-19 pandemic generate a unique ",
      internalNotes: "Add royzman, Iren to the workflow on 21-09-2023"
    },
    {
      requestID: "76089913",
      projectTitle: "The use of insights from the covid-19 pandemic",
      status: "contract Executed",
      approvedAmount: "$110,000",
      remainingPayment: "$80,000",
      milestoneMet: "0",
      organizationName: "Soroko University Medical Center",
      PIName: "Dana Danino",
      abstractSummary: "The Covid-19 pandemic generate a unique ",
      internalNotes: "Add royzman, Iren to the workflow on 21-09-2023"
    },
    {
      requestID: "76089914",
      projectTitle: "The use of insights from the covid-19 pandemic",
      status: "contract Executed",
      approvedAmount: "$100,000",
      remainingPayment: "$70,050",
      milestoneMet: "0",
      organizationName: "Soroko University Medical Center",
      PIName: "Dana Danino",
      abstractSummary: "The Covid-19 pandemic generate a unique ",
      internalNotes: "Add royzman, Iren to the workflow on 21-09-2023"
    },
    {
      requestID: "76089915",
      projectTitle: "The use of insights from the covid-19 pandemic",
      status: "contract Executed",
      approvedAmount: "$150,000",
      remainingPayment: "$90,000",
      milestoneMet: "0",
      organizationName: "Soroko University Medical Center",
      PIName: "Dana Danino",
      abstractSummary: "The Covid-19 pandemic generate a unique ",
      internalNotes: "Add royzman, Iren to the workflow on 21-09-2023"
    },
    {
      requestID: "76089916",
      projectTitle: "The use of insights from the covid-19 pandemic",
      status: "contract Executed",
      approvedAmount: "$180,000",
      remainingPayment: "$80,250",
      milestoneMet: "0",
      organizationName: "Soroko University Medical Center",
      PIName: "Dana Danino",
      abstractSummary: "The Covid-19 pandemic generate a unique ",
      internalNotes: "Add royzman, Iren to the workflow on 21-09-2023"
    },
  ];
  
  return (
    <div className='wrapper'>
      <Header></Header>
      <div className="layout-wrapper main-wrapper-body d-flex">
        <SideBar activeTab={'Marketplace'} />
        <div className="main-content px-0 py-3">
          <div className='page-content'>
            <Container fluid>
              <div className='top-heading-section'>
                <h1 className='heading-top-h1'>Grants Dashboard</h1>
              </div>
              <div className='dashboard-card-element'>
                <Row className='row-grid-mx'>
                  <Col xs='12' md='4' lg='2' className='col-grid-px'>
                    <Card className='card-items-boxes card-box-lt'>
                      <Card.Title as="div" bsPrefix="card-headbox-wth d-flex flex-wrap align-items-center">
                        <div className='section-mt-wm'><h3 className='head-mrs-wts'>Total Submissions</h3></div>
                        <div className='flx-icon-wt'><span className='icon-card-yth'><img src={userIcon1} alt='icon' /></span></div>
                      </Card.Title>
                      <Card.Body className="card-space-wgt">
                        <div className='mdlwp-content'>
                          <h4 className='title-price-ds'>36,400</h4>
                          <p><span className='arrow-icon-mt'><img src={arrowDireaction} alt='icon' /></span><span className='txt-color-thm'>8.5%</span> Up from yesterday</p>
                        </div>
                      </Card.Body>
                    </Card>
                  </Col>
                  <Col xs='12' md='4' lg='2' className='col-grid-px'>
                    <Card className='card-items-boxes card-box-lt'>
                      <Card.Title as="div" bsPrefix="card-headbox-wth d-flex flex-wrap align-items-center">
                        <div className='section-mt-wm'><h3 className='head-mrs-wts'>Approvals</h3></div>
                        <div className='flx-icon-wt'><span className='icon-card-yth'><img src={userIcon2} alt='icon' /></span></div>
                      </Card.Title>
                      <Card.Body className="card-space-wgt">
                        <div className='mdlwp-content'>
                          <h4 className='title-price-ds'>11,900</h4>
                          <p><span className='arrow-icon-mt'><img src={arrowDireaction} alt='icon' /></span><span className='txt-color-thm'>8.5%</span> Up from yesterday</p>
                        </div>
                      </Card.Body>
                    </Card>
                  </Col>
                  <Col xs='12' md='4' lg='2' className='col-grid-px'>
                    <Card className='card-items-boxes card-box-lt'>
                      <Card.Title as="div" bsPrefix="card-headbox-wth d-flex flex-wrap align-items-center">
                        <div className='section-mt-wm'><h3 className='head-mrs-wts'>Total Granted</h3></div>
                        <div className='flx-icon-wt'><span className='icon-card-yth'><img src={userIcon3} alt='icon' /></span></div>
                      </Card.Title>
                      <Card.Body className="card-space-wgt">
                        <div className='mdlwp-content'>
                          <h4 className='title-price-ds'>$792M</h4>
                          <p><span className='arrow-icon-mt'><img src={arrowDireaction} alt='icon' /></span><span className='txt-color-thm'>8.5%</span> Up from yesterday</p>
                        </div>
                      </Card.Body>
                    </Card>
                  </Col>
                  <Col xs='12' md='4' lg='2' className='col-grid-px'>
                    <Card className='card-items-boxes card-box-lt'>
                      <Card.Title as="div" bsPrefix="card-headbox-wth d-flex flex-wrap align-items-center">
                        <div className='section-mt-wm'><h3 className='head-mrs-wts'>HCP Impacted</h3></div>
                        <div className='flx-icon-wt'><span className='icon-card-yth'><img src={userIcon4} alt='icon' /></span></div>
                      </Card.Title>
                      <Card.Body className="card-space-wgt">
                        <div className='mdlwp-content'>
                          <h4 className='title-price-ds'>920.60k</h4>
                          <p><span className='arrow-icon-mt'><img src={arrowDireaction} alt='icon' /></span><span className='txt-color-thm'>8.5%</span> Up from yesterday</p>
                        </div>
                      </Card.Body>
                    </Card>
                  </Col>
                  <Col xs='12' md='4' lg='2' className='col-grid-px'>
                    <Card className='card-items-boxes card-box-lt'>
                      <Card.Title as="div" bsPrefix="card-headbox-wth d-flex flex-wrap align-items-center">
                        <div className='section-mt-wm'><h3 className='head-mrs-wts'>Patients Impacted</h3></div>
                        <div className='flx-icon-wt'><span className='icon-card-yth'><img src={userIcon5} alt='icon' /></span></div>
                      </Card.Title>
                      <Card.Body className="card-space-wgt">
                        <div className='mdlwp-content'>
                          <h4 className='title-price-ds'>920.60k</h4>
                          <p><span className='arrow-icon-mt'><img src={arrowDireaction} alt='icon' /></span><span className='txt-color-thm'>8.5%</span> Up from yesterday</p>
                        </div>
                      </Card.Body>
                    </Card>
                  </Col>
                  <Col xs='12' md='4' lg='2' className='col-grid-px'>
                    <Card className='card-items-boxes card-box-lt'>
                      <Card.Title as="div" bsPrefix="card-headbox-wth d-flex flex-wrap align-items-center">
                        <div className='section-mt-wm'><h3 className='head-mrs-wts'>Learners Impacted</h3></div>
                        <div className='flx-icon-wt'><span className='icon-card-yth'><img src={userIcon6} alt='icon' /></span></div>
                      </Card.Title>
                      <Card.Body className="card-space-wgt">
                        <div className='mdlwp-content'>
                          <h4 className='title-price-ds'>920.60k</h4>
                          <p><span className='arrow-icon-mt'><img src={arrowDireaction} alt='icon' /></span><span className='txt-color-thm'>8.5%</span> Up from yesterday</p>
                        </div>
                      </Card.Body>
                    </Card>
                  </Col>
                </Row>
              </div>
              <div className='elemnt-sec-recomnd'>
                <Card className='card-items-boxes'>
                  <Tab.Container id="left-tabs-example" defaultActiveKey="tabpanel1">
                    <Card.Title as="div" bsPrefix="cardtab-header">
                      <Nav variant="pills" className="tabpanel-pill">
                        <Nav.Item>
                          <Nav.Link eventKey="tabpanel1" className='item-navtab-menu'>Recommended View</Nav.Link>
                        </Nav.Item>
                        <Nav.Item>
                          <Nav.Link eventKey="tabpanel2" className='item-navtab-menu'>All View</Nav.Link>
                        </Nav.Item>
                      </Nav>
                    </Card.Title>
                    <Card.Body>
                      <Tab.Content>
                        <Tab.Pane eventKey="tabpanel1">
                          <div className='content-ytn-waper'>
                            <Row className='mb-4'>
                              <Col xs='12' md='6'>
                                <div className='summary-mtr-lvl'>
                                  <div className='summary-elemnt-wpt mb-3'>
                                    <h3 className='title-sm--wgt mb-3'>Summary</h3>
                                    <Row className='row-grid-mx'>
                                      <Col xs='12' lg='4' className='col-grid-px'>
                                        <div className='summry-card-col d-flex flex-wrap align-items-center mb-2'>
                                          <div className='flex-img-sumr'>
                                            <img className='img-sumry-lvl' src={iconGlobWb} alt='img' />
                                          </div>
                                          <div className='rgt-colwp'>
                                            <h4 className='headt-mtr-rt'>Country</h4>
                                            <p>United States</p>
                                          </div>
                                        </div>
                                      </Col>
                                      <Col xs='12' lg='4' className='col-grid-px'>
                                        <div className='summry-card-col d-flex flex-wrap align-items-center mb-2'>
                                          <div className='flex-img-sumr'>
                                            <img className='img-sumry-lvl' src={iconCorona} alt='img' />
                                          </div>
                                          <div className='rgt-colwp'>
                                            <h4 className='headt-mtr-rt'>Pfizer Bu and Disease</h4>
                                            <p>High Blood Pressure</p>
                                          </div>
                                        </div>
                                      </Col>
                                      <Col xs='12' lg='4' className='col-grid-px'>
                                        <div className='summry-card-col d-flex flex-wrap align-items-center mb-2'>
                                          <div className='flex-img-sumr'>
                                            <img className='img-sumry-lvl' src={iconPeople} alt='img' />
                                          </div>
                                          <div className='rgt-colwp'>
                                            <h4 className='headt-mtr-rt'>Role</h4>
                                            <p>Dentist</p>
                                          </div>
                                        </div>
                                      </Col>
                                    </Row>
                                  </div>
                                  <div className='level-summry'>
                                    <Card className='card-sum-box-wgt'>
                                      <Card.Title as="div" bsPrefix="cardtab-header card-vt-padd">
                                        <h3 className='title-sm--wgt mb-0'>High Level Summary</h3>
                                      </Card.Title>
                                      <Card.Body className='card-wgt-box-tr'>
                                        <div className='summry-content-elemnt-rw'>
                                          <h3 className='heading-mt-lt mb-2'><span className='me-2 d-inline-block'><img src={handIcon} alt='hand' /></span>Hi Akash, welcome back.</h3>
                                          <h4 className='txt-upd-wgt pb-2'>Here are the latest updates</h4>
                                          <ul className='list-update-wps'>
                                            <li className='items-listwp-mtr'>In the last week 12 grants have been approved with the funding total of $2.3M. </li>
                                            <li className='items-listwp-mtr'>There are 4 grants that closed last week with outcomes report and publications below. </li>
                                            <li className='items-listwp-mtr'>Currently 5 grants ongoing need your attention and are flagged by our AI for your review.</li>
                                          </ul>
                                        </div>
                                      </Card.Body>
                                    </Card>
                                  </div>
                                </div>
                              </Col>
                              <Col xs='12' md='6'>
                                <div className='maparea-wgt'>
                                  <h2 className='title-headmvt'>Map View</h2>
                                  <div className='map-ytr-wn'>
                                    <img src={mapChartImg} alt='map' />
                                  </div>
                                </div>
                              </Col>
                            </Row>
                            <Row className='align-items-center'>
                              
                              <Col xs='12' md='6'>
                                <div className='d-flex flex-wrap align-items-center'>
                                  <sapn className="text-insl--tw">Summarize Insights</sapn>
                                  {/* <div className='check-swtch-mt d-inline-block ms-4'>
                                    <Form.Check 
                                      type="switch"
                                      className='onswitch-btn-view'
                                      checked={inSight}
                                      onChange={(e, v) => setInSight(!inSight)}

                                    />
                                  </div> */}
                                </div>
                              </Col>

                              <Col xs='12' md='6'>
                                {inSight ? 
                                <div className='d-flex align-items-center justify-content-end'>
                                  <div class="filter-colgrid-1">
                                    <div className='filtersh-lst--cnt'>
                                      <span className='txtlable-st'>Sort By</span>
                                      <select className='nwst-short-control'>
                                        <option>Newest</option>
                                      </select>
                                    </div>
                                  </div>
                                  {/* <div class="filter-colgrid-2">
                                    <button type='button' className='btn btn-download-btn'><img src={downloadIcon} className='me-2' alt='Download' />Download</button>
                                  </div> */}
                                  <div class="filter-colgrid-3">
                                    <div class="filtertab-itemswgt">
                                      <button onClick={() => setViewType('grid')} type='button' className={`btn btn-gridboth-list btn-flt-1 ${viewType == 'grid' ? 'active' : ''}`} ><FilterListIcon /></button>
                                      <button onClick={() => setViewType('list')}  type='button' className={`btn btn-gridboth-list btn-flt-2 ${viewType == 'list' ? 'active' : ''}`} ><FilterGridIcon /></button>

                                    </div>
                                  </div>
                                </div>
                                : 
                                <p className='text-end txt-wgtty-sum mb-0'>Enable this to view the summary of the grants</p>
                                }
                                
                              </Col>
                            </Row>
                            {
                              inSight ? viewType=="grid"?
                                <>
                                  <div className='sumrize-mult-wapcont mt-4'>
                                    <div className='mult-listwap--cont-wap'>
                                      <Card className='card-boxmlt--mtr'>
                                        <Card.Title as='div' bsPrefix='headtop--wgtmulti'>
                                          <div className='d-flex flex-wrap align-items-center'>
                                            <div className='brandLg--mtr pe-3'>
                                              <img src={brandLogo1} alt='logo' />
                                            </div>
                                            <div className='txtmtr--wgt'>
                                              <h3 className='heading-cadts'>A Multiomics approach to identify mechanisms of tissue damage in ATTR Cardiac amylooidosis</h3>
                                            </div>
                                          </div>
                                          <div className='rightlocated--elmnt'>
                                            <span className='locted-txtmtr'><img src={locationWebIcon} className='me-2' alt='icon' />Tacoma, Seattle, Washington</span>
                                          </div>
                                        </Card.Title>
                                        <Card.Body className='px-2'>
                                          <div className='wap-itemsbd--ytr'>
                                            <div className='mtr-list--morw mb-5'>
                                              <Row className='row-less-space'>
                                                <Col xs="12" md="2" className="p-space-less-5">
                                                  <div className='ptm-rt-bxflex'>
                                                    <div className='flxgrid--icon'>
                                                      <img src={iconweb1} alt='icon' />
                                                    </div>
                                                    <div className='fltrow--mtvb'>
                                                      <h4 className='txt-tl-small'>Total payment</h4>
                                                      <h6 className='bt-ftr--row'>$90,000</h6>
                                                    </div>
                                                  </div>
                                                </Col>
                                                <Col xs="12" md="2" className="p-space-less-5">
                                                  <div className='ptm-rt-bxflex'>
                                                    <div className='flxgrid--icon'>
                                                      <img src={iconweb2} alt='icon' />
                                                    </div>
                                                    <div className='fltrow--mtvb'>
                                                      <h4 className='txt-tl-small'>Pending payment</h4>
                                                      <h6 className='bt-ftr--row'>$16,000</h6>
                                                    </div>
                                                  </div>
                                                </Col>
                                                <Col xs="12" md="2" className="p-space-less-5">
                                                  <div className='ptm-rt-bxflex'>
                                                    <div className='flxgrid--icon'>
                                                      <img src={iconweb3} alt='icon' />
                                                    </div>
                                                    <div className='fltrow--mtvb'>
                                                      <h4 className='txt-tl-small'>Method</h4>
                                                      <h6 className='bt-ftr--row'>Research</h6>
                                                    </div>
                                                  </div>
                                                </Col>
                                                <Col xs="12" md="2" className="p-space-less-5">
                                                  <div className='ptm-rt-bxflex'>
                                                    <div className='flxgrid--icon'>
                                                      <img src={iconweb4} alt='icon' />
                                                    </div>
                                                    <div className='fltrow--mtvb'>
                                                      <h4 className='txt-tl-small'>Disease</h4>
                                                      <h6 className='bt-ftr--row'>Cardia Vascular ATTR</h6>
                                                    </div>
                                                  </div>
                                                </Col>
                                                <Col xs="12" md="2" className="p-space-less-5">
                                                  <div className='ptm-rt-bxflex'>
                                                    <div className='flxgrid--icon'>
                                                      <img src={iconweb5} alt='icon' />
                                                    </div>
                                                    <div className='fltrow--mtvb'>
                                                      <h4 className='txt-tl-small'>Drug Name</h4>
                                                      <h6 className='bt-ftr--row'>Dolo 650</h6>
                                                    </div>
                                                  </div>
                                                </Col>
                                                <Col xs="12" md="2" className="p-space-less-5">
                                                  <div className='ptm-rt-bxflex'>
                                                    <div className='flxgrid--icon'>
                                                      <img src={iconweb6} alt='icon' />
                                                    </div>
                                                    <div className='fltrow--mtvb'>
                                                      <h4 className='txt-tl-small'>Duration</h4>
                                                      <h6 className='bt-ftr--row'>13 Sep 2023 - 14 Apr 2024</h6>
                                                    </div>
                                                  </div>
                                                </Col>
                                              </Row>
                                            </div>
                                            <div className='mdl-area--wgt--mtr mb-5'>
                                              <Row>
                                                <Col xs='12' md='4' lg='4'>
                                                  <div className='field-txtmtr-dsg'>
                                                    <div className='d-flex flex-wrap group-mt-inpt align-items-center'>
                                                      <span class="btn-emt-wgt">Stydy Design</span>
                                                      <div className='flx--rtinput'><input type='text' placeholder='Pr-Clinical - Both Vitro and Invovo' className='form-control field-inpt-trp' /></div>
                                                    </div>
                                                  </div>
                                                </Col>
                                                <Col xs='12' md='4' lg='4'>
                                                  <div className='field-txtmtr-dsg'>
                                                    <div className='d-flex flex-wrap group-mt-inpt align-items-center'>
                                                      <span class="btn-emt-wgt">Population</span>
                                                      <div className='flx--rtinput'><input type='text' placeholder='Adults ; Hispanics' className='form-control field-inpt-trp' /></div>
                                                    </div>
                                                  </div>
                                                </Col>
                                                <Col xs='12' md='4' lg='4'>
                                                  <div className='field-txtmtr-dsg'>
                                                    <div className='d-flex flex-wrap group-mt-inpt align-items-center'>
                                                      <span class="btn-emt-wgt">Patients Enrolled</span>
                                                      <div className='enroll-progress d-flex align-items-center'>
                                                        <span className='txt-count--prg'>22</span>
                                                        <div class="progress--full-bar">
                                                          <span class="progress-wt-prt"></span>
                                                        </div>
                                                        <span className='txt-percent-full'>100</span>
                                                      </div>
                                                    </div>
                                                  </div>
                                                </Col>
                                              </Row>
                                            </div>
                                            <div className='footer-button-mtrol'>
                                              <div className='rw-grid-wps'>
                                                <div className='status-flx-wgt'>
                                                  <span className='left-txtinst'>Status Insights</span>
                                                  <span className='right--wrt-wl'>Completed<img src={completedIcon} className='ms-1' alt="icon" /></span>
                                                </div>
                                              </div>
                                              <div className='rw-grid-wps'>
                                                <div className='status-flx-wgt enrol-insite'>
                                                  <span className='left-txtinst'>Enrollment Insights</span>
                                                  <span className='right--wrt-wl'>Pending<img src={pendingEnollIcon} className='ms-1' alt="icon" /></span>
                                                </div>
                                              </div>
                                              <div className='rw-grid-wps'>
                                                <div className='status-flx-wgt upcoming-wgt'>
                                                  <span className='left-txtinst'>Upcoming</span>
                                                  <span className='right--wrt-wl'>Grant 123</span>
                                                </div>
                                              </div>
                                              <div className='link-zart--vp align-items-center'>
                                                <div className='d-flex flex-wrap align-items-center'>
                                                  <div className='button-wrt-lnk'>
                                                    <button type="button" className='btn btn-link-rpt border-0 p-0'>Outcomes Report</button>
                                                  </div>
                                                  <div className='button-wrt-lnk'>
                                                    <button type="button" className='btn btn-link-rpt border-0 p-0'>Publication Link</button>
                                                  </div>
                                                </div>
                                                <div className='summry-ai-wt'>
                                                  <div className='button-wrt-lnk'>
                                                    <button type="button" className='btn btn-link-rpt border-0 p-0' onClick={() => setShowToggle(!showToggle)}>View Gen AI Summary<img src={circleDown} alt='circle' className='ms-2' /></button>
                                                  </div>
                                                </div>
                                              </div>
                                            </div>

                                            {
                                              showToggle &&
                                              <div className='card-collapse-waper'>
                                                <Row>
                                                  <Col xs="12" md="6">
                                                    <div className='content-view-ai-sumr'>
                                                      <h3 className='head-wt--bnm'>
                                                        <span className='icon-cls me-3'><img src={circleIconRound} alt='cricle' /></span>
                                                        Research Summary
                                                      </h3>
                                                      <p className='lg-disc-wtr'>Current therapies for Transthyretin amyloidosis (ATTR) target the misfolded protein but do not address tissue damage by the already deposited amyloid. We have demonstrated that increased abundance of proteins within cardiac (and renal) amyloid plaques is associated with improved outcomes, which suggests that the amount of deposited proteins, may merely be a surrogate for indolent disease biology.</p>
                                                      <div className='sum-webtxttr mt-4'>
                                                        <ul className='rwt-txtmt'>
                                                          <li className='wa-listmt'><span class="btn-gp--mnt">Data Gaps</span></li>
                                                          <li className='wa-listmt'><span class="btn-gp--mnt">Health Quality</span></li>
                                                          <li className='wa-listmt'><span class="btn-gp--mnt">Digital Health & AI</span></li>
                                                          <li className='wa-listmt'><span class="btn-gp--mnt">Higher Learners Reached</span></li>
                                                        </ul>
                                                      </div>
                                                    </div>
                                                  </Col>
                                                  <Col xs="12" md="6">
                                                    <div className='content-view-ai-sumr'>
                                                      <h3 className='head-wt--bnm'>
                                                        <span className='icon-cls me-3'><img src={circleIconRound} alt='cricle' /></span>
                                                        Outcomes Highlights
                                                      </h3>
                                                      <p className='lg-disc-wtr'>Current therapies for Transthyretin amyloidosis (ATTR) target the misfolded protein but do not address tissue damage by the already deposited amyloid. We have demonstrated that increased abundance of proteins within cardiac (and renal) amyloid plaques is associated with improved outcomes, which suggests that the amount of deposited proteins, may merely be a surrogate for indolent disease biology.</p>
                                                    </div>
                                                  </Col>
                                                </Row>
                                              </div>
                                            }
                                          </div>
                                        </Card.Body>
                                      </Card>
                                    </div>
                                    <div className='mult-listwap--cont-wap'>
                                      <Card className='card-boxmlt--mtr'>
                                        <Card.Title as='div' bsPrefix='headtop--wgtmulti'>
                                          <div className='d-flex flex-wrap align-items-center'>
                                            <div className='brandLg--mtr pe-3'>
                                              <img src={brandLogo1} alt='logo' />
                                            </div>
                                            <div className='txtmtr--wgt'>
                                              <h3 className='heading-cadts'>Educational grant for the organization of the EMMA Vienna 2023 Meeting</h3>
                                            </div>
                                          </div>
                                          <div className='rightlocated--elmnt'>
                                            <span className='locted-txtmtr'><img src={locationWebIcon} className='me-2' alt='icon' />Tacoma, Seattle, Washington</span>
                                          </div>
                                        </Card.Title>
                                        <Card.Body className='px-2'>
                                          <div className='wap-itemsbd--ytr'>
                                            <div className='mtr-list--morw mb-5'>
                                              <Row className='row-less-space'>
                                                <Col xs="12" md="2" className="p-space-less-5">
                                                  <div className='ptm-rt-bxflex'>
                                                    <div className='flxgrid--icon'>
                                                      <img src={iconweb1} alt='icon' />
                                                    </div>
                                                    <div className='fltrow--mtvb'>
                                                      <h4 className='txt-tl-small'>Total payment</h4>
                                                      <h6 className='bt-ftr--row'>$149,000</h6>
                                                    </div>
                                                  </div>
                                                </Col>
                                                <Col xs="12" md="2" className="p-space-less-5">
                                                  <div className='ptm-rt-bxflex'>
                                                    <div className='flxgrid--icon'>
                                                      <img src={iconweb2} alt='icon' />
                                                    </div>
                                                    <div className='fltrow--mtvb'>
                                                      <h4 className='txt-tl-small'>Pending payment</h4>
                                                      <h6 className='bt-ftr--row'>$21,000</h6>
                                                    </div>
                                                  </div>
                                                </Col>
                                                <Col xs="12" md="2" className="p-space-less-5">
                                                  <div className='ptm-rt-bxflex'>
                                                    <div className='flxgrid--icon'>
                                                      <img src={iconweb3} alt='icon' />
                                                    </div>
                                                    <div className='fltrow--mtvb'>
                                                      <h4 className='txt-tl-small'>Method</h4>
                                                      <h6 className='bt-ftr--row'>MedEd</h6>
                                                    </div>
                                                  </div>
                                                </Col>
                                                <Col xs="12" md="2" className="p-space-less-5">
                                                  <div className='ptm-rt-bxflex'>
                                                    <div className='flxgrid--icon'>
                                                      <img src={iconweb4} alt='icon' />
                                                    </div>
                                                    <div className='fltrow--mtvb'>
                                                      <h4 className='txt-tl-small'>Disease</h4>
                                                      <h6 className='bt-ftr--row'>Onclology - Hematology</h6>
                                                    </div>
                                                  </div>
                                                </Col>
                                                {/* <Col xs="12" md="2" className="p-space-less-5">
                                                  <div className='ptm-rt-bxflex'>
                                                    <div className='flxgrid--icon'>
                                                      <img src={iconweb5} alt='icon' />
                                                    </div>
                                                    <div className='fltrow--mtvb'>
                                                      <h4 className='txt-tl-small'>Drug Name</h4>
                                                      <h6 className='bt-ftr--row'>Dolo 650</h6>
                                                    </div>
                                                  </div>
                                                </Col> */}
                                                <Col xs="12" md="2" className="p-space-less-5">
                                                  <div className='ptm-rt-bxflex'>
                                                    <div className='flxgrid--icon'>
                                                      <img src={iconweb6} alt='icon' />
                                                    </div>
                                                    <div className='fltrow--mtvb'>
                                                      <h4 className='txt-tl-small'>Duration</h4>
                                                      <h6 className='bt-ftr--row'>20 Aug 2023 - 14 Apr 2024</h6>
                                                    </div>
                                                  </div>
                                                </Col>
                                              </Row>
                                            </div>
                                            <div className='mdl-area--wgt--mtr mb-5'>
                                              <Row>
                                                <Col xs='12' md='4' lg='4'>
                                                  <div className='field-txtmtr-dsg'>
                                                    <div className='d-flex flex-wrap group-mt-inpt align-items-center'>
                                                      <span class="btn-emt-wgt">Targeted Learner Group</span>
                                                      <div className='flx--rtinput'><input type='text' placeholder='Physicians' className='form-control field-inpt-trp' /></div>
                                                    </div>
                                                  </div>
                                                </Col>
                                                <Col xs='12' md='4' lg='4'>
                                                  <div className='field-txtmtr-dsg'>
                                                    <div className='d-flex flex-wrap group-mt-inpt align-items-center'>
                                                      <span class="btn-emt-wgt">Specialty</span>
                                                      <div className='flx--rtinput'><input type='text' placeholder='Hematology' className='form-control field-inpt-trp' /></div>
                                                    </div>
                                                  </div>
                                                </Col>
                                                <Col xs='12' md='4' lg='4'>
                                                  <div className='field-txtmtr-dsg'>
                                                    <div className='d-flex flex-wrap group-mt-inpt align-items-center'>
                                                      <span class="btn-emt-wgt">Target Learners</span>
                                                      <div className='enroll-progress d-flex align-items-center'>
                                                        <span className='txt-count--prg'>180</span>
                                                        <div class="progress--full-bar">
                                                          <span class="progress-wt-prt"></span>
                                                        </div>
                                                        <span className='txt-percent-full'>100</span>
                                                      </div>
                                                    </div>
                                                  </div>
                                                </Col>
                                              </Row>
                                            </div>
                                            <div className='footer-button-mtrol'>
                                              <div className='rw-grid-wps'>
                                                <div className='status-flx-wgt'>
                                                  <span className='left-txtinst'>Status Insights</span>
                                                  <span className='right--wrt-wl'>Completed<img src={completedIcon} className='ms-1' alt="icon" /></span>
                                                </div>
                                              </div>
                                              <div className='rw-grid-wps'>
                                                <div className='status-flx-wgt upcoming-wgt'>
                                                  <span className='left-txtinst'>Upcoming</span>
                                                  <span className='right--wrt-wl'>Grant 123</span>
                                                </div>
                                              </div>
                                              <div className='link-zart--vp align-items-center'>
                                                <div className='d-flex flex-wrap align-items-center'>
                                                  <div className='button-wrt-lnk'>
                                                    <button type="button" className='btn btn-link-rpt border-0 p-0'>Outcomes Report</button>
                                                  </div>
                                                  <div className='button-wrt-lnk'>
                                                    <button type="button" className='btn btn-link-rpt border-0 p-0'>Publication Link</button>
                                                  </div>
                                                </div>
                                                <div className='summry-ai-wt'>
                                                  <div className='button-wrt-lnk'>
                                                    <button type="button" className='btn btn-link-rpt border-0 p-0'>View Gen AI Summary<img src={circleDown} alt='circle' className='ms-2' /></button>
                                                  </div>
                                                </div>
                                              </div>
                                            </div>

                                          </div>
                                        </Card.Body>
                                      </Card>
                                    </div>
                                    <div className='mult-listwap--cont-wap'>
                                      <Card className='card-boxmlt--mtr'>
                                        <Card.Title as='div' bsPrefix='headtop--wgtmulti'>
                                          <div className='d-flex flex-wrap align-items-center'>
                                            <div className='brandLg--mtr pe-3'>
                                              <img src={brandLogo2} alt='logo' />
                                            </div>
                                            <div className='txtmtr--wgt'>
                                              <h3 className='heading-cadts'>Temple COVID-19 Swab Negative QI Project</h3>
                                            </div>
                                          </div>
                                          <div className='rightlocated--elmnt'>
                                            <span className='locted-txtmtr'><img src={locationWebIcon} className='me-2' alt='icon' />Tacoma, Seattle, Washington</span>
                                          </div>
                                        </Card.Title>
                                        <Card.Body className='px-2'>
                                          <div className='wap-itemsbd--ytr'>
                                            <div className='mtr-list--morw mb-5'>
                                              <Row className='row-less-space'>
                                                <Col xs="12" md="2" className="p-space-less-5">
                                                  <div className='ptm-rt-bxflex'>
                                                    <div className='flxgrid--icon'>
                                                      <img src={iconweb1} alt='icon' />
                                                    </div>
                                                    <div className='fltrow--mtvb'>
                                                      <h4 className='txt-tl-small'>Total payment</h4>
                                                      <h6 className='bt-ftr--row'>$125,000</h6>
                                                    </div>
                                                  </div>
                                                </Col>
                                                <Col xs="12" md="2" className="p-space-less-5">
                                                  <div className='ptm-rt-bxflex'>
                                                    <div className='flxgrid--icon'>
                                                      <img src={iconweb2} alt='icon' />
                                                    </div>
                                                    <div className='fltrow--mtvb'>
                                                      <h4 className='txt-tl-small'>Pending payment</h4>
                                                      <h6 className='bt-ftr--row'>$16,000</h6>
                                                    </div>
                                                  </div>
                                                </Col>
                                                <Col xs="12" md="2" className="p-space-less-5">
                                                  <div className='ptm-rt-bxflex'>
                                                    <div className='flxgrid--icon'>
                                                      <img src={iconweb3} alt='icon' />
                                                    </div>
                                                    <div className='fltrow--mtvb'>
                                                      <h4 className='txt-tl-small'>Method</h4>
                                                      <h6 className='bt-ftr--row'>Quality Improvement</h6>
                                                    </div>
                                                  </div>
                                                </Col>
                                                <Col xs="12" md="2" className="p-space-less-5">
                                                  <div className='ptm-rt-bxflex'>
                                                    <div className='flxgrid--icon'>
                                                      <img src={iconweb4} alt='icon' />
                                                    </div>
                                                    <div className='fltrow--mtvb'>
                                                      <h4 className='txt-tl-small'>Disease</h4>
                                                      <h6 className='bt-ftr--row'>Support for Health Outcomes</h6>
                                                    </div>
                                                  </div>
                                                </Col>
                                                {/* <Col xs="12" md="2" className="p-space-less-5">
                                                  <div className='ptm-rt-bxflex'>
                                                    <div className='flxgrid--icon'>
                                                      <img src={iconweb5} alt='icon' />
                                                    </div>
                                                    <div className='fltrow--mtvb'>
                                                      <h4 className='txt-tl-small'>Drug Name</h4>
                                                      <h6 className='bt-ftr--row'>Dolo 650</h6>
                                                    </div>
                                                  </div>
                                                </Col> */}
                                                <Col xs="12" md="2" className="p-space-less-5">
                                                  <div className='ptm-rt-bxflex'>
                                                    <div className='flxgrid--icon'>
                                                      <img src={iconweb6} alt='icon' />
                                                    </div>
                                                    <div className='fltrow--mtvb'>
                                                      <h4 className='txt-tl-small'>Duration</h4>
                                                      <h6 className='bt-ftr--row'>15 Mar 2023 - 20 Feb 2024</h6>
                                                    </div>
                                                  </div>
                                                </Col>
                                              </Row>
                                            </div>
                                            <div className='mdl-area--wgt--mtr mb-5'>
                                              <Row>
                                                <Col xs='12' md='4' lg='4'>
                                                  <div className='field-txtmtr-dsg'>
                                                    <div className='d-flex flex-wrap group-mt-inpt align-items-center'>
                                                      <span class="btn-emt-wgt">Targeted Learner Group</span>
                                                      <div className='flx--rtinput'><input type='text' placeholder='Physicians' className='form-control field-inpt-trp' /></div>
                                                    </div>
                                                  </div>
                                                </Col>
                                                <Col xs='12' md='4' lg='4'>
                                                  <div className='field-txtmtr-dsg'>
                                                    <div className='d-flex flex-wrap group-mt-inpt align-items-center'>
                                                      <span class="btn-emt-wgt">Specialty</span>
                                                      <div className='flx--rtinput'><input type='text' placeholder='Hematology' className='form-control field-inpt-trp' /></div>
                                                    </div>
                                                  </div>
                                                </Col>
                                              </Row>
                                            </div>
                                            <div className='footer-button-mtrol'>
                                              <div className='rw-grid-wps'>
                                                <div className='status-flx-wgt'>
                                                  <span className='left-txtinst'>Status Insights</span>
                                                  <span className='right--wrt-wl'>Completed<img src={completedIcon} className='ms-1' alt="icon" /></span>
                                                </div>
                                              </div>
                                              <div className='rw-grid-wps'>
                                                <div className='status-flx-wgt upcoming-wgt'>
                                                  <span className='left-txtinst'>Upcoming</span>
                                                  <span className='right--wrt-wl'>Grant 123</span>
                                                </div>
                                              </div>
                                              <div className='link-zart--vp align-items-center'>
                                                <div className='d-flex flex-wrap align-items-center'>
                                                  <div className='button-wrt-lnk'>
                                                    <button type="button" className='btn btn-link-rpt border-0 p-0'>Outcomes Report</button>
                                                  </div>
                                                  <div className='button-wrt-lnk'>
                                                    <button type="button" className='btn btn-link-rpt border-0 p-0'>Publication Link</button>
                                                  </div>
                                                </div>
                                                <div className='summry-ai-wt'>
                                                  <div className='button-wrt-lnk'>
                                                    <button type="button" className='btn btn-link-rpt border-0 p-0'>View Gen AI Summary<img src={circleDown} alt='circle' className='ms-2' /></button>
                                                  </div>
                                                </div>
                                              </div>
                                            </div>
                                          </div>
                                        </Card.Body>
                                      </Card>
                                    </div>
                                  </div>
                                </>
                                :
                                <>
                                <div  className='pt-4'>
                                <table >
  <tr className='font '>
    <td >Request ID <img className='p-1' src={icon}></img></td>
    <td>Project Title<img  className='p-1' src={icon}></img></td>
    <td>Status <img  className='p-1' src={icon}></img></td>
    <td>Approved Amount <img  className='p-1' src={icon}></img></td>
    <td>Remaining Payment<img  className='p-1' src={icon}></img></td>
    <td>Milestone Met<img  className='p-1' src={icon}></img></td>
    <td>Organization Name<img  className='p-1' src={icon}></img></td>
    <td>PI Name <img  className='p-1' src={icon}></img></td>
    <td>Abstract Summary <img  className='p-1' src={icon}></img></td>
    <td>Internal Notes <img  className='p-1' src={icon}></img></td>

  </tr>
  {tdata.map((item, index) => (
  <tr key={index}>
    <td>{item.requestID} </td>
    <td>{item.projectTitle}</td>
    <td>{item.status}</td>
    <td> <img src={vector3}  alt="icon" />{item.approvedAmount} </td>
    <td> <img src={vector4} className='p-2' alt="icon" />{item.remainingPayment} </td>
    <td>{item.milestoneMet}</td>
    <td>{item.organizationName}</td>
    <td>{item.PIName}</td>
    <td>{item.abstractSummary} </td>
    <td>{item.internalNotes} </td>
  </tr>
))}
 
</table>
</div>
                                </>
                                :
                                null
                            }



                          </div>
                        </Tab.Pane>
                        <Tab.Pane eventKey="tabpanel2">
                          <Col xs={12} md={12} className='mt-3 mb-3'>
                            <div className="search-container-dash">
                              <div className="search-wrapper">
                                <img src={searchIcon} alt="Search Icon" className="search-icon" />
                                <input className="col-12 col-md-12 col-lg-12 search-input" type="text" placeholder="Search"></input>
                              </div>
                              <div className='btn-basic-container-dash'>
                                <button type='button' className='btn btn-add-project' onClick={openModal}>
                                  Filters
                                </button>
                                <button type='button' className='btn btn-add-project'>None</button>
                              </div>
                            </div>
                          </Col>
                          <Row className='mb-4'>
                            <Col xs='12' md='6'>
                              <div className='summary-mtr-lvl'>
                                <div className='summary-elemnt-wpt mb-3'>
                                  <h3 className='title-sm--wgt mb-3'>Summary</h3>
                                  <Row className='row-grid-mx'>
                                    <Col xs='12' lg='4' className='col-grid-px'>
                                      <div className='summry-card-col d-flex flex-wrap align-items-center mb-2'>
                                        <div className='flex-img-sumr'>
                                          <img className='img-sumry-lvl' src={iconGlobWb} alt='img' />
                                        </div>
                                        <div className='rgt-colwp'>
                                          <h4 className='headt-mtr-rt'>Country</h4>
                                          <p>United States</p>
                                        </div>
                                      </div>
                                    </Col>
                                    <Col xs='12' lg='4' className='col-grid-px'>
                                    <div className='summry-card-col d-flex flex-wrap align-items-center mb-2'>
                                          <div className='flex-img-sumr'>
                                            <img className='img-sumry-lvl' src={iconCorona} alt='img' />
                                          </div>
                                          <div className='rgt-colwp'>
                                            <h4 className='headt-mtr-rt'>Pfizer Bu and Disease</h4>
                                            <p>High Blood Pressure</p>
                                          </div>
                                        </div>
                                    </Col>
                                    <Col xs='12' lg='4' className='col-grid-px'>
                                      <div className='summry-card-col d-flex flex-wrap align-items-center mb-2'>
                                        <div className='flex-img-sumr'>
                                          <img className='img-sumry-lvl' src={iconPeople} alt='img' />
                                        </div>
                                        <div className='rgt-colwp'>
                                          <h4 className='headt-mtr-rt'>Role</h4>
                                          <p>Dentist</p>
                                        </div>
                                      </div>
                                    </Col>
                                  </Row>
                                </div>
                                <div className='level-summry'>
                                  <Card className='card-sum-box-wgt'>
                                    <Card.Title as="div" bsPrefix="cardtab-header py-3 px-4">
                                      <h3 className='title-sm--wgt mb-0'>High Level Summary</h3>
                                    </Card.Title>
                                    <Card.Body className='p-4'>
                                      <div className='summry-content-elemnt-rw'>
                                        <h3 className='heading-mt-lt mb-3'><span className='me-2 d-inline-block'><img src={handIcon} alt='hand' /></span>Hi Akash, welcome back.</h3>
                                        <h4 className='txt-upd-wgt pb-4'>Here are the latest updates</h4>
                                        <ul className='list-update-wps'>
                                          <li className='items-listwp-mtr'>In the last week 12 grants have been approved with the funding total of $2.3M. </li>
                                          <li className='items-listwp-mtr'>There are 4 grants that closed last week with outcomes report and publications below. </li>
                                          <li className='items-listwp-mtr'>Currently 5 grants ongoing need your attention and are flagged by our AI for your review.</li>
                                        </ul>
                                      </div>
                                    </Card.Body>
                                  </Card>
                                </div>
                              </div>
                            </Col>
                            <Col xs='12' md='6'>
                              <div className='maparea-wgt'>
                                <h2 className='title-headmvt'>Map View</h2>
                                <div className='map-ytr-wn'>
                                  <img src={mapChartImg} alt='map' />
                                </div>
                              </div>
                            </Col>
                          </Row>
                        </Tab.Pane>
                      </Tab.Content>
                    </Card.Body>
                  </Tab.Container>

                </Card>
              </div>
            </Container>
          </div>
        </div>
      </div>
      <Modal show={modalIsOpen} onHide={closeModal}>
        <Modal.Header closeButton>
          <div className='modal-header-sect'>
            <h3 className='modal-title-txt-mt'>Filter Details</h3>
            <p className='modal-txt-disc'>Please enter the project title and description to onboard new use-case to the production</p>
          </div>
        </Modal.Header>
        <Modal.Body>
          <Form className='form-call-md'>
            <Form.Group className="form-group-col mb-2">
              <Form.Label className='modal-txt-disc'>Organisation Name:</Form.Label>
              <Form.Control
                type="text"
                placeholder="Search for Organization Name"
                className='modal-txt-disc mt-2'
                value={orgName}
                onChange={(e) => setOrgName(e.target.value)}
                onKeyPress={(e) => handleKeyPress(e, orgName, setOrgName, orgNameList, setOrgNameList)}
              />
              <div className="mt-2 d-flex">
                {orgNameList.map((item, index) => (
                  <div key={index} className="d-flex align-items-center mb-1 selected-filter-text modal-txt-disc">
                    <span className="me-2">{item}</span>
                    <img className="me-2" src={crossIcon} onClick={() => removeItem(index, orgNameList, setOrgNameList)}></img>
                  </div>
                ))}
              </div>
            </Form.Group>

            <Form.Group className="form-group-col mb-2">
              <Form.Label className='modal-txt-disc'>PI Name:</Form.Label>
              <Form.Control
                type="text"
                placeholder="Type PI Name"
                className='modal-txt-disc mt-2'
                value={piName}
                onChange={(e) => setPiName(e.target.value)}
                onKeyPress={(e) => handleKeyPress(e, piName, setPiName, piNameList, setPiNameList)}
              />
              <div className="mt-2 d-flex">
                {piNameList.map((item, index) => (
                  <div key={index} className="d-flex align-items-center mb-1 selected-filter-text modal-txt-disc">
                    <span className="me-2">{item}</span>
                    <img className="me-2" src={crossIcon} onClick={() => removeItem(index, piNameList, setPiNameList)}></img>
                  </div>
                ))}
              </div>
            </Form.Group>

            <Form.Group className="form-group-col mb-2">
              <Form.Label className='modal-txt-disc'>Grant Title:</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter Grant Title"
                className='modal-txt-disc mt-2'
                value={grantTitle}
                onChange={(e) => setGrantTitle(e.target.value)}
                onKeyPress={(e) => handleKeyPress(e, grantTitle, setGrantTitle, grantTitleList, setGrantTitleList)}
              />
              <div className="mt-2 d-flex">
                {grantTitleList.map((item, index) => (
                  <div key={index} className="d-flex align-items-center mb-1 selected-filter-text modal-txt-disc">
                    <span className="me-2">{item}</span>
                    <img className="me-2" src={crossIcon} onClick={() => removeItem(index, grantTitleList, setGrantTitleList)}></img>
                  </div>
                ))}
              </div>
            </Form.Group>

            <Form.Group className="form-group-col mb-2">
              <Form.Label className='modal-txt-disc'>Pizer BU:</Form.Label>
              <Form.Control
                type="text"
                placeholder="Type Pfizer BU"
                className='modal-txt-disc mt-2'
                value={pizerBU}
                onChange={(e) => setPizerBU(e.target.value)}
                onKeyPress={(e) => handleKeyPress(e, pizerBU, setPizerBU, pizerBUList, setPizerBUList)}
              />
              <div className="mt-2 d-flex">
                {pizerBUList.map((item, index) => (
                  <div key={index} className="d-flex align-items-center mb-1 selected-filter-text modal-txt-disc">
                    <span className="me-2">{item}</span>
                    <img className="me-2" src={crossIcon} onClick={() => removeItem(index, pizerBUList, setPizerBUList)}></img>
                  </div>
                ))}
              </div>
            </Form.Group>

            <Form.Group className="form-group-col mb-2">
              <Form.Label className='modal-txt-disc'>Disease Area:</Form.Label>
              <Form.Control
                type="text"
                placeholder="Disease Area"
                className='modal-txt-disc mt-2'
                value={diseaseArea}
                onChange={(e) => setDiseaseArea(e.target.value)}
                onKeyPress={(e) => handleKeyPress(e, diseaseArea, setDiseaseArea, diseaseAreaList, setDiseaseAreaList)}
              />
              <div className="mt-2 d-flex">
                {diseaseAreaList.map((item, index) => (
                  <div key={index} className="d-flex align-items-center mb-1 selected-filter-text modal-txt-disc">
                    <span className="me-2">{item}</span>
                    <img className="me-2" src={crossIcon} onClick={() => removeItem(index, diseaseAreaList, setDiseaseAreaList)}></img>
                  </div>
                ))}
              </div>
            </Form.Group>

            <Form.Group className="form-group-col mb-2">
              <Form.Label className='modal-txt-disc'>Enter Pfizer Drug:</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter Pfizer Drug"
                className='modal-txt-disc mt-2'
                value={pfizerDrug}
                onChange={(e) => setPfizerDrug(e.target.value)}
                onKeyPress={(e) => handleKeyPress(e, pfizerDrug, setPfizerDrug, pfizerDrugList, setPfizerDrugList)}
              />
              <div className="mt-2 d-flex">
                {pfizerDrugList.map((item, index) => (
                  <div key={index} className="d-flex align-items-center mb-1 selected-filter-text modal-txt-disc">
                    <span className="me-2">{item}</span>
                    <img className="me-2" src={crossIcon} onClick={() => removeItem(index, pfizerDrugList, setPfizerDrugList)}></img>
                  </div>
                ))}
              </div>
            </Form.Group>

            <Form.Group className="form-group-col  mb-2">
              <Form.Label className='modal-txt-disc'>Thei tags</Form.Label>
              <Form.Select className='modal-txt-disc mt-2' >
                <option>Pfizer</option>
              </Form.Select>
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <span className='modal-item-navtab-menu' onClick={() => { resetAllFields(); closeModal(); }}>Apply</span>
        </Modal.Footer>
      </Modal>
    </div>
  );
}

export default Dashboard;
