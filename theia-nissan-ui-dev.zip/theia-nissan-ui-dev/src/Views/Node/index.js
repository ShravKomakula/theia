import React, { useState,useEffect } from 'react';
import { useNavigate } from 'react-router-dom'
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Card from 'react-bootstrap/Card';
import SideBar from '../../Common/SideBar';
import Header from '../../Common/Header';
import './index.scss';
import ClockIcon1 from '../../assets/images/icons/clock-icon-1.svg';
import ClockIcon2 from '../../assets/images/icons/clock-icon-2.svg';
import ClockIcon3 from '../../assets/images/icons/clock-icon-3.svg';
import ClockIcon4 from '../../assets/images/icons/clock-icon-4.svg';
import ClockIcon5 from '../../assets/images/icons/clock-icon-5.svg';
import toothIcon1 from '../../assets/images/icons/tooth-icon-1.svg';
import toothIcon2 from '../../assets/images/icons/tooth-icon-2.svg';
import toothIcon3 from '../../assets/images/icons/tooth-icon-3.svg';
import toothIcon4 from '../../assets/images/icons/tooth-icon-4.svg';
import splistImg from '../../assets/images/pic-user-specialist.png';
import closeIcon from '../../assets/images/icons/close-icon-web.svg';
import userPicture from '../../assets/images/pic-user-specialist.png';
import relatedPic from '../../assets/images/related-img-us.png';
import previousIcon from '../../assets/images/icons/previous-icon.svg';
import nextIcon from '../../assets/images/icons/next-icon.svg';
import goBack from '../../assets/images/icons/arrow-left-long-icon.svg';
import searchScients from '../../assets/images/icons/search-icon-grey.svg';
import icon from './../../assets/images/Rectangle26.svg';
import icon7 from './../../assets/images/Rectangle26(1).svg';
import icon2 from './../../assets/images/Rectangle26(2).svg';
import icon3 from './../../assets/images/Rectangle27.svg';
import icon4 from './../../assets/images/Rectangle27(1).svg';
import icon5 from './../../assets/images/Rectangle28.svg';
import icon6 from './../../assets/images/Rectangle28(1).svg';
import copy from './../../assets/images/Vector(5).svg';
// import Button from 'react-bootstrap/Button';
// import Modal from 'react-bootstrap/Modal';
// import Form from 'react-bootstrap/Modal';
import { Modal, Form, Button } from 'react-bootstrap';
import prson1 from '../../assets/images/expert-person-1.png';
import prson2 from '../../assets/images/expert-person-2.png';
import prson3 from '../../assets/images/expert-person-3.png';
import prson4 from '../../assets/images/expert-person-4.png';
import prson5 from '../../assets/images/expert-person-5.png';
import prson6 from '../../assets/images/expert-person-6.png';
import prson7 from '../../assets/images/expert-person-7.png';
import prson8 from '../../assets/images/expert-person-8.png';
import prson9 from '../../assets/images/expert-person-9.png';
import prson10 from '../../assets/images/expert-person-10.png';
import prson11 from '../../assets/images/expert-person-11.png';
import prson12 from '../../assets/images/expert-person-12.png';


import { ComposableMap, Geographies, Geography, Marker } from 'react-simple-maps';
import { FaUser } from 'react-icons/fa';
import { ReactComponent as PersonIcon } from "../../assets/images/personIcon.svg";
import PlainBarGraph from '../../Common/Graphs/PlainBarGraph';
import Slider from 'react-slick';
let Scientific = () => {
  const navigate = useNavigate()
  const [cardDetails, setCardDetails] = useState(null);
  const [price, setPrice] = useState('');

  const [show, setShow] = useState(false);
  const handleShow = () => setShow(true);
  const [nodes, setNodes] = useState([
    "Publication",
    "Association",
    "Digital Reach focus area",
    "Scientific Focus Area",
    "Speciality",
    "Medical Event",
    "Company",
    "Payment",
    "Trial",
    "Trialwork",
    "Country",
    "Organization",
    "Location"
  ]);
  const properties = [
    {
      name: "<id>",
      number: '80896457',
      icon: copy,
    },
    {
      name: "facility_citelitine_id",
      number: 'NaN',
      icon: copy
    },
    {
      name: "facility_golden_id",
      number: 'DD282353',
      icon: copy
    },
    {
      name: "facility_name",
      number: 'Kaiser Permanente-O’fareell Medical Office',
      icon: copy
    },
  ]

  const [filteredNodes, setFilteredNodes] = useState([
    "Publication",
    "Association",
    "Digital Reach focus area",
    "Scientific Focus Area",
    "Speciality",
    "Medical Event",
    "Company",
    "Payment",
    "Trial",
    "Trialwork",
    "Country",
    "Organization",
    "Location"
  ]);

  const [filters, setFilters] = useState([

  ]);

  const geoUrl = "https://raw.githubusercontent.com/xoolive/topojson/master/world-countries.json";
  const icons = [icon, icon7, icon3, icon5, icon2, icon4, , icon6,];

  const locations = [
    { name: "New York", coordinates: [-74.006, 40.7128] },
    { name: "London", coordinates: [-0.1276, 51.5074] },
    { name: "Tokyo", coordinates: [139.6917, 35.6895] },
    { name: "Sydney", coordinates: [151.2093, -33.8688] },
  ];

  // Sample data with multiple markers at the same location
  const multipleMarkers = [
    { name: "New York", coordinates: [-74.006, 40.7128] },
    { name: "New York", coordinates: [-74.0061, 40.7129] },
    { name: "New York", coordinates: [-74.0059, 40.7127] },
  ];

  let onNodeClick = (val) => {
    let temp = [...filteredNodes]
    if (temp.includes(val)) {
      // let remainingItems = temp.filter(ele => ele != val)
      // setFilteredNodes(remainingItems)
      if (temp.length < 2) {
        setFilteredNodes([...nodes])
      } else {
        setFilteredNodes([val])
      }
    } else {
      //temp.push(val)
      setFilteredNodes([val])
    }
  }


  let onFilterApply = () => {
    setShow(false)
    handleClose()
    setFilteredNodes([...filters])
  }
  const handleClose = () => {
    setShow(false);
    setFilters([])
  }


  let handleCheck = (val) => {
    let temp = [...filters]
    if (temp.includes(val)) {
      let remainingItems = temp.filter(ele => ele != val)
      setFilters(remainingItems)
    } else {
      temp.push(val)
      setFilters(temp)
    }
  }

  let resetFilters = () => {
    setFilteredNodes([
      ...nodes
    ])
  }


  useEffect(() => {
    const randomPrice = (Math.random() * 9000 + 1000).toFixed(2);
    setPrice(`$${randomPrice}`);
  }, []);

  useEffect(() => {
    const data = localStorage.getItem('selectedCard');
    if (data) {
      setCardDetails(JSON.parse(data));
    } else {
      navigate('/'); 
    }
  }, [navigate]);

  if (!cardDetails) {
    return <div>Loading...</div>;
  }

  

  console.log("fill->", cardDetails)

  return (
    <div className='wrapper'>
      <Header></Header>
      <div className="layout-wrapper main-wrapper-body d-flex">
        <SideBar activeTab={'Marketplace'} />
        <div className="main-content py-3">
          <div className='page-content'>
            <Container fluid className='px-0'>
              <Row>
                <Col xs='12' lg='9'>
                  <Card className='card-eql-ht'>
                    <Card.Title as="div" bsPrefix='tophead--bar-element d-flex flex-wrap align-items-center p-3'>
                      <div className='back-flex-wap'>
                        <button onClick={() => navigate('/scientific-expert')} type='button' className='btn btn-back-btn p-0'><img src={goBack} alt='back' className='me-2' />GO Back</button>
                      </div>
                      <div className='search-scientist-flex px-4'>
                        <div className='searchField-top position-relative'>
                          <input type='text' placeholder='Search scientists' className='form-control search-control-scients' />
                          <button type='button' className='btn search-back-snt p-0'><img src={searchScients} alt='Search' /></button>
                        </div>
                      </div>
                      <div className='filter-right-flex'>
                        <div className="filtercard-rght" style={{ cursor: 'pointer' }}>
                          <span className='txt-el-1' onClick={handleShow}>Filter(0)</span>
                          <span onClick={() => resetFilters()} className='txt-el-non'>None</span>
                        </div>
                      </div>
                    </Card.Title>
                    <Card.Body>
                      <div className='chat-layout-wapper-element'>
                        <Row>
                        <div className='p-2'>
                            <h5>Career Summary</h5>
                            <p className='paragraph'>
                              {/* Career A dedicated and accomplished Medical Scientist with extensive experience in biomedical 
                              research and clinical laboratory investigations. Career A dedicated and accomplished Medical Scientist with 
                              extensive experience in biomedical research and clinical laboratory investigations. Career A dedicated and accomplished Medical 
                              Scientist with extensive experience in biomedical research and clinical laboratory investigations. */}
                               </p>
                            </div>
                        </Row>
                        <Row className='align-items-center'>
                          <Col xs='12' md='5' className='pe-4 col-chart-1'>
                            <div class="publication-area-chart">
                              <div className='publi-chart-wgt'>
                                <div className={`list-chart-pbs ${filteredNodes.includes('Publication') ? '' : 'node_disabled'}`} style={{ cursor: 'pointer' }} onClick={() => onNodeClick('Publication')}  >
                                  {/* <div className={`list-chart-pbs disabled ${filteredNodes.includes('Publication') ? 'disabled' : 'disabled'}`}> */}
                                  <div className='leftside-txtbtn'>
                                    <span className='btn-pbls-wt txt-chat-color-1'><img src={ClockIcon1} className='me-1' alt="" />Publication(10)</span>
                                  </div>
                                  <div className='rightside-txtgm coss-line-arrow line-imgcross-1'>
                                    <span>Published</span>
                                  </div>
                                </div>

                                <div className={`list-chart-pbs ${filteredNodes.includes('Association') ? '' : 'node_disabled'}`} style={{ cursor: 'pointer' }} onClick={() => onNodeClick('Association')}  >
                                  <div className='leftside-txtbtn'>
                                    <span className='btn-pbls-wt txt-chat-color-2'><img src={ClockIcon2} className='me-1' alt="" />Association(08)</span>
                                  </div>
                                  <div className='rightside-txtgm coss-line-arrow line-imgcross-2'>
                                    <span>Associated_IN</span>
                                  </div>
                                </div>
                                <div className={`list-chart-pbs ${filteredNodes.includes('Digital Reach focus area') ? '' : 'node_disabled'}`} style={{ cursor: 'pointer' }} onClick={() => onNodeClick('Digital Reach focus area')}  >
                                  <div className='leftside-txtbtn'>
                                    <span className='btn-pbls-wt txt-chat-color-3'><img src={ClockIcon3} className='me-1' alt="" />Digital Reach focus area (04)</span>
                                  </div>
                                  <div className='rightside-txtgm coss-line-arrow line-imgcross-3'>
                                    <span>Has_Digital_Reach</span>
                                  </div>
                                </div>
                                <div className={`list-chart-pbs ${filteredNodes.includes('Scientific Focus Area') ? '' : 'node_disabled'}`} style={{ cursor: 'pointer' }} onClick={() => onNodeClick('Scientific Focus Area')}  >
                                  <div className='leftside-txtbtn'>
                                    <span className='btn-pbls-wt txt-chat-color-4'><img src={toothIcon1} className='me-1' alt="" />Scientific Focus Area(12)</span>
                                  </div>
                                  <div className='rightside-txtgm coss-line-arrow line-imgcross-4'>
                                    <span>Has_Digital_Reach</span>
                                  </div>
                                </div>
                                <div className={`list-chart-pbs ${filteredNodes.includes('Speciality') ? '' : 'node_disabled'}`} style={{ cursor: 'pointer' }} onClick={() => onNodeClick('Speciality')}  >
                                  <div className='leftside-txtbtn'>
                                    <span className='btn-pbls-wt txt-chat-color-5'><img src={toothIcon2} className='me-1' alt="" />Speciality(04)</span>
                                  </div>
                                  <div className='rightside-txtgm coss-line-arrow line-imgcross-5'>
                                    <span>Has_Specialty</span>
                                  </div>
                                </div>
                                <div className={`list-chart-pbs ${filteredNodes.includes('Medical Event') ? '' : 'node_disabled'}`} style={{ cursor: 'pointer' }} onClick={() => onNodeClick('Medical Event')}  >
                                  <div className='leftside-txtbtn'>
                                    <span className='btn-pbls-wt txt-chat-color-6'><img src={toothIcon3} className='me-1' alt="" />Medical Event(28)</span>
                                  </div>
                                  <div className='rightside-txtgm coss-line-arrow line-imgcross-6'>
                                    <span>Attended</span>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </Col>
                           <Col xs='12' md='2' className='px-0 col-chart-2'>
                            <div className='nero-splist position-relative'>
                              {/* <div className='button-close-wgt text-center'>
                                <button type='button' className='btn btn-close-btn p-0 border-0'><img src={closeIcon} alt='close' /></button>
                              </div> */}
                              <div className='d-flex flex-wrap card-nvm-nero'>
                                <div className='img-splst-wgt'>
                                  <img src={cardDetails.personUrl} alt='pic' />
                                </div>
                                <div className='speist-info-cont'>
                                  <h3 className='splist-mnt-cont'>{cardDetails.title}</h3>
                                  <h3 className='splist-mnt-cont'> {cardDetails.reference}</h3>

                                  <p className='const-spl-wtr'><span><img src={toothIcon2} alt='tooth' /></span>{cardDetails.Occupation}</p>
                                </div>
                              </div>
                            </div>
                          </Col> 
                          <Col xs='12' md='5' className='ps-5 col-chart-3'>
                            <div className='company-payed-wt'>
                              <div className='item-bar-wth'>

                                <div style={{ cursor: 'pointer' }} className={`rght-mtweb--top text-end position-relative d-flex align-items-center 
                                 ${filteredNodes.includes('Company') ? '' : 'node_disabled'} `}
                                  onClick={() => onNodeClick('Company')}
                                >
                                  <div className='line-bg-wt'>
                                    <span className='txt-comn-trt'>Payed</span>
                                  </div>
                                  <span class="btn-pbls-wt txt-chat-color-3"><img src={ClockIcon3} class="me-1" alt="watch" />Company</span>
                                </div>

                                <div style={{ cursor: 'pointer' }} className={`rght-mtweb--top ${filteredNodes.includes('Payment') ? '' : 'node_disabled'} `}
                                  onClick={() => onNodeClick('Payment')}
                                >
                                  <div className='width-lyt-1 position-relative'>
                                    <span class="btn-pbls-wt txt-chat-color-7"><img src={ClockIcon4} class="me-1" alt="watch" />Payment(12)</span>
                                    <div className='btm-txtlni img-line-vertcal-1 position-relative'>
                                      <span className='txt-cont-vmn txt-comn-trt'>Refers_to</span>
                                    </div>
                                    <div class="wgt-elmn-corner1">
                                      <span className='lft-corner-line txt-comn-trt'>Received</span>
                                    </div>
                                  </div>

                                </div>

                                <div style={{ cursor: 'pointer' }} className={`rght-mtweb--top ${filteredNodes.includes('Trial') ? '' : 'node_disabled'} `}
                                  onClick={() => onNodeClick('Trial')}
                                >
                                  <div className={`width-lyt-1`}>
                                    <span class="btn-pbls-wt txt-chat-color-8"><img src={toothIcon4} class="me-1" alt="watch" />Trial(12)</span>
                                    <div className='btm-txtlni img-line-vertcal-2 position-relative'>
                                      <span className='txt-cont-vmn txt-comn-trt'>Executed</span>
                                    </div>
                                  </div>
                                </div>

                                <div className='rght-mtweb--top' >
                                  <div className='tw-layer-mtr'>

                                    <div className={`flex-tt-mtr  ${filteredNodes.includes('Trialwork') ? '' : 'node_disabled'} `} style={{ cursor: 'pointer' }}
                                      onClick={() => onNodeClick('Trialwork')}
                                    >
                                      <div className='moretxt-trt position-relative'>
                                        <span class="btn-pbls-wt txt-chat-color-9"><img src={ClockIcon5} class="me-1" alt="watch" />Trialwork(02)</span>
                                        <div class="wgt-elmn-corner2">
                                          <span className='lft-corner-line txt-comn-trt'>Conducted</span>
                                        </div>
                                      </div>
                                      <div className='btm-txtlni img-line-vertcal-3'>
                                        <span className='txt-cont-vmn txt-comn-trt'>Conducted at</span>
                                      </div>
                                    </div>

                                    <div
                                      style={{ cursor: 'pointer' }}
                                      className={`flex-tt-mtr ${filteredNodes.includes('Country') ? '' : 'node_disabled'} `}
                                      onClick={() => onNodeClick('Country')}
                                    >
                                      <div className='moretxt-trt'>
                                        <span class="btn-pbls-wt txt-chat-color-3"><img src={ClockIcon3} class="me-1" alt="watch" />Country</span>
                                      </div>
                                      <div className='btm-txtlni img-line-vertcal-4'>
                                        <span className='txt-cont-vmn txt-comn-trt'>Located In</span>
                                      </div>
                                    </div>

                                  </div>
                                </div>
                                <div className='rght-mtweb--top' >
                                  <div className='tw-layer-mtr align-items-center'>

                                    <div className={`ftr-th-level ${filteredNodes.includes('Organization') ? '' : 'node_disabled'}`}
                                      style={{ cursor: 'pointer' }}
                                      onClick={() => onNodeClick('Organization')}
                                    >
                                      <span class="btn-pbls-wt txt-chat-color-3"><img src={ClockIcon3} class="me-1" alt="watch" />Organization(12)</span>
                                    </div>

                                    <div className={`horizontal-line-wgt`}

                                    >
                                      <span className='txt-located txt-comn-trt'>Located at</span>
                                    </div>
                                    <div className={`ftr-th-level  ${filteredNodes.includes('Location') ? '' : 'node_disabled'}`}

                                      style={{ cursor: 'pointer' }}
                                      onClick={() => onNodeClick('Location')
                                      }
                                    >
                                      <span class="btn-pbls-wt txt-chat-color-3"><img src={ClockIcon3} class="me-1" alt="watch" />Location</span>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </Col>
                        </Row>
                      </div>
                    </Card.Body>
                  </Card>
                </Col>
                <Col xs='12' lg='3' className='ps-0'>
                  {filteredNodes.length > 1 ?
                    <Card className='card-element-container card-box-border card-eql-ht'>
                      <Card.Title as="div" bsPrefix="card-header-sumry-wgt">
                        <div className='head-top-lemnt-ytflx d-flex flex-wrap p-3 align-items-center'>
                          <div className='imgflx--emt-wt'>
                            <img src={cardDetails.personUrl} alt='img' />
                          </div>
                          <div className='info-usermt-hd'>
                            <h4 className='elm-htr--wm'>{cardDetails.title} &nbsp; {cardDetails.reference}</h4>
                          </div>
                        </div>
                      </Card.Title>
                      <Card.Body class="p-0">
                        <div className='txtcareer--elmnt--wgt p-3'>
                          <h3 className='career-head txtintern--elmnt-wgt'>Career Summary</h3>
                          <p className='txt-contentwgt-mt'>His dedicated and accomplished Medical Scientist with extensive experience in biomedical research and clinical laboratory investigations. </p>
                        </div>
                        <div className='chat-engage-wtr p-3'>
                          <div className='ttl-chart-ptm mb-3'>
                            <h3 className='txtintern--elmnt-wgt'>Total Engagements/Payments</h3>
                            <div className='price-eng-pyt'>
                              <span>$4650</span>
                            </div>
                          </div>
                          <div className='pricechart-select'>
                            <div class="wgtchart--txtmtr">
                              <input
                                type='text'
                                value={price}
                                name={price}
                                className='form-control control-pricetxt'
                                readOnly
                              />
                              <select className='form-control select-optionchart'>
                                <option>2023</option>
                                <option>2022</option>
                                <option>2021</option>
                              </select>
                            </div>
                          </div>
                          <div>
                            <PlainBarGraph icons={icons}></PlainBarGraph>
                          </div>
                        </div>

                        <div className='recent-eng--intial p-3'>
                          <div className='sect-heading-engtr d-flex flex-row align-items-center mb-3'>
                            <h3 className='text-title-eng txtintern--elmnt-wgt'>Recent Pfizer Engagements/Initiatives</h3>
                            <div className='slide-btn-view'>
                              <button type='button' className='btn border-0 p-0 me-2'><img src={previousIcon} alt="icon" /></button>
                              <button type='button' className='btn border-0 p-0'><img src={nextIcon} alt="icon" /></button>
                            </div>
                          </div>
                          <Card className='card-box-border'>
                            <Card.Title as="h3" bsPrefix='cardTitle-h3'>Grant Request 01</Card.Title>
                            <Card.Body>
                              <div className='middle-card-fnd'>
                                <h3>Finding payments of a scientist from 2023</h3>
                                <div className='d-flex flex-wrap align-items-center justify-content-between'>
                                  <div className='price-mtr-wgt'><span className='price-txt-rct'>$450</span></div>
                                  <div className='days-rxnt'>
                                    <span className='days-mt-rctp'>2 days ago</span>
                                  </div>
                                </div>
                              </div>
                            </Card.Body>
                          </Card>
                        </div>
                        <div className='related-us-imgweb p-3'>
                          <h3 class="txtintern--elmnt-wgt mb-3">Related Scientists (08)</h3>
                          <Row>
                            <Col xs='6' md='4' lg='3'>
                              <div className='related-sc-whtto'>
                                <img src={prson1} alt='img' />
                              </div>
                            </Col>
                            <Col xs='6' md='4' lg='3'>
                              <div className='related-sc-whtto'>
                                <img src={prson2} alt='img' />
                              </div>
                            </Col>
                            <Col xs='6' md='4' lg='3'>
                              <div className='related-sc-whtto'>
                                <img src={prson3} alt='img' />
                              </div>
                            </Col>
                            <Col xs='6' md='4' lg='3'>
                              <div className='related-sc-whtto'>
                                <img src={prson4} alt='img' />
                              </div>
                            </Col>
                            <Col xs='6' md='4' lg='3'>
                              <div className='related-sc-whtto'>
                                <img src={prson5} alt='img' />
                              </div>
                            </Col>
                            <Col xs='6' md='4' lg='3'>
                              <div className='related-sc-whtto'>
                                <img src={prson6} alt='img' />
                              </div>
                            </Col>
                            <Col xs='6' md='4' lg='3'>
                              <div className='related-sc-whtto'>
                                <img src={prson7} alt='img' />
                              </div>
                            </Col>
                            <Col xs='6' md='4' lg='3'>
                              <div className='related-sc-whtto'>
                                <img src={prson8} alt='img' />
                              </div>
                            </Col>
                          </Row>
                        </div>


                      </Card.Body>
                    </Card> :
                    <>
                      <div className='d-flex justify-content-between'>
                        <h6 className='p-2'>Node Properties</h6>
                        <button className='organization'>Organization</button>
                      </div>
                      <Card className='p-1 m-1 mt-2'>
                        {
                          properties.map((item, index) => (
                            <div className="p-2 sizes" key={index}>
                              <p className='propss'>{item.name}</p>
                              <div className='d-flex justify-content-between align-items-center'>
                                <p>{item.number}</p>
                                <img src={item.icon} />
                              </div>
                            </div>
                          ))
                        }

                      </Card>
                      <Card className='p-1 m-1 mt-2'>
                        {
                          properties.map((item, index) => (
                            <div className="p-2 sizes">
                              <p className='propss'>{item.name}</p>
                              <div className='d-flex justify-content-between align-items-center'>
                                <p>{item.number}</p>
                                <img src={item.icon} />
                              </div>

                            </div>
                          ))
                        }
                      </Card>
                      <Card className='p-1 m-1 mt-2'>
                        {
                          properties.map((item, index) => (
                            <div className="p-2 sizes">
                              <p className='propss'>{item.name}</p>
                              <div className='d-flex justify-content-between align-items-center'>
                                <p>{item.number}</p>
                                <img src={item.icon} />
                              </div>

                            </div>
                          ))
                        }
                      </Card>
                    </>
                  }
                </Col>
              </Row>
              <>
                <Modal show={show} onHide={handleClose}
                  centered
                  // style={{width:'250px'}}   
                  size="sm"

                >
                  <Modal.Header >
                    <Modal.Title>Filters</Modal.Title>
                  </Modal.Header>
                  <Modal.Body>
                    <Form>
                      <Form.Check
                        onClick={(e) => handleCheck(e.target.value)}
                        type="checkbox"
                        id="tesla-checkbox"
                        label="Company"
                        name="Company"
                        value="Company"
                        className=' fontcolor pt-4'
                      />
                      <Form.Check
                        onClick={(e) => handleCheck(e.target.value)}
                        type="checkbox"
                        id="bmw-checkbox"
                        label="Payment"
                        name="BMW"
                        value="Payment"
                        className=' fontcolor pt-4'

                      />
                      <Form.Check
                        onClick={(e) => handleCheck(e.target.value)}
                        type="checkbox"
                        id="audi-checkbox"
                        label="Trail"
                        name="Trail"
                        value="Trail"
                        className='fontcolor pt-4'

                      />
                      <Form.Check
                        onClick={(e) => handleCheck(e.target.value)}
                        type="checkbox"
                        id="mercedes-checkbox"
                        label="Trailwork"
                        name="Trailwork"
                        value="Trailwork"
                        className='fontcolor pt-4'

                      />
                      <Form.Check
                        onClick={(e) => handleCheck(e.target.value)}
                        type="checkbox"
                        id="ford-checkbox"
                        label="Organization"
                        name="Organization"
                        value="Organization"
                        className='fontcolor pt-4'

                      />
                    </Form>
                    <div className="button-container">
                      <button variant="primary" className="mlautos" onClick={onFilterApply}>
                        Apply Filters
                      </button>
                    </div>
                  </Modal.Body>

                </Modal>
              </>

            </Container>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Scientific;
