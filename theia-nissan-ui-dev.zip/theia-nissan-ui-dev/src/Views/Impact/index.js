import React, { useState } from 'react';
import Container from 'react-bootstrap/Container';
import SideBar from '../../Common/SideBar';
import Header from '../../Common/Header';
import './index.scss'

import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Card from 'react-bootstrap/Card';
import Button from 'react-bootstrap/Card';

import ReactApexChart from 'react-apexcharts';

import handShake from './../../assets/images/Handshake.svg'
import downArrow from './../../assets/images/CaretDown.svg'
import tick from './../../assets/images/Task Completed.svg'
import medicine from './../../assets/images/Pill.svg'
import location from './../../assets/images/Location.svg'
import search from './../../assets/images/Vector(1).svg'
import bluedot from './../../assets/images/Ellipse56.svg'
import mayoIcon from '../../assets/images/mayoUniversity.svg'
import checkCircle from '../../assets/images/CheckCircle (1).svg'
import hourCircle from '../../assets/images/Hourglass.svg'
import binoculars from '../../assets/images/Binoculars.svg'
import coins from '../../assets/images/Coins.svg'
import clinicIcon from '../../assets/images/icons/plus-icon-health.svg'
import geo from '../../assets/images/GlobeHemisphereEast.svg'
import arrow from './../../assets/images/Frame2147223674.svg'
import disc from './../../assets/images/Disc.svg'
import { useNavigate } from 'react-router-dom';

let Impact = () => {
  const navigate = useNavigate();


  const data = [
    {
      heading: 'Newest Outcomes',
      text: 'Current therapies for Transthyretin amyloidosis (ATTR)  target the misfolded protein but do not address tissue damage by the already deposited amyloid. We have demonstrated that increased abundance of proteins within cardiac (and renal) amyloid plaques is associated with improved outcomes, which suggests that the amount of deposited proteins, may merely be a surrogate for indolent disease biology.'
    },
    {
      heading: 'Newest Outcomes',
      text: 'Current therapies for Transthyretin amyloidosis (ATTR)  target the misfolded protein but do not address tissue damage by the already deposited amyloid. We have demonstrated that increased abundance of proteins within cardiac (and renal) amyloid plaques is associated with improved outcomes, which suggests that the amount of deposited proteins, may merely be a surrogate for indolent disease biology.'
    },
    {
      heading: 'Newest Outcomes',
      text: 'In the Current therapies for Transthyretin amyloidosis (ATTR)  target the misfolded protein but do not address tissue damage by the already deposited amyloid. We have demonstrated that increased abundance of proteins within cardiac (and renal) amyloid plaques is associated with improved outcomes, which suggests that the amount of deposited proteins, may merely be a surrogate for indolent disease biology.'
    },
  ]

  // const details = [
  //   {
  //     img: binoculars,
  //     title: 'Grant Type',
  //     name: 'MedEd'
  //   },
  //   {
  //     img: coins,
  //     title: 'Total Payment',
  //     name: '$90,000'
  //   },
  //   {
  //     img: clinicIcon,
  //     title: 'Clinical Area',
  //     name: 'Migraine'
  //   },
  //   {
  //     img: geo,
  //     title: 'Geography',
  //     name: 'United States'
  //   },
  // ]
  const [activeButton, setActiveButton] = useState('yourGrants');

  const [cardData, setCardData] = useState([
    {
      id: 1,
      title: 'Advances in Migraine Management',
      reference: '#90264655',
      infotext1: 'MedEd',
      infotext2: '$90,000',
      infotext3: 'Migraine',
      infotext4: 'United States',
      approvedPayment: '$120,000',
      pendingPayment: '$60,000',
      duration: '6 Months',
      location: 'PFizer',
      status: 'Approved',
      approvalRate: '98',
      publications: '54',
      heading: 'Projects that will be considered for Pfizer support will focus on improving the care, management, and  outcomes of adult patients with migraine by supporting healthcare professional education on topics  including:',
      ul: [
        'Unmet need and disease burden associated with migraine • The role of CGRP in the pathophysiology of migraine',
        'CGRP receptor antagonists in the acute treatment of migraine and preventive treatment of episodic migraine',
        'The diagnosis and management of migraine in the primary care, women’s health and emergent care settings (focus on acute treatment and prevention of episodic migraine)',
        'Raising awareness of opportunities to improve the quality of migraine treatment across diverse patient populations • Addressing healthcare disparities in migraine diagnosis, management and treatment',
      ]
    },
    {
      id: 3,
      title: 'Quality Improvement Grants to Support Development Of Cardiac Amyloid Centers',
      reference: '#90264657',
      infotext1: 'Quality Improvement',
      infotext2: '$90,000',
      infotext3: 'Migraine Transthyretin Amyloid Cardiomyopath',
      infotext4: 'United States',
      approvedPayment: '$120,000',
      pendingPayment: '$60,000',
      duration: '6 Months',
      location: 'Wien, Wien, Austria',
      status: 'Approved',
      approvalRate: '86',
      publications: '68',
      heading: 'Projects that will be considered for Pfizer support will focus on:',
      ul: [
        'Supporting the development of cardiac amyloid centers that provide leadership, best practices,  support and/or training of HCPs within a multidisciplinary framework, aiming to enhance the  quality of care for cardiac amyloidosis patients, particularly those in underserved populations.',
        'Identifying significant barriers that contribute to geographic and racial healthcare disparities disproportionately impacting the ATTR-CM patient population. The goal is to enhance early detection and treatment through targeted interventions that address these challenges. ',
        'Exploring empowering strategies that enable patients to actively participate in comprehending heart failure and TTR amyloidosis, as well as in making informed decisions regarding timely diagnosis and disease management options.'
      ]


    },
    {
      id: 2,
      title: 'Transthyretin Cardiac  Amyloidosis Fellowship',
      reference: '#90264656',
      infotext1: 'Fellowship',
      infotext2: '$125,000',
      infotext3: 'ATTR cardiac amyloidosis',
      infotext4: 'United States',
      approvedPayment: '$120,000',
      pendingPayment: '$60,000',
      duration: '6 Months',
      location: 'Wien, Wien, Austria',
      status: 'Pending',
      approvalRate: '65',
      publications: '18',
      heading: 'It is our intent to support institutions with fellowship programs for Cardiologists or Heart Failure  Advanced Practice Providers that have a strong focus on clinical practice, research, and education to  further the understanding of ATTR cardiac amyloidosis. Proposals from both established and emerging fellowships will be considered. Preference will be  given to programs which have not been selected in the last 3 years or states with underserved  populations',
      ul: [
        'Proposals from both established and emerging fellowships will be considered. Preference will be  given to programs which have not been selected in the last 3 years or states with underserved  populations.'
      ]

    },

    {
      id: 4,
      title: 'Educational grant for the organization of the EMMA Vienna 2023 Meeting',
      reference: '#90264658',
      infotext1: 'Quality Improvement',
      infotext2: '$90,000',
      infotext3: 'Migraine Transthyretin Amyloid Cardiomyopath',
      infotext4: 'Japan',
      approvedPayment: '$120,000',
      pendingPayment: '$60,000',
      duration: '6 Months',
      location: 'Wien, Wien, Austria',
      status: 'Approved',
      approvalRate: '70',
      publications: '43',
      ul: [
        'Retrospective or prospective real world studies for Abrocitinib in the management of adolescent atopic  dermatitis will be considered for Pfizer support, which include adolescent patients with moderate-to severe AD treated with Abrocitinib.',
        'Specific topics of interest may include, but not limited to, clinician reported outcomes, patient-reported outcomes (PROs), concomitant treatments, dosing, safety, and tolerability. The grant can be used for conducting a retrospective chart review analysis or prospective study'
      ]

    },
    // {
    //   id: 5,
    //   title: 'Educational grant for the organization of the EMMA Vienna 2023 Meeting',
    //   reference: '#90264659',
    //   approvedPayment: '$120,000',
    //   pendingPayment: '$60,000',
    //   duration: '6 Months',
    //   location: 'Wien, Wien, Austria',
    //   status: 'Approved'

    // },
    // {
    //   id: 6,
    //   title: 'Educational grant for the organization of the EMMA Vienna 2023 Meeting',
    //   reference: '#90264660',
    //   approvedPayment: '$120,000',
    //   pendingPayment: '$60,000',
    //   duration: '6 Months',
    //   location: 'Wien, Wien, Austria',
    //   status: 'Pending'

    // },
  ]);
  const [pendingCardData, setPendingCardData] = useState([
    {
      id: 1,
      title: 'Educational grant for the organization of the EMMA Vienna 2023 Meeting',
      infotext1: 'MedEd',
      infotext2: '$90,000',
      infotext3: 'Migraine',
      infotext4: 'United States',
      reference: '#90264655',
      approvedPayment: '$120,000',
      pendingPayment: '$60,000',
      duration: '6 Months',
      location: 'Wien, Wien, Austria',
      status: 'Pending'
    },
    {
      id: 2,
      title: 'Educational grant for the organization of the EMMA Vienna 2023 Meeting',
      infotext1: 'Fellowship',
      infotext2: '$125,000',
      infotext3: 'ATTR cardiac amyloidosis',
      infotext4: 'United States',
      reference: '#90264656',
      approvedPayment: '$120,000',
      pendingPayment: '$60,000',
      duration: '6 Months',
      location: 'Wien, Wien, Austria',
      status: 'Pending'

    },
    {
      id: 3,
      title: 'Educational grant for the organization of the EMMA Vienna 2023 Meeting',
      infotext1: 'Quality Improvement',
      infotext2: '$90,000',
      infotext3: 'Migraine Transthyretin Amyloid Cardiomyopath',
      infotext4: 'United States',
      reference: '#90264657',
      approvedPayment: '$120,000',
      pendingPayment: '$60,000',
      duration: '6 Months',
      location: 'Wien, Wien, Austria',
      status: 'Pending'

    },
    {
      id: 4,
      title: 'Educational grant for the organization of the EMMA Vienna 2023 Meeting',
      infotext1: 'Quality Improvement',
      infotext2: '$90,000',
      infotext3: 'Migraine Transthyretin Amyloid Cardiomyopath',
      infotext4: 'Japan',
      reference: '#90264658',
      approvedPayment: '$120,000',
      pendingPayment: '$60,000',
      duration: '6 Months',
      location: 'Wien, Wien, Austria',
      status: 'Pending'

    },
    // {
    //   id: 5,
    //   title: 'Educational grant for the organization of the EMMA Vienna 2023 Meeting',
    //   reference: '#90264659',
    //   approvedPayment: '$120,000',
    //   pendingPayment: '$60,000',
    //   duration: '6 Months',
    //   location: 'Wien, Wien, Austria',
    //   status: 'Pending'

    // },
    // {
    //   id: 6,
    //   title: 'Educational grant for the organization of the EMMA Vienna 2023 Meeting',
    //   reference: '#90264660',
    //   approvedPayment: '$120,000',
    //   pendingPayment: '$60,000',
    //   duration: '6 Months',
    //   location: 'Wien, Wien, Austria',
    //   status: 'Pending'

    // },
  ]);
  const handleButtonClick = (buttonName) => {
    setActiveButton(buttonName);
  };

  return (
    <div className='wrapper'>
      <Header></Header>
      <div className="layout-wrapper main-wrapper-body d-flex">
        <SideBar activeTab={'Marketplace'} />
        <div className="main-content py-3 px-1">
          <div className='page-content'>
            <Container fluid>
              <div className='main-card-webtx'>
                <div className='request-paneltab-multi'>
                  <ul className='d-flex flex-wrap align-items-center'>
                    <li className='rt-menu-pnl me-3'>
                      <button
                        type='button'
                        className={`btn tabitem-request-btn ${activeButton === 'yourGrants' ? 'btn-add-Grant-actives' : 'btn-add-projects'}`}
                        onClick={() => handleButtonClick('yourGrants')}
                      >
                        {activeButton === 'yourGrants' ? <div class="dot"></div> : <></>}
                        Request for Proposal
                      </button>
                    </li>
                    <li className='rt-menu-pnl'>
                      <button
                        type='button'
                        className={`btn tabitem-request-btn ${activeButton === 'pendingApprovals' ? 'btn-add-Grant-actives' : 'btn-add-projects'}`}
                        onClick={() => handleButtonClick('pendingApprovals')}
                      >
                        {activeButton === 'pendingApprovals' ? <div class="dot"></div> : <></>}
                        Non Request for Proposal
                      </button>
                    </li>
                  </ul>
                </div>
                <div className='ml-section-boc--trm mb-4'>
                  <Card className="card-box-area">
                    <Card.Body className='card-content-wap d-flex justify-content-between p-2'>
                      <Col xs={12} md={6} lg={4}>
                        <div>
                          <Card.Text>
                            <h6>
                              <img src={location} className='p-1' width={'35px'}></img>
                              Explore Location
                            </h6>
                          </Card.Text>
                          <div class="search-container p-2">
                            <img src={search} class="search-icon" width={'20px'} />
                            <input type="text" placeholder="Search Location" class="search-field" />
                          </div>
                        </div>
                      </Col>
                      <Col xs={12} md={6} lg={4}>
                        <div>
                          <Card.Text>
                            <h6>
                              <img src={medicine} className='p-1' width={'35px'}></img>
                              Explore Disease or Drugs
                            </h6>
                          </Card.Text>
                          <div class="search-container p-2">
                            <input type="text" placeholder="Search Disease or Drugs" class="search-field" />
                            <img src={search} class="search-icon" width={'20px'} />
                          </div>
                        </div>
                      </Col>
                      <Col xs={12} md={6} lg={4}>
                        <div>
                          <Card.Text >
                            <h6>
                              <img src={handShake} className='p-1' width={'35px'}></img>
                              Explore by Partner
                            </h6>
                          </Card.Text>
                          <div class="input-container p-2">
                            <input type="text" placeholder="Partners" class="input-field" />
                            <img src={downArrow} class="input-icon" width={'20px'} />
                          </div>
                        </div>
                      </Col>
                    </Card.Body>
                  </Card>
                  {/* </Col> */}
                  {/* <Col xs={12} md={6} lg={4}>
                    <Card className="card-box-area mb-3 ">
                      <Card.Body className='card-content-wap p-2'>

                      </Card.Body>
                    </Card>
                  </Col>
                  <Col xs={12} md={6} lg={4}>
                    <Card className="card-box-area mb-3 ">
                      <Card.Body className='card-content-wap p-2'>

                      </Card.Body>
                    </Card>
                  </Col> */}
                </div>
                <div className='element-search-bx-area'>
                  <Row>
                    <Col xs='12'>
                      <div className='search-flt-result-show'>
                        <h3 className='title-search'>8 results shown for this search</h3>
                      </div>
                    </Col>
                  </Row>
                  <Row>
                    {(activeButton === 'yourGrants' ? cardData : pendingCardData).map((data) => (
                      <Col md={6} key={data.id} className="mb-4">
                        <Card style={{ cursor: 'pointer' }} onClick={() => navigate('/impact/1')} className="border-color-card">
                          <Card.Header className='bgcolor cardhead-radius-16 btm-color-head py-3'>
                            <div className="d-flex align-items-center justify-content-between">
                              <div className='headsect--title-wgt'>
                                <h5 className='title-text text-impact-head mb-0'>{data.title}</h5>
                              </div>
                              <div class="button-area-wgtmore">
                                <button type='button' className='btn btn-part-wth'>Partnered with American Institute</button>
                              </div>
                            </div>
                          </Card.Header>
                          <Card.Body className='px-2 pt-4 pb-3'>
                            <div className=''>
                              <div className='dflexsCon flex-wrap'>
                                <Col xs={12} lg={6} md={6}>
                                  <div className='dflexs mb-3'>
                                    <img src={binoculars} alt="icon" width={'30px'} className='p-1' />
                                    <div>
                                      <h4 className="text-wg-tt1">Grant Type</h4>
                                      <p class="conttent01-txt">{data.infotext1}</p>
                                    </div>
                                  </div>
                                </Col>
                                <Col xs={12} lg={6} md={6}>
                                  <div className='dflexs mb-3'>
                                    <img src={coins} alt="icon" width={'30px'} className='p-1' />
                                    <div>
                                      <h4 className="text-wg-tt1">Grant Value</h4>
                                      <p class="conttent01-txt">{data.infotext2}</p>
                                    </div>
                                  </div>
                                </Col>
                                <Col xs={12} lg={6} md={6}>
                                  <div className='dflexs mb-3'>
                                    <img src={clinicIcon} alt="icon" width={'30px'} className='p-1' />
                                    <div>
                                      <h4 className="text-wg-tt1">Clinical Area</h4>
                                      <p class="conttent01-txt">{data.infotext3}</p>
                                    </div>
                                  </div>
                                </Col>
                                <Col xs={12} lg={6} md={6}>
                                  <div className='dflexs mb-3'>
                                    <img src={geo} alt="icon" width={'30px'} className='p-1' />
                                    <div>
                                      <h4 className="text-wg-tt1">Geography</h4>
                                      <p class="conttent01-txt">{data.infotext4}</p>
                                    </div>
                                  </div>
                                </Col>
                              </div>
                            </div>
                            <div className='color obj-elmnt-wgt'>
                              <h6 class="title-obj--wgt">Objectives</h6>
                              <p className='objlst-disc ms-0 mb-2'>
                                {data.heading}
                                {/* Projects that will be considered for Pfizer support will focus on improving the care, management, and  outcomes of adult patients with migraine by supporting healthcare professional education on topics  including: */}
                              </p>
                              <div className='object-list-impact'>
                                {/* <ul className='object-web-impact'>
                                  <li className='list-items-objt'>
                                    {data.list1}
                                    Unmet need and disease burden associated with migraine • The role of CGRP in the pathophysiology of migraine 
                                  </li>
                                  <li className='list-items-objt'>
                                    {data.list2}
                                    CGRP receptor antagonists in the acute treatment of migraine and preventive treatment of  episodic migraine 
                                  </li>
                                  <li className='list-items-objt'>
                                    {data.list3}
                                    The diagnosis and management of migraine in the primary care, women’s health and emergent  care settings (focus on acute treatment and prevention of episodic migraine) 
                                  </li>
                                  <li className='list-items-objt'>
                                    {data.list4}
                                    Raising awareness of opportunities to improve the quality of migraine treatment across diverse patient populations • Addressing healthcare disparities in migraine diagnosis, management and treatment
                                  </li>
                                </ul> */}
                                <div className='object-list-impact'>
                                  <ul>
                                    {data.ul && data.ul.length > 0 ? (
                                      data.ul.map((item, index) => (
                                        <ul className='object-web-impact'>
                                          <li className='list-items-objt' key={index}>{item}</li>
                                        </ul>
                                      ))
                                    ) : (
                                      <></>
                                    )}
                                  </ul>
                                </div>
                              </div>
                            </div>
                            <div className="d-flex justify-content-between mt-3 p-1">
                              <div className='wgt-orgtt-cont'>
                                <h4 className="ht--mtr">Org Name</h4>
                                {/* <p>{data.duration}</p> */}
                                <p>PFizer</p>
                              </div>
                              <div className='wgt-orgtt-cont'>
                                <h4 className="ht--mtr">Project Title</h4>
                                {/* <p>{data.location}</p> */}
                                <p>Grant Req</p>
                              </div>
                              <div className='wgt-orgtt-cont'>
                                <h4 className="ht--mtr">PI Name</h4>
                                {/* <p>{data.location}</p> */}
                                <p>John Doe</p>
                              </div>
                            </div>
                            <div className="d-flex justify-content-between align-items-center mt-3">
                              {(activeButton === 'yourGrants') && (
                                <>
                                  {(data.status === 'Pending' || data.status === 'Pending') && (
                                    <>
                                      <div className='pending mt-2 mx-1'>
                                        <h5 className="mt-wgt--tt p-2">Approval Rate</h5>
                                        <p className='p-2'>{data.approvalRate}</p>
                                      </div>
                                      <div className='pending mt-2 mx-1'>
                                        <h5 className="mt-wgt--tt p-2">Publications</h5>
                                        <p className='p-2'>{data.publications}</p>
                                      </div>
                                    </>
                                  )}
                                  {data.status === 'Approved' && (
                                    <>
                                      <div className='approval mt-2 mx-1'>
                                        <h5 className="mt-wgt--tt p-2">Approval Rate</h5>
                                        <p className='p-2'>{data.approvalRate}</p>
                                      </div>
                                      <div className='approval mt-2 mx-1'>
                                        <h5 className="mt-wgt--tt p-2">Publications</h5>
                                        <p className='p-2'>{data.publications}</p>
                                      </div>
                                    </>
                                  )}
                                </>
                              )}
                              {activeButton === 'pendingApprovals' && (
                                <>
                                  {data.status === 'Pending' && (
                                    <button type='button' className="btn btn-pending-status btn-pending">
                                      {data.status}
                                      <img src={hourCircle} alt="Hour Circle" className="img-fluid mx-2" />
                                    </button>
                                  )}
                                </>
                              )}
                              {/* <span className='text-btn me-5'>View Details</span> */}
                            </div>
                          </Card.Body>
                        </Card>
                      </Col>
                    ))}
                  </Row>
                </div>
              </div>
            </Container>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Impact;
