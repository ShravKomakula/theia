import React, { useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { Container, Col, Nav, Card, Tab, Row, Form, Button } from 'react-bootstrap';
import SideBar from '../../Common/SideBar';
import Header from '../../Common/Header';
import './index.scss'
import iconGlobWb from '../../assets/images/icons/globe-map-circle-icon.svg';
import iconLocation from '../../assets/images/icons/location-sum-icon.svg';
import iconPeople from '../../assets/images/icons/people-sum-icon.svg';
import handIcon from '../../assets/images/icons/hand-icon.svg';
import mapChartImg from '../../assets/images/mapmore-chart.jpg';
import mayoIcon from '../../assets/images/mayoUniversity.svg'
import arrowLeft from '../../assets/images/ArrowLeft.svg'
import hourCircle from '../../assets/images/Hourglass.svg'
import checkCircle from '../../assets/images/CheckCircle (1).svg'
import pdfFile from './../../assets/PDF/GMG_2024_VA-RSV-Genera-RFP-Education_English 2.pdf'



function DetailPage() {
  const { id } = useParams()
  const navigate = useNavigate();

  const cardData = JSON.parse(localStorage.getItem('cardData')) || [];
  const card = cardData.find(item => item.id.toString() === id);
  const [activeTab, setActiveTab] = useState('yourGrants');
  const [approved, setApproved] = useState(false);
  const [approvedIds, setApprovedIds] = useState(["1", "3", "4", "5", "9"]);



  const handleTabChange = (tab) => {
    setActiveTab(tab);
  };

  const downloadPDF = () => {
    toast("Downloaded Successfully");
  };
  const handleClick = () => {
    if (id == 2) {
      toast("Successfully approved!");
      setApproved(true);
    }

  };
  return (
    <div className='wrapper'>
      <ToastContainer />

      <Header></Header>
      <div className="layout-wrapper main-wrapper-body d-flex">
        <SideBar activeTab={'Marketplace'} />
        <div className="main-content py-3">
          <div className='page-content'>
            <Container fluid>
              <h5>Grant Review</h5>
              <Col>
                <Nav variant="pills" className="tabpanel-pill" activeKey={activeTab} onSelect={handleTabChange}>
                  <Nav.Item>
                    <Nav.Link eventKey="yourGrants" className='item-navtab-menu'>Your Grants</Nav.Link>
                  </Nav.Item>
                  <Nav.Item>
                    <Nav.Link eventKey="pendingApprovals" className='item-navtab-menu'>Pending Approvals</Nav.Link>
                  </Nav.Item>
                </Nav>
              </Col>
              <div className='elemnt-sec-recomnd mt-3'>
                <Card className='card-items-boxes'>
                  <Tab.Container id="left-tabs-example" defaultActiveKey="tabpanel1">
                    <Card.Title as="div" bsPrefix="cardtab-header">
                      <Row>
                        <Col xs={12} lg={8} className="d-flex align-items-start">
                          <img className='mt-3 me-3' src={arrowLeft} alt="Back Arrow" onClick={() => navigate(-1)} style={{ cursor: 'pointer' }} />
                          <img src={mayoIcon} alt="Mayo Clinic" className="img-fluid me-3 mt-1" />
                          <div>
                            <h5 className='title-text'>{card.title}</h5>
                            <p className="text-muted">{card.reference}</p>
                          </div>
                        </Col>

                        <Col xs={12} lg={4} className="d-flex justify-content-end align-items-center mt-3 mt-lg-0">
                          <a href={pdfFile} download="PDF-document" target="_blank" rel="noopener noreferrer">
                            <Button className="modal-item-navtab-menu" onClick={downloadPDF}>Download</Button>
                          </a>
                          {approved ? (
                            <>
                              <Button className='me-3 btn-approved'>
                                Approved
                                <img src={checkCircle} alt="Check Circle" className="img-fluid mx-2" />
                              </Button>

                            </>
                          ) : (
                            <>
                              {
                                approvedIds.includes(id) ?
                                  <>
                                    <Button className='me-3 btn-approved'>
                                      Approved
                                      <img src={checkCircle} alt="Check Circle" className="img-fluid mx-2" />
                                    </Button>
                                  </>
                                  :
                                  <>
                                    <Button className='btn-pending btn btn-primary me-3'>
                                      Pending <img src={hourCircle} alt="Hour Circle" />
                                    </Button>
                                    {
                                      id == "2" ?
                                        <Button onClick={handleClick} className="text-white">Approve Grant</Button>
                                        :
                                        null


                                    }
                                  </>
                              }

                            </>
                          )}
                        </Col>
                      </Row>
                    </Card.Title>
                    <Card.Body>
                      <Tab.Content>
                        <Tab.Pane eventKey="tabpanel1">
                          <div className='content-ytn-waper'>
                            <Row className='mb-4'>
                              <Col xs='12' md='6'>
                                <div className='summary-mtr-lvl'>
                                  <div className='summary-elemnt-wpt mb-3'>
                                    <h3 className='title-sm--wgt mb-3'>Summary</h3>
                                    <Row className='row-grid-mx'>
                                      <Col xs='12' lg='4' className='col-grid-px'>
                                        <div className='summry-card-col d-flex flex-wrap align-items-center mb-2'>
                                          <div className='flex-img-sumr'>
                                            <img className='img-sumry-lvl' src={iconGlobWb} alt='img' />
                                          </div>
                                          <div className='rgt-colwp'>
                                            <h4 className='headt-mtr-rt'>Country</h4>
                                            <p>United States</p>
                                          </div>
                                        </div>
                                      </Col>
                                      <Col xs='12' lg='4' className='col-grid-px'>
                                        <div className='summry-card-col d-flex flex-wrap align-items-center mb-2'>
                                          <div className='flex-img-sumr'>
                                            <img className='img-sumry-lvl' src={iconLocation} alt='img' />
                                          </div>
                                          <div className='rgt-colwp'>
                                            <h4 className='headt-mtr-rt'>Region</h4>
                                            <p>Washington</p>
                                          </div>
                                        </div>
                                      </Col>
                                      <Col xs='12' lg='4' className='col-grid-px'>
                                        <div className='summry-card-col d-flex flex-wrap align-items-center mb-2'>
                                          <div className='flex-img-sumr'>
                                            <img className='img-sumry-lvl' src={iconPeople} alt='img' />
                                          </div>
                                          <div className='rgt-colwp'>
                                            <h4 className='headt-mtr-rt'>Role</h4>
                                            <p>Dentist</p>
                                          </div>
                                        </div>
                                      </Col>
                                    </Row>
                                  </div>
                                  <div className='level-summry'>
                                    <Card className='card-sum-box-wgt'>
                                      <Card.Title as="div" bsPrefix="cardtab-header py-3 px-4">
                                        <h3 className='title-sm--wgt mb-0'>High Level Summary</h3>
                                      </Card.Title>
                                      <Card.Body className='p-4'>
                                        <div className='summry-content-elemnt-rw'>
                                          <h3 className='heading-mt-lt mb-3'><span className='me-2 d-inline-block'><img src={handIcon} alt='hand' /></span>Hi Parth, welcome back.</h3>
                                          <h4 className='txt-upd-wgt pb-4'>Here are the latest updates</h4>
                                          <ul className='list-update-wps'>
                                            <li className='items-listwp-mtr'>In the last week 12 grants have been approved with the funding total of $2.3M. </li>
                                            <li className='items-listwp-mtr'>There are 4 grants that closed last week with outcomes report and publications below. </li>
                                            <li className='items-listwp-mtr'>Currently 5 grants ongoing need your attention and are flagged by our AI for your review.</li>
                                          </ul>
                                        </div>
                                      </Card.Body>
                                    </Card>
                                  </div>
                                </div>
                              </Col>
                              <Col xs='12' md='6'>
                                <div className='maparea-wgt'>
                                  <h2 className='title-headmvt'>Map View</h2>
                                  <div className='map-ytr-wn'>
                                    <img src={mapChartImg} alt='map' />
                                  </div>
                                </div>
                              </Col>
                            </Row>
                            {/* <Row>
                              <Col xs='12' md='6'>
                                <div className='d-flex flex-wrap align-items-center'>
                                  <sapn className="text-insl--tw">Summarize Insights</sapn>
                                  <div className='check-swtch-mt d-inline-block ms-4'>
                                    <Form.Check // prettier-ignore
                                      type="switch"
                                      className='onswitch-btn-view'
                                    />
                                  </div>
                                </div>
                              </Col>
                              <Col xs='12' md='6'>
                                <p className='text-end txt-wgtty-sum mb-0'>Enable this to view the summary of the grants</p>
                              </Col>
                            </Row> */}
                          </div>
                        </Tab.Pane>
                        <Tab.Pane eventKey="tabpanel2">Second tab content</Tab.Pane>
                      </Tab.Content>
                    </Card.Body>
                  </Tab.Container>

                </Card>
              </div>
            </Container>
          </div>
        </div>
      </div>
    </div>
  )
}

export default DetailPage