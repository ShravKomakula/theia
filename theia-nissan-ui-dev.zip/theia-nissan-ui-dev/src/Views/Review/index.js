import React, { useState,useEffect } from 'react';
import Container from 'react-bootstrap/Container';
import SideBar from '../../Common/SideBar';
import Header from '../../Common/Header';
import './index.scss'
import { Col, Row, Card, Button } from 'react-bootstrap';
import searchIcon from '../../assets/images/MagnifyingGlass (2).svg'
import mayoIcon from '../../assets/images/mayoUniversity.svg'
import checkCircle from '../../assets/images/CheckCircle (1).svg'
import hourCircle from '../../assets/images/Hourglass.svg'
import Nav from 'react-bootstrap/Nav';
import { useNavigate } from 'react-router-dom';




let Review = () => {

  const [activeTab, setActiveTab] = useState('yourGrants');
  const [cardData, setCardData] = useState([
    {
      id: 1,
      title: 'RSV Infection and RSV Maternal Immunization in Area of Obstetrics',
      reference: '#90264655',
      approvedPayment: '$120,000',
      pendingPayment: '$60,000',
      duration: '6 Months',
      location: 'Wien, Wien, Austria',
      status: 'Approved'
    },
    {
      id: 2,
      title: 'Bolstering Clinical Research Capacity to Address China Health Equity ',
      reference: '#90264656',
      approvedPayment: '$130,000',
      pendingPayment: '$70,000',
      duration: '3 Months',
      location: 'Wien, Wien, Austria',
      status: 'Pending'

    },
    {
      id: 3,
      title: 'Develop Physicians to Lead the Increase in Preventive Awareness',
      reference: '#90264657',
      approvedPayment: '$110,000',
      pendingPayment: '$80,000',
      duration: '4 Months',
      location: 'Wien, Wien, Austria',
      status: 'Approved'

    },
    {
      id: 4,
      title: 'Improving the Therapeutic Environment for Metastatic Breast Cancer',
      reference: '#90264658',
      approvedPayment: '$90,000',
      pendingPayment: '$50,000',
      duration: '8 Months',
      location: 'Wien, Wien, Austria',
      status: 'Approved'

    },
    {
      id: 5,
      title: 'Shared Decision-Making (SDM) in Lung Cancer',
      reference: '#90264659',
      approvedPayment: '$180,000',
      pendingPayment: '$40,000',
      duration: '7 Months',
      location: 'Wien, Wien, Austria',
      status: 'Approved'

    },
    {
      id: 6,
      title: 'Transthyretin Cardiac Amyloidosis Fellowship',
      reference: '#90264660',
      approvedPayment: '$170,000',
      pendingPayment: '$100,000',
      duration: '3 Months',
      location: 'Wien, Wien, Austria',
      status: 'Pending'

    },
    {
      id: 7,
      title: 'Sickle Cell Disease (SCD) Fellowship',
      reference: '#90264660',
      approvedPayment: '$170,000',
      pendingPayment: '$100,000',
      duration: '3 Months',
      location: 'Wien, Wien, Austria',
      status: 'Pending'

    },
    {
      id: 8,
      title: 'Transthyretin Cardiac Amyloidosis Fellowship',
      reference: '#90264660',
      approvedPayment: '$170,000',
      pendingPayment: '$100,000',
      duration: '3 Months',
      location: 'Wien, Wien, Austria',
      status: 'Pending'

    },
    {
      id: 9,
      title: 'Projects for Enhancing Regional Cancer Treatment',
      reference: '#90264660',
      approvedPayment: '$170,000',
      pendingPayment: '$100,000',
      duration: '3 Months',
      location: 'Wien, Wien, Austria',
      status: 'Approved'

    },

    // {
    //   id: 10,
    //   title: 'Education for Improvement of Early Detection and Appropriate Anticoagulant Therapy for Atrial Fibrillation',
    //   reference: '#90264660',
    //   approvedPayment: '$170,000',
    //   pendingPayment: '$100,000',
    //   duration: '3 Months',
    //   location: 'Wien, Wien, Austria',
    //   status: 'Pending'

    // },
    // {
    //   id: 11,
    //   title: 'Pathological diagnosis and Immunohistochemistry biomarker assessments of Breast Cancer',
    //   reference: '#90264660',
    //   approvedPayment: '$170,000',
    //   pendingPayment: '$100,000',
    //   duration: '3 Months',
    //   location: 'Wien, Wien, Austria',
    //   status: 'Approved'

    // },
    // {
    //   id: 12,
    //   title: 'Real World Evidence of Abrocitinib in Adolescent Patients with Moderate-to-Severe Atopic Dermatitis',
    //   reference: '#90264660',
    //   approvedPayment: '$170,000',
    //   pendingPayment: '$100,000',
    //   duration: '3 Months',
    //   location: 'Wien, Wien, Austria',
    //   status: 'Pending'

    // },
    // {
    //   id: 13,
    //   title: 'The Value of Standardized Diagnosis and Treatment in Patients with Moderate-to-Severe Atopic Dermatitis',
    //   reference: '#90264660',
    //   approvedPayment: '$170,000',
    //   pendingPayment: '$100,000',
    //   duration: '3 Months',
    //   location: 'Wien, Wien, Austria',
    //   status: 'Approved'

    // },
    // {
    //   id: 14,
    //   title: 'Evolving Treatment Options in First-line Metastatic Urothelial Carcinoma (mUC) and Muscle Invasive Bladder Cancer (MIBC)',
    //   reference: '#90264660',
    //   approvedPayment: '$170,000',
    //   pendingPayment: '$100,000',
    //   duration: '3 Months',
    //   location: 'Wien, Wien, Austria',
    //   status: 'Pending'

    // },


  ]);
  const [pendingCardData, setPendingCardData] = useState([
    {
      id: 11,
      title: 'RSV Infection and RSV Maternal Immunization in Area of Obstetrics',
      reference: '#90264655',
      approvedPayment: '$120,000',
      pendingPayment: '$60,000',
      duration: '6 Months',
      location: 'Wien, Wien, Austria',
      status: 'Pending'

    },
    {
      id: 12,
      title: 'Bolstering Clinical Research Capacity to Address China Health Equity Disparities',
      reference: '#90264656',
      approvedPayment: '$130,000',
      pendingPayment: '$70,000',
      duration: '3 Months',
      location: 'Wien, Wien, Austria',
      status: 'Pending'

    },
    {
      id: 13,
      title: 'Develop Physicians to Lead the Increase in Preventive Awareness by Vaccination',
      reference: '#90264657',
      approvedPayment: '$110,000',
      pendingPayment: '$80,000',
      duration: '4 Months',
      location: 'Wien, Wien, Austria',
      status: 'Pending'

    },
    {
      id: 14,
      title: 'Improving the Therapeutic Environment for Metastatic Breast Cancer',
      reference: '#90264658',
      approvedPayment: '$90,000',
      pendingPayment: '$50,000',
      duration: '8 Months',
      location: 'Wien, Wien, Austria',
      status: 'Pending'

    },
    {
      id: 15,
      title: 'Shared Decision-Making (SDM) in Lung Cancer',
      reference: '#90264659',
      approvedPayment: '$180,000',
      pendingPayment: '$40,000',
      duration: '7 Months',
      location: 'Wien, Wien, Austria',
      status: 'Pending'

    },
    {
      id: 16,
      title: 'Transthyretin Cardiac Amyloidosis Fellowship',
      reference: '#90264660',
      approvedPayment: '$170,000',
      pendingPayment: '$100,000',
      duration: '3 Months',
      location: 'Wien, Wien, Austria',
      status: 'Pending'

    },
    {
      id: 17,
      title: 'Sickle Cell Disease (SCD) Fellowship',
      reference: '#90264660',
      approvedPayment: '$170,000',
      pendingPayment: '$100,000',
      duration: '3 Months',
      location: 'Wien, Wien, Austria',
      status: 'Pending'

    },
    {
      id: 18,
      title: 'Transthyretin Cardiac Amyloidosis Fellowship',
      reference: '#90264660',
      approvedPayment: '$170,000',
      pendingPayment: '$100,000',
      duration: '3 Months',
      location: 'Wien, Wien, Austria',
      status: 'Pending'

    },
    {
      id: 19,
      title: 'Projects for Enhancing Regional Cancer Treatment',
      reference: '#90264660',
      approvedPayment: '$170,000',
      pendingPayment: '$100,000',
      duration: '3 Months',
      location: 'Wien, Wien, Austria',
      status: 'Pending'

    },
    {
      id: 20,
      title: 'Education for Improvement of Early Detection and Appropriate Anticoagulant Therapy for Atrial Fibrillation',
      reference: '#90264660',
      approvedPayment: '$170,000',
      pendingPayment: '$100,000',
      duration: '3 Months',
      location: 'Wien, Wien, Austria',
      status: 'Pending'

    },
    {
      id: 21,
      title: 'Pathological diagnosis and Immunohistochemistry biomarker assessments of Breast Cancer',
      reference: '#90264660',
      approvedPayment: '$170,000',
      pendingPayment: '$100,000',
      duration: '3 Months',
      location: 'Wien, Wien, Austria',
      status: 'Pending'

    },
    {
      id: 22,
      title: 'Real World Evidence of Abrocitinib in Adolescent Patients with Moderate-to-Severe Atopic Dermatitis',
      reference: '#90264660',
      approvedPayment: '$170,000',
      pendingPayment: '$100,000',
      duration: '3 Months',
      location: 'Wien, Wien, Austria',
      status: 'Pending'

    },
    {
      id: 23,
      title: 'The Value of Standardized Diagnosis and Treatment in Patients with Moderate-to-Severe Atopic Dermatitis',
      reference: '#90264660',
      approvedPayment: '$170,000',
      pendingPayment: '$100,000',
      duration: '3 Months',
      location: 'Wien, Wien, Austria',
      status: 'Pending'

    },
    {
      id: 24,
      title: 'Evolving Treatment Options in First-line Metastatic Urothelial Carcinoma (mUC) and Muscle Invasive Bladder Cancer (MIBC)',
      reference: '#90264660',
      approvedPayment: '$170,000',
      pendingPayment: '$100,000',
      duration: '3 Months',
      location: 'Wien, Wien, Austria',
      status: 'Pending'

    },
  ]);

  const navigate = useNavigate();

  const handleCardClick = (id) => {
    navigate(`/review/${id}`);
  };

  useEffect(() => {
    localStorage.setItem('cardData', JSON.stringify([...cardData, ...pendingCardData]));
  }, [cardData, pendingCardData]);

  const handleTabChange = (tab) => {
    setActiveTab(tab);
  };
  const getActiveCardData = () => {
    if (activeTab === 'yourGrants') {
      return cardData;
    } else if (activeTab === 'pendingApprovals') {
      return pendingCardData;
    }
  };

  return (
    <div className='wrapper'>
      <Header></Header>
      <div className="layout-wrapper main-wrapper-body d-flex">
        <SideBar activeTab={'Marketplace'} />
        <div className="main-content py-3">
          <div className='page-content'>
            <Container fluid>
              <h1 className='heading-top-h1'>Grant Review</h1>
                <Col xs={12} md={6}>
                  <Nav variant="pills" className="tabpanel-pill" activeKey={activeTab} onSelect={handleTabChange}>
                    <Nav.Item>
                      <Nav.Link eventKey="yourGrants" className='item-navtab-menu'>Your Grants</Nav.Link>
                    </Nav.Item>
                    <Nav.Item>
                      <Nav.Link eventKey="pendingApprovals" className='item-navtab-menu'>Pending Approvals</Nav.Link>
                    </Nav.Item>
                  </Nav>
                </Col>
              <Col xs={12} md={12} className='mt-3'>
                <div className="search-container">
                  <div className="search-wrapper">
                    <img src={searchIcon} alt="Search Icon" className="search-icon" />
                    <input className="col-12 col-md-12 col-lg-12 search-input" type="text" placeholder="Search"></input>
                  </div>
                  <div className='btn-basic-container'>
                    <button type='button' className='btn btn-add-project flt-txt-btn1'>Filters(0)</button>
                    <button type='button' className='btn btn-add-project flt-txt-btn2'>None</button>
                  </div>
                </div>
              </Col>
              <Col>
              </Col>
              <Row className="mt-3">
                {getActiveCardData().map((data) => (
                  <Col md={4} key={data.id} className="mb-4">
                    <Card style={{cursor: 'pointer'}} className="p-3 shadow-sm" onClick={() => handleCardClick(data.id)}>
                      <Card.Body className='p-0'>
                        <div className="d-flex align-items-start">
                          <img src={mayoIcon} alt="Mayo Clinic" className="img-fluid me-3 mt-1" />
                          <div>
                            <h5 className='title-text'>{data.title}</h5>
                            <p className="text-muted">{data.reference}</p>
                          </div>
                        </div>
                        <div className='d-flex justify-content-between'>
                          <div className="mt-3">
                            <p className="text-muted">Approved Payment</p>
                            <h5 className="text-primary">{data.approvedPayment}</h5>
                          </div>
                          <div className="mt-3 me-3">
                            <p className="text-muted">Pending Payment</p>
                            <h5 className="text-warning">{data.pendingPayment}</h5>
                          </div>
                        </div>
                        <div className="d-flex justify-content-between mt-3">
                          <div>
                            <p className="text-muted">Duration</p>
                            <p>{data.duration}</p>
                          </div>
                          <div>
                            <p className="text-muted">Location</p>
                            <p>{data.location}</p>
                          </div>
                        </div>
                        <div className="d-flex justify-content-between align-items-center mt-3">
                          {(activeTab === 'yourGrants') && (
                            <>
                              {(data.status === 'Pending' || data.status === 'Pending') && (
                                <Button className="btn-pending">
                                  {data.status}
                                  <img src={hourCircle} alt="Hour Circle" className="img-fluid mx-2" />
                                </Button>
                              )}
                              {data.status === 'Approved' && (
                                <Button className="btn-approved">
                                  {data.status}
                                  <img src={checkCircle} alt="Check Circle" className="img-fluid mx-2" />
                                </Button>
                              )}
                            </>
                          )}
                          {activeTab === 'pendingApprovals' && (
                            <>
                              {data.status === 'Pending' && (
                                <Button className="btn-pending">
                                  {data.status}
                                  <img src={hourCircle} alt="Hour Circle" className="img-fluid mx-2" />
                                </Button>
                              )}
                            </>
                          )}
                          <span className='text-btn me-5'>View Details</span>
                        </div>
                      </Card.Body>
                    </Card>
                  </Col>
                ))}
              </Row>
            </Container>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Review;
