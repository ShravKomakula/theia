import React, { useState, useEffect } from 'react';
import Container from 'react-bootstrap/Container';
import SideBar from '../../Common/SideBar';
import Header from '../../Common/Header';
import './index.scss'
import { Col, Row } from 'react-bootstrap';
import PieGraph from '../../Common/Graphs/PieGraph';
import BarGraph from '../../Common/Graphs/BarGraph';
import Table from 'react-bootstrap/Table';
import downArrow from '../../assets/images/arrow-down.svg'
import checkCircle from '../../assets/images/CheckCircle (1).svg'
import rejectedIcon from '../../assets/images/rejectedIcon.svg'
import pendingIcon from '../../assets/images/Hourglass.svg'

const truncateText = (element, maxLength = 5) => {
  const img = element.querySelector('img');
  const text = element.textContent.trim();

  if (text.length > maxLength) {
    element.innerHTML = `${img ? img.outerHTML : ''}${text.substring(0, maxLength)}...`;
  }
};

let Compliance = () => {
  useEffect(() => {
    const headers = document.querySelectorAll('.tableHeadingText');
    headers.forEach(header => truncateText(header));

    const cells = document.querySelectorAll('.tbody-element--wp td');
    cells.forEach(cell => truncateText(cell));
  }, []);

  return (
    <div className='wrapper'>
      <Header></Header>
      <div className="layout-wrapper main-wrapper-body d-flex">
        <SideBar activeTab={'Marketplace'} />
        <div className="main-content py-3">
          <div className='page-content'>
            <Container fluid>
              <h1 className='heading-top-h1'>
                Ops Compliance
              </h1>
              <Row className='d-flex'>
                <Col xs="12" md="6">
                  <div className='map-img-wp card-box-area mb-3 card p-4'>
                    <h5 className='mainText-Heading'>
                    Compliance Metrics
                    </h5>
                    <PieGraph />
                  </div>
                </Col>
                <Col xs="12" md="6">
                  <div className='map-img-wp card-box-area mb-3 card p-4'>
                    <h5 className='mainText-Heading'>
                    Grant Projection                    </h5>
                    <BarGraph />
                  </div>
                </Col>
              </Row>
              <Row>
                <div className="table-list" >
                  <Table responsive className='table-lits-wap-pground mb-0'>
                    <thead className='thead-md-wp'>
                      <tr>
                        <th className='tableHeadingText'>ID <img src={downArrow} alt="downArrow" /></th>
                        <th className='tableHeadingText'>Request ID <img src={downArrow} alt="downArrow" /></th>
                        <th className='tableHeadingText'>Owner Name <img src={downArrow} alt="downArrow" /></th>
                        <th className='tableHeadingText'>Owner Title <img src={downArrow} alt="downArrow" /></th>
                        <th className='tableHeadingText'>Budgt Section <img src={downArrow} alt="downArrow" /></th>
                        <th className='tableHeadingText'>Final Report <img src={downArrow} alt="downArrow" /></th>
                        <th className='tableHeadingText'>Map Dates <img src={downArrow} alt="downArrow" /></th>
                        <th className='tableHeadingText'>Map Section <img src={downArrow} alt="downArrow" /></th>
                        <th className='tableHeadingText'>Payment Section <img src={downArrow} alt="downArrow" /></th>
                        <th className='tableHeadingText'>Project Closure <img src={downArrow} alt="downArrow" /></th>
                        <th className='tableHeadingText'>Payment Status <img src={downArrow} alt="downArrow" /></th>
                        <th className='tableHeadingText'>Satus <img src={downArrow} alt="downArrow" /></th>
                      </tr>
                    </thead>
                    <tbody className='tbody-element--wp'>
                      <tr>
                        <td>1</td>
                        <td>5605855</td>
                        <td>Veronica</td>
                        <td>Grant Administration</td>
                        <td>TAC Administration</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={rejectedIcon} alt="rejectedIcon" />Cancel</td>
                      </tr>
                      <tr>
                        <td>2</td>
                        <td>6509835</td>
                        <td>Veronica</td>
                        <td>Grant Administration</td>
                        <td>TAC Administration</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={rejectedIcon} alt="rejectedIcon" />Cancel</td>
                      </tr>
                      <tr>
                        <td>3</td>
                        <td>8945631</td>
                        <td>Veronica</td>
                        <td>Grant Administration</td>
                        <td>TAC Administration</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={rejectedIcon} alt="rejectedIcon" />Rejected</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={rejectedIcon} alt="rejectedIcon" />Rejected</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={checkCircle} alt="checkCircle" />Completed</td>
                      </tr>
                      <tr>
                        <td>4</td>
                        <td>4235623</td>
                        <td>Veronica</td>
                        <td>Grant Administration</td>
                        <td>TAC Administration</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={rejectedIcon} alt="rejectedIcon" />Rejected</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={rejectedIcon} alt="rejectedIcon" />Rejected</td>
                        <td><img src={pendingIcon} alt="pendingIcon" />pending</td>
                      </tr>
                      <tr>
                        <td>5</td>
                        <td>2035893</td>
                        <td>Veronica</td>
                        <td>Grant Administration</td>
                        <td>TAC Administration</td>
                        <td><img src={rejectedIcon} alt="rejectedIcon" />Rejected</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={rejectedIcon} alt="rejectedIcon" />Rejected</td>
                        <td><img src={pendingIcon} alt="pendingIcon" />Pending</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={checkCircle} alt="checkCircle" />completed</td>
                      </tr>
                      <tr>
                        <td>6</td>
                        <td>9854230</td>
                        <td>Veronica</td>
                        <td>Grant Administration</td>
                        <td>TAC Administration</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={rejectedIcon} alt="rejectedIcon" />Cancel</td>
                      </tr>
                    </tbody>
                  </Table>
                </div>
              </Row>
            </Container>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Compliance;