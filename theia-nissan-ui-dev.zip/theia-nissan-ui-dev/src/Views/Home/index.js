import React, { useState } from 'react';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Card from 'react-bootstrap/Card';
import SideBar from '../../Common/SideBar';
import Header from '../../Common/Header';
import './index.scss'

import gmgService from '../../assets/images/gmg-self.png';
import globeImg from '../../assets/images/globe-img-web.png';
import mapSatelite from '../../assets/images/map-mark-img.png';
import earthGlobeImg from '../../assets/images/earth-img-globe.svg';


let Home = () => {


  return (
    <div className='wrapper'>
      <Header></Header>
      <div className="layout-wrapper main-wrapper-body d-flex">
        <SideBar activeTab={'Marketplace'} />
        <div className="main-content py-3">
          <div className='page-content'>
            <Container fluid>
              <div className='content-waplay'>
                <div className='medical-inter-wgt mb-3'>
                  <h2 className='heading-wgt-md'>WMS x GMG -  Independent Grants and<br /> Medical Activities Intelligence Platform</h2>
                </div>
                <div className='main-card-webtx'>
                  <Row>
                    <Col xs="12" md="9">
                      <Row>
                        <Col xs={12} md={6}>
                          <Card className="card-box-area mb-3">
                            <Card.Title as="h3" bsPrefix="title-card-head p-3">GMG Self service & Automated</Card.Title>
                            <Card.Body className='card-content-wap pb-0'>
                              <Card.Text>
                                <div className='img-webservice text-center'>
                                  <img src={gmgService} style={{ maxWidth: '200px' }} alt='img' />
                                </div>
                              </Card.Text>
                            </Card.Body>
                          </Card>
                        </Col>
                        <Col xs={12} md={6}>
                          <Card className="card-box-area mb-3">
                            <Card.Title as="h3" bsPrefix="title-card-head p-3">Organization & PI Intelligence</Card.Title>
                            <Card.Body className='card-content-wap pb-0'>
                              <Card.Text>
                                <div className='img-webservice text-center'>
                                  <img src={globeImg} alt='img' />
                                </div>
                              </Card.Text>
                            </Card.Body>
                          </Card>
                        </Col>
                        <Col xs={12}>
                          <Card className="card-box-area mb-3 p-4">
                            <Row className='align-items-center'>
                              <Col xs="12" md="6">
                                <div className='left-content--wapn'>
                                  <h3 className='title-card-head text-start mb-4'>Explore Pfizer Scientific Footprint</h3>
                                  <ul className='list-content-discwp'>
                                    <li>This platform connects you with scientific experts worldwide, facilitating access to a diverse pool of knowledge and expertise.</li>
                                    <li>Through comprehensive networking and collaboration tools, it empowers professionals to discover, engage, and leverage insights from leading minds across the globe. </li>
                                  </ul>
                                </div>
                              </Col>
                              <Col xs="12" md="6">
                                <div className='map-img-wp'>
                                    <img src={mapSatelite} alt='img' />
                                </div>
                              </Col>
                            </Row>
                          </Card>
                        </Col>
                      </Row>
                    </Col>
                    <Col xs="12" md="3">
                      <div className='rigt-content-solv'>
                        <p className='textmt-disc-wt'>Pioneering widespread medical initiatives and intelligence dissemination across the globe, our mission is to transform healthcare on a monumental level, catalyzing advancements and innovations in the field.</p>
                        <div className='img-globwmp mt-5 text-center'>
                          <img src={earthGlobeImg} alt='img' />
                        </div>
                      </div>
                    </Col>
                  </Row>

                </div>
              </div>
            </Container>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Home;
