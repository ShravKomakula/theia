import React, { useState } from 'react';
import Container from 'react-bootstrap/Container';
import SideBar from '../../Common/SideBar';
import Header from '../../Common/Header';
import './index.scss';

import { ComposableMap, Geographies, Geography, Marker } from 'react-simple-maps';
import { FaUser } from 'react-icons/fa';
import { ReactComponent as PersonIcon } from "../../assets/images/personIcon.svg";

let Scientific = () => {

  const geoUrl = "https://raw.githubusercontent.com/xoolive/topojson/master/world-countries.json";

  const locations = [
    { name: "New York", coordinates: [-74.006, 40.7128] },
    { name: "London", coordinates: [-0.1276, 51.5074] },
    { name: "Tokyo", coordinates: [139.6917, 35.6895] },
    { name: "Sydney", coordinates: [151.2093, -33.8688] },
  ];

  const multipleMarkers = [
    { name: "New York", coordinates: [-74.006, 40.7128] },
    { name: "New York", coordinates: [-74.0061, 40.7129] },
    { name: "New York", coordinates: [-74.0059, 40.7127] },
  ];

  return (
    <div className='wrapper'>
      <Header></Header>
      <div className="layout-wrapper main-wrapper-body d-flex">
        <SideBar activeTab={'Marketplace'} />
        <div className="main-content py-3">
          <div className='page-content'>
            <Container fluid>
              <ComposableMap>
                <Geographies geography={geoUrl}>
                  {({ geographies }) =>
                    geographies.map((geo) => (
                      <Geography key={geo.rsmKey} geography={geo} style={{
                        default: {
                          fill: "#D6D6DA",
                          outline: "none"
                        },
                        hover: {
                          fill: "#0000FF",  // Changed from #F53 to #0000FF
                          outline: "none"
                        },
                        pressed: {
                          fill: "#E42",
                          outline: "none"
                        }
                      }} />
                    ))
                  }
                </Geographies>
                {locations.map(({ name, coordinates }) => (
                  <Marker key={name} coordinates={coordinates}>
                    <PersonIcon width={30} height={30} alt='Person Icon' />
                  </Marker>
                ))}
                {multipleMarkers.map(({ name, coordinates }, index) => (
                  <Marker key={`${name}-${index}`} coordinates={coordinates}>
                    <PersonIcon width={30} height={30} alt='Person Icon' />
                  </Marker>
                ))}
              </ComposableMap>
            </Container>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Scientific;
