import React, { useState, useEffect } from "react";
import "./ScientificProfilesPage.css"; // You can define your styles in this CSS file
import { CiLocationOn, CiSearch } from "react-icons/ci";
import { MdClose } from "react-icons/md"; // Import close icon
import axios from "axios"; // Import axios for HTTP requests
import { ScientificProfileData } from "../../common/api-config";
import { FaUser } from "react-icons/fa";
import GoogleMapReact from "google-map-react";
import { Pagination,Button } from "react-bootstrap";
import { PiNameSearchEndPoint } from "../../common/api-config";
const ScientificProfilesPage = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [profiles, setProfiles] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [profilesPerPage, setProfilesPerPage] = useState(8);
  const [isMapView, setIsMapView] = useState(false); // State to track map or grid view
  const [selectedFilters, setSelectedFilters] = useState([]);
  const [showSelectedDigitalFilters, setShowSelectedDigitalFilters] = useState(false);
  const [showSelectedScientificFilters, setShowSelectedScientificFilters] = useState(false);
  const [showDigitalLeaderFilters, setShowDigitalLeaderFilters] = useState(false);
  const [showScientificLeaderFilters,setShowScientificLeaderFilters] = useState(false);
  const [countries, setCountries] = useState([]); // State to store the list of countries
  const [selectedCountry, setSelectedCountry] = useState(""); // State to store the selected country
  const [organizations, setOrganizations] = useState([]); 
  const [countriesFlags, setCountriesFlags] = useState([]);
  useEffect(() => {
    axios
      .get(ScientificProfileData(), {})
      .then((response) => {
        const uniqueCountries = Array.from(
          new Set(response.data.map((profile) => profile.COUNTRY_NAME))
        );
        const uniqueOrganizations = Array.from(
          new Set(response.data.map((profile) => profile.AFFILIATION))
        );
  
        // Construct countriesFlags array
        const countriesFlags = response.data.map((profile) => profile.COUNTRY_FLAG_LINK);
  
        setCountries(uniqueCountries);
        setOrganizations(uniqueOrganizations);
        setProfiles(response.data);
        setCountriesFlags(countriesFlags); // Set the countriesFlags state
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
      });
  }, []);
  // Empty dependency array ensures the effect runs only once when the component mounts
  const handleCountryChange = (event) => {
    setSelectedCountry(event.target.value);
  };
  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  const toggleView = () => {
    setIsMapView(!isMapView);
  };
  const paginate = (newPage) => {
    setCurrentPage(newPage);
    // Add any additional logic for handling pagination, e.g., fetching data for the new page.
  };
  const CustomMarker = ({ lat, lng, profileName }) => {
    const [showTooltip, setShowTooltip] = useState(false);
  
    return (
      <div
        style={{
          position: 'absolute',
          width: '20px',
          height: '20px',
          backgroundColor: 'red',
          borderRadius: '50%',
          border: '2px solid white',
          textAlign: 'center',
          color: 'white',
          fontSize: '16px',
          fontWeight: 'bold',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          transform: 'translate(-50%, -50%)',
          cursor: 'pointer', // Add cursor pointer for hover effect
        }}
        lat={lat}
        lng={lng}
        onMouseEnter={() => setShowTooltip(true)}
        onMouseLeave={() => setShowTooltip(false)}
      >
        {/* Tooltip */}
        {showTooltip && (
          <div
            style={{
              position: 'absolute',
              backgroundColor: 'rgba(0, 0, 0, 0.7)',
              color: 'white',
              padding: '5px',
              borderRadius: '5px',
              fontSize: '12px',
              zIndex: '999',
            }}
          >
            {profileName}
          </div>
        )}
      </div>
    );
  };
  

  
  // Logic to get profiles for the current page
  const indexOfLastProfile = currentPage * profilesPerPage;
  const indexOfFirstProfile = indexOfLastProfile - profilesPerPage;
  const currentProfiles = profiles.slice(
    indexOfFirstProfile,
    indexOfLastProfile
  );



  // Function to toggle selected filters
  const toggleFilter = (filter) => {
    if (selectedFilters.includes(filter)) {
      setSelectedFilters(selectedFilters.filter((f) => f !== filter));
    } else {
      setSelectedFilters([...selectedFilters, filter]);
    }
  };

  // Function to apply filters
  const applyDigitalFilters = () => {
    setShowSelectedDigitalFilters(true);
  };

  const applyScientificFilters = () => {
    setShowSelectedScientificFilters(true);
  };

  return (
    <div className="container">
      <h4>Scientific Experts</h4>
      <div className="search-filter">
        <input
          type="text"
          placeholder="Search Scientists"
          className="search-bar"
        />
        <div className="gap"></div>
        <button className="filter-option" onClick={toggleSidebar}>
          Filter(0) &nbsp;&nbsp;&nbsp;&nbsp; None
        </button>
        <button className="view-map-btn" onClick={toggleView}>
          <CiLocationOn /> {isMapView ? "View on Grid" : "View on Map"}
        </button>
      </div>
      {isMapView ? (
        <div className="Gmap">
 


<GoogleMapReact
  // Set your Google Maps API key here
  bootstrapURLKeys={{
    key: "AIzaSyDx1t1xehKETxiCv0KPsGUGVzo0YXra8ZU",
  }}
  defaultCenter={{ lat: 0, lng: 0 }}
  defaultZoom={1}
>
  {/* Add markers for each profile */}
  {currentProfiles.map((profile) => (
    <CustomMarker
    key={profile.LINK_ID}
    lat={profile.ARCGISLATITUDE}
    lng={profile.ARCGISLONGITUDE}
    profileName={profile.FIRST_NAME + " " + profile.LAST_NAME}
    />
  ))}
</GoogleMapReact>

        </div>
      ) : (
        <div className="card-container">
          {currentProfiles.map((profile) => (
            <ProfileCard
              key={profile.SE_ID}
              name={`${profile.FIRST_NAME} ${profile.LAST_NAME}`}
              degree={profile.DEGREE_S_}
              profession={profile.PROFESSION}
              speciality={profile.SPECIALTY}
              scientificReach={profile.SCIENTIFIC_REACH}
              emergingExpert={profile.EMERGING_EXPERT}
              congressContributions={profile.CONGRESS_CONTRIBUTIONS}
              publications={profile.PUBLICATIONS}
              clinicalTrials={profile.CLINICAL_TRIALS}
              digitalEngagement={profile.DIGITAL_ENGAGEMENT}

            />
          ))}
           <div className="d-flex justify-content-center mt-4">
                    <pre>
                      {currentPage > 1 && (
                        <Button onClick={() => paginate(currentPage - 1)}>
                          {"Prev"}
                        </Button>
                      )}
                      &nbsp;
                      {currentPage} (current Page){" "}
                      <Button onClick={() => paginate(currentPage + 1)}>
                        {"Next"}
                      </Button>
                    </pre>
                  </div>
        </div>
      )}

<Sidebar
  isOpen={isSidebarOpen}
  toggleSidebar={toggleSidebar}
  handleCountryChange={handleCountryChange}
  setShowDigitalLeaderFilters={setShowDigitalLeaderFilters}
  showDigitalLeaderFilters={showDigitalLeaderFilters}
  setShowScientificLeaderFilters={setShowScientificLeaderFilters}
  showScientificLeaderFilters={showScientificLeaderFilters} // Corrected prop name
  selectedFilters={selectedFilters}
  showSelectedDigitalFilters={showSelectedDigitalFilters}
  showSelectedScientificFilters={showSelectedScientificFilters}
  setShowSelectedDigitalFilters={setShowSelectedDigitalFilters}
  setShowSelectedScientificFilters={setShowSelectedScientificFilters}
  toggleFilter={toggleFilter}
  applyDigitalFilters={applyDigitalFilters}
  applyScientificFilters={applyScientificFilters}
  countries={countries}
  setCountries={setCountries}
  countriesFlags={countriesFlags}
  organizations={organizations}
  setOrganizations={setOrganizations}
  selectedCountry={selectedCountry}
  setSelectedCountry={setSelectedCountry}
/>

    </div>
  );
};

const ProfileCard = ({
  name,
  speciality,
  degree,
  profession,
  scientificReach,
  emergingExpert,
  congressContributions,
  publications,
  clinicalTrials,
  digitalEngagement,
}) => {
  // Function to generate filled and unfilled dots based on the provided value
  const generateDots = (filledCount, label) => {
    const maxDots = 5;
    const filledDots = Math.min(filledCount, maxDots);
    const unfilledDots = maxDots - filledDots;

    const dots = [];

    // Push filled dots
    for (let i = 0; i < filledDots; i++) {
      dots.push(<span className="filled-dot" key={`filled-dot-${i}`} />);
    }

    // Push unfilled dots
    for (let i = 0; i < unfilledDots; i++) {
      dots.push(<span className="unfilled-dot" key={`unfilled-dot-${i}`} />);
    }

    return (
      <div className="dots">
        {dots}
        <p>
          <strong>{label}</strong>
        </p>
      </div>
    );
  };

  return (
    <div className="profile-card">
      <div className="profile-info">
        <FaUser className="profile-image" /> &nbsp;&nbsp;
        <h6 className="profile-name">{name}</h6>
        <div>
          {" "}
          <p className="degree">{degree}</p>
        </div>
        <p className="speciality">{profession}</p>
      </div>
      <div className="additional-info">
        <div className="reach-expert">
          <p>
            <span className="Sreach">{scientificReach} Reach</span> &nbsp;&nbsp;
            {emergingExpert === "Y" && (
              <span className="emerging-expert">Emerging Expert</span>
            )}
          </p>
        </div>
        <div className="activities">
          <h5>Activities:</h5>
          <div className="activity-line">
            {generateDots(congressContributions, "Congress Contributions")}
            {generateDots(publications, "Publications")}
          </div>
          <div className="activity-line2">
            {generateDots(clinicalTrials, "Clinical Trials")}
            {generateDots(digitalEngagement, "Digital Engagement")}
          </div>
        </div>
      </div>
    </div>
  );
};
const Sidebar = ({
  isOpen,
  toggleSidebar,
  selectedFilters,
  showSelectedDigitalFilters,
  showSelectedScientificFilters,
  toggleFilter,
  applyDigitalFilters,
  applyScientificFilters,
  setShowDigitalLeaderFilters,
  showDigitalLeaderFilters,
  setShowScientificLeaderFilters,
  showScientificLeaderFilters,
  countries,setCountries,selectedCountry,setSelectedCountry,countriesFlags,setCountriesFlags,handleCountryChange,organizations,setOrganizations
}) => {
  const toggleDigitalLeaderFilters = () => {
    setShowDigitalLeaderFilters(!showDigitalLeaderFilters);
  };
  const toggleScientificLeaderFilters = () => {
    setShowScientificLeaderFilters(!showScientificLeaderFilters);
  };
  
  const toggleCheckboxColor = (id) => {
    const checkbox = document.getElementById(id);
    const label = checkbox.nextElementSibling;
  
    if (checkbox.checked) {
      label.style.color = "#007bff"; // Change label text color to blue when checked
      label.style.borderColor = "#007bff"; // Change checkbox border color to blue when checked
    } else {
      label.style.color = "#706d6d"; // Reset label text color when unchecked
      label.style.borderColor = "#706d6d"; // Reset checkbox border color when unchecked
    }
  };
  
  return (
    <div className={`sidebarRight ${isOpen ? "open" : ""}`}>
      
      <div className="sidebar-content ">
        <h5>Filters</h5>

        <h6>Country:</h6>
      
        <select value={selectedCountry} onChange={handleCountryChange}>
  <option value="">Select a country</option>
  {countries.map((country, index) => (
    <option key={index} value={country}>
  
      {country}<img src={`https://flagpedia.net/data/flags/mini/nl.png`}  width={10} height={10}/>
    </option>
  ))}
</select>

        <h6>Organization:</h6>
        <select className="dropdown">
        <option value="">Select an organization</option>
        {organizations.map((org, index) => (
          <option key={index} value={org}>
            {org}
          </option>
        ))}
      </select>

        <h6>Scientific Leader</h6>
     
        <input
          type="search"
          title="Scientific Leader Search"
          placeholder="Find Topics"
          className="leaderSearch"
          onClick={toggleScientificLeaderFilters}
          />
          {showSelectedScientificFilters && (
            <div className="selected-filters1">
              {selectedFilters.map((filter, index) => (
                <span key={index} className="selected-filter1">
                  {filter}
                  <MdClose onClick={() => toggleFilter(filter)} />
                </span>
              ))}
            </div>
          )}
          {showScientificLeaderFilters && (
            <>
            <div className="blue-checkboxes">
            <div>
              <input
                type="checkbox"
                id="association"
                onChange={() => {toggleFilter("Association"); toggleCheckboxColor("association");}}
              />
              <label htmlFor="association" className="blue">
                Association
              </label>
            </div>
            <div>
              <input
                type="checkbox"
                id="pfizer"
                onChange={() => {toggleFilter("Pfizer"); toggleCheckboxColor("pfizer");}}
              />
              <label htmlFor="pfizer" className="blue">
                Pfizer
              </label>
            </div>
            <div>
              <input
                type="checkbox"
                id="medical"
                onChange={() => {toggleFilter("Medical"); toggleCheckboxColor("medical");}}
              />
              <label htmlFor="medical" className="blue">
                Medical
              </label>
            </div>
            <div>
              <input
                type="checkbox"
                id="cardio"
                onChange={() =>{ toggleFilter("Cardio"); toggleCheckboxColor("cardio");}}
              />
              <label htmlFor="cardio" className="blue">
                Cardio
              </label>
            </div>
          </div>
  
          <button className="btn filter" onClick={applyScientificFilters} type="submit">
            Apply Filters
          </button></>
          )}
          

        <h6>Digital Leader</h6>
        <input
          type="search"
          title="Digital Leader Search"
          placeholder="Find Topics"
          className="leaderSearch"
          onClick={toggleDigitalLeaderFilters}
          />
          {showSelectedDigitalFilters && (
            <div className="selected-filters">
              {selectedFilters.map((filter, index) => (
                <span key={index} className="selected-filter">
                  {filter}
                  <MdClose onClick={() => toggleFilter(filter)}/>
                </span>
              ))}
            </div>
          )}
          {showDigitalLeaderFilters && (
            <>
            <div className="blue-checkboxes">
            <div>
            <input
      type="checkbox"
      id="association1"
      onChange={() => {
        toggleFilter("Association");
        toggleCheckboxColor("association1");
      }}
    />
              <label htmlFor="association1" className="blue1">
                Association
              </label>
            </div>
            <div>
              <input
                type="checkbox"
                id="pfizer1"
                onChange={() => {toggleFilter("Pfizer"); toggleCheckboxColor("pfizer1");}}
                
              />
              <label htmlFor="pfizer1" className="blue1">
                Pfizer
              </label>
            </div>
            <div>
              <input
                type="checkbox"
                id="medical1"
                onChange={() => {toggleFilter("Medical"); toggleCheckboxColor("medical1");}}
              />
              <label htmlFor="medical1" className="blue1">
                Medical
              </label>
            </div>
            <div>
              <input
                type="checkbox"
                id="cardio1"
                onChange={() => {toggleFilter("Cardio"); toggleCheckboxColor("cardio1");}}
              />
              <label htmlFor="cardio1" className="blue1">
                Cardio
              </label>
            </div>
          </div>
  
          <button className="btn filter" onClick={applyDigitalFilters} type="submit">
            Apply Filters
          </button></>
          )}
          
        <h6>Emerging Expert</h6>

        <div className="radio">
          <input type="radio" id="yes" name="emergingExpert" value="yes" />
          <label htmlFor="yes" className="emerging">
            Yes
          </label>
          <input type="radio" id="no" name="emergingExpert" value="no" />
          <label htmlFor="no" className="emerging">
            No
          </label>
        </div>

        <h6>Scientific Reach</h6>
        <div className="check-box">
          <input type="checkbox" id="Local" />
          <label htmlFor="Local">Local Reach</label>
          <input type="checkbox" id="National" />
          <label htmlFor="National">National Reach</label>
        </div>
        <div className="check-box">
          <input type="checkbox" id="regional" />
          <label htmlFor="regional">Regional Reach</label>
          <input type="checkbox" id="global" />
          <label htmlFor="global">Global Reach</label>
        </div>
        <button className="btn-apply " type="submit">Apply FIlters</button>
      </div>
      
      <MdClose className="close-icon" onClick={toggleSidebar} />
    </div>
  );
};



export default ScientificProfilesPage;