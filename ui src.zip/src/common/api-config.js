//const BASIC_GATEWAY = "http://10.11.185.89:8011/";
const BASIC_GATEWAY = "http://127.0.0.1:8035/";
export const GetSsoTokenOauth2 = (code) => (`${BASIC_GATEWAY}token_oauth2?code=${code}`)
export const ValidateSsoOauth2 = (token) => (`${BASIC_GATEWAY}validate_oauth2?token=${token}`)
export const RefreshTokenEndpoint =(refresh_token) => (`${BASIC_GATEWAY}refresh_oauth2?refresh_token=${refresh_token}`)
export const QuestionEndPoint = () => (`${BASIC_GATEWAY}query_rag`)
export const GetPastQuesriesEndPoint = () => (`${BASIC_GATEWAY}get_question_list`)
export const GetAnswerEndPoint = () => (`${BASIC_GATEWAY}get_answer`)
export const DownloadEndPoint = (document_key) => (`${BASIC_GATEWAY}download/${document_key}`)
export const ViewEndpoint = (document_key) => (`${BASIC_GATEWAY}view/${document_key}`)
export const LikeEndPoint = () => (`${BASIC_GATEWAY}like`)
export const DisLikeEndPoint = () => (`${BASIC_GATEWAY}dislike`)
export const CommentEndPoint = () => (`${BASIC_GATEWAY}comment`)
export const FetchSnowFlakeData = () => (`${BASIC_GATEWAY}snowflake_query`)
export const TextToSql = () => (`${BASIC_GATEWAY}Query_Details`)
export const UserLogsEndpoint = () => (`${BASIC_GATEWAY}user_session`)
export const InsightsEndPoint = () =>  (`${BASIC_GATEWAY}bring-data`)
export const RevokeTokenEndPoint = () =>  (`${BASIC_GATEWAY}revoke_oauth2`)
export const ScientificProfileData = () =>  (`${BASIC_GATEWAY}profile-data`)
export const PiNameSearchEndPoint = () =>  (`${BASIC_GATEWAY}piName`)
export const CountrySearchEndPoint = () =>  (`${BASIC_GATEWAY}country`)
export const OrganizationearchEndPoint = () =>  (`${BASIC_GATEWAY}organization`)
export const SleaderSearchEndPoint = () =>  (`${BASIC_GATEWAY}Sleader`)
export const DleaderearchEndPoint = () =>  (`${BASIC_GATEWAY}Dleader`)
export const FilterEndPoint = () =>  (`${BASIC_GATEWAY}scientific_records`)
export const careersummaryEndpoint = () =>  (`${BASIC_GATEWAY}career_summary`)
export const mainsearchEndpoint = (piName, topK) => {

    const queryParams = new URLSearchParams({
      pi_name: piName,
      top_k: topK
    }).toString();
    return `${BASIC_GATEWAY}main-search?${queryParams}`;
  };
  
export const overviewEndpoint = () =>  (`${BASIC_GATEWAY}overviewdata`)
export const viewoutcomesreport = (document_key) => (`${BASIC_GATEWAY}oview/${document_key}`)