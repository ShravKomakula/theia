import React from 'react';
import Topbar from '../../common/Topbar';
import Footer from '../../common/Footer/Footer';
import History from '../History/History';
import { useNavigate } from "react-router-dom";
import "./helpqa.css"
const HelpQA = () => {
const navigate=useNavigate();
   const gotoHistory= () => {
    navigate("/History");
  };
    return (
        <>
            <div className='topbar'>
                <Topbar />
            </div>
<div className='helpqa-content'>
<h1 className='main-heading' onClick={gotoHistory}>Theia AI History and Feedback Log</h1>
</div>
            
                <Footer />
           
        </>
    )
}

export default HelpQA;
