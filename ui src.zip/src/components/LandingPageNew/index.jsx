import React, { useState, useEffect } from "react";
import { toast } from "react-toastify";
import { useNavigate, Link } from "react-router-dom";
import AnimatedMic from "../../assets/images/animatesmic.svg";
import Footer from "../../common/Footer/Footer";
import { useAuth } from "../../components/AuthContext";
import "./LandingPageNew.css";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import { Dropdown, DropdownDivider } from 'react-bootstrap';


import Topbar from "../../common/Topbar";
import icon1 from "../../assets/images/icon1.svg";
import icon2 from "../../assets/images/icon2.svg";
import icon3 from "../../assets/images/icon3.svg";
const LandingPageNew = () => {
  const navigate = useNavigate();

  const { logout } = useAuth();
  const [question, setQuestion] = useState("");
  const [displayDropdown, setDisplayDropdown] = useState(false);
  const [pastQueries, setPastQueries] = useState([]);
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [selectedDropdown, setSelectedDropdown] = useState('Select Source');
const checking=()=>{
console.log('clicked')
}
  const selectQuestion = (event) => {
    setQuestion(event.target.value);
  };
  const handleDropdownChange = (eventKey) => {
    setSelectedDropdown(eventKey);
  };
  const searchQuestions = () => {
    let searchQuery = transcript || question;
    if (selectedDropdown === "Select Source") {
      toast.warning("Please select a source.", {
        position: toast.POSITION.TOP_CENTER,
      });
      return; // Stop execution if source is not selected
    }
    
    if (searchQuery.trim() !== "") {
      navigate("/queries", {
        state: { question: searchQuery, sourceType: selectedDropdown },
      });
      localStorage.setItem("queryQuestion", JSON.stringify(searchQuery));
    } else {
      toast.warning("Please enter a question.", {
        position: toast.POSITION.TOP_CENTER,
      });
    }
  };
  
  
  const handleDropdownFocus = () => {
    setDisplayDropdown(true);
  };


  const handleDropdownBlur = () => {
    setDisplayDropdown(true);
  };

  const handleDownItemClick = (value) => {
    setQuestion(value);
   // setSelectedDropdown("Source"); // Set the default value to "Source"
    setDisplayDropdown(false);
  };
  

  const startListening = () => {
    setIsListening(true);

    const recognition = new (window.SpeechRecognition ||
      window.webkitSpeechRecognition)();

    recognition.continuous = false;

    recognition.interimResults = false;

    recognition.onresult = (event) => {
      const result = event.results[0];

      setTranscript(result[0].transcript);
    };

    recognition.onend = () => {
      setIsListening(false);

      searchQuestions();
    };

    recognition.start();
  }; 

  const stopListening = () => {
    setIsListening(false);
    if (transcript.trim() !== "") {
      setQuestion(transcript);
      searchQuestions();
    } else {
      toast.warning("Please enter a question.", {
        position: toast.POSITION.TOP_CENTER,
      });
    }
  };


  const handleKeyDown = (event) => {
    if (event.key === "Enter") {
      searchQuestions();
    }
  };

  return (
   <>
     <Topbar />

     <div
      className="d-flex flex-column align-items-center">
 
      <div
        className="input-section d-flex flex-column mt-5 w-100 justify-content-center align-items-center auto">
        <div className="main-container">
          <Row>
            <Col className="col-12 col-lg-12">
              <Row className="mx-0">
                <Col className="col-12 col-md-12 ps-0 pe-2">
                  <span className="heading mt-3">
                    WMS x GMG - Independent Grants & Medical Activities
                  </span>

                  <span className="heading-2">
                     Intelligence Platform
                  </span>

                  
                </Col>

                <div className="pb-5 position-relative common-align">
                
 
                <div className="bar">
  <input
    className="searchbar pl-3 col-lg-12"
    type="text"
    title="Search"
    width={600}
    value={transcript || question}
    onFocus={handleDropdownFocus}
    onBlur={handleDropdownBlur}
    onChange={(event) => setTranscript(event.target.value)}
    onKeyDown={handleKeyDown}
  />
  <div> {/* Here, remove the parentheses after checking */}
  <img
  className="voice"
  onClick={isListening ? stopListening : startListening}
  src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e8/Google_mic.svg/716px-Google_mic.svg.png"
  title="Search by Voice"
/>

  </div>
  <Dropdown onSelect={handleDropdownChange} className="selectDropdown">
    <Dropdown.Toggle id="dropdown-basic">{selectedDropdown}</Dropdown.Toggle>

    <Dropdown.Menu>
      <Dropdown.Item eventKey="Select Source">Select Source</Dropdown.Item>
      <DropdownDivider />
      <Dropdown.Item eventKey="GNT01 SOPs and JobAids">GNT01 SOPs and JobAids</Dropdown.Item>
      <Dropdown.Item eventKey="Grant Details">Grant Details</Dropdown.Item>
      <Dropdown.Item eventKey="Grant Uploads">Grant Uploads</Dropdown.Item>
      <Dropdown.Item eventKey="Org & HCP Intelligence">Org & HCP Intelligence</Dropdown.Item>
      <Dropdown.Item eventKey="placeholder- DFO">placeholder- DFO</Dropdown.Item>
      <Dropdown.Item eventKey="Placeholder-MedInfo">Placeholder-MedInfo</Dropdown.Item>
    </Dropdown.Menu>
  </Dropdown>
</div>

  
</div>


                
           
              </Row>
            </Col>
          </Row>
        </div>
        <div className="container">
  <div className="row">
  <div className="col-lg-1"></div>
    <div className="col-lg-3">
      <div className="card landingCard mb-3">
        <div className="card-body landingCard-body carda">
          <h5 className="card-title">GMG Self Service</h5>
          <br></br>
          <img src={icon1} className="card-img-top" alt="Image 1" />
        </div>
      </div>
    </div>
    <div className="col-lg-3">
    
    </div>
    <div className="col-lg-4">
        <div className="card landingCard mb-3">
        <div className="card-body landingCard-body cardb">
          <h5 className="card-title">Organization &<br />PI Intellegence</h5>
          <p className="card-text">
          <img src={icon2} className="card-img-top" alt="Image 2" />
          </p>
        </div>
      </div>
      <div className="card landingCard mb-3">
        <div className="card-body landingCard-body cardc">
          <h5 className="card-title">Explore Pfizer<br/>Scientific Footprint</h5>
          <p className="card-text">
          <img src={icon3} className="card-img-top" alt="Image 3" />
          </p>
        </div>
      </div>
    </div>
    <div className="col-lg-1"></div>
  </div>
</div>


         
      
   
      </div>

    </div>

   <Footer />

    </>

  );
};

export default LandingPageNew;
