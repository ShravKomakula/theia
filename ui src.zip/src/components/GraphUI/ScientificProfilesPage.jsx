import React, { useState, useEffect } from 'react';
import './ScientificProfilesPage.css'; // You can define your styles in this CSS file
import { CiLocationOn, CiSearch } from 'react-icons/ci';
import { MdClose } from 'react-icons/md'; // Import close icon
import axios from 'axios'; // Import axios for HTTP requests
import { ScientificProfileData } from '../../common/api-config';
import { FaUser } from 'react-icons/fa';
const ScientificProfilesPage = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [profiles, setProfiles] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [profilesPerPage, setProfilesPerPage] = useState(8);

  useEffect(() => {
    // Fetch data from the API when the component mounts
    axios.get(ScientificProfileData(), {})
      .then(response => {
        setProfiles(response.data);
      })
      .catch(error => {
        console.error('Error fetching data:', error);
      });
  }, []); // Empty dependency array ensures the effect runs only once when the component mounts

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  // Logic to get profiles for the current page
  const indexOfLastProfile = currentPage * profilesPerPage;
  const indexOfFirstProfile = indexOfLastProfile - profilesPerPage;
  const currentProfiles = profiles.slice(indexOfFirstProfile, indexOfLastProfile);

  // Change page
  const paginate = pageNumber => setCurrentPage(pageNumber);

  return (
    <div className="container">
      <h4>Scientific Experts</h4>
      <div className="search-filter">
        <input type="text" placeholder="Search Scientists" className="search-bar" />
        <div className="gap"></div>
        <button className="filter-option" onClick={toggleSidebar}>
          Filter (0) None
        </button>
        <button className="view-map-btn"><CiLocationOn /> &nbsp;View on Map</button>
      </div>
      <div className="card-container">
        {currentProfiles.map(profile => (
          <ProfileCard
            key={profile.SE_ID}
            name={`${profile.FIRST_NAME} ${profile.LAST_NAME}`}
            degree={profile.DEGREE_S_}
            profession={profile.PROFESSION}
            speciality={profile.SPECIALTY}
            scientificReach={profile.SCIENTIFIC_REACH}
            emergingExpert={profile.EMERGING_EXPERT}
            congressContributions={profile.CONGRESS_CONTRIBUTIONS}
            publications={profile.PUBLICATIONS}
            clinicalTrials={profile.CLINICAL_TRIALS}
            digitalEngagement={profile.DIGITAL_ENGAGEMENT}
          />
        ))}
      </div>
      <Pagination
        profilesPerPage={profilesPerPage}
        totalProfiles={profiles.length}
        paginate={paginate}
      />
      <Sidebar isOpen={isSidebarOpen} toggleSidebar={toggleSidebar} />
    </div>
  );
};


const ProfileCard = ({ name, speciality, degree, profession, scientificReach, emergingExpert, activities, congressContributions, digitalEngagement, clinicalTrials, publications }) => {
  // Function to generate filled and unfilled dots based on the provided value
  const generateDots = (filledCount) => {
    const maxDots = 5;
    const filledDots = Math.min(filledCount, maxDots);
    const unfilledDots = maxDots - filledDots;
    
    const dots = [];

    // Push filled dots
    for (let i = 0; i < filledDots; i++) {
      dots.push(<span className="filled-dot" key={`filled-dot-${i}`} />);
    }

    // Push unfilled dots
    for (let i = 0; i < unfilledDots; i++) {
      dots.push(<span className="unfilled-dot" key={`unfilled-dot-${i}`} />);
    }

    return dots;
  };

  return (
    <div className="profile-card">
      <div className="profile-info">
        <FaUser className="profile-image" /> &nbsp;&nbsp;
        <h6 className="profile-name">{name}</h6>
        <div> <p className='degree'>{degree}</p></div>
        <p className="speciality">{profession}</p>
      </div>
      <div className="additional-info">
        <div className="reach-expert">
          <p>
            <span className='Sreach'>{scientificReach} Reach</span> &nbsp;&nbsp;
            {emergingExpert === 'Y' && <span className="emerging-expert">Emerging Expert</span>}
          </p>
        </div>
        <div className="activities">
          <h5>Activities:</h5>
          <div className="activity-line">
          <div className="dots one">{generateDots(congressContributions)}</div>
            <p><strong className='leftcontent'>Congress Contributions</strong> </p>
           
            <div className="dots two">{generateDots(publications)}</div>
            <p><strong className='rightcontent'>Publications</strong> </p>
         
          </div>
          <div className="activity-line2">
          <div className="dots three">{generateDots(clinicalTrials)}</div>
            <p><strong className='leftcontent'>Clinical Trials</strong></p>
            <div className="dots four">{generateDots(digitalEngagement)}</div>
            <p><strong className='rightcontent'>Digital Engagement</strong></p>
          
          </div>
        </div>
      </div>
    </div>
  );
};





const Sidebar = ({ isOpen, toggleSidebar }) => {
  return (
    <div className={`sidebarRight ${isOpen ? 'open' : ''}`}>
      <div className="sidebar-content">
        <h5>Filters</h5>
        <ul>
          <li>Country</li>
          <li>Organization</li>
          <li>Scientific Leader</li>
          <li>Digital Leader</li>
          <li>Emerging Expert</li>
          <li>Scientific Reach</li>
        </ul>
        <div className="checkbox-group">
          <h5>Logical Search</h5>
          <input type="checkbox" id="logical-search-1" />
          <label htmlFor="logical-search-1">Logical Search 1</label>
          <input type="checkbox" id="logical-search-2" />
          <label htmlFor="logical-search-2">Logical Search 2</label>
          {/* Add more checkboxes as needed */}
        </div>
      </div>
      <MdClose className="close-icon" onClick={toggleSidebar} />
    </div>
  );
};

const Pagination = ({ profilesPerPage, totalProfiles, paginate }) => {
  const pageNumbers = [];

  for (let i = 1; i <= Math.ceil(totalProfiles / profilesPerPage); i++) {
    pageNumbers.push(i);
  }

  return (
    <nav>
      <ul className="pagination">
        {pageNumbers.map(number => (
          <li key={number} className="page-item">
            <button onClick={() => paginate(number)} className="page-link">
              {number}
            </button>
          </li>
        ))}
      </ul>
    </nav>
  );
};

export default ScientificProfilesPage;
