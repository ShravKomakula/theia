import React, { useState, useEffect } from "react";
import "./Dashboard.css";
import axios from "axios";
import Mapwithsummary from "./Mapwithsummary";
import { CiGrid2H } from "react-icons/ci";
import { MdGridOn } from "react-icons/md";
import { DataGrid } from '@mui/x-data-grid';
import { FetchSnowFlakeData, mainsearchEndpoint } from "../../common/api-config";
import { format, isValid } from 'date-fns';
import TileView from "./TileView";
import Overview from "./Overview";
import { GoArrowDown, GoDownload } from "react-icons/go";
import pending from "../../assets/pending.svg";
import success from "../../assets/success.svg";
function Dashboard() {
  const [grantedViewActive, setGrantedViewActive] = useState(true);
  const [allViewActive, setAllViewActive] = useState(false);
  const [data, setData] = useState({});
  const [rows, setRows] = useState([]);
  const [columns, setColumns] = useState([]);
  const [isGridView, setIsGridView] = useState(false);
  const [searchResults, setSearchResults] = useState([]);
  const [query, setQuery] = useState({
    pi_name: '',
    organization_name: '',
    primary_area_of_interest_disease: '',
    top_k: 100
  });

  const [searchCriterion, setSearchCriterion] = useState('pi_name');
  const userC = JSON.parse(localStorage.getItem('access_token'));
  const userCountryCode = userC.userInfo.LOCATION_CODE_ISO2;

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const response = await fetch(FetchSnowFlakeData());
      const result = await response.json();

      const columnNames = result.columns;
      const excludedColumns = ['LATITUDE', 'LONGITUDE', 'LOGO_URL', 'COUNTRY_CODE', 'CITY', 'COUNTRY'];
      const filteredColumns = columnNames
        .filter((fieldName) => !excludedColumns.includes(fieldName))
        .map((fieldName) => ({
          field: fieldName,
          headerName: fieldName
            .replace(/_/g, ' ')
            .toLowerCase()
            .replace(/\b(\w)/g, (char) => char.toUpperCase()),
          width: 150,
          valueFormatter: (params) => {
            const value = params.value;
            if (fieldName === 'LAST_UPDATE' || fieldName === 'NEXT_MILESTONE') {
              const date = new Date(value);
              return isValid(date) ? format(date, 'MM/dd/yyyy') : '';
            }
            if (fieldName === 'APPROVED_AMOUNT' || fieldName === 'PAYMENT_REMAINING') {
              return `$${value != null ? value.toFixed(2) : '0.00'}`;
            }
            return value;
          },
        }));

      setColumns(filteredColumns);

      const formattedRows = result.results.map((row, index) => {
        const rowObject = {};
        columnNames.forEach((name, i) => {
          rowObject[name] = row[i];
        });
        rowObject.id = index;  // Ensure each row has a unique id
        return rowObject;
      });

      setData(result);
      setRows(formattedRows);
      console.log("All rows", result.results);
      console.log("Formatted rows", formattedRows);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  const formatRows = (dataRows, columnList, columnNames) => {
    return dataRows.map((row, index) => {
      const rowObject = { id: index }; // Assigning the index as the id
      columnList.forEach((column) => {
        const columnName = column.field;
        const columnIndex = columnNames.indexOf(columnName);
        if (columnIndex !== -1) {
          rowObject[columnName] = row[columnIndex];
        }
      });
      return rowObject;
    });
  };

  const handleGrantedViewClick = () => {
    if (searchResults.length === 0) {
      setGrantedViewActive(true);
      setAllViewActive(false);
    } else {
      setSearchResults([]); // Reset search results when switching back to the recommended view
      setGrantedViewActive(true);
      setAllViewActive(false);
    }
  };
  
  
  const handleAllViewClick = () => {
    setGrantedViewActive(false);
    setAllViewActive(true);
  };

  const handleTileViewClick = () => {
    setIsGridView(false);
  };

  const handleGridViewClick = () => {
    setIsGridView(true);
  };

  const filteredData = (data.results && grantedViewActive)
    ? data.results.filter(row => row[data.columns.indexOf('COUNTRY_CODE')] === userCountryCode)
    : data.results || [];

  const formattedFilteredData = formatRows(filteredData, columns, data.columns || []);

  const handleSearch = async () => {
    try {
      console.log("Query Parameters:", query);
      const response = await axios.post(mainsearchEndpoint(), null, {
        params: query
      });
      console.log("Search Response:", response.data);
  
      if (response.data && response.data.results) {
        const searchResults = response.data.results.map((row) => {
          const result = {};
          response.data.columns.forEach((columnName, index) => {
            result[columnName] = row[index];
          });
          return result;
        });
        console.log("Formatted Search Results:", searchResults);
        setSearchResults(searchResults);
  
        if (searchResults.length === 0) {
          alert("No data found, please search another");
        }
      } else {
        console.warn("Search response is empty or incorrectly formatted", response.data);
        setSearchResults([]);
        alert("No data found");
      }
  
      // Reset the search query after performing the search
      setQuery({
        pi_name: '',
        organization_name: '',
        primary_area_of_interest_disease: '',
        top_k: 100
      });
    } catch (error) {
      console.error('Error fetching search data:', error);
    }
  };
  
  
  
  
const handleCriterionChange = (e) => {
  setSearchCriterion(e.target.value);
  setQuery({
    ...query,
    pi_name: '',
    organization_name: '',
    primary_area_of_interest_disease: ''
  });
};
/* console.log(searchResults,"searchresults");
console.log(filteredData,"filterdata");
console.log(formattedFilteredData,"formattedFilteredData");
console.log(searchResults.length ,"length") */
const handleDownload = () => {
  // Extract all rows data
  const allRows = searchResults.length > 0 ? searchResults : formattedFilteredData;

  // Extract column headers
  const columnHeaders = columns.map(column => column.headerName);

  // Combine column headers and rows data
  const csvContent =
    "data:text/csv;charset=utf-8," +
    [columnHeaders.join(",")].concat(
      allRows.map(row => Object.values(row).join(","))
    ).join("\n");

  // Trigger download
  const encodedUri = encodeURI(csvContent);
  const link = document.createElement("a");
  link.setAttribute("href", encodedUri);
  link.setAttribute("download", "data.csv"); // Set the filename as data.csv
  document.body.appendChild(link);
  link.click();
};

  return (
    <div className="Dashboard">
      <h4>Grants Dashboard</h4>
      <Overview />
      <div className="section1">
        <div className="buttons-section">
          <button
            type="button"
            className={`btn rbtn ${grantedViewActive ? "active" : ""}`}
            onClick={handleGrantedViewClick}
          >
            Recommended View
          </button>
          <button
            type="button"
            className={`btn abtn ${allViewActive ? "active" : ""}`}
            onClick={handleAllViewClick}
          >
            All View
          </button>
        </div>
        {allViewActive && (
         <div className="inputsection">
         <select value={searchCriterion} onChange={handleCriterionChange}>
           <option value="pi_name">PI Name</option>
           <option value="organization_name">Organization Name</option>
           <option value="primary_area_of_interest_disease">Primary Area of Interest/Disease</option>
         </select>
         <input
  type="text"
  placeholder={`Search by ${searchCriterion.replace('_', ' ')}`}
  value={query[searchCriterion]}
  onChange={(e) => setQuery({ ...query, [searchCriterion]: e.target.value })}
  onKeyPress={(e) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  }}
/>

         <button onClick={handleSearch}>Search</button>
       </div>
       
        )}
       <div className="section2">
 
  <Mapwithsummary data={searchResults.length > 0 ? searchResults : filteredData} userCountryCode={userCountryCode} />

</div>
<div className="section3">

  <div className="icon-section">
    <CiGrid2H
      className={`Tileview ${!isGridView ? "active" : ""}`}
      onClick={handleTileViewClick}
    />
    <MdGridOn
      className={`Gridview ${isGridView ? "active" : ""}`}
      onClick={handleGridViewClick}
    />
       {isGridView && (
    <button className="download-button" onClick={handleDownload}><GoArrowDown/> Download</button>
  )}
  </div>


  <div className="content-section">
    {!isGridView && (
      <TileView data={searchResults.length > 0 ? searchResults : filteredData} userCountryCode={userCountryCode} />
    )}
  {isGridView && (
          <div style={{ width: '100%', height: '400px', maxWidth: 1000, margin: 'auto' }}>
            <DataGrid
              rows={searchResults.length > 0 ? searchResults : formattedFilteredData}
              columns={[
                ...columns.filter(column => column.field !== 'APPROVED_AMOUNT' && column.field !== 'PAYMENT_REMAINING'),
                {
                  field: 'APPROVED_AMOUNT',
                  headerName: 'Approved Amount',
                  width: 200,
                  renderCell: (params) => (
                    <div style={{ display: 'flex', alignItems: 'center' }}>
                      {params.value != null && <img src={success} alt="Success" style={{ marginRight: '5px', width: '20px' }} />}
                      {params.value != null ? `$${params.value.toFixed(2)}` : ''}
                    </div>
                  )
                },
                {
                  field: 'PAYMENT_REMAINING',
                  headerName: 'Payment Remaining',
                  width: 200,
                  renderCell: (params) => (
                    <div style={{ display: 'flex', alignItems: 'center' }}>
                      {params.value != null && <img src={pending} alt="Pending" style={{ marginRight: '5px', width: '20px' }} />}
                      {params.value != null ? `$${params.value.toFixed(2)}` : ''}
                    </div>
                  )
                }
              ]}
              pageSize={5}
              className="gridtable"
              rowsPerPageOptions={[5, 10, 20]}
              getRowId={(row) => row.REQUEST_ID}
            />
          </div>
        )}
    


  </div>
</div>

      </div>
    </div>
  );
}

export default Dashboard;
