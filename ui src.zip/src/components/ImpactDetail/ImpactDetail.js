import React, { useState } from 'react';
import Container from 'react-bootstrap/Container';

import './index.css'

import ArrowLeft from '../../assets/images/ArrowLeft.svg'
import EllipseBlue from '../../assets/images/Ellipse-Blue.svg'
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import ReactApexChart from 'react-apexcharts';

import Table from 'react-bootstrap/Table';
import downArrow from '../../assets/images/arrow-down.svg'

let ImpactDetail = () => {

  const options = {
    legend: {
        position: 'bottom',
        horizontalAlign: 'center',
      },
    chart: {
      type: 'donut',
      
    },
    plotOptions: {
      pie: {
        startAngle: -90,
        endAngle: 270,
      },
    },
    dataLabels: {
      enabled: false,
    },
    fill: {
      type: 'gradient',
    },
    legend: {
      formatter: function (val, opts) {
        return val + " - " + opts.w.globals.series[opts.seriesIndex];
      },
    },
    labels: ["Project 1", "Project 2", "Project 3", "Project 4"],
    responsive: [
        {
          breakpoint: 480,
          options: {
            chart: {},
            legend: {
              position: 'bottom',
            },
          },
        },
      ],
  };

  const budget = [50000, 25000, 15000, 10000];






  const data = [
    {

      title: "Newest Outcomes",
      content: "Current therapies for Transthyretin amyloidosis (ATTR)  target the misfolded protein but do not address tissue damage by the already deposited amyloid. We have demonstrated that increased abundance of proteins within cardiac (and renal) amyloid plaques is associated with improved outcomes, which suggests that the amount of deposited proteins, may merely be a surrogate for indolent disease biology."
    },
    {
      title: "How do these differ?",
      content: "Current therapies for Transthyretin amyloidosis (ATTR)  target the misfolded protein but do not address tissue damage by the already deposited amyloid. We have demonstrated that increased abundance of proteins within cardiac (and renal) amyloid plaques is associated with improved outcomes, which suggests that the amount of deposited proteins, may merely be a surrogate for indolent disease biology."
    },
    {
      title: "Hints of High Impact",
      content: "In the Current therapies for Transthyretin amyloidosis (ATTR)  target the misfolded protein but do not address tissue damage by the already deposited amyloid. We have demonstrated that increased abundance of proteins within cardiac (and renal) amyloid plaques is associated with improved outcomes, which suggests that the amount of deposited proteins, may merely be a surrogate for indolent disease biology.last week 12 grants have been approved with the funding total of $2.3M.  amyloid plaques is associated with improved outcomes, which suggests that the amount of deposited proteins, may merely be a surrogate for indolent disease biology.last week 12 grants have been approved with the funding total of $2.3M.  for indolent disease biology.last week 12 grants have been approved with the funding total of $2.3M. for indolent disease biology.last week 12 grants have been approved"
    }
  ]


  return (
    <div className='wrapper'>
      <div className="layout-wrapper main-wrapper-body d-flex">
        <div className="main-content py-3">
          <div className='page-content'>
            <Container fluid>
              <div className='content-waplay'>
                <div className='content-box'>
                  <div style={{ display: "flex", flexDirection: "row", margin: "10px 0px" }}>
                    <img src={ArrowLeft} className='image-space'></img>

                    <div>
                      <h1 className='title-text'>Educational grant for the organization of the EMMA Vienna 2023 Meeting</h1>
                      <h1 className='span-text'>#90264655</h1>
                    </div>
                  </div>
                  <hr></hr>
                  <div>
                    <h1 className='header-text'>Gen AI Summary</h1>
                    {data.map((item) => (
                      <div>
                        <div style={{ display: "flex", flexDirection: "row", marginBottom: "15px" }}>
                          <img src={EllipseBlue} style={{ marginRight: "20px" }}></img>
                          <span className='header-text-blue'>{item.title}</span>
                        </div>
                        <p className='paragraph-text'>{item.content}</p>
                      </div>

                    ))}



                  </div>

                  <div style={{margin:"35px 0px"}}>
                    <Row>
                      <Col xs={12} md={4}>
                        <div className='border-style' style={{height:"300px"}}>
                          <h1 className='chart-heading'>Cost Metrics</h1>
                          <hr></hr>
                          <ReactApexChart options={options} series={budget} type="donut" />

                        </div>
                      </Col>
                      <Col xs={12} md={8}>
                        <div className='border-style' style={{height:"300px"}}>

                        <h1 className='chart-heading'> Publications</h1>
                          <hr></hr>
                          <Table responsive className='table-lits-wap-pground mb-0'>
                            <thead className="custom-table-header" >
                              <tr>
                                <th className='table-header-text' style={{color:"#667085"}}>Name of Publication<img src={downArrow} alt="downArrow" /></th>
                                <th className='table-header-text' style={{color:"#667085"}}>Journal <img src={downArrow} alt="downArrow" /></th>
                                <th className='table-header-text' style={{color:"#667085"}}>Description <img src={downArrow} alt="downArrow" /></th>
                                <th className='table-header-text' style={{color:"#667085"}}>Published Date<img src={downArrow} alt="downArrow" /></th>
                                <th className='table-header-text' style={{color:"#667085"}}>Published Time <img src={downArrow} alt="downArrow" /></th>

                              </tr>
                            </thead>
                            <tbody className='tbody-element--wp'>
                              <tr>
                                <td className='table-body-text'>Pfizer Grant</td>
                                <td className='table-body-text'>Newyork Times</td>
                                <td className='table-body-text'>Add royzman, Iren to the workflow on 21-09-2023</td>
                                <td className='table-body-text'>28 November 2023</td>
                                <td className='table-body-text'>11:26 AM EST</td>

                              </tr>
                              <tr>
                                <td className='table-body-text'>Pfizer Grant</td>
                                <td className='table-body-text'>Newyork Times</td>
                                <td className='table-body-text'>Add royzman, Iren to the workflow on 21-09-2023</td>
                                <td className='table-body-text'>28 November 2023</td>
                                <td className='table-body-text'>11:26 AM EST</td>

                              </tr>

                            </tbody>
                          </Table>
                        </div>
                      </Col>
                    </Row>



                  </div>
                </div>

              </div>
            </Container>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ImpactDetail;
