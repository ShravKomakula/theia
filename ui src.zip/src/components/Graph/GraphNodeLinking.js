import { Edge, MarkerType } from 'reactflow';

export const getEdgeObject = (id, source, sourceHandle, target, targetHandle, label, color='#fff') => {
    return {
        id: id,
        source: source,
        sourceHandle: sourceHandle,
        target: target,
        targetHandle: targetHandle,
        type: 'bezier',//smoothstep, bezier, straight, step
        markerEnd: {
          type: ''
        },
        label: label,
        updatable: 'target',
        // focusable: true,
        labelShowBg: true,
        position: { x: 0, y: 0 },
        animated: false,
        style: { stroke: color },
    }
}

export const graphNodeLinking = {
    'main': {
        'sourceHandles': [
            {id: 'main-source-payment'},
            {id: 'main-source-trialwork'}
        ],
        'targetHandles': [
            {id: 'main-target-medicalevent'},
            {id: 'main-target-speciality'},
            {id: 'main-target-scientificfocusarea'},
            {id: 'main-target-digitalreachfocusarea'},
            {id: 'main-target-association'},
            {id: 'main-target-publication'}
        ],
        'edges': []
    },
    // eslint-disable-next-line no-use-before-define
    'medicalevent': {'sourceHandles': [{id: 'main-source-medicalevent'}], 'targetHandles': [], 'edges': [getEdgeObject('main-medicalevent', 'medicalevent', 'main-source-medicalevent', 'main', 'main-target-medicalevent', 'Attended', '#D101E3')]},
    'speciality': {'sourceHandles': [{id: 'main-source-speciality'}], 'targetHandles': [], 'edges': [getEdgeObject('main-speciality', 'speciality', 'main-source-speciality', 'main', 'main-target-speciality', 'Has_Speciality', '#2B01BE')]},
    'scientificfocusarea': {'sourceHandles': [{id: 'main-source-scientificfocusarea'}], 'targetHandles': [], 'edges': [getEdgeObject('main-scientificfocusarea', 'scientificfocusarea', 'main-source-scientificfocusarea', 'main', 'main-target-scientificfocusarea', 'Has_Digital_Reach', '#01A7BE')]},
    'digitalreachfocusarea': {'sourceHandles': [{id: 'main-source-digitalreachfocusarea'}], 'targetHandles': [], 'edges': [getEdgeObject('main-digitalreachfocusarea', 'digitalreachfocusarea', 'main-source-digitalreachfocusarea', 'main', 'main-target-digitalreachfocusarea', 'Has_Digital_Reach', '#D01D68')]},
    'association': {'sourceHandles': [{id: 'main-source-association'}], 'targetHandles': [], 'edges': [getEdgeObject('main-association', 'association', 'main-source-association', 'main', 'main-target-association', 'Associated_IN', '#D0891D')]},
    'publication': {'sourceHandles': [{id: 'main-source-publication'}], 'targetHandles': [], 'edges': [getEdgeObject('main-publication', 'publication', 'main-source-publication', 'main', 'main-target-publication', 'Published', '#3DD706')]},
    'company': {'sourceHandles': [{id: 'company-source-payment'}], 'targetHandles': [], 'edges': [getEdgeObject('company-payment', 'company', 'company-source-payment', 'company', 'company-target-payment', 'Attended', '#D01D68')]},
    'payment': {'sourceHandles': [{id: 'payment-source-trial'}], 'targetHandles': [{id: 'company-target-payment'}, {id: 'main-target-payment'}], 
    'edges': [getEdgeObject('main-payment', 'main', 'main-source-payment', 'payment', 'main-target-payment', 'Received', '#B549DB'),
        getEdgeObject('company-payment', 'company', 'company-source-payment', 'payment', 'company-target-payment', 'Payed', '#B549DB')
    ]},
    'trial': {'sourceHandles': [{id: 'trial-source-trialwork'}], 'targetHandles': [{id: 'payment-target-trial'}], 'edges': 
        [getEdgeObject('payment-trial', 'payment', 'payment-source-trial', 'trial', 'payment-target-trial', 'Refers_to', '#733D0A')]},
    'trialwork': {'sourceHandles': [], 'targetHandles': [{id: 'main-target-trialwork'}, {id: 'trial-target-trialwork'}, {id: 'organization-target-trialwork'}],
    'edges': [
        getEdgeObject('trial-trialwork', 'trial', 'trial-source-trialwork', 'trialwork', 'trial-target-trialwork', 'Executed', '#10BE75'),
        getEdgeObject('main-trialwork', 'main', 'main-source-trialwork', 'trialwork', 'main-target-trialwork', 'Conducted', '#10BE75')
    ]},
    'organization': {'sourceHandles': [{id: 'organization-source-location'}, {id: 'organization-source-trialwork'}], 'targetHandles': [],
    'edges': [getEdgeObject('organization-trialwork', 'organization', 'organization-source-trialwork', 'trialwork', 'organization-target-trialwork', 'Conducted at', '#D01D68'),
    getEdgeObject('organization-location', 'organization', 'organization-source-location', 'location', 'organization-target-location', 'Located at', '#D01D68')
    ]},
    'location': {'sourceHandles': [{id: 'location-source-country'}], 'targetHandles': [{id: 'organization-target-location'}],
    'edges': [getEdgeObject('location-country', 'location', 'location-source-country', 'country', 'location-target-country', 'Located In', '#D01D68')]},
    'country': {'sourceHandles': [], 'targetHandles': [{id: 'location-target-country'}]},
}