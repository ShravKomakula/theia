import React, { useEffect, useMemo, useState, useCallback } from 'react'
import {
    Container, Grid, Flex, Card, Image,
    Text, Group, Button,
    TextInput, Popover, Stack, Checkbox, LoadingOverlay,
    MultiSelect
} from '@mantine/core';
import styled from '@emotion/styled'
import { getGraphDataCount, getNodeProperty } from '../../services/DashboardService'
import vectorSvg from '../../assets/svg/Vector.svg'
import ReactFlow, {
    Controls,
    Background,
    BackgroundVariant,
    MiniMap,
    useNodesState,
    useEdgesState,
    MarkerType,
    useReactFlow
} from 'reactflow';

import ElkNode from './ReactFlowGraph/ElkNode';
import useLayoutNodes from './ReactFlowGraph/useLayoutNodes';
import NodeProperty from './NodeProperty';
import { graphNodeLinking } from './GraphNodeLinking'
import 'reactflow/dist/style.css';
import './ReactFlowGraph/index.css'
import SummaryDetail from './SummaryDetail';

const StyleSearchBarBox = styled(Card.Section)`
    /* height: 90px; */
    /* display: flex; */
    background: linear-gradient(90deg, rgba(43, 1, 190, 0.05) 0%, rgba(1, 144, 255, 0.05) 100%);
    .goback-text {
        font-family: Product Sans;
        font-size: 16px;
        font-weight: 400;
        line-height: 24px;
        text-align: center;
        color: #16161699;
    }
    .flex {
        align-items: center;
        justify: center;
        align: center
        direction: row
        wrap: wrap
    }
    .filter-selection {
        width: auto;
        padding: 8px;
        /* gap: 40px; */
        border-radius: 8px;
        border: 1px;
        display: flex;
        justify: space-between;
        align-content: space-between;
        flex-flow: row wrap;
        opacity: 10px;
        background: #FFFFFF;
        border: 1px solid #0000001A
    }
    .text-filter {
        font-family: Product Sans;
        font-size: 14px;
        font-weight: 400;
        color: #00000099;
    }
    .text-filter-clear {
        font-family: Product Sans;
        font-size: 16px;
        font-weight: 400;
        line-height: 20px;
        text-align: center;
        color: #0190FF;
    }
`

const StyleSearchInput = styled(TextInput)`
    width: 550px;
    border-radius: 12px;
    border: 1px;
    opacity: 0px;
`

const graphNodeLabel = {
    'publication': {'node': 'Publication', 'edge': 'Published', 'color': '#3DD706'},
    'association': {'node': 'Association', 'edge': 'Associated_IN', 'color': '#D0891D'},
    'digitalreachfocusarea': {'node': 'Digital Reach Focus Area', 'edge': 'Has_Digital_Reach', 'color': '#D01D68'},
    'scientificfocusarea': {'node': 'Scientific Focus Area', 'edge': 'Has_Digital_Reach', 'color': '#01A7BE'},
    'speciality': {'node': 'Speciality', 'edge': 'Has_Speciality', 'color': '#2B01BE'},
    'medicalevent': {'node': 'Medical Event', 'edge': 'Attended', 'color': '#D101E3'},
    'company': {'node': 'Company', 'edge': 'Payed', 'color': '#D01D68'},
    'payment': {'node': 'Payment', 'edge': 'Received', 'color': '#B549DB'},
    'trial': {'node': 'Trial', 'edge': 'Refers_to', 'color': '#733D0A'},
    'trialwork': {'node': 'Trial Work', 'edge': 'Executed', 'color': '#10BE75'},
    'organization': {'node': 'Organization', 'edge': 'Conducted at', 'color': '#D01D68'},
    'location': {'node': 'Location', 'edge': 'Located at', 'color': '#D01D68'},
    'country': {'node': 'Country', 'edge': 'Located In', 'color': '#D01D68'},
}

const graphNodeStyle = (color='#2B01BE', height='40px') => {
    return {
        // padding: '13.17px',
        // gap: '13.17px',
        fontFamily: 'Product Sans',
        fontWeight: 400,
        fontSize: '16.46px',
        borderRadius: '6.58px',
        border: 'rgba(0, 0, 0, 0.1)',
        stroke: '#fff', 
        color: color,
        alignContent: 'center',
        height: height,
        borderColor: '#0041d0',
        backgroundColor: 'rgba(255, 255, 255, 1)', 
        boxShadow: '0px 3.29px 13.17px 0px #0000001A'
    }
}

// const scientistsName = 'Felicia Cosman';

const GraphUI = (props) => {
    const { scientistsName, setSelectedGraphUser } = props;

    const { fitView } = useReactFlow();
    const [graphCntQryData, setGraphCntQryData] = useState({});
    const [visibleLoader, setVisibleLoader] = useState(false);
    const [nodes, setNodes, onNodesChange] = useNodesState([]);
    const [edges, setEdges, onEdgesChange] = useEdgesState([]);
    const [isSidebarOpen, setIsSidebarOpen] = useState(false);
    const [selectedFilters, setSelectedFilters] = useState([]);
    const [filteredNodes, setFilteredNodes] = useState([]);
    const [filterGraphLinkingNode, setFilterGraphLinkingNode] = useState({})
    const [selectedFilterCount, setSelectedFilterCount] = useState(0);
    const [selectedNodeProperty, setSelectedNodeProperty] = useState([]);
    const [selectedNode, setSelectedNode] = useState({});
    const proOptions = { hideAttribution: true };

    useEffect(() => {
        return () => {
            setSelectedGraphUser(null);
        }
    }, [])

    useEffect(() => {
        setVisibleLoader(true);
        const resp = getGraphDataCount(scientistsName);
        resp.then((resp) => {
            if (resp && resp.results && resp.results[0]?.data.length > 0) {
                setGraphCntQryData(resp.results[0].data[0]['row'][0]);
                setVisibleLoader(false);
            } else {
                setVisibleLoader(false);
            }
        })
    }, [])

    useEffect(() => {
        if(filteredNodes.length > 0) {
            let newFilterLinking = {};
            for(const [key, value] of Object.entries(graphNodeLinking)) {
                // if(key === 'main') {
                //     newFilterLinking[key] = value;
                //     continue;
                // }
                let linkingObj = {
                    'sourceHandles':[],
                    'targetHandles': [],
                    'edges': [] 
                }
                if(value['sourceHandles'] && value['sourceHandles'].length > 0) {
                    linkingObj['sourceHandles'] = value['sourceHandles'].filter((obj) => {
                        return filteredNodes.some(substring=>obj['id'].includes(substring));
                    });
                }
                if(value['targetHandles'] && value['targetHandles'].length > 0) {
                    linkingObj['targetHandles'] = value['targetHandles'].filter((obj) => {
                        return filteredNodes.some(substring=>obj['id'].includes(substring));
                    });
                }
                if(value['edges'] && value['edges'].length > 0) {
                    linkingObj['edges'] = value['edges'].filter((obj) => {
                        return filteredNodes.some(substring=>obj['id'].includes(substring));
                    });
                }
                newFilterLinking[key] = linkingObj;
            }
            setFilterGraphLinkingNode(newFilterLinking);
        } else {
            setFilterGraphLinkingNode(graphNodeLinking);
        }
    }, [filteredNodes])
    // console.log(filteredNodes, 'filteredNodes');
    useEffect(() => {
        if(Object.keys(graphCntQryData).length > 0) {
            let graphNodes = [];
            let graphEdges = [];
            let cnt = 0;
            for(const [key, value] of Object.entries(graphNodeLabel)) {
                if(filteredNodes.length > 0 && !filteredNodes.includes(key)) {
                    continue;
                }
                graphNodes[cnt] = {
                    id: key,
                    data: {
                      label: `${value['node']}(${graphCntQryData[key] ?? 0})`,
                      // we need unique ids for the handles (called 'ports' in elkjs) for the layouting
                      // an id is structured like: nodeid-source/target-id
                      sourceHandles: filterGraphLinkingNode[key]['sourceHandles'],
                      targetHandles: filterGraphLinkingNode[key]['targetHandles'],
                    },
                    position: { x: 0, y: 0 },
                    type: 'elk',
                    // sourcePosition: 'left',
                    style: graphNodeStyle(graphNodeLabel[key]['color']),
                }
                if(filterGraphLinkingNode[key]['edges']) {
                    Array.prototype.push.apply(graphEdges, filterGraphLinkingNode[key]['edges']);
                }
                cnt++;
            }
            setNodes([{
                id: 'main',
                data: {
                  label: `${scientistsName}`,
                  // we need unique ids for the handles (called 'ports' in elkjs) for the layouting
                  // an id is structured like: nodeid-source/target-id
                  sourceHandles: filterGraphLinkingNode['main']['sourceHandles'],
                  targetHandles: filterGraphLinkingNode['main']['targetHandles'],
                },
                position: { x: 0, y: 0 },
                type: 'elk',
                // sourcePosition: 'right',
                style: graphNodeStyle('#2B01BE', '70px'),
            }, ...graphNodes]);
            setEdges(graphEdges);
            // window.requestAnimationFrame(() => {
            //     fitView();
            // })
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [graphCntQryData, filterGraphLinkingNode])//filteredNodes

    useLayoutNodes();

    const nodeTypes = useMemo(
        () => ({
            elk: ElkNode,
        }),
        [],
    );

    const onNodeClick = (event, node) => {
        if(node.id === 'main') {
            setIsSidebarOpen(false);
            return;
        }
        setVisibleLoader(true);
        setSelectedNode(node);
        const resp = getNodeProperty(node.id, scientistsName);
        resp.then((resp) => {
            if (resp && resp.results && resp.results[0].data.length > 0) {
                setSelectedNodeProperty(resp.results[0]['data']);
                // toggleSidebar();
                setIsSidebarOpen(true);
                setVisibleLoader(false);
            } else {
                setVisibleLoader(false);
            }
        })
    };
    const onPaneClick = (event) => {};

    const toggleSidebar = () => {
        setIsSidebarOpen(!isSidebarOpen);
    };

    const handleFilterSelection = (event) => {
        if(event.target.checked) {
            setSelectedFilters([...selectedFilters, event.target.value]);
        } else {
            const newArr = selectedFilters.filter((filter) => filter !== event.target.value);
            setSelectedFilters(newArr);
        }
    };

    const handleResetFilter = () => {
        setSelectedFilters([]);
        setSelectedFilterCount(0);
    }

    const handleSearchSelection = (value) => {
        setFilteredNodes(value);
    }

    return (
        <Container fluid p={0}>
        <Grid>
            <Grid.Col span={9} style={{ height: '100vh' }}>
                <LoadingOverlay visible={visibleLoader} zIndex={1000} overlayProps={{ radius: "sm", blur: 2 }} />
                <Card withBorder shadow="sm" radius="md">
                    <StyleSearchBarBox withBorder inheritPadding py="xs">
                        {/* <Group className='group'> */}
                            <Flex
                                direction={{ base: 'column', sm: 'row' }}
                                gap={{ base: 'sm', sm: 'lg' }}
                                justify={{ sm: 'space-between' }}
                                className='flex'
                            >
                                <Text className='goback-text' onClick={() => {setSelectedGraphUser(null)}}>
                                    <Group>
                                    <Image
                                        src={vectorSvg}
                                        alt="Frame"
                                        // width={14}
                                        height={12}
                                    />
                                    Go Back
                                    </Group>
                                </Text>
                                <MultiSelect
                                    placeholder="Search Node"
                                    data={Object.keys(graphNodeLabel).map((nodeKey) => {
                                        return {value: nodeKey, label: graphNodeLabel[nodeKey]['node']}
                                    })}
                                    // data={[
                                    //     {value: 'company', label: 'Company'},
                                    //     {value: 'payment', label: 'Payment'},
                                    //     {value: 'trial', label: 'Trial'},
                                    //     {value: 'trialwork', label: 'Trial Work'},
                                    //     {value: 'organization', label: 'Organization'}
                                    // ]}
                                    defaultValue={[]}
                                    clearable
                                    searchable
                                    style={{width: '80%'}}
                                    onChange={(value) => handleSearchSelection(value)}
                                />
                                {/* <StyleSearchInput
                                    leftSectionPointerEvents="none"
                                    leftSection={''}
                                    placeholder="Search scientists"
                                /> */}
                                {/* <Group shadow="xs" className='filter-selection'>
                                    <Popover width={200} position="bottom" withArrow shadow="md">
                                        <Popover.Target>
                                            <Text className='text-filter'>Filters({selectedFilterCount})</Text>
                                        </Popover.Target>
                                        <Popover.Dropdown>
                                            <Card radius="md">
                                                <Card.Section py="xs">
                                                    Filters
                                                </Card.Section>
                                                <Stack>
                                                    { Object.keys(graphNodeLabel).map((nodeKey) => {
                                                        return (
                                                            <Checkbox defaultChecked={selectedFilters.includes(nodeKey)} onChange={handleFilterSelection} label={graphNodeLabel[nodeKey]['node']} value={nodeKey} />
                                                        )
                                                    })}
                                                    <Button type='button' variant='outline' onClick={() => {setSelectedFilterCount(selectedFilters.length); setFilteredNodes(selectedFilters);}}>Apply Filter</Button>
                                                </Stack>
                                            </Card>
                                        </Popover.Dropdown>
                                    </Popover>
                                    {selectedFilterCount === 0 ? <Text className='text-filter'>None</Text> : <Text className='text-filter-clear' onClick={() => handleResetFilter()}>Clear All</Text>}
                                </Group> */}
                            </Flex>
                        {/* </Group> */}
                    </StyleSearchBarBox>
                   <div className='genai-career-summary'>
                    <p></p>
                   </div>
                    <Card.Section mt="sm" style={{ height: '85vh' }}>
                        <ReactFlow
                            nodes={nodes}
                            edges={edges}
                            onNodesChange={onNodesChange}
                            onEdgesChange={onEdgesChange}
                            fitView
                            nodeTypes={nodeTypes}
                            style={{ background: '#ffff' }}
                            maxZoom={3.5}
                            // minZoom={0.7}
                            // connectionLineStyle={connectionLineStyle}
                            snapToGrid={true}
                            // snapGrid={snapGrid}
                            // defaultViewport={defaultViewport}
                            // attributionPosition="bottom-left"
                            onNodeClick={onNodeClick}
                            onPaneClick={onPaneClick}
                            // onConnect={onConnect}
                            proOptions={proOptions}
                        >
                            {/* <Background color="#f1f1f1" variant={BackgroundVariant.Cross} /> */}
                            <Controls />
                            {/* <MiniMap /> */}
                        </ReactFlow>
                    </Card.Section>
                </Card>
            </Grid.Col>
            <Grid.Col span={3}>
                { isSidebarOpen ?
                    <NodeProperty graphNodeLabel={graphNodeLabel} selectedNode={selectedNode} isOpen={isSidebarOpen} toggleSidebar={toggleSidebar} nodeProperty={selectedNodeProperty} />
                    :
                    <SummaryDetail scientistsName={scientistsName} />
                }
            </Grid.Col>
        </Grid>
        </Container>
    );
};

export default GraphUI;
