import React, { useEffect, useState } from 'react';
import {
    Flex, Card,
    Text, Group,
    Avatar,
    Input,
    Select,
    SimpleGrid,
    ScrollArea,
    LoadingOverlay
} from '@mantine/core';
import { getChartData, getRealtedScientists } from '../../services/DashboardService'
import ReactApexChart from 'react-apexcharts'
import styled from '@emotion/styled'
import ellipseSvg from '../../assets/svg/Ellipse.svg'
import SideBarChart from './SideBarChart';

const images = [
    ellipseSvg,
    ellipseSvg,
    ellipseSvg,
    ellipseSvg,
    ellipseSvg,
    ellipseSvg,
    ellipseSvg,
    ellipseSvg
];

const StyleRightSection = styled(Card)`
    .text-title {
        font-family: Product Sans;
        padding-top: 5px;
        font-size: 14px;
        font-weight: 400;
        color: #161616;
    }
    .text-desc {
        font-family: Product Sans;
        font-size: 14px;
        font-weight: 400;
        color: #16161680;
    }
    .text-payment-value {
        font-family: Product Sans;
        font-size: 14px;
        font-weight: 400;
        line-height: 24.26px;
        text-align: left;
        color: #344BFD;
    }
    .text-initiatives {
        font-family: Product Sans;
        padding-top: 10px;
        font-size: 14px;
        font-weight: 400;
        color: #2B01BE;
    }
    .related-scientists {
        color: #2B01BE1A;
    }
`
const options = {
    series: [{
        data: []
    }],
    chart: {
        height: 350,
        type: 'bar',
        events: {
            click: function (chart, w, e) {
                // console.log(chart, w, e)
            }
        },
        toolbar: {
            show: false,
            tools: {
                download: false
            },
        }
    },
    //   colors: colors,
    plotOptions: {
        bar: {
            columnWidth: '45%',
            distributed: true,
        }
    },
    dataLabels: {
        enabled: false
    },
    legend: {
        show: false
    },
    xaxis: {
        categories: [],
        labels: {
            style: {
                // colors: colors,
                fontSize: '12px'
            }
        }
    },
    yaxis: {
        show: false,
        title: {
            text: '$ (thousands)'
        }
    },
}
const options1 = {
    chart: {
        type: 'bar',
        height: 150,
        //   columnWidth: '70%',
        stacked: false,
        toolbar: {
            show: false,
            tools: {
                download: false
            },
        },
    },
    legend: {
        show: false
    },
    plotOptions: {
        bar: {
            horizontal: false,
            // columnWidth: '70%',
            endingShape: 'rounded'
        },
    },
    dataLabels: {
        enabled: true
    },
    stroke: {
        show: true,
        width: 20,
        colors: ['transparent']
    },
    xaxis: {
        categories: [],
    },
    yaxis: {
        show: false,
        title: {
            text: '$ (thousands)'
        }
    },
    fill: {
        opacity: 1
    },
    tooltip: {
        show: false
        //   y: {
        //     formatter: function (val) {
        //       return "$ " + val + " thousands"
        //     }
        //   }
    }
}
const SummaryDetail = (props) => {
    const { scientistsName } = props;
    const [series, setSeries] = useState([]);
    const [chartData, setChartData] = useState([]);
    const [relatedScientists, setRelatedScientists] = useState([]);
    const [companyArr, setCompanyArr] = useState([]);
    const [totalPayment, setTotalPayment] = useState(0);
    const [selectedYear, setSelectedYear] = useState('2021');
    const [visibleLoader, setVisibleLoader] = useState(false);

    useEffect(() => {
        setVisibleLoader(true);
        const resp = getChartData(scientistsName, selectedYear);
        resp.then((resp) => {
            if (resp && resp.results && resp.results[0].data.length > 0) {
                let amountArr = [];
                let yearArr = [];
                let companyArr = [];
                let paymentSum = 0;
                let chartArr = [];
                resp.results[0]['data'].forEach((obj) => {
                    chartArr.push(
                        {
                            amount: obj['row'][0]['amount'],
                            year: obj['row'][0]['year'],
                            company_name: obj['row'][0]['company_name']
                        }
                    );
                    paymentSum = paymentSum + obj['row'][0]['amount'];
                    amountArr.push(obj['row'][0]['amount']);
                    yearArr.push(obj['row'][0]['year']);
                    companyArr.push(obj['row'][0]['company_name']);
                })
                setChartData(chartArr);
                setTotalPayment(paymentSum);
                // const chartDataArr = [{
                //     name: 'Amount',
                //     data: amountArr
                // }, {
                //     name: 'Year',
                //     data: yearArr
                // }, {
                //     name: 'Company Name',
                //     data: companyArr
                // }];
                setSeries(amountArr);
                setCompanyArr(companyArr);
                options.xaxis.categories = companyArr;
                setVisibleLoader(false);
            } else {
                setSeries([]);
                setVisibleLoader(false);
            }
        })
    }, [scientistsName, selectedYear])

    useEffect(() => {
        const resp = getRealtedScientists(scientistsName);
        resp.then((resp) => {
            if (resp && resp.results && resp.results[0].data.length > 0) {
                setRelatedScientists(resp.results[0].data);
            }
        })
    }, [scientistsName])
    return (
        <ScrollArea h={'100vh'} w={'fit-content'}>
            {/* <LoadingOverlay visible={visibleLoader} zIndex={1000} overlayProps={{ radius: "sm", blur: 2 }} /> */}
            <StyleRightSection withBorder shadow="sm" radius="md">
                <Card.Section withBorder inheritPadding py="xs">
                    <Group>
                        <Avatar radius="xl" />
                        <Text fw={500}>{scientistsName}</Text>
                    </Group>
                </Card.Section>
                <Text size="sm" className='text-title'>Career Summary</Text>
                <Text mt="5" c="dimmed" size="sm" className='text-desc' mb={'sm'}>
                    Career A dedicated and accomplished Medical Scientist with extensive experience in biomedical research and clinical laboratory investigations.
                </Text>
                <Card.Section withBorder inheritPadding py="xs">
                    <Group pb={10}>
                        <Text size="sm" className='text-title'>Total Engagements/Payments</Text>
                        <Text size="sm" className='text-payment-value'>{`${totalPayment}`}</Text>
                    </Group>
                    <Flex
                        direction={{ base: 'column', sm: 'row' }}
                    // gap={{ base: 'sm', sm: 'lg' }}
                    // justify={{ sm: 'center' }}
                    >
                        <Input placeholder={totalPayment} />
                        <Select
                            placeholder='Year'
                            value={selectedYear}
                            data={['2024', '2023', '2022', '2021', '2020', '2019', '2018', '2017']}
                            onChange={(value) => setSelectedYear(value)}
                        />
                    </Flex>
                    {/* <ReactApexChart options={options} series={series} type="bar" /> */}
                    <SideBarChart data={chartData} />
                </Card.Section>
                <Card.Section withBorder inheritPadding py="xs">
                    <Group pb={5}>
                        <Text size="sm" className='text-title'>Recent Pfizer Engagements/Initiatives</Text>
                    </Group>
                    <Card withBorder shadow="sm" radius="md">
                        <Card.Section withBorder inheritPadding py="xs">
                            <Text size="sm" className='text-title'>Grant Request 01</Text>
                        </Card.Section>
                        <Text size="sm" className='text-initiatives'>Finding payments of a scientist from 2023</Text>
                    </Card>
                </Card.Section>
                <Card.Section withBorder inheritPadding py="xs">
                    <Group pb={5}>
                        <Text size="sm" className='text-title'>Related Scientists</Text>
                    </Group>
                    <Card.Section inheritPadding mt="sm" pb="md">
                        <SimpleGrid cols={4} className='related-scientists'>
                            {relatedScientists.length > 0 && relatedScientists.map((image) => (
                                <Avatar radius="xl" >{image['row'][0]['name'].slice(0, 2)}</Avatar>
                            ))}
                        </SimpleGrid>
                    </Card.Section>
                </Card.Section>
            </StyleRightSection>
        </ScrollArea>
    )
}

export default SummaryDetail