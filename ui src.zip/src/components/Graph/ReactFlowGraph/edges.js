import { Edge, MarkerType } from 'reactflow';

export const edges = [
  {
    id: 'a-b',
    source: 'a',
    sourceHandle: 'a-s-a',
    target: 'b',
    targetHandle: 'b-t-a',
    type: 'smoothstep',
    markerEnd: {
      type: MarkerType.Arrow,
    },
    label: 'Published',
    updatable: 'source',
    // position: { x: 300, y: 50 },
    // animated: true,
    // style: { stroke: '#fff' },
  },
  {
    id: 'a-c',
    source: 'a',
    sourceHandle: 'a-s-c',
    target: 'c',
    targetHandle: 'c-t-c',
    type: 'smoothstep',
    markerEnd: {
      type: MarkerType.Arrow,
    },
    label: 'Associated_IN',
    style: { border: '1px solid #777', padding: 10 },
  },
  {
    id: 'a-d',
    source: 'a',
    sourceHandle: 'a-s-b',
    target: 'd',
    targetHandle: 'd-t-b',
    type: 'smoothstep',
    markerEnd: {
      type: MarkerType.Arrow,
    },
    label: 'Published',
  },
  {
    id: 'b-e',
    source: 'b',
    sourceHandle: 'b-s-a',
    target: 'e',
    targetHandle: 'e-t-a',
    type: 'smoothstep',
    markerEnd: {
      type: MarkerType.Arrow,
    },
    label: 'Associated_IN',
  },
  {
    id: 'd-e',
    source: 'd',
    sourceHandle: 'd-s-a',
    target: 'e',
    targetHandle: 'e-t-a',
    type: 'smoothstep',
    markerEnd: {
      type: MarkerType.Arrow,
    },
    label: 'Has_Specialty',
  },
  {
    id: 'e-f',
    source: 'e',
    sourceHandle: 'e-s-a',
    target: 'f',
    targetHandle: 'f-t-b',
    type: 'smoothstep',
    markerEnd: {
      type: MarkerType.Arrow,
    },
    label: 'Attended',
  },
  {
    id: 'e-g',
    source: 'e',
    sourceHandle: 'e-s-a',
    target: 'g',
    targetHandle: 'g-t-a',
    type: 'smoothstep',
    markerEnd: {
      type: MarkerType.Arrow,
    },
    label: 'Received',
  },
];
