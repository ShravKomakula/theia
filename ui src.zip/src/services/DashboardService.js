import axiosInstance from "./AxiosInstance";

export const apiRequest = async (request) => {
    // let localStorageDetails = localStorage.getItem('user');
    // localStorageDetails = JSON.parse(localStorageDetails);
    // if(localStorageDetails && localStorageDetails.loginType === 'SSO') {
    //   const respValidateTokenReq = validateAuthTokenRequest({token: localStorageDetails.tokenInfo.access_token});
    //   respValidateTokenReq.then((respToken) => {
    //     if(respToken.status !== 200) {
    //       localStorage.clear();
    //       window.location.reload();
    //     }
    //   });
    // }
    return await axiosInstance.post('', request).then((result) => {
        return result.data;
    }).catch((err) => {
        if (err.response) {
            return err.response;
        }
        return [];
    });
}

export const getGraphDataCount = async (name) => {
    return await apiRequest({
        "statements": [
            {
                "statement": `MATCH (se:ScientificExpert) WHERE se.name='${name}' WITH [(se)-[:CONDUCTED]->(tw:TrialWork)<-[:CONDUCTED]-(org:Organization)|org.facility_golden_id] as org,[(se)-[:CONDUCTED]->(tw:TrialWork)<-[:CONDUCTED]-(org:Organization)-[:LOCATED_AT]->(loc:Location)|loc.location_id] as loc,[(se)-[:CONDUCTED]->(tw:TrialWork)<-[:CONDUCTED]-(org:Organization)-[:LOCATED_AT]->(loc:Location)-[:LOCATED_IN]->(cy:Country)|cy.country_id] as cy,[(se)-[:CONDUCTED]->(tw:TrialWork)<-[:EXECUTED]-(tl:Trial)|tl.trial_id] as tl,[(se)-[:CONDUCTED]->(tw:TrialWork)|tw.trial_work_id] as tw,[(se)-[:PUBLISHED]->(pn:Publication)|pn.publication_id] as pn,[(se)-[:ASSOCIATED_IN]->(an:Association)|an.association_id] as an,[(se)-[:HAS_DIGITAL_REACH]->(da:DigitalReachFocusArea)|da.focus_name] as da,[(se)-[:HAS_FOCUS_AREA]->(sfa:ScientificFocusArea)|sfa.focus_name] as sfa,[(se)-[:HAS_SPECIALTY]->(sy:Specialty)|sy.specialty_id] as sy,
                [(se)-[:ATTENDED]->(me:MedicalEvent)|me.medical_event_id] as me,[(se)-[:RECEIVED]->(pt:Payment)<-[:PAYED]-(cm:Company)|cm.company_id] as cm,[(se)-[:RECEIVED]->(pt:Payment)|pt.payment_id] as pt 
                RETURN 
                {organization:size(apoc.coll.toSet(org)),trialwork:size(apoc.coll.toSet(tw)),
                publication:size(apoc.coll.toSet(pn)),association:size(apoc.coll.toSet(an)),
                digitalreachfocusarea:size(apoc.coll.toSet(da)),
                scientificfocusarea:size(apoc.coll.toSet(sfa)),speciality:size(apoc.coll.toSet(sy)),
                medicalevent:size(apoc.coll.toSet(me)),company:size(apoc.coll.toSet(cm)),
                payment:size(apoc.coll.toSet(pt)),trail:size(apoc.coll.toSet(tl)),location:size(apoc.coll.toSet(loc)),
                country:size(apoc.coll.toSet(cy))} as data`
            }
        ]
    });
}

export const getNodeProperty = (type, name) => {
    switch (type) {
        case 'publication':
            return getPublication(name);
        case 'association':
            return getAssociation(name);
        case 'digitalreachfocusarea':
            return getDigitalReachFocusArea(name);
        case 'scientificfocusarea':
            return getScientificFocusArea(name);
        case 'speciality':
            return getSpeciality(name);
        case 'medicalevent':
            return getMedicalEvent(name);
        case 'company':
            return getCompany(name);
        case 'payment':
            return getPayment(name);
        case 'organization':
            return getOrganization(name);
        case 'trial':
            return getTrial(name);
        case 'trialwork':
            return getTrialWork(name);
        case 'country':
            return getCountry(name);
        case 'location':
            return getLocation(name);
        default:
            return false;
    }
}

export const getRealtedScientists = async (name) => {
    return await apiRequest({
        "statements": [
            {
                "statement": `MATCH (se:ScientificExpert) WHERE se.name='${name}' MATCH 
                (se)-[:HAS_DIGITAL_REACH]->(da:DigitalReachFocusArea) 
                MATCH (se)-[:CONDUCTED]->(tw:TrialWork)<-[:CONDUCTED]-(org:Organization)-[:LOCATED_AT]->(loc:Location) 
                CALL { WITH se,da,loc  MATCH (se1:ScientificExpert) WHERE se.name<>se1.name  
                    MATCH (se1)-[:HAS_DIGITAL_REACH]->(dfa:DigitalReachFocusArea) WHERE dfa.focus_name = da.focus_name 
                    MATCH (se1)-[:CONDUCTED]->(twk:TrialWork)<-[:CONDUCTED]-(orgn:Organization)-[:LOCATED_AT]->(ln:Location) 
                    WHERE ln.location_id=loc.location_id RETURN se1  AS scex} RETURN DISTINCT {name:scex.name} as name LIMIT 8`
            }
        ]
    });
}

export const getChartData = async (name, year) => {
    return await apiRequest({
        "statements": [
            {
                "statement": `MATCH (se:ScientificExpert) WHERE se.name='${name}'  MATCH 
                (se)-[:RECEIVED]->(pt:Payment) WHERE date(pt.payment_date).year=${year} MATCH (cm:Company)-[:PAYED]->(pt) WITH cm.company_name as name,
                date(pt.payment_date).year as year,toInteger(SUM(pt.amount)) as amount ORDER BY year 
                RETURN {company_name:name,year:year,amount:amount}`
            }
        ]
    });
}

export const getPublication = async (name) => {
    return await apiRequest({
        "statements": [
            {
                "statement": `MATCH (se:ScientificExpert) WHERE se.name='${name}'
            MATCH (se)-[:PUBLISHED]->(pn:Publication)
            RETURN DISTINCT {
              date:pn.date,
              publication_id:pn.publication_id,
              journal: pn.journal,
              title:pn.title
            } AS publication`
            }
        ]
    });
}

export const getAssociation = async (name) => {
    return await apiRequest({
        "statements": [
            {
                "statement": `MATCH (se:ScientificExpert) WHERE se.name='${name}'
            MATCH (se)-[:ASSOCIATED_IN]->(an:Association)
            RETURN DISTINCT {
              association_name: an.association_name,
              association_type: an.association_type,
              association_id:an.association_id
            } AS association`
            }
        ]
    });
}

export const getOrganization = async (name) => {
    return await apiRequest({
        "statements": [
            {
                "statement": `MATCH (se:ScientificExpert) 
                WHERE se.name='${name}'
                MATCH (se)-[:CONDUCTED]->(tw:TrialWork)<-[:CONDUCTED]-(org:Organization)
                RETURN DISTINCT {
                facility_citeline_id:org.facility_citeline_id,
                facility_golden_id: org.facility_golden_id,
                facility_name:org.facility_name
                } AS organization`
            }
        ]
    });
}

export const getDigitalReachFocusArea = async (name) => {
    return await apiRequest({
        "statements": [
            {
                "statement": `MATCH (se:ScientificExpert) WHERE se.name='${name}'
                OPTIONAL MATCH (se)-[:HAS_DIGITAL_REACH]->(da:DigitalReachFocusArea)
                RETURN DISTINCT {focus_name: da.focus_name} AS digitalreachfocusarea`
            }
        ]
    });
}

export const getScientificFocusArea = async (name) => {
    return await apiRequest({
        "statements": [
            {
                "statement": `MATCH (se:ScientificExpert) WHERE se.name='${name}'
                MATCH (se)-[:HAS_FOCUS_AREA]->(sfa:ScientificFocusArea)
                RETURN DISTINCT {
                  focus_type: sfa.focus_type,
                  focus_name: sfa.focus_name
                } AS scientificfocusarea`
            }
        ]
    });
}

export const getSpeciality = async (name) => {
    return await apiRequest({
        "statements": [
            {
                "statement": `MATCH (se:ScientificExpert) WHERE se.name='${name}'
                MATCH (se)-[:HAS_SPECIALTY]->(sy:Specialty)
                RETURN DISTINCT{
                  specialty: sy.specialty,
                  specialty_id: sy.specialty_id
                } AS specialty`
            }
        ]
    });
}

export const getMedicalEvent = async (name) => {
    return await apiRequest({
        "statements": [
            {
                "statement": `MATCH (se:ScientificExpert) WHERE se.name='${name}'
                MATCH (se)-[:ATTENDED]->(me:MedicalEvent)
                RETURN DISTINCT {
                  city_name: me.city_name,
                  medical_event_id: me.medical_event_id,
                  event_type: me.event_type,
                  name: me.name,
                  country_name: me.country_name,
                  start_date: me.start_date
                } as medicalevent`
            }
        ]
    });
}

export const getCompany = async (name) => {
    return await apiRequest({
        "statements": [
            {
                "statement": `MATCH (se:ScientificExpert) WHERE se.name='${name}'
                MATCH (se)-[:RECEIVED]->(pt:Payment)<-[:PAYED]-(cm:Company)
                RETURN DISTINCT {
                  company_id: cm.company_id,
                  company_name: cm.company_name
                } AS company`
            }
        ]
    });
}

export const getPayment = async (name) => {
    return await apiRequest({
        "statements": [
            {
                "statement": `MATCH (se:ScientificExpert) WHERE se.name='${name}'
                MATCH (se)-[:RECEIVED]->(pt:Payment)
                MATCH (cm:Company)-[:PAYED]->(pt)
                RETURN DISTINCT {
                  amount: pt.amount,
                  number_of_payments: pt.number_of_payments,
                  payment_id: pt.payment_id,
                  nature_of_payment: pt.nature_of_payment,
                  currency: pt.currency,
                  details: pt.details,
                  type: pt.type,
                  payment_date: pt.payment_date
                } AS payment`
            }
        ]
    });
}

export const getTrial = async (name) => {
    return await apiRequest({
        "statements": [
            {
                "statement": `MATCH (se:ScientificExpert) WHERE se.name='${name}'
                MATCH (se)-[:RECEIVED]->(pt:Payment)
                MATCH (pt)-[:REFERS_TO]->(tl:Trial)
                RETURN DISTINCT {
                  phase: tl.phase,
                  study_title: tl.study_title,
                  trial_id: tl.trial_id
                } AS trial LIMIT 25`
            }
        ]
    });
}

export const getTrialWork = async (name) => {
    return await apiRequest({
        "statements": [
            {
                "statement": `MATCH (se:ScientificExpert) WHERE se.name='${name}'
                MATCH (se)-[:CONDUCTED]->(tw:TrialWork)
                RETURN DISTINCT {
                  trial_work_id: tw.trial_work_id,
                  site_status: tw.site_status,
                  nr_enrolled: tw.nr_enrolled,
                  psm:tw.psm
                } AS trialwork LIMIT 25`
            }
        ]
    });
}

export const getLocation = async (name) => {
    return await apiRequest({
        "statements": [
            {
                "statement": `MATCH (se:ScientificExpert) 
                WHERE se.name='${name}'
                MATCH (se)-[:CONDUCTED]->(tw:TrialWork)<-[:CONDUCTED]-(org:Organization)
                MATCH (org)-[:LOCATED_AT]->(loc:Location)
                RETURN DISTINCT {
                  address: loc.address,
                  city: loc.city,
                  state: loc.state,
                  location_id: loc.location_id
                } AS location`
            }
        ]
    });
}

export const getCountry = async (name) => {
    return await apiRequest({
        "statements": [
            {
                "statement": `MATCH (se:ScientificExpert) 
                WHERE se.name='${name}'
                MATCH (se)-[:CONDUCTED]->(tw:TrialWork)<-[:CONDUCTED]-(org:Organization)
                MATCH (org)-[:LOCATED_AT]->(loc:Location)-[:LOCATED_IN]->(cy:Country)
                RETURN DISTINCT {
                  country: cy.country,
                  country_id: cy.country_id
                } AS country`
            }
        ]
    });
}
