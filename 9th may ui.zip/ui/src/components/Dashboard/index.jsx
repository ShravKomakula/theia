import React, { useState } from "react";
import "./Dashboard.css"; // Assuming you have a CSS file for styling
import { FiUsers } from "react-icons/fi"; // Assuming you're using React Icons library
import { HiArrowTrendingUp } from "react-icons/hi2";
import icon1 from "../../assets/icon1.svg";
import icon2 from "../../assets/icon2.svg";
import icon3 from "../../assets/icon3.svg";
import icon4 from "../../assets/icon4.svg";
import icon5 from "../../assets/icon5.svg";
import icon6 from "../../assets/icon6.svg";
import MapWithAutocomplete from "./Map";
function Dashboard() {
  const [grantedViewActive, setGrantedViewActive] = useState(false);
  const [allViewActive, setAllViewActive] = useState(false);

  const handleGrantedViewClick = () => {
    setGrantedViewActive(true);
    setAllViewActive(false);
  };

  const handleAllViewClick = () => {
    setGrantedViewActive(false);
    setAllViewActive(true);
  };

  return (
    <div className="Dashboard">
      <h4>Grants Dashboard</h4>
      <div className="card-section">
        <div className="cards-container">
          <div className="card card1">
            <div className="card-header">
              <span>Total Submissions</span>
              <img src={icon1} alt="icon1" width={30} height={30} />
            </div>
            <div className="card-content">
              <span>37,000</span>
              <div className="change">
                <span>
                  {" "}
                  <b>
                    <HiArrowTrendingUp size={20} /> &nbsp; 85%
                  </b>{" "}
                  Up from yesterday
                </span>
              </div>
            </div>
          </div>
          <div className="card card1">
            <div className="card-header">
              <span>Approvals</span>
              <img src={icon2} alt="icon2" width={30} height={30} />
            </div>
            <div className="card-content">
              <span>37,000</span>
              <div className="change">
                <span>
                  {" "}
                  <b>
                    <HiArrowTrendingUp size={20} /> &nbsp; 85%
                  </b>{" "}
                  Up from yesterday
                </span>
              </div>
            </div>
          </div>
          <div className="card card1">
            <div className="card-header">
              <span>Total Granted</span>
              <img src={icon3} alt="icon3" width={30} height={30} />
            </div>
            <div className="card-content">
              <span>37,000</span>
              <div className="change">
                <span>
                  {" "}
                  <b>
                    <HiArrowTrendingUp size={20} /> &nbsp; 85%
                  </b>{" "}
                  Up from yesterday
                </span>
              </div>
            </div>
          </div>
          <div className="card card1">
            <div className="card-header">
              <span>HCP Impacted</span>
              <img src={icon4} alt="icon4" width={30} height={30} />
            </div>
            <div className="card-content">
              <span>37,000</span>
              <div className="change">
                <span>
                  {" "}
                  <b>
                    <HiArrowTrendingUp size={20} /> &nbsp; 85%
                  </b>{" "}
                  Up from yesterday
                </span>
              </div>
            </div>
          </div>
          <div className="card card1">
            <div className="card-header">
              <span>Patients Impacted</span>
              <img src={icon5} alt="icon5" width={30} height={30} />
            </div>
            <div className="card-content">
              <span>37,000</span>
              <div className="change">
                <span>
                  {" "}
                  <b>
                    <HiArrowTrendingUp size={20} /> &nbsp; 85%
                  </b>{" "}
                  Up from yesterday
                </span>
              </div>
            </div>
          </div>
          <div className="card card1">
            <div className="card-header">
              <span>Learners Imapcted</span>
              <img src={icon6} alt="icon6" width={30} height={30} />
            </div>
            <div className="card-content">
              <span>37,000</span>
              <div className="change">
                <span>
                  {" "}
                  <b>
                    <HiArrowTrendingUp size={20} /> &nbsp; 85%
                  </b>{" "}
                  Up from yesterday
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="section1">
        <div className="buttons-section">
          <button
            type="button"
            className="btn recommendedview"
            onClick={handleGrantedViewClick}
          >
            Recommended View
          </button>
          <button
            type="button"
            className="btn allview"
            onClick={handleAllViewClick}
          >
            All View
          </button>
          <div className="inputsection">
            <input
              type="text"
              className="search-input input"
              placeholder="Search.."
            />
            <button type="button" className="btn filter-btn">
              Filter(0) None
            </button>
          </div>
          <div className="section2">
            <div className="leftcontainer card2">
              <h6>Summary</h6>
              <div className="summary">
                <div className="card summarycard">
                  <span>Country</span>
                </div>
                <div className="card summarycard">
                  <span>Location</span>
                </div>
                <div className="card summarycard">
                  <span>User</span>
                </div>
              </div>
              <div className="blog">
                <p>With this change, the map should now occupy only 50% of the container's width. Make sure to apply this updated CSS to your Dashboard component. If the map still doesn't display within 50% of the container, ensure there are no conflicting styles overriding this setting.</p>
              </div>
            </div>
            <div className="rightContainer card2">
              <MapWithAutocomplete />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;
