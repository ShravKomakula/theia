import React, { useState, useEffect } from "react";
import { toast } from "react-toastify";
import "./../MyDashboard/MyDashboard.css";
import search from "../../assets/images/Vector (3).svg";
import { Geo, MapMarker } from "@aws-amplify/geo";
import Select, { components } from "react-select";
import LoadingSpinner from "./LoadingSpinner";
import refreshIcon from "../../assets/images/Refresh.svg";
import funnelSimpleWhite from "../../assets/images/FunnelSimple.svg";
import Ellipse from "../../assets/images/Ellipse.svg";
import eyeIconClose from "../../assets/images/closeEye.png";
import downloadSimple from "../../assets/images/DownloadSimple.svg";
import logo from "../../assets/images/Logo_3-removebg-preview 1 (1).svg";
import demoimg from "./../../assets/images/CaretCircleDoubleLeft.svg";
import signOut from "../../assets/images/SignOut.svg";
import imageTheia from "../../assets/images/theia.png";
import { default as ReactSelect } from "react-select";
import Footer from "../../common/Footer/Footer";
import { GiMedicines, GiSandsOfTime } from "react-icons/gi";
/* import { CircleLoader } from "react-awesome-loaders" */
import { useNavigate, Link } from "react-router-dom";
import { useAuth } from "../AuthContext";
import Card from "react-bootstrap/Card";
import Button from "react-bootstrap/Button";
import elipse from "../../assets/images/Ellipse 2.svg";
import { Tab, Nav, Col, Row, Pagination } from "react-bootstrap";
import DataTable from "react-data-table-component";
import { FaUserCheck, FaChevronCircleDown } from "react-icons/fa";
import home from "./../../assets/images/Rectangle 1494.svg";
import tower from "./../../assets/images/Rectangle 1494 (1).svg";
import rect from "./../../assets/images/Rectangle.svg";
import ashrect from "./../../assets/images/Rext.svg";
import gridwind from "./../../assets/images/GridFourwind.svg";
import tileviewimg from "./../../assets/images/Vector (1).svg";
import { FetchSnowFlakeData } from "../../common/api-config";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import { IoLocationSharp } from "react-icons/io5";
import { Icon, marker } from "leaflet";
import voicesearch from "./../../assets/images/voicesearch.png";
import Topbar from "../../common/Topbar";
import axios from "axios";
import { DataGrid } from '@mui/x-data-grid';
import MapComponents from "./MapComponents";
function MyDashboard(route, navigation) {
  const [selectedMarker, setSelectedMarker] = useState(null);

  const navigate = useNavigate();
  const [columnsView1, setColumns1] = useState([]);
  const [apiData, setApiData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [dropdownSelectedValue, setDropdownSelectedValue] = useState("");
  const [filteredTableData, setFilteredTableData] = useState(apiData);
  const [dropdownStatus, setDropdownStatus] = useState(false);
  const { logout } = useAuth();
  const [currentPage, setCurrentPage] = useState(1);
  const [columns, setColumns] = useState([]);
  const [rows, setRows] = useState([]);
  const [activeTab, setActiveTab] = useState('first');
  const apiKey =
    "v1.public.eyJqdGkiOiI3MDk3NDkyNi0wMzU0LTQ5YjEtYTQwYi05YWNiZDBmYmMyNzQifZdZ8zg6IC_6qRTZ6gCayyFESTbNKc7YIZeuttnCJ019QxGuhNvl9xqbuUDg598X5knyqNw1SQkYpuzFFfUUOVIBXHnHbJRfnyd2o1gpu5UFx0blFe1xvSNZxUAp4_fKfbiQo6zXsQ4stfTxbvCs7b0U5PuF7qOeYge6__YZgr6cNd56dpmIX2BuDKhl7uUYnTNAarOGx0fHX2jCUYiIeMflR359FIOiBhnL-5unP60nc0kikRMpIhfGGeCLqSDNBQY_FudDXMsXs3SnQ2cQyooH_tb4GgDTwHXmGGjU6724BISi5Jm34rZjL0FVk4a5HpFWuF7A_lNJs0XcsomrYBU.NjAyMWJkZWUtMGMyOS00NmRkLThjZTMtODEyOTkzZTUyMTBi";
  const mapName = "mymap01";
  const region = "us-east-2";
  const [question, setQuestion] = useState("");
  const [displayDropdown, setDisplayDropdown] = useState(false);
  const cardsPerPage = 12; // Number of cards to display per page
  const totalPages = Math.ceil(apiData.length / cardsPerPage);

  const indexOfLastCard = currentPage * cardsPerPage;
  const indexOfFirstCard = indexOfLastCard - cardsPerPage;
  const currentCards = apiData.slice(indexOfFirstCard, indexOfLastCard);
  const [isSummaryVisible, setIsSummaryVisible] = useState(false);

  const toggleSummary = () => {
    setIsSummaryVisible(!isSummaryVisible);
  };
  const paginate = (newPage) => {
    setCurrentPage(newPage);
    // Add any additional logic for handling pagination, e.g., fetching data for the new page.
  };
  const selectQuestion = (event) => {
    setQuestion(event.target.value);
  };

  const handleDropdownFocus = () => {
    setDisplayDropdown(true);
  };

  const handleDropdownBlur = () => {
    setDisplayDropdown(true);
  };

  const [activeKey, setActiveKey] = useState("first");
  const [markers, setMarkers] = useState([]);
  const customicon = new Icon({
    iconUrl: "https://cdn-icons-png.flaticon.com/256/684/684908.png",
    iconSize: [38, 38],
  });
  const { Option } = components;

// Function to format and set up data for the tile view
const setupTileViewData = (data) => {
  if (!data || !data.results || data.results.length === 0) {
    console.warn('No data provided for tile view setup.');
    return;
  }

  // Assuming columns are provided in the response
  const columnNames = data.columns;

  // Check if latitude and longitude columns exist
  const latitudeIndex = columnNames.indexOf('LATITUDE');
  const longitudeIndex = columnNames.indexOf('LONGITUDE');
  if (latitudeIndex === -1 || longitudeIndex === -1) {
    console.warn("Latitude or Longitude column not found.");
    return;
  }

  const tileViewData = data.results.map((item) => ({
    latitude: parseFloat(item[latitudeIndex]),
    longitude: parseFloat(item[longitudeIndex]),
    title: item[columnNames.indexOf('PROJECT_TITLE')],
    status: item[columnNames.indexOf('STATUS')],
  }));

  setupTileViewData(tileViewData);
};

useEffect(() => {
  const fetchData = async () => {
    try {
      const response = await axios.get(FetchSnowFlakeData(), {});
      const apiData = response.data.results;

      // Log the entire API response
      console.log("API Data:", apiData);

      if (!apiData || apiData.length === 0) {
        console.warn('Fetched data is empty or undefined.');
        return;
      }

      // Assuming columns are provided in the response
      const columnNames = response.data.columns;

      // Exclude specific columns (e.g., 'LATITUDE' and 'LONGITUDE')
      const excludedColumns = ['LATITUDE', 'LONGITUDE', 'LOGO_URL'];
      const filteredColumns = columnNames
        .filter((fieldName) => !excludedColumns.includes(fieldName))
        .map((fieldName) => ({
          field: fieldName,
          headerName: formatHeader(fieldName),
          width: 150,
        }));

      setColumns(filteredColumns);

      // Map data rows to match the columns
      const generatedRows = apiData.map((dataRow, index) => {
        const rowObject = {};
        filteredColumns.forEach((column, columnIndex) => {
          const columnName = column.field;
          const value = dataRow[columnIndex];

          try {
            if (columnName === 'APPROVED_AMOUNT' || columnName === 'PAYMENT_REMAINING') {
              // Format approved_amount and payment_remaining columns
              rowObject[columnName] = `$${parseFloat(value).toFixed(2)}`;
            } else if (columnName === 'LAST_UPDATE') {
              // Format date for LAST_UPDATE column
              rowObject[columnName] = new Date(value).toLocaleDateString('en-US');
            } else {
              rowObject[columnName] = value;
            }
          } catch (error) {
            console.error(`Error processing column ${columnName}:`, error);
            rowObject[columnName] = value; // If an error occurs, just use the original value
          }
        });

        return { id: index, ...rowObject };
      });

      setRows(generatedRows);
      setApiData(apiData);

      // Call setupTileViewData to format data for tile view
      setupTileViewData(response.data);

      // Filter out entries with invalid latitude or longitude
      const validMarkers = apiData
        .filter((item) => {
          const latitudeIndex = columnNames.indexOf('LATITUDE');
          const longitudeIndex = columnNames.indexOf('LONGITUDE');
          if (latitudeIndex === -1 || longitudeIndex === -1) {
            console.warn("Latitude or Longitude column not found.");
            return false;
          }
          const latitude = parseFloat(item[latitudeIndex]);
          const longitude = parseFloat(item[longitudeIndex]);

          if (isNaN(latitude) || isNaN(longitude)) {
            console.warn("Invalid Latitude or Longitude:", item);
            return false;
          }

          return true;
        })
        .map((item) => {
          const latitudeIndex = columnNames.indexOf('LATITUDE');
          const longitudeIndex = columnNames.indexOf('LONGITUDE');
          return {
            geocode: [parseFloat(item[latitudeIndex]), parseFloat(item[longitudeIndex])],
            popUp: item[0],
            requestId: item[0],
            title: item[1],
            remainingAmount: item[4],
            piName: item[7],
            approvedAmount: item[3],
            logo: item[15],
            nextMilestone: item[6],
          };
        });

      // Log the valid markers
      console.log("Valid Markers:", validMarkers);

      setMarkers(validMarkers);
      setLoading(false);
    } catch (error) {
      console.error("Error fetching data:", error);
      setError(error);
      setLoading(false);
    }
  };

  fetchData();
}, []);

const formatHeader = (header) => {
  const words = header.split('_');
  const formattedHeader = words
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
    .join(' '); // Replace underscores with space
  return <strong>{formattedHeader}</strong>;
};

  const renderUrlCell = (params) => (
    <a href={params.value} target="_blank" rel="noopener noreferrer">
      Open in Cyber Grants
    </a>
  );
 const convertToCsv = () => {
  // Extract column headers from the columns array
  const columnHeaders = columns.map((column) => column.field);

  // Initialize an array to store maximum widths for each column
  const maxWidths = Array(columnHeaders.length).fill(0);

  // Iterate through each row to measure the content width in each cell
  rows.forEach((row) => {
    columnHeaders.forEach((header, index) => {
      const cellContent = row[header];
      const cellWidth = cellContent ? cellContent.toString().length : 0;
      maxWidths[index] = Math.max(maxWidths[index], cellWidth);
    });
  });

  // Generate the CSV content with adjusted column widths
  const csvContent = [
    columnHeaders.map((header, index) => {
      // Adjust the width of each cell based on the maximum width of its column
      const cellValue = header.padEnd(maxWidths[index], ' ');
      // Encode special characters in the cell value
      return '"' + cellValue.replace(/"/g, '""') + '"';
    }).join(','), // Add column headers as the first row
    ...rows.map((row) =>
      columnHeaders
        .map((header, index) => {
          let cellValue = row[header];
          // Adjust the width of each cell based on the maximum width of its column
          cellValue = (cellValue || '').toString().padEnd(maxWidths[index], ' ');
          // Encode special characters in the cell value
          return '"' + cellValue.replace(/"/g, '""') + '"';
        })
        .join(','),
    ),
  ].join('\n');

  // Create a Blob containing the CSV content
  const blob = new Blob([csvContent], { type: 'text/csv' });

  // Create a temporary link element to trigger the download
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = 'datagrid.csv';
  link.click();
};

if (loading) {
  return <LoadingSpinner />;
}


  if (error) {
    return <p>Error fetching data: {error.message}</p>;
  }

  // Example: Custom logic to replace default titles

  return (
    <>
      <Topbar />
      <div
        className="d-flex flex-column justify-content-center align-items-center"
        style={{ backgroundColor: "#fff" }}
      >
        <div className="input-section d-flex flex-column mt-5 w-100 justify-content-center align-items-center">
          <div className="mt-5 position-relative">
          
          </div>
        </div>
        <div>
 <MapComponents />

        </div>
        <Tab.Container id="left-tabs-example" defaultActiveKey="first" activeKey={activeTab} onSelect={(key) => setActiveTab(key)}>
  <div className="rightalign ml-auto p-3">
            <Row style={{ marginRight: "20px" }}>
              <div className="navitem">
                <Nav variant="pills">
                  <Nav.Item>
                    <Nav.Link eventKey="first">
                      <img src={gridwind}></img>&nbsp; Tile
                    </Nav.Link>
                  </Nav.Item>

                  <Nav.Item>
                    <Nav.Link eventKey="second">
                      <img src={tileviewimg}></img>&nbsp; Grid
                    </Nav.Link>
                  </Nav.Item>
                  {activeTab === 'second' && ( // Render the download icon only when the grid view is active
            <Nav.Item>
              <Nav.Link>
                <img
                  src={downloadSimple}
                  style={{ cursor: "pointer", marginRight: "10px" }}
                  height="30px"
                  width="30px"
                  alt="Download Icon"
                  onClick={convertToCsv}
                />
              </Nav.Link>
            </Nav.Item>
          )}
        </Nav>
              
              </div>
            </Row>
          </div>
          <Row style={{ width: "100%", marginBottom: "20px" }}>
            <Tab.Content style={{ width: "100%" }}>
              <Tab.Pane eventKey="first">
                <Col className="col-12 col-lg-12">
                  <Row className="mx-0">
                    {selectedMarker && (
                      <Col
                        className="col-12  ps-0 pe-2 geocardstyles"
                        key={selectedMarker.popUp}
                      >
                        <Card
                          style={{
                            width: "100%",
                            padding: "10px",
                            borderRadius: "10px",
                            border: "none",
                            left: "-20%",
                          }}
                        >
                          <Card.Body
                            style={{
                              background: "#f2f2f2",
                              width: "80%",
                              borderRadius: "20px",
                            }}
                          >
                            {/* First Row */}
                            <div className="row align-items-center justify-content-between">
                              <div className="col-2">
                                <div
                                  style={{
                                    background: "lightgreen",
                                    padding: "5px",
                                    borderRadius: "5px",
                                    color: "white",
                                    textAlign: "center",
                                  }}
                                >
                                  ${selectedMarker.approvedAmount}
                                </div>
                              </div>
                              <div className="col-7">
                                <h6 className="strongText"> {selectedMarker.title}</h6>#
                                {selectedMarker.requestId}
                              </div>

                              <div className="col-2">
                                <IoLocationSharp size={20} />
                                Location
                              </div>
                              <div className="col-1">
                                <img
                                  src={selectedMarker.logo}
                                  alt="logo"
                                  className="logoImage"
                                  height={50}
                                  size={50}
                                />
                              </div>
                            </div>

                            {/* Second Row */}
                            <div className="row align-items-center justify-content-between">
                              <div className="col-2">
                              <span className="strongText">    Remaining Payment:</span> $
                                {selectedMarker.remainingAmount}
                              </div>
                              <div className="col-1">Reasearch</div>
                              <div className="col-2">
                                Proposal Type with Logo
                              </div>
                              <div className="col-2">Primary Area:</div>
                              <div className="col-2">
                                <GiMedicines size={20} /> Pfizer Drug:
                              </div>
                              <div className="col-2">
                                <GiSandsOfTime size={20} /> Duration:
                              </div>
                              <div className="col-1">
                              <span className="strongText">  PiName:</span>{selectedMarker.piName}
                              </div>
                            </div>

                            {/* Horizontal Line */}
                            <hr />

                            {/* Third Row */}
                            <div className="row align-items-center justify-content-between">
                              <div className="col-3">Study Design:</div>
                              <div className="col-4">Population:</div>
                              <div className="col-4">Patient Enroll:</div>
                              <div className="col-1">
                                <FaChevronCircleDown
                                  onClick={toggleSummary}
                                  style={{ cursor: "pointer" }}
                                />
                              </div>
                            </div>

                            {/* Horizontal Line */}
                            <hr />

                            {/* Fourth Row */}
                            <div className="row align-items-center justify-content-between">
                              <div className="col-4">Status Insight:</div>
                              <div className="col-4">Patient Insight:</div>
                              <div className="col-4">
                              <span className="strongText">   Next Milestone:</span> {selectedMarker.nextMilestone}
                              </div>
                              {/* Summary */}
                              {isSummaryVisible && (
                                <div className="row summary">
                                  <hr />
                                  <div className="col-12">
                                    <p>
                                      <b>Research Summary:</b> It seems like the
                                      reverse geocoding service might not be
                                      returning the expected data. Let's modify
                                      the code to log the response from the
                                      reverse geocoding service
                                    </p>
                                    <b>Outcomes Height:</b>
                                  </div>

                                  <div className="row col-12 ">
                                    <div className="col-3 button">
                                      <Button>Data Gaps</Button>
                                    </div>
                                    <div className="col-3 button">
                                      <Button>Health Equality</Button>
                                    </div>
                                    <div className="col-3 button">
                                      <Button>Digital Health & AI</Button>
                                    </div>
                                    <div className="col-3 button">
                                      <Button className="btn-success">
                                        Heigher Learners Reached
                                      </Button>
                                    </div>
                                  </div>
                                </div>
                              )}
                            </div>
                          </Card.Body>
                        </Card>
                      </Col>
                    )}
                    <br></br>
                    {currentCards.map((item, index) => (
                      <Col className="col-12  ps-0 pe-2" key={index}>
                        <Card
                          className="cardstyles"
                          style={{
                            width: "100%",
                            padding: "10px",
                            borderRadius: "10px",
                            border: "none",
                          }}
                        >
                          <Card.Body
                            style={{
                              background: "#f2f2f2",
                              width: "80%",
                              borderRadius: "20px",
                            }}
                          >
                            {/* Your existing content here */}

                            {/* First Row */}
                            <div className="row align-items-center justify-content-between">
                              <div className="col-2">
                                <div
                                  style={{
                                    background: "lightgreen",
                                    padding: "5px",
                                    borderRadius: "5px",
                                    color: "white",
                                    textAlign: "center",
                                  }}
                                >
                                  ${item[3]}
                                </div>
                              </div>
                              <div className="col-7">
                                <h6 className="strongText">{item[1]}</h6>#{item[0]}
                              </div>
                              <div className="col-2">
                                <IoLocationSharp size={20} />
                                Location
                              </div>
                              <div className="col-1">
                                <img
                                  src={item[15]}
                                  alt="logo"
                                  height={50}
                                  size={50}
                                />
                              </div>
                            </div>

                            {/* Second Row */}
                            <div className="row align-items-center justify-content-between">
                              <div className="col-2">
                              <span className="strongText"> Remaining Amount: $</span>{item[4]}
                              </div>
                              <div className="col-1">Reasearch</div>
                              <div className="col-2">
                                Proposal Type with Logo
                              </div>
                              <div className="col-2">Primary Area:</div>
                              <div className="col-2">
                                <GiMedicines size={20} /> Pfizer Drug:
                              </div>
                              <div className="col-2">
                                <GiSandsOfTime size={20} /> Duration:
                              </div>
                              <div className="col-1">
                              <span className="strongText">PiName:</span>{item[7]}</div>
                            </div>

                            {/* Horizontal Line */}
                            <hr />

                            {/* Third Row */}
                            <div className="row align-items-center justify-content-between">
                              <div className="col-3">Study Design:</div>
                              <div className="col-4">Population:</div>
                              <div className="col-4">Patient Enroll:</div>
                              <div className="col-1">
                                <FaChevronCircleDown
                                  onClick={toggleSummary}
                                  style={{ cursor: "pointer" }}
                                />
                              </div>
                            </div>

                            {/* Horizontal Line */}
                            <hr />

                            {/* Fourth Row */}
                            <div className="row align-items-center justify-content-between">
                              <div className="col-4">Status Insight:</div>
                              <div className="col-4">Patient Insight:</div>
                              <div className="col-4">
                              <span className="strongText">Next Milestone: </span>{item[5]}
                              </div>
                              {/* Summary */}
                              {isSummaryVisible && (
                                <div className="row summary">
                                  <hr />
                                  <div className="col-12">
                                    <p>
                                      <b>Research Summary:</b> It seems like the
                                      reverse geocoding service might not be
                                      returning the expected data. Let's modify
                                      the code to log the response from the
                                      reverse geocoding service
                                    </p>
                                    <b>Outcomes Height:</b>
                                  </div>

                                  <div className="row col-12 ">
                                    <div className="col-3 button">
                                      <button>Data Gaps</button>
                                    </div>
                                    <div className="col-3 button">
                                      <button>Health Equality</button>
                                    </div>
                                    <div className="col-3 button">
                                      <button>Digital Health & AI</button>
                                    </div>
                                    <div className="col-3 button">
                                      <button className="btn-success">
                                        Heigher Learners Reached
                                      </button>
                                    </div>
                                  </div>
                                </div>
                              )}
                            </div>
                          </Card.Body>
                        </Card>
                      </Col>
                    ))}
                  </Row>
                  {/* Numbered pagination links */}
                  <div className="d-flex justify-content-center mt-4">
                    <pre>
                      {currentPage > 1 && (
                        <Button onClick={() => paginate(currentPage - 1)}>
                          {"Prev"}
                        </Button>
                      )}
                      &nbsp;
                      {currentPage} (current Page){" "}
                      <Button onClick={() => paginate(currentPage + 1)}>
                        {"Next"}
                      </Button>
                    </pre>
                  </div>
                </Col>
              </Tab.Pane>
              <Tab.Pane eventKey="second">
                <div style={{ overflowY: "auto" }}>
                <div style={{ height: 400, width: '100%', backgroundColor: '#f2f2f2' ,marginTop:'70px'}} className="datagridtable">
     
     {rows.length > 0 ? (
       <>
         <DataGrid
           rows={rows}
           columns={columns.map((column) => ({
             ...column,
             renderCell: (params) => (column.field === 'LINK' ? renderUrlCell(params) : params.value),
           }))}
           pageSize={5}
           rowsPerPageOptions={[5, 10, 20]}
           checkboxSelection
           getRowId={(row) => row.id} // Assuming the unique id is in the 'id' field of each row
         />
        
       </>
     ) : (
       <p>No rows available</p>
     )}
   </div>
                </div>
              </Tab.Pane>
            </Tab.Content>
          </Row>
        </Tab.Container>
      </div>
      <Footer />
    </>
  );
}

export default MyDashboard;
