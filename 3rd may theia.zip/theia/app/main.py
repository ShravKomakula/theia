import logging
from logging.handlers import RotatingFileHandler
from typing import List
from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel
from app.document_extract import *
from app.gpt import *
from app.text_to_sql import *
import uvicorn
from fastapi.responses import StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
import boto3
from urllib.parse import urlparse, unquote
import mimetypes
import base64
import typing
import csv
from datetime import datetime
import json
import os
from auth import *
#from snow import *
from conn import *
import numpy as np
# Initialize logging
# logging.basicConfig(level=logging.DEBUG)

# # Create a logger
# logger = logging.getLogger(__name__)

# # Set up a rotating file handler for the logs
# handler = RotatingFileHandler("app.log", maxBytes=1000000, backupCount=5)
# handler.setLevel(logging.DEBUG)

# # Create a formatter and set it for the handler
# formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
# handler.setFormatter(formatter)

# # Add the handler to the logger
# logger.addHandler(handler)

# Initialize S3 client
s3_client = boto3.client('s3', region_name='us-east-2')

# Initialize FastAPI
app = FastAPI()

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Define Pydantic models
# class nsql_query(BaseModel):
#     user :str
#     query: str
#     source: str
#     temperature: float
#     top_p: float
#     max_new_tokens: int  

class InputQuery(BaseModel):
    source: str = "GNT01 SOPs and JobAids"
    user :str='Suresh.kamakshigari'
    query: str
    k_similarity_docs: int = 3 
    temperature: float =0.1
    top_p: float = 0.6
    max_new_tokens: int = 512

# class User_session(BaseModel):
#     user :str

class Comment(BaseModel):
    text: str

class QAResponse(BaseModel):
    query: str
    result: typing.Any
    result_text: str
    sql: str=''
    table:str=''
    source_links: List[str] = []
    page_content: List[str] = []
    likes: int = None
    dislikes: int = None
    comments: List[str] = []

# class SQLResponse(BaseModel):
#     query: str
#     sql_query: typing.Any
#     table:str
#     likes: int = 0
#     dislikes: int = 0
#     comments: List[str] = []

# List to hold QA data
qa_data = []

# Function to get CSV filename with current month and year
def get_csv_filename():
    # now = datetime.now()
    # print(f"qa_data_{now.strftime('%Y_%m')}.csv")
    # return f"qa_data_{now.strftime('%Y_%m')}.csv"
    return "qa_data.csv"

def update_or_append_log(timestamp, source, api_type, user, query, result=None,result_text=None,sql=None, result_table=None, source_links=None, k_similarity_docs=None, page_content=None, temperature=None, top_p=None, max_new_tokens=None, like=None, dislike=None,comment=None):
    # Define the file name based on the current month and year
    file_name = get_csv_filename()
    
    try:
        # Try to load the existing CSV file
        log_df = pd.read_csv(file_name)
    except FileNotFoundError:
        # If the file does not exist, create an empty DataFrame
        log_df = pd.DataFrame(columns=["timestamp", "source", "api_type", "user", "query", "result", "result_text","sql", "result_table", "source_links", "page_content", "k_similarity_docs", "temperature", "top_p", "max_new_tokens", "like", "dislike","comment"])
 
    if api_type == 'query':
        new_entry = pd.DataFrame({
            "timestamp": [timestamp],
            "source":[source],
            "api_type": [api_type],
            "user": [user],
            "query": [query], 
            "result": [result], 
            "result_text":[result_text],
            "sql": [sql],
            "result_table":[result_table],
            "source_links": [source_links],
            "page_content": [page_content],
            "k_similarity_docs":[k_similarity_docs],
            "temperature" :[temperature],
            "top_p": [top_p],
            "max_new_tokens": [max_new_tokens],
            "like": [like], 
            "dislike":[dislike],
            "comment": [comment]
        })
        log_df = pd.concat([log_df, new_entry], ignore_index=True)
    elif api_type =='like':
        print('im inside if ',log_df.empty,log_df.iloc[-1]["query"], query)
        if not log_df.empty and log_df.iloc[-1]["query"] == query:
            
            if like is not None:
                log_df.at[len(log_df)-1, "like"] = like
    
    elif api_type =='dislike':
        if not log_df.empty and log_df.iloc[-1]["query"] == query:
            if dislike is not None:
                log_df.at[len(log_df)-1, "dislike"] = dislike
 
    elif api_type == 'comment':
        if not log_df.empty and log_df.iloc[-1]["query"] == query:
            if comment is not None:
                log_df.at[len(log_df)-1, "comment"] = comment
         
    else:
        print('invalid type')

    # Save the updated DataFrame to the CSV file
    log_df.to_csv(file_name, index=False)
 
# Endpoint to query RAG
@app.post("/query_rag")
async def query_rag(details: InputQuery):
    try:
        query=details.query
        k_similarity_docs = details.k_similarity_docs
        temperature=details.temperature
        top_p=details.top_p
        max_new_tokens=details.max_new_tokens
        # Replace this with your actual function to get the result
        result = RetrievalQA_rag_response(conv_ret_chain, query, k_similarity_docs, temperature, top_p, max_new_tokens)
        qa_item = QAResponse(query=details.query, result=result, source_links=result["source"])
        qa_data.append(qa_item)
        save_to_csv(qa_item)
        # logger.info(f"Question added: {details.query}")
        return qa_item
    except Exception as e:
        # logger.error(f"Error adding question: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

    
@app.get("/download/{document_key:path}")
async def download_document(document_key: str):
    try:
        document_key = unquote(document_key)
        response = s3_client.get_object(Bucket=s3_bucket_name, Key=document_key)
        file_content = response['Body'].read()
        filename = document_key.split("/")[-1]
        headers = {"Content-Disposition": f"attachment; filename={filename}"}
        return StreamingResponse(content=iter([file_content]), headers=headers, media_type='application/octet-stream')
    except Exception as e:
        # logger.error(f"Error downloading document - Document Key: {document_key}, Error: {str(e)}")
        raise HTTPException(status_code=404, detail="Document not found")

@app.get("/view/{document_key:path}")
async def view_document(document_key: str):
    try:
        document_key = unquote(document_key)
        response = s3_client.get_object(Bucket=s3_bucket_name, Key=document_key)
        # logger.info(f"S3 Request Details: {response}")
        file_content = response['Body'].read()
        filename = document_key.split("/")[-1]
        encoded_content = base64.b64encode(file_content).decode('utf-8')
        media_type, _ = mimetypes.guess_type(filename)
        headers = {"Content-Disposition": f"inline; filename={filename}"}
        return StreamingResponse(content=iter([encoded_content]), media_type=media_type, headers=headers)
    except Exception as e:
        # logger.error(f"Error viewing document - Document Key: {document_key}, Error: {str(e)}")
        raise HTTPException(status_code=404, detail="Document not found")

@app.get("/get_question_list")
async def get_question_list():
    file_name = get_csv_filename()
    df = pd.read_csv(file_name)
    df = df[["query", "like", "dislike", "comment"]]
    df = df.fillna(value="-")
    # df = df.where(pd.notna(df) )
    question_list = df.to_dict(orient='records')
    #question_list = [{"query": item.query, "likes": item.likes, "dislikes": item.dislikes, "comments": item.comments} for item in qa_data]
    return question_list

@app.post("/get_answer")
def get_answer(details: InputQuery):
    try:
        qa_item = next(item for item in qa_data if item.query == details.query)
        return {"answer": qa_item.result, "likes": qa_item.likes, "dislikes": qa_item.dislikes, "comments": qa_item.comments}
    except StopIteration:
        # logger.warning(f"Question not found: {details.query}")
        raise HTTPException(status_code=404, detail="Question not found")

@app.post("/like")
def like_qa(details: InputQuery):
    try:

        like='like'
        timestamp = datetime.now()
        source = details.source
        api_type = 'like'
        user   = details.user 
        query = details.query

        update_or_append_log(timestamp=timestamp, source=source, api_type=api_type, user=user, query=query, like=like)
            
        # logger.info(f"Question liked: {details.query}")
        return {"message": "Liked successfully"}
    except StopIteration:
        # logger.warning(f"Question not found: {details.query}")
        raise HTTPException(status_code=404, detail="Question not found")
@app.post("/dislike")
def dislike_qa(details: InputQuery):
    try:    
        dislike='dislike'
        timestamp = datetime.now()
        source = details.source
        api_type = 'dislike'
        user   = details.user 
        query = details.query

        update_or_append_log(timestamp=timestamp, source=source, api_type=api_type, user=user, query=query, dislike=dislike)

        # logger.info(f"Question disliked: {details.query}")
        return {"message": "Disliked successfully"}
    except StopIteration:
        # logger.warning(f"Question not found: {details.query}")
        raise HTTPException(status_code=404, detail="Question not found")

@app.post("/comment")
def comment_qa(details: InputQuery, comment: Comment):
    try:
        comment=comment.text
        timestamp = datetime.now()
        source = details.source
        api_type = 'comment'
        user   = details.user 
        query = details.query

        update_or_append_log(timestamp=timestamp, source=source, api_type=api_type, user=user, query=query, comment=comment)

        # logger.info(f"Comment added to question: {details.query}")
        return {"message": "Comment added successfully"}
    except StopIteration:
        # logger.warning(f"Question not found: {details.query}")
        raise HTTPException(status_code=404, detail="Question not found")


# @app.post("/fetch_data")
# async def fetch_data():
#     try:
#         cursor = con.cursor()
#         cursor.execute("select REQUEST_ID, PROJECT_TITLE, STATUS, APPROVED_AMOUNT, PAYMENT_REMAINING, NEXT_MILESTONE, ORGANIZATION_NAME, PI_NAME, ABSTRACT_SUMMARY, INTERNAL_NOTES, LAST_UPDATE, PROJECT_BARRIERS, OWNER_NAME, OWNER_TITLE, LINK, logo_url, latitude, longitude, from GMGTEST_V_REQUEST_DASHBOARD;")
#         result = cursor.fetchall()
 
#         metadata = fetch_metadata(cursor)
 
#         metadata_dict = {
#             "resultSetMetaData": {
#                 "numRows": len(result),
#                 "format": "jsonv2",
#                 "partitionInfo": [],
#                 "rowType": []
#             }
#         }
 
#         for row in metadata:
#             column_name = row[0]
#             column_type = row[1].upper()
#             column_precision = row[2]
#             column_scale = row[3]
#             column_nullable = row[4]
 
#             type_map = {
#                 "FIXED": "INTEGER" if column_scale == 0 else "DECIMAL",
#                 "TEXT": "STRING",
#                 "DATE": "DATE",
#                 "TIME": "TIME",
#                 "TIMESTAMP": "TIMESTAMP"
#             }
 
#             if column_type in type_map:
#                 column_type = type_map[column_type]
 
#             column_metadata = {
#                 "name": column_name,
#                 "database": snowflake_database,
#                 "schema": snowflake_schema,
#                 "table": "GMGTEST_V_REQUEST_DASHBOARD",
#                 "type": column_type,
#                 "precision": column_precision,
#                 "scale": column_scale,
#                 "nullable": column_nullable
#             }
 
#             metadata_dict["resultSetMetaData"]["rowType"].append(column_metadata)
 
#         data_with_metadata = {
#             "metadata": metadata_dict,
#             "data": result
#         }
 
#         return data_with_metadata
 
#     except snowflake.connector.errors.ProgrammingError as e:
#         # Log the error
#         logging.error("Snowflake ProgrammingError: %s", e)
#         # Check if it's an authentication error
#         if "Authentication token has expired" in str(e):
#             # Re-authenticate and retry the operation
#             con.reauthenticate()
#             # Retry the operation
#             return fetch_data()
#         else:
#             raise HTTPException(status_code=500, detail=str(e))
 
#     except Exception as e:
#         # Log the error
#         logging.error("An unexpected error occurred: %s", e)
#         raise HTTPException(status_code=500, detail=str(e))
@app.get("/snowflake_query")
async def fetch_snowflake_data():
    return await execute_snowflake_query()

# Define FastAPI endpoint to fetch latitude and longitude
@app.get("/latitude_longitude/")
async def get_latitude_longitude():
    latitude_longitude_results = fetch_latitude_longitude()
    return latitude_longitude_results

@app.post("/Query_Details")
def Query_Details(details: InputQuery):
    try:
        snowflake_db = SnowflakeDB()
        tables_schema = snowflake_db.get_tables_schema(snowflake_db.conn)

        timestamp = datetime.now()
        source = details.source
        api_type = 'query'
        user   = details.user 
        query = details.query
        k_similarity_docs = details.k_similarity_docs
        temperature=details.temperature
        top_p=details.top_p
        max_new_tokens=details.max_new_tokens

        like = None
        dislike =None
        comment =None
        intial_token,token_gen_time = generate_token()

        if query and source == "Grant Details":
            # -- curate prompt
            prompt = snowflake_db.read_prompt_file("sql_prompt.txt")
            prompt = prompt.replace("<<TABLES>>", tables_schema)
            prompt = prompt.replace("<<QUESTION>>", query)

            gpt = vox_response
            
            text_response = gpt(prompt,temperature,max_new_tokens,token_gen_time,intial_token)

            result_json = json.loads(text_response.json()['result'])
            result = result_json['content']
            totalTokens = text_response.json()['totalTokens']
            

            df = snowflake_db.query(snowflake_db.conn, result)
        
            # Replace this with your actual function to get the result
            sql = result
            result=''
            result_table = str(df)
            source_links=[]
            page_content=[]
            result_text =  natural_sql(query,result_table)

        elif query and source == "GNT01 SOPs and JobAids":
            response = RetrievalQA_rag_response(conv_ret_chain, query, k_similarity_docs, temperature, top_p, max_new_tokens)
            result = response["result"]
            source_links = response["source"]
            page_content = response["page_content"]
            sql = ''
            result_table = ''
            result_text = ''
        qa_item =  QAResponse(query=query, result=result, result_text=result_text, sql=sql, table=result_table, source_links=source_links, page_content=page_content, like=like, dislike=dislike, comment=comment)
        update_or_append_log(timestamp, source, api_type, user, query, result, result_text,sql, result_table, source_links, page_content, k_similarity_docs, temperature, top_p, max_new_tokens, like, dislike, comment)
        
        # logger.info(f"Question added: {details.query}")
        return qa_item
    
    except Exception as e:
        text_response = ' '
        if text_response:
           return {"error": str(e) +'text_response :'+ str(text_response)}
        else:
            return {"error": str(e)}
    
@app.get("/user_session")
def User_session_info():
    file_name = get_csv_filename()
    try:
        # Try to load the existing CSV file
        log_df = pd.read_csv(file_name)

        #user_data = log_df[log_df['user']==user_details] 
        log_df = log_df.replace({np.nan:"-"})    
        return log_df.to_dict(orient='records')
   
    except Exception as e:
        return {"error": str(e)}
@app.get("/bring-data", response_model=List[dict])
async def get_data():
    query = """
            select REQUEST_ID,OWNER_NAME,OWNER_TITLE,FINAL_REPORT_STATUS,MAPP_DATES_STATUS,MAPP_SECTION_STATUS,PAYMENT_AMOUNT_STATUS,PROJECT_CLOSURE_STATUS,PAYMENT_STATUS,MEDICAL_REVIEW_STATUS,STUDY_STATUS,CONTRACT_DATES_STATUS,IMPACT_REPORT_STATUS FROM GMGTEST_GA_WORKFLOW_COMBINED;
            """
    data = fetch_data_from_snowflake(query)
    return data

@app.get("/profile-data", response_model=List[dict])
async def get_data():
    query = """
            select * FROM GMGTEST_VEEVA_LINK_COMBINED LIMIT 100;
            """
    data = fetch_data_from_snowflake(query)
    return data

@app.post("/token_oauth2")
async def get_access_token(code: str, client: httpx.AsyncClient = Depends(get_http_client)):
    if not code:
        raise HTTPException(status_code=400, detail="Code is required")

    try:
        response = await client.post(
            f"{ISSUER}token.oauth2?grant_type=authorization_code&redirect_uri={REDIRECT_URL}&response_type={RESPONSE_TYPE}&scope={SCOPE}&code={code}",
            auth=(USERNAME, PASSWORD)
        )
        response.raise_for_status()
        return {"message": "SSO request successful", "status": 200, "data": response.json()}
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/validate_oauth2")
async def validate_token(token: str, client: httpx.AsyncClient = Depends(get_http_client)):
    if not token:
        raise HTTPException(status_code=400, detail="Token is required")

    try:
        response = await client.post(
            f"{ISSUER}token.oauth2",
            headers={'Content-Type': 'application/x-www-form-urlencoded'},
            data={
                'client_id': USERNAME_VALIDATE,
                'client_secret': PASSWORD_VALIDATE,
                'grant_type': 'urn:pingidentity.com:oauth2:grant_type:validate_bearer',
                'token': token
            }
        )
        response.raise_for_status()
        return {"message": "SSO request successful", "status": 200, "data": response.json()}
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/refresh_oauth2")
async def refresh_token(refresh_token: str, client: httpx.AsyncClient = Depends(get_http_client)):
    if not refresh_token:
        raise HTTPException(status_code=400, detail="Refresh Token is required")

    try:
        response = await client.post(
            f"{ISSUER}token.oauth2",
            headers={'Content-Type': 'application/x-www-form-urlencoded'},
            data={
                'client_id': USERNAME,
                'client_secret': PASSWORD,
                'refresh_token': refresh_token,
                'grant_type': 'refresh_token'
            }
        )
        response.raise_for_status()
        return {"message": "SSO request successful", "status": 200, "data": response.json()}
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/introspect_oauth2")
async def introspection_token(token: str, client: httpx.AsyncClient = Depends(get_http_client)):
    if not token:
        raise HTTPException(status_code=400, detail="Token is required")

    try:
        response = await client.post(
            f"{ISSUER}introspect.oauth2",
            headers={'Content-Type': 'application/x-www-form-urlencoded'},
            data={
                'client_id': USERNAME,
                'client_secret': PASSWORD,
                'token_type_hint': 'access_token',
                'token': token
            }
        )
        response.raise_for_status()
        return {"message": "SSO request successful", "status": 200, "data": response.json()}
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=400, detail=str(e))
@app.post("/revoke_oauth2")
async def revoke_token(token: str, client: httpx.AsyncClient = Depends(get_http_client)):
    if not token:
        raise HTTPException(status_code=400, detail="Token is required")

    try:
        response = await client.post(
            f"{ISSUER}revoke.oauth2",
            headers={'Content-Type': 'application/x-www-form-urlencoded'},
            data={
                'client_id': USERNAME,
                'client_secret': PASSWORD,
                'token': token
            }
        )
        response.raise_for_status()
        return {"message": "Token revocation successful", "status": 200, "data": response.json()}
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=400, detail=str(e))
if __name__ == "__main__":
    uvicorn.run('main:app',host='127.0.0.1', port=8025, reload=True)