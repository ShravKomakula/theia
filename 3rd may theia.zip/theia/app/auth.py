from fastapi import FastAPI, HTTPException, Depends
import httpx
from config import *

app = FastAPI()

# # Hardcoded configuration values
# USERNAME = 'Kgui_client'
# PASSWORD = 'vD5ykH8H62ZYOk320z611n2f'
# USERNAME_VALIDATE = 'Kgui_validation'
# PASSWORD_VALIDATE = 'BqeezMNekXIhouf5r88fC9Lc'
# ISSUER = 'https://devfederate.pfizer.com/as/'
# SCOPE = 'edit'
# RESPONSE_TYPE = 'code'
# REDIRECT_URL = 'https://wws-kgui-dev.pfizer.com:3000/auth-redirect'

# Define a dependency for the httpx.AsyncClient
async def get_http_client():
    async with httpx.AsyncClient() as client:
        yield client

# @app.post("/token_oauth2")
# async def get_access_token(code: str, client: httpx.AsyncClient = Depends(get_http_client)):
#     if not code:
#         raise HTTPException(status_code=400, detail="Code is required")

#     try:
#         response = await client.post(
#             f"{ISSUER}token.oauth2?grant_type=authorization_code&redirect_uri={REDIRECT_URL}&response_type={RESPONSE_TYPE}&scope={SCOPE}&code={code}",
#             auth=(USERNAME, PASSWORD)
#         )
#         response.raise_for_status()
#         return {"message": "SSO request successful", "status": 200, "data": response.json()}
#     except httpx.HTTPStatusError as e:
#         raise HTTPException(status_code=400, detail=str(e))

# @app.post("/validate_oauth2")
# async def validate_token(token: str, client: httpx.AsyncClient = Depends(get_http_client)):
#     if not token:
#         raise HTTPException(status_code=400, detail="Token is required")

#     try:
#         response = await client.post(
#             f"{ISSUER}token.oauth2",
#             headers={'Content-Type': 'application/x-www-form-urlencoded'},
#             data={
#                 'client_id': USERNAME_VALIDATE,
#                 'client_secret': PASSWORD_VALIDATE,
#                 'grant_type': 'urn:pingidentity.com:oauth2:grant_type:validate_bearer',
#                 'token': token
#             }
#         )
#         response.raise_for_status()
#         return {"message": "SSO request successful", "status": 200, "data": response.json()}
#     except httpx.HTTPStatusError as e:
#         raise HTTPException(status_code=400, detail=str(e))

# @app.post("/refresh_oauth2")
# async def refresh_token(refresh_token: str, client: httpx.AsyncClient = Depends(get_http_client)):
#     if not refresh_token:
#         raise HTTPException(status_code=400, detail="Refresh Token is required")

#     try:
#         response = await client.post(
#             f"{ISSUER}token.oauth2",
#             headers={'Content-Type': 'application/x-www-form-urlencoded'},
#             data={
#                 'client_id': USERNAME,
#                 'client_secret': PASSWORD,
#                 'refresh_token': refresh_token,
#                 'grant_type': 'refresh_token'
#             }
#         )
#         response.raise_for_status()
#         return {"message": "SSO request successful", "status": 200, "data": response.json()}
#     except httpx.HTTPStatusError as e:
#         raise HTTPException(status_code=400, detail=str(e))

# @app.post("/introspect_oauth2")
# async def introspection_token(token: str, client: httpx.AsyncClient = Depends(get_http_client)):
#     if not token:
#         raise HTTPException(status_code=400, detail="Token is required")

#     try:
#         response = await client.post(
#             f"{ISSUER}introspect.oauth2",
#             headers={'Content-Type': 'application/x-www-form-urlencoded'},
#             data={
#                 'client_id': USERNAME,
#                 'client_secret': PASSWORD,
#                 'token_type_hint': 'access_token',
#                 'token': token
#             }
#         )
#         response.raise_for_status()
#         return {"message": "SSO request successful", "status": 200, "data": response.json()}
#     except httpx.HTTPStatusError as e:
#         raise HTTPException(status_code=400, detail=str(e))

# if __name__ == "__main__":
#     import uvicorn
#     uvicorn.run(app, port=8015)