import os
import requests
import json
from datetime  import datetime



endpointurl = "https://mule4api-comm-amer-stg.pfizer.com/vessel-openai-api-v1"
oauthtoken = "https://stgfederate.pfizer.com/as/token.oauth2?grant_type=client_credentials"
username = "f9b4feec2a69414a961fe35e8cc999d3"
password = "a162bBCE27094BF79Acf83247e8f6Fa0"

#To list config items
mulesoft_url = endpointurl
verification_url = oauthtoken
client_id = username
client_secret = password

def generate_token():
    '''
    Generates the Bearer token needed for OpenAI API authentication. Returns the Bearer token as a string.
    '''
    try:
        url = f"{verification_url}"
        payload = f"client_id={client_id}&client_secret={client_secret}"
        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        response = requests.request("POST", url, headers=headers, data=payload)
        token = response.json()["access_token"]
        token_gen_time = datetime.now()
        return "Bearer " + token ,token_gen_time
    
    except Exception as e:
        return {
            "status": "error",
            "data": e,
            "message": e.orig.args if hasattr(e, "orig") else f"{e}",
        }
    
    
def vox_response(prompt,temperature,max_new_tokens,token_gen_time,initial_token):

    engine = "gpt-4-32k"
    current_time  = datetime.now()
    time_delta = current_time - token_gen_time
    if time_delta.seconds > 1790 :
        token = generate_token()
    else :   
        token = initial_token

    url_chatCompletion = mulesoft_url + '/chatCompletion'
    headers = {"Authorization": token, "Content-Type": "application/json"}
    payload = {
                "engine": engine,
                "messages": [
                    {
                        "role": "system",
                        "content": "Assistant is a large language model trained by OpenAI.",
                    },
                    {
                        "role": "user",
                        "content": prompt,
                    }
                ],
                "temperature":temperature,
                "max_tokens":max_new_tokens
            }
    
    
    text_response = requests.post(url=url_chatCompletion, headers=headers, json=payload)
   
    return text_response

def natural_sql(InputQuery,result_table):
        prompt=f"""This intelligent component, respond questions based {InputQuery} from {result_table} and  response in plain english"""
        

        temperature=0.8
                
        max_new_tokens=512

        intial_token,token_gen_time = generate_token()
        gpt = vox_response
                
        text_response = gpt(prompt,temperature, max_new_tokens, token_gen_time,intial_token)

        result_json = json.loads(text_response.json()['result'])
        result = result_json['content']
        return result

