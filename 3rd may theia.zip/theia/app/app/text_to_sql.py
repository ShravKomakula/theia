import snowflake.connector
import pandas as pd
# from gpt import vox_response


class SnowflakeDB:
    def __init__(self) -> None:
        self.conn = snowflake.connector.connect(
            user="gmgdevs@pfizer.com",
            password="ZGLOBALmedicalgrants100@@@",
            account="amerdev01.us-east-1",
            warehouse="VAW_AMER_DEV_WH",
            schema="GMGTEST",
            database="VAW_AMER_DEV_QUAL"
        )
        self.cursor = self.conn.cursor()

    @staticmethod
    def read_prompt_file(fname):
        with open(fname, "r") as f:
            return f.read()

    @staticmethod
    def query(_conn, query):
        try:
            return pd.read_sql(query, _conn)
        except Exception as e:
            print("Error is ", e)

    @staticmethod
    def get_tables_schema(_conn):
        specific_tables = ["GMGTEST_V_REQ_ORG_GEOCODING_JOINED","GMGTEST_V_IMPACT_REPORT_FINAL_UNPIVOTED"]
        SnowflakeDB.query(_conn, "use role VAW_AMER_DEV_QUAL_DSS_WMS_GMG_RC;")
        table_schemas = ""
        df = SnowflakeDB.query(_conn, "show tables")
        filtered_df = df[df['name'].isin(specific_tables)]

        for table in specific_tables:
            t = f"{table}"
            df_result = SnowflakeDB.query(_conn, f"select * from {t};")
            ddl_query = f"select get_ddl('table', '{t}');"
            ddl = SnowflakeDB.query(_conn, ddl_query)

            if ddl is not None and not ddl.empty:
                schema = f"\n{ddl.iloc[0, 0]}\n"
                table_schemas = table_schemas + f"\n{table}\n"
                table_schemas = table_schemas + f"{schema}\n"
            else:
                print(f"No DDL found for table {table}")

        return table_schemas

# def ask(prompt):
#     gpt = vox_response
#     response = gpt(prompt)
#     # print(response)     
#     return response
