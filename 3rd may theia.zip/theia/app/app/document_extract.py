import boto3, json
import re
import os
import time
import requests
import torch
from sentence_transformers import SentenceTransformer
from langchain.document_loaders import PyPDFLoader, S3DirectoryLoader, S3FileLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.vectorstores import Chroma
from langchain.embeddings import HuggingFaceInstructEmbeddings
from langchain.chains import RetrievalQA, RetrievalQAWithSourcesChain
from langchain.llms.sagemaker_endpoint import LLMContentHandler
from langchain import SagemakerEndpoint, LLMChain, PromptTemplate
from langchain.chains import ConversationalRetrievalChain
from langchain.memory import ConversationBufferMemory, ConversationBufferWindowMemory, ConversationSummaryMemory

# Setting the variables
s3_bucket_name = 'gmg-s3-sagemaker-artifacts' 
folder_name_docs = 'grants_documents/'
folder_name = 'gmg_job_Aids&sop'
logs_s3_folder_name = "theia_chat_logs"
db_dir = "gmg_vector_db"
s3_prefix_db = "gmg-chromadb"
model_id, model_version = "meta-textgeneration-llama-2-7b-f", "*"
endpoint_name="meta-textgeneration-llama-2-7b-f-2023-11-08-17-44-44-335"
aws_region = "us-east-2"
# k_similarity_docs = 3
# max_new_tokens = 512
# top_p = 0.6
# temperature = 0.1

# Loading the embedding Model
DEVICE = "cuda:0" if torch.cuda.is_available() else "cpu"

embeddings = HuggingFaceInstructEmbeddings(
    model_name="hkunlp/instructor-large", model_kwargs={"device": DEVICE}
)

# Initialize the S3 client
s3 = boto3.client('s3')

def document_loader_pypdf(s3, document_name):
  
    document_name = document_name
    response = s3.get_object(Bucket=s3_bucket_name, Key=folder_name+document_name)
    #print(file_meta_data['Metadata'])
    pdf_content = response["Body"].read()
    
    local_file_path = "temp_file.pdf"
    with open(local_file_path, 'wb') as local_file:
        local_file.write(pdf_content)
        
    pdf_loader = PyPDFLoader(file_path=local_file_path)
    document = pdf_loader.load()
    return document

def objects_list_in_s3(s3, s3_bucket_name, folder_name):
    
    # Get list of objets in s3
    objects = s3.list_objects_v2(Bucket=s3_bucket_name, Prefix=folder_name)
    
    # Extract files paths from object
    document_paths = [obj['Key'] for obj in objects.get('Contents', [])]
    document_paths = document_paths[1:]
    return document_paths

def document_loader_s3(s3, s3_bucket_name, document_path):
    
    #defining S3 Bucket, Key
    bucket = s3_bucket_name
    document_path = document_path
    
    # Load Pdf file from S3
    document_loader = S3FileLoader(bucket=bucket, key=document_path)
    document = document_loader.load()
    return document
def upload_logs_to_s3(filename):
    #defining S3 Bucket, Key
    bucket = s3_bucket_name
    filepath = filename
    key= logs_s3_folder_name+'/'+filename
    s3.upload_file(filepath, bucket, key)


# Text Pre processing
def clean_text(text):
    #Remove special characters
    cleaned_text = re.sub(r'[^a-zA-Z0-9\s$@%&.,:;/]', "", text)
    
    #Remove double spaces
    #cleaned_text = re.sub(r'\s+', " ", cleaned_text)
    
    #Remove empty and double lines
    cleaned_text = re.sub(r'(\n\s*){2,}', '\n\n', cleaned_text)
    #Remove all empty lines
    #cleaned_text = re.sub(r'\n\s*\n', '\n', cleaned_text)
    return cleaned_text


# Embeding and storing to Vector DB
def insert_all_embedings_in_db(s3, s3_bucket_name, folder_name, embeddings, db_dir):
    documents_in_s3 = objects_list_in_s3(s3, s3_bucket_name, folder_name)

    for doc in documents_in_s3:
        # Loading the document
        document = document_loader_s3(s3, s3_bucket_name, doc)

        # Cleaned document
        document[0].page_content = clean_text(document[0].page_content)

        # Checking the documents
        text_splitter = RecursiveCharacterTextSplitter(chunk_size=1024, chunk_overlap=64)
        texts = text_splitter.split_documents(document)

        # Storing the Vectors in Vector DB
        db = Chroma.from_documents(documents=texts, embedding=embeddings, persist_directory=db_dir)
        return db

# Creating the vector DB and embedding the prompt examples
def get_vector_db(embeddings, db_dir, db_type='retriever', documents=None):
    if db_type == 'retriever':
        vector_db = Chroma(embedding_function=embeddings, persist_directory=db_dir)
    elif db_type == 'embedding' and documents!=None:
        vector_db = Chroma.from_documents(documents=prompt_examples, embedding=embeddings, persist_directory=db_dir)
    return vector_db



# Upload DB to S3
def upload_db_to_s3(local_folder, s3_bucket, s3_prefix=""):
    try:
        for root, dirs, files in os.walk(local_folder):
            for file in files:
                local_path = os.path.join(root, file)
                s3_path = os.path.join(s3_prefix, os.path.relpath(local_path, local_folder))
                s3.upload_file(local_path, s3_bucket, s3_path)
                print(f"Uploaded {local_path} from Sagemaker to S3 bucket: {s3_bucket}/{s3_path}")
    except:
        print("Upload unsucessfull")     
# local_folder = "gmg_vector_db"
# s3_bucket_name = "gmg-s3-sagemaker-artifacts"
# s3_prefix = "gmg-chromadb"
# upload_db_to_s3(local_folder, s3_bucket_name, s3_prefix)


# Download DB to S3
def download_from_s3_to_sagemaker(s3_bucket, s3_prefix, local_folder):
    # Ensure the local folder exits
    os.makedirs(local_folder, exist_ok=True)
    
    # List objects in s3 bucket
    objects = s3.list_objects(Bucket=s3_bucket, Prefix=s3_prefix)['Contents']

    for obj in objects:
        s3_path = obj['Key']
        local_path = os.path.join(local_folder, os.path.relpath(s3_path, s3_prefix))
        if not s3_path.endswith('/'):
            os.makedirs(os.path.dirname(local_path), exist_ok=True)
            s3.download_file(s3_bucket, s3_path, local_path)
        print(f"Downloaded {s3_path} from S3 to Sagemaker folder: {local_path}")
#download_from_s3_to_sagemaker(s3_bucket_name, s3_prefix_db, db_dir)

# ContentHandler       
class ContentHandler(LLMContentHandler):
    content_type = "application/json"
    accepts = "application/json"

    def transform_input(self, prompt: str, model_kwargs: dict) -> bytes:
        input_str = json.dumps({"inputs":[[{"role":"system", "content":"You are a kind robot"}, 
                                            {"role":"user", "content":prompt}]],
                                             "parameters": {**model_kwargs}})
        return input_str.encode("utf-8")

    def transform_output(self, output: bytes) -> str:
        response_json = json.loads(output.read().decode("utf-8"))
        return response_json[0]["generation"]["content"]


# Prompt
DEFAULT_SYSTEM_PROMPT = """
You are a helpful, respectful and honest assistant. Always answer as helpfully as possible, while being safe. 
Your answers should not include any harmful, unethical, racist, sexist, toxic, dangerous, or illegal content. 
Please ensure that your responses are socially unbiased and positive in nature.

If a question does not make any sense, or is not factually coherent, explain why instead of answering something not correct. 
If you don't know the answer to a question, please don't share false information.
""".strip()

def generate_prompt(prompt: str, system_prompt: str = DEFAULT_SYSTEM_PROMPT) -> str:
    return f"""[INST] <>
                {system_prompt}
                <>

                {prompt} [/INST]
                """.strip()



def conv_ret_chain(query, k_similarity_docs, temperature, top_p, max_new_tokens): 


    #Calling DB & retriver
    db =  get_vector_db(embeddings, db_dir)
    retriever = db.as_retriever(search_type="similarity_score_threshold", search_kwargs={"k":k_similarity_docs, 'score_threshold': 0.8}) 
    #retriever = db.as_retriever(search_type="similarity", search_kwargs={"k":k_similarity_docs, 'score_threshold': 0.8}) 

    content_handler = ContentHandler()
    #Calling LLM
    llm = SagemakerEndpoint(
        endpoint_name=endpoint_name,
        region_name=aws_region,
        model_kwargs={"max_new_tokens": max_new_tokens, "top_p": top_p, "temperature": temperature},
        endpoint_kwargs={"CustomAttributes":'accept_eula=true'},
        content_handler=content_handler,
        verbose=True
    )

    SYSTEM_PROMPT = "Use the following pieces of context to answer the question at the end. If you don't know the answer, just say that you don't know, don't try to make up an answer."
    template = generate_prompt(
                                """
                                {context}
                                Question: {question}
                                """,
                                    system_prompt=SYSTEM_PROMPT,
                                )

    prompt = PromptTemplate(template=template, input_variables=["context", "question"])

    RetrievalWithSources_QA = RetrievalQAWithSourcesChain.from_llm(llm=llm, retriever=retriever)

    Retrieval_QA = RetrievalQA.from_chain_type(
        llm=llm, 
        chain_type="stuff", 
        retriever=retriever, 
        chain_type_kwargs={"prompt": prompt},
        verbose=True
        )

    memory = ConversationBufferWindowMemory(memory_key="chat_history", return_messages=True, k=k_similarity_docs, output_key='answer')
    # memory = ConversationSummaryMemory(llm=llm, memory_key="chat_history", return_messages=True,)
    
    # Defining conversational retraval chain
    conv_ret_chain = ConversationalRetrievalChain.from_llm(llm, retriever, memory=memory, verbose=False, return_source_documents=True) #max_tokens_limit = 2500
    response = conv_ret_chain.invoke({"question": query})
    return response
def RetrievalQA_rag_response(conv_ret_chain, query, k_similarity_docs, temperature, top_p, max_new_tokens):
    result = conv_ret_chain(query, k_similarity_docs, temperature, top_p, max_new_tokens)

    docs = result["source_documents"]
    source_links=[]
    page_content = []
    for doc in docs:
        source_links.append(doc.metadata['source'])
        page_content.append(doc.page_content)
    unique_source_links = list(set(source_links))
    return {"query":query, "result":result['answer'], "source":source_links, "page_content":page_content}


# function for getting response with Retrieval_QA(query)
# def RetrievalQA_rag_response(Retrieval_QA, query):
#     result = Retrieval_QA(query)
#     docs = db.similarity_search(query, k=k_similarity_docs)
#     source_links=[]
#     for doc in docs:
#         doc_details = doc.to_json()['kwargs']
#         source_links.append(doc_details['metadata']['source'])
#     return {"query":result["query"], "result":result["result"], "source":source_links}

# # Retrival docs with similarity_search
# def RetrievalQA_rag_response(conv_ret_chain, query):
#     result = conv_ret_chain(query)

#     docs = db.similarity_search(query, k=k_similarity_docs)
#     source_links=[]
#     for doc in docs:
#         doc_details = doc.to_json()['kwargs']
#         source_links.append(doc_details['metadata']['source'])
#     unique_source_links = list(set(source_links))
#     return {"query":query, "result":result, "source":unique_source_links}

# # Retrival docs with similarity_search_with_relevance_scores
# def RetrievalQA_rag_response(conv_ret_chain, query):
#     result = conv_ret_chain(query)

#     docs = db.similarity_search_with_relevance_scores(query, k=k_similarity_docs, score_threshold= 0.8)
#     source_links=[]
#     for doc in docs:
#         source_links.append(doc[0].metadata['source'])
#     unique_source_links = list(set(source_links))
#     return {"query":query, "result":result, "source":unique_source_links}


# query = "What is the Applicant Eligibility Criteria for Independent Medical Education Grants"
# response = test_rag(qa, query)