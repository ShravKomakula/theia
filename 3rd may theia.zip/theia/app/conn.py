from fastapi import FastAPI
import snowflake.connector
from config import *
 
app = FastAPI()
 
# Snowflake connection setup
con = snowflake.connector.connect(
    user=SNOWFLAKE_USERNAME,
    password=SNOWFLAKE_PASSWORD,
    account=SNOWFLAKE_ACCOUNT,
    warehouse=snowflake_warehouse,
    database=snowflake_database,
    schema=snowflake_schema,
    role="VAW_AMER_DEV_QUAL_DSS_WMS_GMG_RC"
)
 
# Define function to fetch metadata
def fetch_metadata(cursor):
    cursor.execute("DESCRIBE TABLE GMGTEST_V_REQUEST_DASHBOARD")
    metadata = cursor.fetchall()
    return metadata
def fetch_data_from_snowflake(query):
    # Define a context manager for the Snowflake connection
    with snowflake.connector.connect(
        user=SNOWFLAKE_USERNAME,
        password=SNOWFLAKE_PASSWORD,
        account=SNOWFLAKE_ACCOUNT,
        warehouse=snowflake_warehouse,
        database=snowflake_database,
        schema=snowflake_schema,
        role="VAW_AMER_DEV_QUAL_DSS_WMS_GMG_RC"
    ) as conn:
        with conn.cursor() as cur:
            # Execute the query without LIMIT and OFFSET
            query = query
            cur.execute(query)

            # Fetch all rows
            rows = cur.fetchall()

            # Convert rows to the desired output format
            result = [dict(zip([column[0] for column in cur.description], row)) for row in rows]

    return result

from snowflake.connector import connect, ProgrammingError
import logging
 
# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
 
# Your FastAPI app instance
app = FastAPI()
 
SNOWFLAKE_ACCOUNT = "amerdev01.us-east-1"
SNOWFLAKE_USERNAME = "gmgdevs@pfizer.com"
SNOWFLAKE_PASSWORD = "ZGLOBALmedicalgrants100@@@"
SNOWFLAKE_WAREHOUSE = "VAW_AMER_DEV_WH"
SNOWFLAKE_DATABASE = "VAW_AMER_DEV_QUAL"
SNOWFLAKE_SCHEMA = "GMGTEST"
SNOWFLAKE_ROLE = "VAW_AMER_DEV_QUAL_DSS_WMS_GMG_RC"
 
# Function to establish Snowflake connection
def snowflake_connect():
    # Connect to Snowflake
    conn = connect(
        account=SNOWFLAKE_ACCOUNT,
        user=SNOWFLAKE_USERNAME,
        password=SNOWFLAKE_PASSWORD,
        warehouse=SNOWFLAKE_WAREHOUSE,
        database=SNOWFLAKE_DATABASE,
        schema=SNOWFLAKE_SCHEMA,
        role=SNOWFLAKE_ROLE
    )
   
    # Refresh token if it's expired
    if conn.is_closed():
        conn = connect(
            account=SNOWFLAKE_ACCOUNT,
            user=SNOWFLAKE_USERNAME,
            password=SNOWFLAKE_PASSWORD,
            warehouse=SNOWFLAKE_WAREHOUSE,
            database=SNOWFLAKE_DATABASE,
            schema=SNOWFLAKE_SCHEMA,
            role=SNOWFLAKE_ROLE
        )
       
    return conn
 
# Function to execute Snowflake query
async def execute_snowflake_query():
    try:
        # Establish connection
        conn = snowflake_connect()
        cursor = conn.cursor()
 
        # Snowflake query
        query = """
            SELECT REQUEST_ID, PROJECT_TITLE, STATUS, APPROVED_AMOUNT, PAYMENT_REMAINING,
                   NEXT_MILESTONE, ORGANIZATION_NAME, PI_NAME, ABSTRACT_SUMMARY, INTERNAL_NOTES,
                   LAST_UPDATE, PROJECT_BARRIERS, OWNER_NAME, OWNER_TITLE, LINK, logo_url,
                   latitude, longitude
            FROM GMGTEST_V_REQUEST_DASHBOARD
        """
 
        # Execute query
        cursor.execute(query)
 
        # Fetch column names
        columns = [column[0] for column in cursor.description]
 
        # Fetch all results
        results = cursor.fetchall()
 
        # Return results and column names
        return {"columns": columns, "results": results}
    except ProgrammingError as e:
        # Log the error
        logger.error(f"Snowflake query execution failed: {e}")
        # Handle programming errors, such as authentication issues
        return {"error": str(e)}
    finally:
        # Close cursor and connection
        cursor.close()
        conn.close()

# Function to execute Snowflake query to fetch latitude and longitude
def fetch_latitude_longitude():
    try:
        # Establish connection
        conn = snowflake_connect()
        cursor = conn.cursor()
 
        # Snowflake query to fetch latitude and longitude
        query = """
            SELECT latitude, longitude
            FROM GMGTEST_V_REQUEST_DASHBOARD
        """
 
        # Execute query
        cursor.execute(query)
 
        # Fetch all results
        results = cursor.fetchall()
 
        # Convert results into an array of dictionaries
        output = [{"latitude": row[0], "longitude": row[1]} for row in results]
 
        return output
    except snowflake.connector.errors.ProgrammingError as e:
        # Handle programming errors
        return {"error": str(e)}
    finally:
        # Close cursor and connection
        cursor.close()
        conn.close()