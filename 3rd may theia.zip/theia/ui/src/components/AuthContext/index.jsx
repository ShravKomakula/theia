
import { createContext, useContext, useState } from 'react';
import { toast } from 'react-toastify';


const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [authenticated, setAuthenticated] = useState(localStorage.getItem('authenticated') === 'true');

  const login = (email, password, navigate,firstname='') => {
    if(email === "parth.patel2@pfizer.com"&& password === "Random123@"){
      setAuthenticated(true)
      localStorage.setItem("authenticated", true)
      localStorage.setItem("email", email)
      localStorage.setItem("userName", "Parth")

      toast.success("Logged in successfully", { position: toast.POSITION.TOP_CENTER });
      navigate('/landing-page');
  } else if(email === "sainath.kumar@pfizer.com"&& password === "Random123@"){
      setAuthenticated(true)
      localStorage.setItem("authenticated", true)
      localStorage.setItem("email", email)
      localStorage.setItem("userName", "Sainath")
      toast.success("Logged in successfully", { position: toast.POSITION.TOP_CENTER });
      navigate('/landing-page');
  } else if(email === "pranathi.depa@pfizer.com"&& password === "Random123@"){
    setAuthenticated(true)
    localStorage.setItem("authenticated", true)
    localStorage.setItem("email", email)
    localStorage.setItem("userName", "Pranathi")
    toast.success("Logged in successfully", { position: toast.POSITION.TOP_CENTER });
    navigate('/landing-page');
  } else if(email === "shravani.komakula@pfizer.com"&& password === "Random123@"){
    setAuthenticated(true)
    localStorage.setItem("authenticated", true)
    localStorage.setItem("email", email)
    localStorage.setItem("userName", "Shravani")
    toast.success("Logged in successfully", { position: toast.POSITION.TOP_CENTER });
    navigate('/landing-page');
  } else if(email === "nithin.makkina@pfizer.com"&& password === "Random123@"){
    setAuthenticated(true)
    localStorage.setItem("authenticated", true)
    localStorage.setItem("email", email)
    localStorage.setItem("userName", "Nithin")
    toast.success("Logged in successfully", { position: toast.POSITION.TOP_CENTER });
    navigate('/landing-page');
  } else if(email === "eswar.poluri@pfizer.com"&& password === "Random123@"){
    setAuthenticated(true)
    localStorage.setItem("authenticated", true)
    localStorage.setItem("email", email)
    localStorage.setItem("userName", "Eswar")
    toast.success("Logged in successfully", { position: toast.POSITION.TOP_CENTER });
    navigate('/landing-page');
  } else if(email === "ryan.nork@pfizer.com"&& password === "Random123@"){
      setAuthenticated(true)
      localStorage.setItem("authenticated", true)
      localStorage.setItem("email", email)
      localStorage.setItem("userName", "Ryan")
      toast.success("Logged in successfully", { position: toast.POSITION.TOP_CENTER });
      navigate('/landing-page');
  }else if(email === "sombir.vats@pfizer.com"&& password === "Random123@"){
    setAuthenticated(true)
    localStorage.setItem("authenticated", true)
    localStorage.setItem("email", email)
    localStorage.setItem("userName", "Sombir")
    toast.success("Logged in successfully", { position: toast.POSITION.TOP_CENTER });
    navigate('/landing-page');
  }else if(password==="ssologin"){
    setAuthenticated(true)
    localStorage.setItem("authenticated", true)
    localStorage.setItem("email", email)
    localStorage.setItem("userName", firstname)
    toast.success("Logged in successfully", { position: toast.POSITION.TOP_CENTER });
    navigate('/landing-page');
  }
   else {
      toast.warning("Please provide valid Email & Password", { position: toast.POSITION.TOP_CENTER });
  }

  };

  const logout = () => {
    setAuthenticated(false)
    localStorage.removeItem('authenticated');
    localStorage.clear()
  };

  return (
    <AuthContext.Provider value={{ authenticated, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
