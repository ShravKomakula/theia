import React, { useState, useEffect } from 'react';

import { FetchSnowFlakeData } from '../../common/api-config';

const MapWithMarkers = () => {
  const [map, setMap] = useState(null);
  const [markers, setMarkers] = useState([]);

  useEffect(() => {
    const loadMapScript = () => {
      const script = document.createElement('script');
      script.src = `https://maps.googleapis.com/maps/api/js?key=AIzaSyDx1t1xehKETxiCv0KPsGUGVzo0YXra8ZU&libraries=places&v=weekly`;
      script.defer = true;
      script.onload = initMap;
      document.head.appendChild(script);
    };

    loadMapScript();
  }, []);

  useEffect(() => {
    if (map && markers.length) {
      markers.forEach((markerData) => {
        new window.google.maps.Marker({
          position: markerData,
          map: map,
        });
      });
    }
  }, [map, markers]);

  const initMap = () => {
    const mapInstance = new window.google.maps.Map(document.getElementById('map'), {
      center: { lat: 40.749933, lng: -73.98633 },
      zoom: 3,
      mapTypeControl: false,
    });
    setMap(mapInstance);
    
    // Fetch data from Snowflake API and set markers
    const fetchData = async () => {
      try {
        const response = await fetch(FetchSnowFlakeData(), {});
        const data = await response.json();
        const fetchedMarkers = data.results.map(result => ({
          lat: parseFloat(result[16]),
          lng: parseFloat(result[17]),
        }));
        setMarkers(fetchedMarkers);
      } catch (error) {
        console.error('Error fetching data from Snowflake API:', error);
      }
    };
    fetchData();
  };

  return (
    <div>
      <div id="map"></div>
    </div>
  );
};

export default MapWithMarkers;
