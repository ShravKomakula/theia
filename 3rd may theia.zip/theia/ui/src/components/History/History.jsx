import React, { useState, useEffect } from 'react';
import Topbar from '../../common/Topbar';
import Footer from '../../common/Footer/Footer';
import { DataGrid } from '@mui/x-data-grid';
import axios from 'axios';
import "./History.css";
import { UserLogsEndpoint } from '../../common/api-config';
import downloadSimple from "../../assets/images/DownloadSimple.svg";

import { saveAs } from 'file-saver'; // Import saveAs function for file download
import { Nav } from 'react-bootstrap';
const History = () => {
    const [rows, setRows] = useState([]);
    const [selectedRow, setSelectedRow] = useState(null);
    const [showPopup, setShowPopup] = useState(false);
    const handleClosePopup = () => {
        setShowPopup(false);
    };

    useEffect(() => {
        const handleOutsideClick = (event) => {
            if (!event.target.closest('.popup-content')) {
                handleClosePopup();
            }
        };

        document.addEventListener('mousedown', handleOutsideClick);

        return () => {
            document.removeEventListener('mousedown', handleOutsideClick);
        };
    }, [handleClosePopup]);
    useEffect(() => {
        axios.get(UserLogsEndpoint())
            .then(response => {
                const rows = response.data.map((row, index) => ({ ...row, id: index + 1 }));
                setRows(rows || []);
            })
            .catch(error => {
                console.error('Error fetching data:', error);
            });
    }, []);

    const handleRowSelection = (params) => {
        setSelectedRow(params.row);
        setShowPopup(true);
    };
    const handleDownload = () => {
      // Extract column headers excluding 'id'
      const headers = Object.keys(rows[0]).filter(header => header !== 'id');
  
      // Construct CSV content with headers
      let csvContent = "data:text/csv;charset=utf-8," + headers.join(',') + '\n';
  
      // Append rows to CSV content, excluding 'id' column
      csvContent += rows.map(row =>
          headers.map(header =>
              typeof row[header] === 'string' ? `"${row[header].replace(/"/g, '""')}"` : row[header]
          ).join(',')
      ).join('\n');
  
      const encodedUri = encodeURI(csvContent);
      saveAs(encodedUri, "user_logs.csv");
  };
  
  
// Columns configuration
const columns = [
    {field: 'user', headerName: 'UserName', width: 150,headerClassName: 'custome-style'  },
    { field: 'timestamp', headerName: 'Timestamp', width: 150,headerClassName: 'custome-style'  },
    { field: 'source', headerName: 'Category', width: 150,headerClassName: 'custome-style'  },
    { field: 'like', headerName: 'Like', width: 100,headerClassName: 'custome-style'  },
    { field: 'dislike', headerName: 'Dislike', width: 100,headerClassName: 'custome-style'  },
    { field: 'comment', headerName: 'Comment', width: 150,headerClassName: 'custome-style'  },
    { field: 'query', headerName: 'Promt', width: 300,headerClassName: 'custome-style'  },
    { field: 'result', headerName: 'Job Aids Result', width: 150,headerClassName: 'custome-style'  },
    { field: 'result_text', headerName: 'Grant Result', width: 150,headerClassName: 'custome-style'  },
/*     { field: 'sql', headerName: 'SQL', width: 150,headerClassName: 'custome-style'  },
    { field: 'result_table', headerName: 'Table', width: 150 ,headerClassName: 'custome-style' }, */
    { field: 'temperature', headerName: 'Temparature', width: 150,headerClassName: 'custome-style'  },
    { field: 'top_p', headerName: 'Top', width: 100,headerClassName: 'custome-style'  },
    { field: 'max_new_tokens', headerName: 'Length', width: 100,headerClassName: 'custome-style'  },
];

    return (
        <>
            <div className='topbar'>
                <Topbar />
            </div>
            <div className='LogsInfo'>
                <h2 className='heading'>User Activity and feedback Logs</h2>
                <p className='short-content'>we can add some content here related to user Activity and Feedback logs</p>
                <div className='tableView'>
                    <div className='row col-12'>
                        <div className='col-1'></div>
                        <div className='col-3'>
                            <p className='block'> Accuracy Score:</p>
                        </div>
                        <div className='col-4 ml-5'>
                            <p className='block'>Avg Session Length:<br />
                                Avg InQueries per seesion:</p>
                        </div>
                        <div className='col-3'>
                            <p className='block'>Number of responces generated:</p>
                        </div>
                        <div className='col-1'></div>
                    </div>
                    <div className='download-icon' >
                    <Nav.Link >
                                      
                                      <img src={downloadSimple} alt="download Icon" onClick={handleDownload}/>
                                  </Nav.Link>
                    </div>
                    <DataGrid rows={rows} columns={columns} pageSize={5} onRowClick={handleRowSelection} />
                </div>
            </div>
            {showPopup && selectedRow && (
                <div className='popup' style={{ width: '1000px' }}>
                
                 <div className='popup-content'>
                 <div className="popup-header">
       
          </div>
                 <div className='popup-scrollable-content'>
                      
                        <p><strong>Prompt:</strong> {selectedRow.query}</p>
                        {selectedRow.result !=='-' && <p><strong>Job Aids Result:</strong> {selectedRow.result}</p>}
                        {selectedRow.result_text !=='-' && <p><strong>Grant:</strong> {selectedRow.result_text}</p>}
                       {/*  {selectedRow.sql!=='-' && <span>SQl Query :<code>{selectedRow.sql}</code></span>}
                        {selectedRow.result_table !=='-' && (
                            <div>
                                                <div className="table-view">
          <span>Table:</span>
          <table>
            <tbody>
              {selectedRow.result_table.split('\n').map((row, index) => (
                <tr key={index}>
                  {row.split(/\s+/).map((cell, cellIndex) => (
                    <td key={cellIndex}>{cell}</td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
                            </div>
                        )}
                         */}
                       
        
                        <button className='close-button' onClick={handleClosePopup}>OK</button>
                    </div>
                 </div>
                </div>
            )}
         <div className='Footer'>
         <Footer />
         </div>
        </>
    );
}

export default History;
