import React from 'react';
import logo from '../../assets/images/Logo_3-removebg-preview 1 (1).svg';
import { FaUserCheck } from 'react-icons/fa';
import './topbar.css';
import { useNavigate } from "react-router-dom";
import imageTheia from "../../assets/images/theia.png";
import signOut from "../../assets/images/SignOut.svg";
import { useAuth } from '../../components/AuthContext';
import { RevokeTokenEndPoint } from '../api-config';

import axios from 'axios';
const Topbar = () => {
    const navigate = useNavigate();
    const goToLanding = () => {
        navigate("/Main");
      };
  const gotoDashboardView = () => {
    navigate("/my-dashboard");
  };
  const QueriesPage = () => {
    navigate("/queries");
  };

  const gotoInSightsView = () => {
    navigate("/insights");
  };

  const goToHistory = () => {
    navigate("/History");
  };

  const gotToHelpQA = () => {
    navigate("/HelpQA");
  };
  const revokeToken = async () => {
    try {
      const accessToken = JSON.parse(localStorage.access_token).tokenInfo.access_token;
      await axios.post(RevokeTokenEndPoint, { token: accessToken });
      localStorage.removeItem("access_token"); // Remove the access token from localStorage after revoking
    } catch (error) {
      console.error("Error revoking token", error);
      throw error;
    }
  };


    const { logout } = useAuth();

    const handleLogout = () => {
      revokeToken();
        logout()
    }
    return (
      <div className='top-section'>
          <div className="header w-100 justify-content-between p-1 fixed-top">
        <div className="logo-section d-flex flex-row align-items-center">
         
          <img
            src={imageTheia}
            alt="imageTheia"
            className="ml-3"
            onClick={goToLanding}
            style={{ height: "50px", cursor: "pointer" }}
          />
        </div>

        <div className="d-flex flex-row align-items-center">
         
          <span
            className="ml-3 topbar-text"
            onClick={() => gotoDashboardView()}
            style={{ cursor: "pointer" }}
          >
            Dashboard
          </span>

          <div className="vertical-line ml-3"></div>

          <span
            className="ml-3 topbar-text"
            onClick={() => gotoInSightsView()}
            style={{ cursor: "pointer" }}
          >
            Insights
          </span>

          <div className="vertical-line ml-3"></div>

          <span className="ml-3 topbar-text"
          onClick={gotToHelpQA}
          style={{ cursor: "pointer" }}>
            Help & FAQ
          </span>

          <div className="user-account" style={{ display: "flex" }}>
            <div
              className="ml-3 topbar-text"
              style={{ marginTop: "3px", marginRight: "5px" }}
            >
              {localStorage.getItem("userName")}
            </div>

            <div>
            <FaUserCheck size={25}/>

              <img
                style={{ marginLeft: "10px", cursor: "pointer" }}
                src={signOut}
                onClick={() => handleLogout()}
                alt="User Icon"
              />
            </div>
          </div>
        </div>
      </div>
      </div>

    )
}

export default Topbar;