import React, { Component } from 'react'

export default class FileName extends Component {
  render() {
    return <div>unauthorised</div>
  }
}