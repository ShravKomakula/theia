import React, { useState } from "react";
import { Card, Container, Row, Col, Tab } from "react-bootstrap";
import "./index.css";
import binoculars from "../../assets/images/Binoculars.svg";
import coinsIcon from "../../assets/images/Coins.svg";
import FirstAidIcon from "../../assets/images/FirstAid.svg";
import globalicon from "../../assets/images/GlobeHemisphereEast.svg";
import worldIcon from "../../assets/images/world.svg";
import drugIcon from "../../assets/images/Pill.svg";
import handshakeIcon from "../../assets/images/Handshake.svg";
import downArrow from "../../assets/images/dropdownArrow.svg";
import search from "../../assets/images/MagnifyingGlass (3).svg";

const Impacts = ({ onCardClick }) => {
  const [cards, setCards] = useState([
    {
      id: 1,
      title: "Advances in Migraine Management",
      partner: "Partnered with American Institute",
      grantType: "Education",
      totalBudget: "$90,000",
      clinicalArea: "Migraine",
      geography: "United States",
      description:
        "Projects that will be considered for Pfizer support will focus on improving the care, management, and outcomes of adult patients with migraine by supporting healthcare professional education on topics including:",
      objectives: [
        "Unmet need and disease burden associated with migraine The role of CGRP in the pathophysiology of migraine",
        "CGRP receptor antagonists in the acute treatment of migraine and preventive treatment of episodic migraine",
        "The diagnosis and management of migraine in the primary care, women’s health and emergent care settings (focus on acute treatment and prevention of episodic migraine)",
        "Raising awareness of opportunities to improve the quality of migraine treatment across diverse patient populations • Addressing healthcare disparities in migraine diagnosis, management and treatment",
      ],
      icons: {
        grantType: binoculars,
        totalBudget: coinsIcon,
        clinicalArea: FirstAidIcon,
        geography: globalicon,
      },
    },
    {
      id: 2,
      title: "Transthyretin Cardiac  Amyloidosis Fellowship",
      partner: "Partnered with American Institute",
      grantType: "Fellowship",
      totalBudget: "$90,000",
      clinicalArea: "ATTR cardiac amyloidosis",
      geography: "United States",
      description:
        "It is our intent to support institutions with fellowship programs for Cardiologists or Heart Failure  Advanced Practice Providers that have a strong focus on clinical practice, research, and education to  further the understanding of ATTR cardiac amyloidosis.",

      objectives: [
        "Unmet need and disease burden associated with migraine The role of CGRP in the pathophysiology of migraine",
        "CGRP receptor antagonists in the acute treatment of migraine and preventive treatment of episodic migraine",
        "The diagnosis and management of migraine in the primary care, women’s health and emergent care settings (focus on acute treatment and prevention of episodic migraine)",
        "Raising awareness of opportunities to improve the quality of migraine treatment across diverse patient populations • Addressing healthcare disparities in migraine diagnosis, management and treatment",
      ],
      icons: {
        grantType: binoculars,
        totalBudget: coinsIcon,
        clinicalArea: FirstAidIcon,
        geography: globalicon,
      },
    },
    /*  {
      id: 3,
      title: "Advances in Migraine Management",
      partner: "Partnered with American Institute",
      grantType: "Education",
      totalBudget: "$90,000",
      clinicalArea: "Migraine",
      geography: "United States",
      description:
        "Projects that will be considered for Pfizer support will focus on improving the care, management, and outcomes of adult patients with migraine by supporting healthcare professional education on topics including:",
      objectives: [
        "Unmet need and disease burden associated with migraine The role of CGRP in the pathophysiology of migraine",
        "CGRP receptor antagonists in the acute treatment of migraine and preventive treatment of episodic migraine",
        "The diagnosis and management of migraine in the primary care, women’s health and emergent care settings (focus on acute treatment and prevention of episodic migraine)",
        "Raising awareness of opportunities to improve the quality of migraine treatment across diverse patient populations • Addressing healthcare disparities in migraine diagnosis, management and treatment",
      ],
      icons: {
        grantType: binoculars,
        totalBudget: coinsIcon,
        clinicalArea: FirstAidIcon,
        geography: globalicon,
      },
    },
    {
      id: 4,
      title: "Advances in Migraine Management",
      partner: "Partnered with American Institute",
      grantType: "Education",
      totalBudget: "$90,000",
      clinicalArea: "Migraine",
      geography: "United States",
      description:
        "Projects that will be considered for Pfizer support will focus on improving the care, management, and outcomes of adult patients with migraine by supporting healthcare professional education on topics including:",
      objectives: [
        "Unmet need and disease burden associated with migraine The role of CGRP in the pathophysiology of migraine",
        "CGRP receptor antagonists in the acute treatment of migraine and preventive treatment of episodic migraine",
        "The diagnosis and management of migraine in the primary care, women’s health and emergent care settings (focus on acute treatment and prevention of episodic migraine)",
        "Raising awareness of opportunities to improve the quality of migraine treatment across diverse patient populations • Addressing healthcare disparities in migraine diagnosis, management and treatment",
      ],
      icons: {
        grantType: binoculars,
        totalBudget: coinsIcon,
        clinicalArea: FirstAidIcon,
        geography: globalicon,
      },
    }, */
  ]);
  const [activeButton, setActiveButton] = useState("yourGrants");

  const handleButtonClick = (buttonName) => {
    setActiveButton(buttonName);
  };
  return (
    <>
      <Col xs={12} md={6} className="p-2">
        <div>
          <span
            className={`btn ${
              activeButton === "yourGrants"
                ? "btn-add-Grant-actives"
                : "btn-add-projects"
            }`}
            onClick={() => handleButtonClick("yourGrants")}
          >
            {activeButton === "yourGrants" ? <div class="dot"></div> : <></>}
            Request for Proposal
          </span>
          <span
            className={`btn ${
              activeButton === "pendingApprovals"
                ? "btn-add-Grant-actives"
                : "btn-add-projects"
            }`}
            onClick={() => handleButtonClick("pendingApprovals")}
          >
            {activeButton === "pendingApprovals" ? (
              <div class="dot"></div>
            ) : (
              <></>
            )}
            Non Request for Proposal
          </span>
        </div>
      </Col>
      <Card className="card-box-area mb-3 mt-3">
        <Card.Body className="card-content-wap d-flex justify-content-between p-2">
          <Col xs={12} md={4} lg={4}>
            <div>
              <Card.Text>
                <h6>
                  <img
                    src={worldIcon}
                    className="p-1"
                    width={"35px"}
                    alt="location icon"
                  />
                  Explore Location
                </h6>
              </Card.Text>
              <div className="search-container p-2">
                <div className="search-wrapper">
                  <img src={search} alt="Search Icon" className="search-icon" />
                  <input
                    className="col-12 col-md-12 col-lg-12 search-input"
                    type="text"
                    placeholder="Search"
                  ></input>
                </div>
              </div>
            </div>
          </Col>
          <Col xs={12} md={4} lg={4}>
            <div>
              <Card.Text>
                <h6>
                  <img
                    src={drugIcon}
                    className="p-1"
                    width={"35px"}
                    alt="medicine icon"
                  />
                  Explore Disease or Drugs
                </h6>
              </Card.Text>
              <div className="search-container p-2">
                <div className="search-wrapper">
                  <img src={search} alt="Search Icon" className="search-icon" />
                  <input
                    className="col-12 col-md-12 col-lg-12 search-input"
                    type="text"
                    placeholder="Search"
                  ></input>
                </div>
              </div>
            </div>
          </Col>
          <Col xs={12} md={4} lg={4}>
            <div>
              <Card.Text>
                <h6>
                  <img
                    src={handshakeIcon}
                    className="p-1"
                    width={"35px"}
                    alt="handshake icon"
                  />
                  Explore by Partner
                </h6>
              </Card.Text>
              <div className="search-container p-2">
                <div className="search-wrapper">
                  <img src={search} alt="Search Icon" className="search-icon" />
                  <input
                    className="col-12 col-md-12 col-lg-12 search-input"
                    type="text"
                    placeholder="Search"
                  ></input>
                </div>
              </div>
            </div>
          </Col>
        </Card.Body>
      </Card>
      <Row>
        {cards.map((card) => (
          <Col xs="12" lg="6" md="6" key={card.id} className="mb-4 d-flex ">
            <Card className="card-radius" onClick={() => onCardClick(card.id)}>
              <Card.Title className="d-flex justify-content-between align-items-center cardtab-header">
                <h5>{card.title}</h5>
                <span className="item-navtab-menu">{card.partner}</span>
              </Card.Title>
              <Card.Body>
                <Container>
                  <Row className="mb-3">
                    <Col>
                      <div className="d-flex align-items-center">
                        <img
                          src={card.icons.grantType}
                          alt="Grant Type Icon"
                        ></img>
                        <div className="pl-2">
                          <div className="card-text-heading">Grant Type</div>
                          <div className="card-text-ans">{card.grantType}</div>
                        </div>
                      </div>
                    </Col>
                    <Col>
                      <div className="d-flex align-items-center">
                        <img
                          src={card.icons.totalBudget}
                          alt="Total Budget Icon"
                        ></img>
                        <div className="pl-2">
                          <div className="card-text-heading">Total Budget</div>
                          <div className="card-text-ans">
                            {card.totalBudget}
                          </div>
                        </div>
                      </div>
                    </Col>
                  </Row>
                  <Row className="mb-3">
                    <Col>
                      <div className="d-flex align-items-center">
                        <img
                          src={card.icons.clinicalArea}
                          alt="Clinical Area Icon"
                        ></img>
                        <div className="pl-2">
                          <div className="card-text-heading">Clinical Area</div>
                          <div className="card-text-ans">
                            {card.clinicalArea}
                          </div>
                        </div>
                      </div>
                    </Col>
                    <Col>
                      <div className="d-flex align-items-center">
                        <img
                          src={card.icons.geography}
                          alt="Geography Icon"
                        ></img>
                        <div className="pl-2">
                          <div className="card-text-heading">Geography</div>
                          <div className="card-text-ans">{card.geography}</div>
                        </div>
                      </div>
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                      <Card className="p-2 card-sub-container">
                        <Card.Title>Objectives</Card.Title>
                        <Card.Text>{card.description}</Card.Text>
                        <ul>
                          {card.objectives.map((objective, index) => (
                            <li key={index}>{objective}</li>
                          ))}
                        </ul>
                      </Card>
                    </Col>
                  </Row>
                  <Row className="d-flex justify-content-between align-items-center mt-3 padding-row-card">
                    <Col md="3">
                      <div className="card-text-heading">Org Name</div>
                      <div className="card-text-ans">Pfizer</div>
                    </Col>
                    <Col md="3">
                      <div className="card-text-heading">Project Title</div>
                      <div className="card-text-ans">Grant Req</div>
                    </Col>
                    <Col md="3">
                      <div className="card-text-heading">PI Name</div>
                      <div className="card-text-ans">JohnDoe</div>
                    </Col>
                  </Row>
                  <Row className="d-flex justify-content-between align-items-center mt-3 ">
                    <Col className="pending m-2 d-flex justify-content-between align-items-center">
                      <p className="text-muted">Approval Rate</p>
                      <p className="">108</p>
                    </Col>
                    <Col className="pending m-2 d-flex justify-content-between align-items-center">
                      <p className="text-muted">Publications</p>
                      <p className="">54</p>
                    </Col>
                  </Row>
                </Container>
              </Card.Body>
            </Card>
          </Col>
        ))}
      </Row>
    </>
  );
};

export default Impacts;
