import React, { useEffect, useState } from "react";
import { overviewEndpoint } from "../../common/api-config";
import "./Dashboard.css";

import { HiArrowTrendingUp } from "react-icons/hi2";
import icon1 from "../../assets/icon1.svg";
import icon2 from "../../assets/icon2.svg";
import icon3 from "../../assets/icon3.svg";
import icon4 from "../../assets/icon4.svg";
import icon5 from "../../assets/icon5.svg";
import icon6 from "../../assets/icon6.svg";

const formatNumber = (number) => {
  if (number >= 1000000000) {
    return (number / 1000000000).toFixed(1) + "B";
  }
  if (number >= 1000000) {
    return (number / 1000000).toFixed(1) + "M";
  }
  return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
};

const Overview = () => {
  const [overviewData, setOverviewData] = useState(null); // State for overview data

  useEffect(() => {
    fetchOverviewData(); // Fetch overview data
  }, []);

  const fetchOverviewData = async () => {
    try {
      const response = await fetch(overviewEndpoint()); // Adjust the API endpoint as needed
      const result = await response.json();
      setOverviewData(result[0]); // Assuming the result is an array with one object
    } catch (error) {
      console.error("Error fetching overview data:", error);
    }
  };

  return (
    <div className="card-section">
      <div className="cards-container">
        {[
          { title: "Total Submissions", icon: icon1, key: "SUBMISSIONS" },
          { title: "Approvals", icon: icon2, key: "APPROVALS" },
          { title: "Total Granted", icon: icon3, key: "TOTAL_GRANTED", prefix: "$", isDollar: true },
          { title: "HCP Impacted", icon: icon4, key: "HCP_IMPACTED" },
          { title: "Patients Impacted", icon: icon5, key: "PATIENT_IMPACTED" },
          { title: "Learners Impacted", icon: icon6, key: "LEARNER_IMPACTED" },
        ].map((card, index) => (
          <div key={index} className="card card1">
            <div className="card-header">
              <span>{card.title}</span>
              <img src={card.icon} alt={card.title} width={30} height={30} />
            </div>
            <div className="card-content">
              <span className="totalvalue">
                {overviewData
                  ? card.isDollar
                    ? `${card.prefix}${formatNumber(overviewData[card.key])}`
                    : formatNumber(overviewData[card.key])
                  : "Loading..."}
              </span>
              {/*  <div className="change">
                <span>
                  <b>
                    <HiArrowTrendingUp size={20} /> &nbsp; 85%
                  </b>{" "}
                  Up from Last Month
                </span>
              </div> */}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Overview;
