import React, { useState } from "react";
import "./TileView.css"; // Your CSS file for styling
import totalpayment from "../../assets/totalpayment.svg";
import pendingpayment from "../../assets/pendingpayment.svg";
import method from "../../assets/method.svg";
import disease from "../../assets/disease.svg";
import drug from "../../assets/drug.svg";
import duration from "../../assets/durations.svg";

import location from "../../assets/location.svg";
import { IoIosArrowDropdownCircle } from "react-icons/io";
import { GoDotFill } from "react-icons/go";
const ITEMS_PER_PAGE = 3; // Number of items to display per page
// Define a function to get the background color based on the status
const getStatusColor = (status) => {
  switch (status) {
    case 'Pending':
      return '#FFC000';
    case 'Rejected':
    case 'Canceled':
    case 'Terminated – Post Approval':
      return '#FFA18B';
    case 'Review':
    case 'Sent to Org':
    case 'Other contracting status':
      return '#CCFF99';
    case 'Approved':
      return '#C5E0B4';
    case 'Completed':
      return '#3366FF';
    default:
      return '#FFFFFF'; // default color if status doesn't match any case
  }
};

const TileView = ({ status,data }) => {
  // Get the background color for the current status
  const backgroundColor = getStatusColor(status);

  console.log("TileView data:", data); // Check data received
  // Rest of the component code

  const [currentPage, setCurrentPage] = useState(0);

  // Filter the data based on the user's country code
  const filteredData = data;

  const startIndex = currentPage * ITEMS_PER_PAGE;
  const endIndex = startIndex + ITEMS_PER_PAGE;
  const currentItems = filteredData.slice(startIndex, endIndex);

  const [expandedCard, setExpandedCard] = useState(null);
  const toggleCard = (index) => {
    setExpandedCard(expandedCard === index ? null : index);
  };

  const handlePrev = () => {
    setCurrentPage((prevPage) => Math.max(prevPage - 1, 0));
  };

  const handleNext = () => {
    setCurrentPage((prevPage) =>
      Math.min(
        prevPage + 1,
        Math.ceil(filteredData.length / ITEMS_PER_PAGE) - 1
      )
    );
  };

  const handleOutcomeReportClick = async (document_Key) => {
    if (!document_Key) {
      alert("No outcome report available");
      return;
    }

    try {
      // Extracting the filename from the document key
      const filename = document_Key.replace("s3://gmg-llm-poc/", "");

      const response = await fetch(
        `http://127.0.0.1:8055/outcomereport/${filename}`,
        {
          method: "GET",
          headers: {
            Accept:
              "application/pdf, application/vnd.openxmlformats-officedocument.wordprocessingml.document, application/vnd.openxmlformats-officedocument.presentationml.presentation, application/msword, application/vnd.ms-excel, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, text/csv",
          },
        }
      );

      if (response.ok) {
        const contentType = response.headers.get("content-type");

        const blob = await response.blob();
        const url = URL.createObjectURL(blob);

        // Check if the content type indicates a document type
        if (
          contentType.includes("application/pdf") ||
          contentType.includes(
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
          ) ||
          contentType.includes(
            "application/vnd.openxmlformats-officedocument.presentationml.presentation"
          ) ||
          contentType.includes("application/msword") ||
          contentType.includes("application/vnd.ms-excel") ||
          contentType.includes(
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
          ) ||
          contentType.includes("text/csv") ||
          contentType.includes("application/vnd.ms-powerpoint")
        ) {
          // Render the document in a new tab
          window.open(url, "_blank");
        } else if (contentType.includes("text/html")) {
          // Show the HTML content in a new tab
          window.open(url, "_blank");
        } else {
          console.error("Unsupported document type:", contentType);
          alert("Unsupported document type");
        }
      } else {
        console.error("Error fetching document URL:", response.status);
        alert("No outcome report available");
      }
    } catch (error) {
      console.error("Error:", error);
      alert("An error occurred while fetching the outcome report");
    }
  };

  return (
    <>
      <div className="tile-container">
        {currentItems.map((item, index) => (
          <div
            key={index}
            className="card"
            style={{
              width: "100%",
              padding: "10px",
              borderRadius: "10px",
              border: "none",
              marginBottom: "20px",
            }}
          >
            <div className="card-body tile-body">
              {/* 1st row */}
              <div className="row align-items-center">
                <div className="col-1 logo">
                  {/* Logo */}
                  {item.LOGO_URL  ? (
                    <img
                      src={item.LOGO_URL}
                      alt="Logo"
                      style={{ width: "100%" }}
                    />
                  ) : (
                    <img src={item[15]} alt="Logo" style={{ width: "100%" }} />
                  )}
                </div>
                <div className="col-6 project-title">
                  {/* Project Title */}
                  <p>
                    {item.PROJECT_TITLE ? item.PROJECT_TITLE : item[1]}<br />
                    #{item.REQUEST_ID ? item.REQUEST_ID:item[0]} .&nbsp;{item.ORGANIZATION_NAME ?item.ORGANIZATION_NAME:item[6]}
                  </p>
                </div>
                <div className="col-1.5 location">
               
  <p>
    <img
      src={location}
      alt="location"
      style={{ width: "20px", marginRight: "5px" }}
    />
    {item[26] && item[27] ? (
      <>
        {item[26]}&nbsp;,&nbsp;{item[27]}
      </>
    ) : (
      <>
        {item.CITY}&nbsp;,&nbsp;{item.COUNTRY}
      </>
    )}
  </p>
</div>
<div className="col-1.5 status-text" >
                  <p className="grant-status" style={{ backgroundColor: getStatusColor(item.DISPOSITION_GRANT_STATUS || item[36]) }}>
                    {item.DISPOSITION_GRANT_STATUS ? item.DISPOSITION_GRANT_STATUS : item[36]}
                  </p>
                </div>

              </div>

              {/* 2nd row */}
           
<div className="row align-items-center secondrow">
  {/* Total Payment */}
  <div className="col-1.5">
    <div className="d-flex align-items-center">
      <img
        src={totalpayment}
        alt="total payment"
        className="tileicon"
      />
      <span>
        Grant Amount: <br />
        ${item.APPROVED_AMOUNT} {item[3]}
      </span>
    </div>
  </div>

  {/* Pending Payment */}
  <div className="col-1.5">
    <div className="d-flex align-items-center">
      <img
        src={pendingpayment}
        alt="pending payment"
        className="tileicon"
      />
      <span>
        Pending : <br />
        ${item.PAYMENT_REMAINING} {item[4]}
      </span>
    </div>
  </div>

  {/* Method */}
  <div className="col-2">
    <div className="d-flex align-items-center">
      <img src={method} alt="method" className="tileicon" />
      <span>
        Type: <br />
        {item.PROPOSAL_TYPE} {item[19]}
      </span>
    </div>
  </div>

  {/* Disease */}
  <div className="col-2">
    <div className="d-flex align-items-center">
      <img src={disease} alt="disease" className="tileicon" />
      <span>
        Disease: <br />
        {item[18]} {item.PRIMARY_AREA_OF_INTERST_DISEASE}
      </span>
    </div>
  </div>

   {/* Drug Name */}
{(item.PROPOSAL_TYPE === 'Research Grant' || item[19] === 'Research Grant') && (
  <div className="col-2">
    <div className="d-flex align-items-center">
      <img src={drug} alt="drug" className="tileicon" />
      <span>
        Drug Name: <br />
        {item[20]} {item.PRIMARY_PFIZER_DRUG}
      </span>
    </div>
  </div>
)}

 

  {/* Duration */}
  <div className="col-2">
    <div className="d-flex align-items-center">
      <img src={duration} alt="duration" className="tileicon" />
      <span>
        Duration: <br />
        {item[21]} {item.DURATION}
      </span>
    </div>
  </div>
</div>

              {/* 3rd row */}
              <div className="row align-items-center">
                {/* Study Design */}
                {!(
                  item.PROPOSAL_TYPE === "Medical Education" ||
                  item.PROPOSAL_TYPE === "Quality Improvement" ||
                  item[19] === "Medical Education" ||
                  item[19] === "Quality Improvement"
                ) && (
                  <div className="col-4">
                    <div className="input-group-prepend">
                      <span
                        className="input-group-text spanblock"
                        id="inputGroup-sizing-sm"
                      >
                        Study Design
                      </span>
                      <input
                        type="text"
                        className="form-control custom-input studyinput"
                        aria-label="Small"
                        aria-describedby="inputGroup-sizing-sm"
                        value={item[30] || item.Study_Design}
                        readOnly
                      />
                    </div>
                  </div>
                )}

                {/* Population */}
                {!(
                  item.PROPOSAL_TYPE === "Medical Education" ||
                  item.PROPOSAL_TYPE === "Quality Improvement" ||
                  item[19] === "Medical Education" ||
                  item[19] === "Quality Improvement"
                ) && (
                  <div className="col-3">
                    <div className="input-group-prepend">
                      <span
                        className="input-group-text spanblock"
                        id="inputGroup-sizing-sm"
                      >
                        Population
                      </span>
                      <input
                        type="text"
                        className="form-control custom-input studyinput"
                        aria-label="Small"
                        aria-describedby="inputGroup-sizing-sm"
                        value={item[28] || item.Population}
                        readOnly
                      />
                    </div>
                  </div>
                )}

                {/* Patients Enrolled */}
                {!(
                  item.PROPOSAL_TYPE === "Medical Education" ||
                  item.PROPOSAL_TYPE === "Quality Improvement" ||
                  item[19] === "Medical Education" ||
                  item[19] === "Quality Improvement"
                ) && (
                  <div className="col-4">
                    <div className="input-group-prepend">
                      <span
                        className="input-group-text spanblock"
                        id="inputGroup-sizing-sm"
                      >
                        Patients Enrolled
                      </span>
                      <div className="progress" style={{ width: "100%" }}>
                        <div
                          className="progress-bar"
                          role="progressbar"
                          style={{
                            width: item[22] ? `${item[22]}` : "0",
                            backgroundColor: item[22] ? "blue" : "#f3f3f3",
                          }}
                          aria-valuenow={item[22]}
                          aria-valuemin="0"
                          aria-valuemax="10000"
                        >
                          {item[22] ? `${item[22]}` : "0"}
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Additional fields for specific methods */}
                {(item.PROPOSAL_TYPE === "Medical Education" ||
                  item.PROPOSAL_TYPE === "Quality Improvement" ||
                  item[19] === "Medical Education" ||
                  item[19] === "Quality Improvement") && (
                  <>
                    {/* Add your additional fields for Medical Education and Quality Improvement here */}
                    <div className="col-3">
                      {/* Target Learner Group */}
                      <div className="input-group-prepend">
                        <span
                          className="input-group-text spanblock"
                          id="inputGroup-sizing-sm"
                        >
                          Target Learner Group
                        </span>
                        <input
                          type="text"
                          className="form-control custom-input studyinput"
                          aria-label="Small"
                          aria-describedby="inputGroup-sizing-sm"
                          value={item[31] || item.TARGETED_LEARNER_GROUP}
                          readOnly
                        />
                      </div>
                    </div>
                    <div className="col-3">
                      {/* Specialty */}
                      <div className="input-group-prepend">
                        <span
                          className="input-group-text spanblock"
                          id="inputGroup-sizing-sm"
                        >
                          Specialty
                        </span>
                        <input
                          type="text"
                          className="form-control custom-input studyinput"
                          aria-label="Small"
                          aria-describedby="inputGroup-sizing-sm"
                          value={item[32] || item.SPECIALITY}
                          readOnly
                        />
                      </div>
                    </div>
                   
                      {/* Target Learners */}
                      <div className="col-4">
                    <div className="input-group-prepend">
                      <span
                        className="input-group-text spanblock"
                        id="inputGroup-sizing-sm"
                      >
                       Target Learners
                      </span>
                      <div className="progress" style={{ width: "100%" }}>
                        <div
                          className="progress-bar"
                          role="progressbar"
                          style={{
                            width: item[33] ? `${item[33]}` : "0",
                            backgroundColor: item[33] ? "blue" : "#f3f3f3",
                          }}
                          aria-valuenow={item[33]}
                          aria-valuemin="0"
                          aria-valuemax="10000"
                        >
                          {item[33] ? `${item[33]}` : "0"}
                        </div>
                      </div>
                    </div>
                  </div>

                  
                  </>
                )}
              </div>

              {/* 4th row */}
              <div
                className="row align-items-center"
                style={{ paddingTop: "20px" }}
              >
                <div className="col-2 status">
                  {/* Status */}

                  <p>
                    Status Insights : {item[23]}
                    {item.STATUS_INSIGHT}
                  </p>
                </div>
                <div className="col-2 enrollment">
                  {/* Insight */}

                  <p>
                    Enrollment Insight: {item[24]}
                    {item.PATIENT_INSIGHT}
                  </p>
                </div>
                <div className="col-2 upcoming">
                  {/* Completed */}
                  <p>
                    Upcoming: {item[5]} {item.NEXT_MILESTONE}
                  </p>
                </div>
                <div className="col-1.5 link">
                  {/* Outcome Report */}
                  <a
                    href="#"
                    onClick={(e) => {
                      e.preventDefault();
                      handleOutcomeReportClick(item.S3FILENAME || item[34]);
                    }}
                  >
                    Outcome Report{" "}
                  </a>
                </div>
                <div className="col-1.5 link">
  {/* Publication Link */}
  {Array.isArray(item.PUBLICATION_LINK || item[35]) && (item.PUBLICATION_LINK || item[35]).length > 0 ? (
    <div className="dropdown">
      <button
        className="btn btn-link dropdown-toggle"
        type="button"
        id={`dropdownMenuButton-${index}`}
        data-toggle="dropdown"
        aria-haspopup="true"
        aria-expanded="false"
      >
        Publication Links
      </button>
      <div className="dropdown-menu" aria-labelledby={`dropdownMenuButton-${index}`}>
        {(item.PUBLICATION_LINK || item[35]).split(';').map((link, i) => (
          <a
            className="dropdown-item"
            href={link.trim()} // Trim to remove any leading/trailing spaces
            target="_blank"
            rel="noopener noreferrer"
            key={i}
          >
            Link {i + 1}
          </a>
        ))}
      </div>
    </div>
  ) : (item.PUBLICATION_LINK || item[35]) ? (
    <a
      href={(item.PUBLICATION_LINK || item[35]).split(';')[0].trim()} // Extracting the first URL
      target="_blank"
      rel="noopener noreferrer"
    >
      Publication Link
    </a>
  ) : (
    <a
      href="#"
      onClick={(e) => {
        e.preventDefault();
        alert("Publication link not available");
      }}
    >
      Publication Link
    </a>
  )}
</div>


                <div className="col-2 link">
                  <a
                    href="#"
                    onClick={(e) => {
                      e.preventDefault();
                      toggleCard(index);
                    }}
                  >
                    View GenAI Summary <IoIosArrowDropdownCircle />
                  </a>
                </div>
              </div>
              {expandedCard === index && (
                <div className="genAI-Summary">
                  <div className="row">
                    <div className="col-6 leftsummary">
                      <h6>
                        <GoDotFill className="icon-blue" /> Research Summary
                      </h6>
                      <p>
                        Research Summary Current therapies for Transthyretin
                        amyloidosis (ATTR) target the misfolded protein but do
                        not address tissue damage by the already deposited
                        amyloid. We have demonstrated that increased abundance
                        of proteins within cardiac (and renal) amyloid plaques
                        is associated with improved outcomes, which suggests
                        that the amount of deposited proteins, may merely be a
                        surrogate for indolent disease biology.
                      </p>
                      <div className="btn-group buttonblock">
                        <button
                          type="button"
                          className="btn bluebg mr-2 rounded-pill"
                        >
                          Data Gaps
                        </button>
                        <button
                          type="button"
                          className="btn bluebg mr-2 rounded-pill"
                        >
                          Health Quality
                        </button>
                        <button
                          type="button"
                          className="btn bluebg mr-2 rounded-pill"
                        >
                          Digital Health & AI
                        </button>
                        <button
                          type="button"
                          className="btn greenbg rounded-pill"
                        >
                          Higher Learners Reached
                        </button>
                      </div>
                    </div>
                    <div className="col-5 rightsummary">
                      <h6>
                        <GoDotFill className="icon-blue" /> Outcomes Heilights
                      </h6>
                      <p>
                        Current therapies for Transthyretin amyloidosis (ATTR)
                        target the misfolded protein but do not address tissue
                        damage by the already deposited amyloid. We have
                        demonstrated that increased abundance of proteins within
                        cardiac (and renal) amyloid plaques is associated with
                        improved outcomes, which suggests that the amount of
                        deposited proteins, may merely be a surrogate for
                        indolent disease biology.
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
      {/* Pagination Controls */}
      <div className="pagination-controls">
        <button onClick={handlePrev} disabled={currentPage === 0}>
          Prev
        </button>
        <button onClick={handleNext} disabled={endIndex >= filteredData.length}>
          Next
        </button>
      </div>
    </>
  );
}

export default TileView;
