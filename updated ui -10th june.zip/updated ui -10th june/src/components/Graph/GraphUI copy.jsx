import React, { useEffect, useMemo, useState } from 'react'
import {
    Container, Grid, Flex, Card, Image,
    Text, Group, Button,
    TextInput, Popover, Stack, Checkbox
} from '@mantine/core';
import styled from '@emotion/styled'
import { getGraphDataCount, getOrganization } from '../../services/DashboardService'
import vectorSvg from '../../assets/svg/Vector.svg'
import ReactFlow, {
    Controls,
    Background,
    BackgroundVariant,
    MiniMap,
    useNodesState,
    useEdgesState,
    MarkerType,
} from 'reactflow';

import ElkNode from './ReactFlowGraph/ElkNode';
// import { nodes as initNodes } from './ReactFlowGraph/nodes';
// import { edges as initEdges } from './ReactFlowGraph/edges';
import useLayoutNodes from './ReactFlowGraph/useLayoutNodes';
import NodeProperty from './NodeProperty';
import '@mantine/charts/styles.css';
import 'reactflow/dist/style.css';
import './ReactFlowGraph/index.css'
import SummaryDetail from './SummaryDetail';

const StyleSearchBarBox = styled(Card.Section)`
    /* height: 90px; */
    /* display: flex; */
    background: linear-gradient(90deg, rgba(43, 1, 190, 0.05) 0%, rgba(1, 144, 255, 0.05) 100%);
    .goback-text {
        font-family: 'Noto Sans', sans-serif !important;
        font-size: 16px;
        font-weight: 400;
        line-height: 24px;
        text-align: center;
        color: #16161699;
    }
    .flex {
        align-items: center;
        justify: center;
        align: center
        direction: row
        wrap: wrap
    }
    .filter-selection {
        width: auto;
        padding: 8px;
        /* gap: 40px; */
        border-radius: 8px;
        border: 1px;
        display: flex;
        justify: space-between;
        align-content: space-between;
        flex-flow: row wrap;
        opacity: 10px;
        background: #FFFFFF;
        border: 1px solid #0000001A
    }
    .text-filter {
        font-family: 'Noto Sans', sans-serif !important;
        font-size: 14px;
        font-weight: 400;
        color: #00000099;
    }
    .text-filter-clear {
        font-family: 'Noto Sans', sans-serif !important;
        font-size: 16px;
        font-weight: 400;
        line-height: 20px;
        text-align: center;
        color: #0190FF;
    }
`

const StyleSearchInput = styled(TextInput)`
    width: 550px;
    border-radius: 12px;
    border: 1px;
    opacity: 0px;
`

const graphNodeLabel = {
    'publication': {'node': 'Publication', 'edge': 'Published'},
    'association': {'node': 'Association', 'edge': 'Associated_IN'},
    'digitalreachfocusarea': {'node': 'Digital Reach Focus Area', 'edge': 'Has_Digital_Reach'},
    'scientificfocusarea': {'node': 'Scientific Focus Area', 'edge': 'Has_Digital_Reach'},
    'speciality': {'node': 'Speciality', 'edge': 'Has_Speciality'},
    'medicalevent': {'node': 'Medical Event', 'edge': 'Attended'},
    'company': {'node': 'Company', 'edge': 'Payed'},
    'payment': {'node': 'Payment', 'edge': 'Received'},
    'organization': {'node': 'Organization', 'edge': 'Conducted at'},
    'trial': {'node': 'Trial', 'edge': 'Refers_to'},
    'trialwork': {'node': 'Trial Work', 'edge': 'Executed'},
    'country': {'node': 'Country', 'edge': 'Located In'},
    'location': {'node': 'Location', 'edge': 'Located at'},
}

const graphNodeLinking = {
    'main': {
        'sourceHandles': [],
        'targetHandles': []
    } 
}

const graphNodeStyle = {
    // padding: '13.17px',
    // gap: '13.17px',
    borderRadius: '6.58px',
    border: 'rgba(0, 0, 0, 0.1)',
    stroke: '#fff', 
    color: '#0041d0',
    borderColor: '#0041d0',
    backgroundColor: 'rgba(255, 255, 255, 1)', 
    boxShadow: '0px 3.29px 13.17px 0px #0000001A'
}

const GraphUI = () => {
    const [graphCntQryData, setGraphCntQryData] = useState({});
    const [nodes, setNodes, onNodesChange] = useNodesState([]);
    const [edges, setEdges, onEdgesChange] = useEdgesState([]);
    const [isSidebarOpen, setIsSidebarOpen] = useState(false);
    const [selectedFilters, setSelectedFilters] = useState([]);
    const [selectedFilterCount, setSelectedFilterCount] = useState(0);
    const proOptions = { hideAttribution: true };

    useEffect(() => {
        const resp = getGraphDataCount('Felicia Cosman');
        resp.then((resp) => {
            if (resp && resp.results && resp.results[0]?.data.length > 0) {
                setGraphCntQryData(resp.results[0].data[0]['row'][0]);
            }
        })
    }, [])

    useEffect(() => {
        if(Object.keys(graphCntQryData).length > 0) {
            let graphNodes = [];
            let graphEdges = [];
            let mainSourceHandler = [];
            let cnt = 0;
            let edgeCnt = 0;
            for(const [key, value] of Object.entries(graphNodeLabel)) {
                let sourceNode = 'main';
                let sourcePosition = 'left';
                let sourceHandles = [];
                let targetHandles = [];
                if(key === 'payment') {
                    targetHandles = [{id: `${key}-target-main`}, {id: `${key}-target-company`}];
                    sourceHandles = [{id: `trial-source-${key}`}];
                    sourceNode = 'main';
                    mainSourceHandler.push({id:`${key}-source-${sourceNode}`});
                    graphEdges[edgeCnt] = {
                        id: `${key}-${sourceNode}`,
                        source: sourceNode,
                        sourceHandle: `${key}-source-${sourceNode}`,
                        target: key,
                        targetHandle: `${key}-target-${sourceNode}`,
                        type: 'smoothstep',
                        markerEnd: {
                            type: MarkerType.Arrow,
                        },
                        label: `${value['edge']}`,
                        updatable: 'source',
                        position: { x: 0, y: 0 },
                        // animated: true,
                        // style: { stroke: '#fff' },
                    }
                    edgeCnt++;
                    sourceNode = 'company';
                    graphEdges[edgeCnt] = {
                        id: `${key}-${sourceNode}`,
                        source: sourceNode,
                        sourceHandle: `${key}-source-${sourceNode}`,
                        target: key,
                        targetHandle: `${key}-target-${sourceNode}`,
                        type: 'smoothstep',
                        markerEnd: {
                            type: MarkerType.Arrow,
                        },
                        label: `${value['edge']}`,
                        updatable: 'source',
                        position: { x: 0, y: 0 },
                        // animated: true,
                        // style: { stroke: '#fff' },
                    }
                    edgeCnt++;
                } else if(key === 'trial') {
                    sourceNode = 'payment';
                    sourceHandles = [{id:`trialwork-source-${key}`}];
                    targetHandles = [{id:`${key}-target-${sourceNode}`}];
                    graphEdges[edgeCnt] = {
                        id: `${key}-${sourceNode}`,
                        source: sourceNode,
                        sourceHandle: `${key}-source-${sourceNode}`,
                        target: key,
                        targetHandle: `${key}-target-${sourceNode}`,
                        type: 'smoothstep',
                        markerEnd: {
                            type: MarkerType.Arrow,
                        },
                        label: `${value['edge']}`,
                        updatable: 'source',
                        position: { x: 0, y: 0 },
                        // animated: true,
                        // style: { stroke: '#fff' },
                    }
                    edgeCnt++;
                } else if(key === 'trialwork') {
                    sourceNode = 'trial';
                    // sourceHandles = [{id:`payment-source-${key}`}];
                    targetHandles = [{id:`${key}-target-main`}, {id:`${key}-target-${sourceNode}`}, {id:`organization-target-${key}`}];
                    graphEdges[edgeCnt] = {
                        id: `${key}-${sourceNode}`,
                        source: sourceNode,
                        sourceHandle: `${key}-source-${sourceNode}`,
                        target: key,
                        targetHandle: `${key}-target-${sourceNode}`,
                        type: 'smoothstep',
                        markerEnd: {
                            type: MarkerType.Arrow,
                        },
                        label: `${value['edge']}`,
                        updatable: 'source',
                        position: { x: 0, y: 0 },
                        // animated: true,
                        // style: { stroke: '#fff' },
                    }
                    edgeCnt++;
                    sourceNode = 'main';
                    mainSourceHandler.push({id:`${key}-source-${sourceNode}`});
                    graphEdges[edgeCnt] = {
                        id: `${key}-${sourceNode}`,
                        source: sourceNode,
                        sourceHandle: `${key}-source-${sourceNode}`,
                        target: key,
                        targetHandle: `${key}-target-${sourceNode}`,
                        type: 'smoothstep',
                        markerEnd: {
                            type: MarkerType.Arrow,
                        },
                        label: `${value['edge']}`,
                        updatable: 'source',
                        position: { x: 0, y: 0 },
                        // animated: true,
                        // style: { stroke: '#fff' },
                    }
                    edgeCnt++;
                } else if(key === 'organization') {
                    targetHandles = [];
                    sourceNode = 'trialwork';
                    sourceHandles = [{id:`${key}-source-trialwork`}, {id:`${key}-source-location`}, {id:`location-source-${key}`}];
                    targetHandles = [{id:`location-target-organization`}];
                    graphEdges[edgeCnt] = {
                        id: `${key}-${sourceNode}`,
                        source: sourceNode,
                        sourceHandle: `${key}-source-${sourceNode}`,
                        target: key,
                        targetHandle: `${key}-target-${sourceNode}`,
                        type: 'smoothstep',
                        markerEnd: {
                            type: MarkerType.Arrow,
                        },
                        label: `${value['edge']}`,
                        updatable: 'source',
                        position: { x: 0, y: 0 },
                        // animated: true,
                        // style: { stroke: '#fff' },
                    }
                    edgeCnt++;
                } else if(key === 'company') {
                    sourceHandles = [{id:`payment-source-${key}`}];
                    targetHandles = [];
                } else if(key === 'location') {
                    sourceHandles = [{id:`country-source-${key}`}];
                    targetHandles = [{id:`country-target-${key}`}];
                    sourceNode = 'organization';
                    graphEdges[edgeCnt] = {
                        id: `${key}-${sourceNode}`,
                        source: sourceNode,
                        sourceHandle: `${key}-source-${sourceNode}`,
                        target: key,
                        targetHandle: `${key}-target-${sourceNode}`,
                        type: 'smoothstep',
                        markerEnd: {
                            type: MarkerType.Arrow,
                        },
                        label: `${value['edge']}`,
                        updatable: 'source',
                        position: { x: 0, y: 0 },
                        // animated: true,
                        // style: { stroke: '#fff' },
                    }
                    edgeCnt++;
                } else if(key === 'country') {
                    sourceHandles = [];
                    targetHandles = [{id:`${key}-target-location`}];
                    sourceNode = 'location';
                    graphEdges[edgeCnt] = {
                        id: `${key}-${sourceNode}`,
                        source: sourceNode,
                        sourceHandle: `${key}-source-${sourceNode}`,
                        target: key,
                        targetHandle: `${key}-target-${sourceNode}`,
                        type: 'smoothstep',
                        markerEnd: {
                            type: MarkerType.Arrow,
                        },
                        label: `${value['edge']}`,
                        updatable: 'source',
                        position: { x: 0, y: 0 },
                        // animated: true,
                        // style: { stroke: '#fff' },
                    }
                    edgeCnt++;
                } else {
                    sourceNode = 'main';
                    targetHandles = [{id: `${key}-target-${sourceNode}`}];
                    mainSourceHandler.push({id:`${key}-source-${sourceNode}`});
                    graphEdges[edgeCnt] = {
                        id: `${key}-${sourceNode}`,
                        source: sourceNode,
                        sourceHandle: `${key}-source-${sourceNode}`,
                        target: key,
                        targetHandle: `${key}-target-${sourceNode}`,
                        type: 'smoothstep',
                        markerEnd: {
                            type: MarkerType.Arrow,
                        },
                        label: `${value['edge']}`,
                        updatable: 'source',
                        position: { x: 0, y: 0 },
                        // animated: true,
                        // style: { stroke: '#fff' },
                    }
                    edgeCnt++;
                }
                graphNodes[cnt] = {
                    id: key,
                    data: {
                      label: `${value['node']}(${graphCntQryData[key] ?? 0})`,
                      // we need unique ids for the handles (called 'ports' in elkjs) for the layouting
                      // an id is structured like: nodeid-source/target-id
                      sourceHandles: sourceHandles,
                      targetHandles: targetHandles,
                    },
                    position: { x: 0, y: 0 },
                    type: 'elk',
                    sourcePosition: sourcePosition,
                    style: graphNodeStyle,
                }
                cnt++;
            }
            setNodes([{
                id: 'main',
                data: {
                  label: 'Silvio Danese, MD,Phd, Neuro specialist',
                  // we need unique ids for the handles (called 'ports' in elkjs) for the layouting
                  // an id is structured like: nodeid-source/target-id
                  sourceHandles: mainSourceHandler ?? [],
                  targetHandles: [],
                },
                position: { x: 0, y: 0 },
                type: 'elk',
                sourcePosition: 'right',
                style: {
                  // padding: '13.17px',
                  // gap: '13.17px',
                  borderRadius: '6.58px',
                  border: 'rgba(0, 0, 0, 0.1)',
                  stroke: '#fff', 
                  color: '#0041d0',
                  borderColor: '#0041d0',
                  backgroundColor: 'rgba(255, 255, 255, 1)', 
                  boxShadow: '0px 3.29px 13.17px 0px #0000001A'
                },
            }, ...graphNodes]);
            setEdges(graphEdges);
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [graphCntQryData])

    console.log(nodes, 'nodes');
    console.log(edges, 'edges');
    console.log(graphCntQryData, 'graphCntQryData');

    useLayoutNodes();

    const nodeTypes = useMemo(
        () => ({
            elk: ElkNode,
        }),
        [],
    );

    const onNodeClick = (event, node) => { toggleSidebar(); console.log('click node', node) };
    const onPaneClick = (event) => console.log('onPaneClick', event);

    const toggleSidebar = () => {
        setIsSidebarOpen(!isSidebarOpen);
    };

    const handleFilterSelection = (event) => {
        if(event.target.checked) {
            setSelectedFilters([...selectedFilters, event.target.value]);
        } else {
            const newArr = selectedFilters.filter((filter) => filter !== event.target.value);
            setSelectedFilters(newArr);
        }
    };

    const handleResetFilter = () => {
        setSelectedFilters([]);
        setSelectedFilterCount(0);
    }

    return (
        <Container fluid p={0}>
        <Grid>
            <Grid.Col span={9} style={{ height: '100vh' }}>
                <Card withBorder shadow="sm" radius="md">
                    <StyleSearchBarBox withBorder inheritPadding py="xs">
                        {/* <Group className='group'> */}
                            <Flex
                                direction={{ base: 'column', sm: 'row' }}
                                gap={{ base: 'sm', sm: 'lg' }}
                                justify={{ sm: 'space-between' }}
                                className='flex'
                            >
                                <Text className='goback-text'>
                                    <Group>
                                    <Image
                                        src={vectorSvg}
                                        alt="Frame"
                                        // width={14}
                                        height={12}
                                    />
                                    Go Back
                                    </Group>
                                </Text>
                                <StyleSearchInput
                                    leftSectionPointerEvents="none"
                                    leftSection={''}
                                    placeholder="Search scientists"
                                />
                                <Group shadow="xs" className='filter-selection'>
                                    <Popover width={200} position="bottom" withArrow shadow="md">
                                        <Popover.Target>
                                            <Text className='text-filter'>Filters({selectedFilterCount})</Text>
                                        </Popover.Target>
                                        <Popover.Dropdown>
                                            <Card radius="md">
                                                <Card.Section py="xs">
                                                    Filters
                                                </Card.Section>
                                                <Stack>
                                                    <Checkbox defaultChecked={selectedFilters.includes("Company")} onChange={handleFilterSelection} label="Company" value={"Company"} />
                                                    <Checkbox defaultChecked={selectedFilters.includes("Payment")} onChange={handleFilterSelection} label="Payment" value={"Payment"} />
                                                    <Checkbox defaultChecked={selectedFilters.includes("Trial")} onChange={handleFilterSelection} label="Trial" value={"Trial"} />
                                                    <Checkbox defaultChecked={selectedFilters.includes("Trailwork")} onChange={handleFilterSelection} label="Trailwork" value={"Trailwork"} />
                                                    <Checkbox defaultChecked={selectedFilters.includes("Organization")} onChange={handleFilterSelection} label="Organization" value={"Organization"} />
                                                    <Button type='button' onClick={() => {setSelectedFilterCount(selectedFilters.length)}}>Apply Filter</Button>
                                                </Stack>
                                            </Card>
                                        </Popover.Dropdown>
                                    </Popover>
                                    {selectedFilterCount === 0 ? <Text className='text-filter'>None</Text> : <Text className='text-filter-clear' onClick={() => handleResetFilter()}>Clear All</Text>}
                                </Group>
                            </Flex>
                        {/* </Group> */}
                    </StyleSearchBarBox>
                    <Card.Section mt="sm" style={{ height: '85vh' }}>
                        <ReactFlow
                            nodes={nodes}
                            edges={edges}
                            onNodesChange={onNodesChange}
                            onEdgesChange={onEdgesChange}
                            fitView
                            nodeTypes={nodeTypes}
                            style={{ background: '#ffff' }}
                            // maxZoom={1.5}
                            // minZoom={0.1}
                            // connectionLineStyle={connectionLineStyle}
                            snapToGrid={true}
                            // snapGrid={snapGrid}
                            // defaultViewport={defaultViewport}
                            // attributionPosition="bottom-left"
                            onNodeClick={onNodeClick}
                            onPaneClick={onPaneClick}
                            proOptions={proOptions}
                        >
                            {/* <Background color="#f1f1f1" variant={BackgroundVariant.Cross} /> */}
                            <Controls />
                            {/* <MiniMap /> */}
                        </ReactFlow>
                    </Card.Section>
                </Card>
            </Grid.Col>
            <Grid.Col span={3}>
                { isSidebarOpen ?
                    <NodeProperty isOpen={isSidebarOpen} toggleSidebar={toggleSidebar} />
                    :
                    <SummaryDetail />
                }
            </Grid.Col>
        </Grid>
        </Container>
    );
};

export default GraphUI;
