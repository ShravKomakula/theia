import { Card, Group, Text, Image, Button, Box, ScrollArea, Tooltip, CopyButton } from '@mantine/core';
import styled from '@emotion/styled'
import copyIconSvg from '../../assets/svg/copy-icon.svg'
import correctIconSvg from '../../assets/svg/correct.svg'

const StyleNodeProperty = styled(Card)`
    .text-title {
      font-family: 'Noto Sans', sans-serif !important;
        font-size: 16px;
        font-weight: 400;
        color: #000000;
    }
    .org-button {
        padding: 8px;
        gap: 10px;
        border-radius: 100px;
        border: 1px;
        opacity: 0px;
        background: #0190FF1A;
        border: 1px solid #0190FF;
        color: #000000;
    }
    .text-column-name {
        font-family: 'Noto Sans', sans-serif !important;
        padding-top: 10px;
        font-size: 14px;
        font-weight: 400;
        line-height: 20px;
        text-align: center;
        color: #00000080;
    }
    .text-column-value {
          font-family: 'Noto Sans', sans-serif !important;
        font-size: 14px;
        font-weight: 400;
        line-height: 20px;
        text-align: center;
        color: #000000;
    }
    .copy-icon {
        cursor: pointer;
    }
`

const NodeProperty = (props) => {
    const { nodeProperty, isOpen, toggleSidebar, selectedNode, graphNodeLabel } = props;

    const truncate = (string, length=20) => {
        if (string && string.length > length)
            return string.substring(0,length)+'...';
        else
            return string;
    };

    const getNodePropJsx = (prop) => {
        return <Box>
            { Object.entries(prop).map((value, key) => {
                return(
                <>
                    <Group>
                        <Text className='text-column-name'>{`${value[0]}`}</Text>
                    </Group>
                    <Group justify={'space-between'}>
                        <Tooltip label={value[1]} color='#5a5a91' multiline={true}>
                            <Text className='text-column-value'>{truncate(value[1])}</Text>
                        </Tooltip>
                        <CopyButton value={value[1]} timeout={2000}>
                        {({ copied, copy }) => (
                            <>
                            {copied ? (
                                <Image
                                    src={correctIconSvg}
                                    alt="Frame"
                                    height={12}
                                />
                              ) : (
                                <Image
                                    src={copyIconSvg}
                                    alt="Frame"
                                    className='copy-icon'
                                    height={12}
                                    onClick={copy}
                                />
                              )}
                            </>
                        )}
                        </CopyButton>
                    </Group>
                </>)
                }
            ) }
        </Box>
    }
    return (
        <ScrollArea h={'100vh'}>
            <StyleNodeProperty withBorder inheritPadding shadow="sm" radius="md">
                <Card.Section withBorder inheritPadding py="xs">
                    <Group justify="space-between">
                        <Text fw={500} className='text-title'>Node Property</Text>
                        <Button size="xs" type='button' className='org-button'>Organization</Button>
                    </Group>
                    <Text fw={500} c={graphNodeLabel[selectedNode.id]['color']}>{graphNodeLabel[selectedNode.id]['node']}</Text>
                </Card.Section>
                { nodeProperty && nodeProperty.length > 0 && nodeProperty.map((nodePropObj) => {
                    return (
                        <Card py="sm" mt={10}>
                            <Card.Section inheritPadding py="sm">
                                {getNodePropJsx(nodePropObj['row'][0])}
                            </Card.Section>
                        </Card>
                    )}
                )}
            </StyleNodeProperty>
        </ScrollArea>
    );
}

export default NodeProperty;