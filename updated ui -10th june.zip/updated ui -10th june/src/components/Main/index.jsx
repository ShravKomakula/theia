import React, { useState } from 'react';
import './Main.css'; // You can define your styles in this CSS file
import TopbarNew from '../../common/TopbarNew';
import { CiBellOn,CiUser,CiHome,CiChat2 } from "react-icons/ci";
import { HiOutlineDocumentText } from "react-icons/hi2";
import { BsBarChart} from "react-icons/bs";
import { IoSettingsOutline } from "react-icons/io5";
import ScientificProfilesPage from '../GraphUI';
import HomePage from '../Home';
import Dashbaord from '../Dashboard';

import Impacts from '../Impact/Index';
import ImpactDetail from '../ImpactDetail/ImpactDetail';
const Main = () => {
  const [selectedNavItem, setSelectedNavItem] = useState('home');
  const [selectedCardId, setSelectedCardId] = useState(null);

  const handleNavItemClick = (item) => {
    setSelectedNavItem(item);
    setSelectedCardId(null); // Reset selected card ID when navigating to a different section
  };

  const handleCardClick = (id) => {
    setSelectedNavItem('impactDetail');
    setSelectedCardId(id);
  };

  

  return (
    <>
    <TopbarNew />
    <div className="profile">
      {/* Sidebar */}
      <div className="sidebarNav">
       
        <ul className="nav">
        <li>MAIN
          <li className={selectedNavItem === 'home' ? 'active' : ''} onClick={() => handleNavItemClick('home')}>
           <CiHome/>&nbsp;Home
          </li>
          <li className={selectedNavItem === 'dashboard' ? 'active' : ''} onClick={() => handleNavItemClick('dashboard')}>
          <CiUser/>&nbsp;Dashboard
          </li>
          </li>
          <li >
            APPS
         
              <li className={selectedNavItem === 'grant' ? 'active' : ''} onClick={() => handleNavItemClick('grant')}>
              <HiOutlineDocumentText/>&nbsp;Grant View
              </li>
              <li className={selectedNavItem === 'chat' ? 'active' : ''} onClick={() => handleNavItemClick('chat')}>
               <CiChat2/>&nbsp;Chat
              </li>
              <li className={selectedNavItem === 'draft' ? 'active' : ''} onClick={() => handleNavItemClick('draft')}>
               <BsBarChart/>&nbsp;Ops Compliance
              </li>
      
          </li>
          <li >
            DISCOVER
       
              <li className={selectedNavItem === 'impact' ? 'active' : ''} onClick={() => handleNavItemClick('impact')}>
               <CiBellOn className='svg'/>&nbsp;Impact & Outcomes
              </li>
              <li className={selectedNavItem === 'experts' ? 'active' : ''} onClick={() => handleNavItemClick('experts')}>
               <IoSettingsOutline/>&nbsp;Scientific Experts
              </li>
         
          </li>
        </ul>
      </div>
      
      {/* Main Content */}
      <div className="main-content">
          {selectedNavItem === 'home' && <HomePage />}
          {selectedNavItem === 'dashboard' && <Dashbaord />}
          {selectedNavItem === 'grant' && <div>Grants View</div>}
          {selectedNavItem === 'chat' && <div>chat Content</div>}
          {selectedNavItem === 'draft' && <div>Ops Compliance</div>}
          {selectedNavItem === 'impact' && <Impacts onCardClick={handleCardClick} />}
          {selectedNavItem === 'experts' && <ScientificProfilesPage />}
          {selectedNavItem === 'impactDetail' && selectedCardId && (
            <ImpactDetail cardId={selectedCardId} />
          )}
        </div>
    </div>
    </>
  
  );
};

export default Main;
