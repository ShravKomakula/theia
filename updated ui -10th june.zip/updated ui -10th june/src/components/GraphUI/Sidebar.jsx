import React, { useState, useEffect, useRef } from "react";
import { MdClose } from "react-icons/md";
import axios from "axios";


const Sidebar = ({
    isOpen,
    toggleSidebar,
    selectedCountry,
    countryPayload,
    organizationPayload,
    scientificLeaderPayload,
    digitalLeaderPayload,
    emergingExpertPayload,
    scientificReachPayload,
    payloadObject,
    setPayloadObject,
    booleanCountry,
    setBooleanCountry,
    incrementFilters,
    selectedOrganization,
    emergingExpert,
    setEmergingExpert,
    scientificReach,
    setScientificReach,
    countriesFlags,
    handleCountrySearch,
    handleCountrySelect,
    handleOrganizationSearch,
    handleOrganizationSelect,
    countrySearchResults = [], // Initialize with an empty array
    organizationSearchResults = [], // Initialize with an empty array
    scientificLeaderSearchResults = [],
    digitalLeaderSearchResults = [],
    scientificReachOptions = [],
    emergingOptions = [],
    handleDigitalLeaderSearch,
    handleDigitalLeaderSelect,
    handleScientificLeaderSearch,
    handleScientificLeaderSelect,
    handleFilterApply,
    selectedSleaders,
    setSelectedSleaders,
    selectedScientificReach,
    setSelectedScientificReach,
    selectedDleaders,
    setSelectedDleaders,
  }) => {
    const scientificDropdownRef = useRef(null);
    const digitalDropdownRef = useRef(null);
    const countryDropdownRef = useRef(null);
    const organizationDropdownRef = useRef(null);
  
    const [scientificSearchValue, setScientificSearchValue] = useState("");
    const [digitalSearchValue, setDigitalSearchValue] = useState("");
    const [showScientificDropdown, setShowScientificDropdown] = useState(false);
    const [showDigitalDropdown, setShowDigitalDropdown] = useState(false);
    const [showCountryDropdown, setShowCountryDropdown] = useState(false);
    const [showOrganizationDropdown, setShowOrganizationDropdown] = useState(false);
  
    const handleEmergingExpertChange = (event, type) => {
      setEmergingExpert(event.target.value);
      setPayloadObject((prevPayload) => {
        const newPayload = {
          ...prevPayload,
          [type]: event?.target?.value,
        };
        setBooleanCountry(true);
        return newPayload;
      });
    };
  
    const toggleSelection = (selectedList, item, setSelected, type) => {
      let listItems;
      if (selectedList.includes(item)) {
        setSelected(selectedList.filter((i) => i !== item));
        listItems = selectedList.filter((i) => i !== item);
      } else {
        setSelected([...selectedList, item]);
        listItems = [...selectedList, item];
      }
      setPayloadObject((prevPayload) => {
        const newPayload = {
          ...prevPayload,
          [type]: listItems,
        };
        setBooleanCountry(true);
        return newPayload;
      });
    };
  
    const handleScientificReachChange = (e, selectedScientificReach, setSelectedScientificReach, type) => {
      const value = e.target.value;
      let itemList;
      if (selectedScientificReach.includes(value)) {
        itemList = selectedScientificReach.filter((i) => i !== value);
      } else {
        itemList = [...selectedScientificReach, value];
      }
      setSelectedScientificReach(itemList);
      setPayloadObject((prevPayload) => {
        const newPayload = {
          ...prevPayload,
          [type]: itemList,
        };
        setBooleanCountry(true);
        return newPayload;
      });
    };
  
    const handleOutsideClick = (event) => {
      if (
        scientificDropdownRef.current &&
        !scientificDropdownRef.current.contains(event.target)
      ) {
        setShowScientificDropdown(false);
      }
      if (
        digitalDropdownRef.current &&
        !digitalDropdownRef.current.contains(event.target)
      ) {
        setShowDigitalDropdown(false);
      }
      if (
        countryDropdownRef.current &&
        !countryDropdownRef.current.contains(event.target)
      ) {
        setShowCountryDropdown(false);
      }
      if (
        organizationDropdownRef.current &&
        !organizationDropdownRef.current.contains(event.target)
      ) {
        setShowOrganizationDropdown(false);
      }
    };
  
    useEffect(() => {
      document.addEventListener("mousedown", handleOutsideClick);
      return () => {
        document.removeEventListener("mousedown", handleOutsideClick);
      };
    }, [payloadObject]);
  
    return (
      <div className={`sidebarRight ${isOpen ? "open" : ""}`}>
        <div className="sidebar-content">
          <h5>Filters</h5>
  
          <h6>Country</h6>
          <input
            type="text"
            placeholder="Search for Country"
            className="filter-search"
            onChange={(e) => handleCountrySearch(e.target.value)}
            value={selectedCountry}
            onClick={() => setShowCountryDropdown(true)}
          />
          {showCountryDropdown && countrySearchResults.length > 0 && (
            <div className="autocomplete-country" ref={countryDropdownRef}>
              {countrySearchResults.map((country, index) => (
                <div
                  key={index}
                  className="autocomplete-item"
                  onClick={() => {
                    handleCountrySelect("CNTRY_NM", country);
                    setShowCountryDropdown(false);
                  }}
                >
                  <img src={countriesFlags[index]} width={15} height={10} />
                  &nbsp;&nbsp; {country}
                </div>
              ))}
            </div>
          )}
  
          <h6>Organization</h6>
          <input
            type="text"
            placeholder="Search for Organization"
            className="filter-search"
            onChange={(e) => handleOrganizationSearch(e.target.value)}
            value={selectedOrganization}
            onClick={() => setShowOrganizationDropdown(true)}
          />
          {showOrganizationDropdown && organizationSearchResults.length > 0 && (
            <div className="autocomplete-org" ref={organizationDropdownRef}>
              {organizationSearchResults.map((organization, index) => (
                <div
                  key={index}
                  className="autocomplete-item"
                  onClick={() => {
                    handleOrganizationSelect("AFFILIATION", organization);
                    setShowOrganizationDropdown(false);
                  }}
                >
                  {organization}
                </div>
              ))}
            </div>
          )}
  
          <h6>Scientific Leader</h6>
          <input
            type="text"
            placeholder="Search for Scientific Leader"
            className="filter-search"
            onChange={(e) => {
              setScientificSearchValue(e.target.value);
              handleScientificLeaderSearch(e.target.value);
              setShowScientificDropdown(true);
            }}
            value={scientificSearchValue}
            onClick={() => setShowScientificDropdown(true)}
          />
          {showScientificDropdown && scientificLeaderSearchResults.length > 0 && (
            <div className="autocomplete-sl" ref={scientificDropdownRef}>
              {scientificLeaderSearchResults.map((sleader, index) => (
                <div
                  key={index}
                  className="autocomplete-item"
                  onClick={() =>
                    toggleSelection(
                      selectedSleaders,
                      sleader,
                      setSelectedSleaders,
                      "SCIENTIFIC_LEADER"
                    )
                  }
                >
                  <input
                    type="checkbox"
                    checked={selectedSleaders.includes(sleader)}
                    onChange={() =>
                      toggleSelection(
                        selectedSleaders,
                        sleader,
                        setSelectedSleaders,
                        "SCIENTIFIC_LEADER"
                      )
                    }
                  />
                  &nbsp; {sleader}
                </div>
              ))}
            </div>
          )}
          <div className="selected-items">
            {selectedSleaders.map((sleader, index) => (
              <div key={index} className="selected-item">
                {sleader}
                <MdClose
                  onClick={() =>
                    toggleSelection(
                      selectedSleaders,
                      sleader,
                      setSelectedSleaders,
                      "SCIENTIFIC_LEADER"
                    )
                  }
                />
              </div>
            ))}
          </div>
  
          <h6>Digital Leader</h6>
          <input
            type="search"
            title="Digital Leader Search"
            placeholder="Find Topics"
            className="filter-search"
            onChange={(e) => {
              setDigitalSearchValue(e.target.value);
              handleDigitalLeaderSearch(e.target.value);
              setShowDigitalDropdown(true);
            }}
            value={digitalSearchValue}
            onClick={() => setShowDigitalDropdown(true)}
          />
          {showDigitalDropdown && digitalLeaderSearchResults.length > 0 && (
            <div className="autocomplete-dl" ref={digitalDropdownRef}>
              {digitalLeaderSearchResults.map((dleader, index) => (
                <div
                  key={index}
                  className="autocomplete-item"
                  onClick={() =>
                    toggleSelection(
                      selectedDleaders,
                      dleader,
                      setSelectedDleaders,
                      "DIGITAL_LEADER"
                    )
                  }
                >
                  <input
                    type="checkbox"
                    checked={selectedDleaders.includes(dleader)}
                    onChange={() =>
                      toggleSelection(
                        selectedDleaders,
                        dleader,
                        setSelectedDleaders,
                        "DIGITAL_LEADER"
                      )
                    }
                  />
                  &nbsp; {dleader}
                </div>
              ))}
            </div>
          )}
          <div className="selected-items">
            {selectedDleaders.map((dleader, index) => (
              <div key={index} className="selected-item">
                {dleader}
                <MdClose
                  onClick={() =>
                    toggleSelection(
                      selectedDleaders,
                      dleader,
                      setSelectedDleaders,
                      "DIGITAL_LEADER"
                    )
                  }
                />
              </div>
            ))}
          </div>
  
          <h6>Emerging Expert</h6>
          {emergingOptions?.map((emergingOption) => (
            <div className="radio" key={emergingOption?.value}>
              <input
                type="radio"
                id={emergingOption?.value}
                name="emergingExpert"
                value={emergingOption?.value}
                checked={emergingExpert === emergingOption?.value}
                onChange={(e) => handleEmergingExpertChange(e, "EMERGING_EXPERT")}
              />
              <label htmlFor={emergingOption?.value} className="emerging">
                {emergingOption?.label}
              </label>
            </div>
          ))}
  
          <h6>Scientific Reach</h6>
          {scientificReachOptions?.map((option) => (
            <div className="check-box" key={option?.value}>
              <input
                type="checkbox"
                id={option?.value}
                value={option?.value}
                checked={selectedScientificReach.includes(option?.value)}
                onChange={(e) =>
                  handleScientificReachChange(
                    e,
                    selectedScientificReach,
                    setSelectedScientificReach,
                    "SCIENTIFIC_REACH"
                  )
                }
              />
              <label htmlFor={option?.value}>{option?.label}</label>
            </div>
          ))}
         
          <button className="btn-apply" type="submit" onClick={handleFilterApply}>
            Apply Filters
          </button>
        </div>
  
        <MdClose className="close-icon" onClick={toggleSidebar} />
      </div>
    );
  };
  
export default Sidebar;