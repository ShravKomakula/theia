import React, { useEffect } from 'react';
import { FaUser } from 'react-icons/fa';

const ProfileCard = ({
    name,
    speciality,
    degree,
    profession,
    key,
    sid,
    scientificReach,
    emergingExpert,
    congressContributions,
    publications,
    clinicalTrials,
    digitalEngagement,
    selectedGraphUser,
    setSelectedGraphUser,
    selectedProfileData,
    setSelectedProfileData,
    selectedGraphUserId,
    setSelectedGraphUserId
}) => {
    useEffect(() => {
        if (selectedProfileData && selectedProfileData.length > 0) {
            console.log("Selected Profile Data:", selectedProfileData);
            console.log("Country:", selectedProfileData[0].COUNTRY);
        }
    }, [selectedProfileData]);

    // Function to generate filled and unfilled dots based on the provided value
    const generateDots = (filledCount, label) => {
        const maxDots = 5;
        const filledDots = Math.min(filledCount, maxDots);
        const unfilledDots = maxDots - filledDots;

        const dots = [];

        for (let i = 0; i < filledDots; i++) {
            dots.push(<span className="filled-dot" key={`filled-dot-${i}`} />);
        }

        for (let i = 0; i < unfilledDots; i++) {
            dots.push(<span className="unfilled-dot" key={`unfilled-dot-${filledDots + i}`} />);
        }
        

        return (
            <div className="dots">
                {dots}
                <p>
                    <strong>{label}</strong>
                </p>
            </div>
        );
    };

    const handleNameClick = (name) => {
        setSelectedGraphUser(name);
        setSelectedGraphUserId(sid);
        
      };
   
    
    if (!selectedProfileData || selectedProfileData.length === 0) {
        return (
            <div className="profile-card">
                <h6
                    className="profile-name"
                    onClick={() => {
                        handleNameClick(name);
                        
                    }}
                >
                    {name}
                </h6>
                <div className="profile-info">
                    <FaUser className="profile-image" /> &nbsp;&nbsp;
                    <p className="degree">
                        {degree}
                        <br />
                    </p>
                    <p className="speciality">{profession}</p>
                </div>
                <div className="additional-info">
                    <div className="reach-expert">
                        <p>
                            <span className="Sreach">{scientificReach} Reach</span> &nbsp;&nbsp;
                            {emergingExpert === "Y" && (
                                <span className="emerging-expert">Emerging Expert</span>
                            )}
                        </p>
                    </div>
                    <div className="activities">
                        <h5>Activities:</h5>
                        <div className="activity-line">
                            {generateDots(digitalEngagement, "Digital Engagement")}
                            {generateDots(clinicalTrials, "Clinical Trials")}
                        </div>
                        <div className="activity-line2">
                            {generateDots(congressContributions, "Congress Contributions")}
                            {generateDots(publications, "Publications")}
                        </div>
                    </div>
                </div>
            </div>
        );
    } else {
        const profile = selectedProfileData[0]; // Access the first element

        return (
            <div className="profile-card">
                <h6
                    className="profile-name"
                    onClick={() => {
                        handleNameClick(profile.FULL_NAME);
                    }}
                >
                    {profile.FULL_NAME}
                </h6>
                <div className="profile-info">
                    <FaUser className="profile-image" /> &nbsp;&nbsp;
                    <p className="degree">
                        {profile.DEGREE_S_}
                        <br />
                    </p>
                    <span className="speciality">{profile.PROFESSION}</span>
                </div>
                <div className="additional-info">
                    <div className="reach-expert">
                        <p>
                            <span className="Sreach">{profile.SCIENTIFIC_REACH} Reach</span> &nbsp;&nbsp;
                            {profile.EMERGING_EXPERT === "Y" && (
                                <span className="emerging-expert">Emerging Expert</span>
                            )}
                        </p>
                    </div>
                    <div className="activities">
                        <h5>Activities:</h5>
                        <div className="activity-line">
                            {generateDots(profile.DIGITAL_ENGAGEMENT, "Digital Engagement")}
                            {generateDots(profile.CLINICAL_TRIALS, "Clinical Trials")}
                        </div>
                        <div className="activity-line2">
                            {generateDots(profile.CONGRESS_CONTRIBUTIONS, "Congress Contributions")}
                            {generateDots(profile.PUBLICATIONS, "Publications")}
                        </div>
                    </div>
                </div>
            </div>
        );
    }
};

export default ProfileCard;
