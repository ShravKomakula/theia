import React, { useState, useEffect, useRef } from "react";
import "./ScientificProfilesPage.css"; // You can define your styles in this CSS file
import { CiLocationOn, CiSearch } from "react-icons/ci";
import { MdClose } from "react-icons/md"; // Import close icon
import axios from "axios"; // Import axios for HTTP requests
import { ScientificProfileData } from "../../common/api-config";
import { FaUser } from "react-icons/fa";
import GoogleMapReact from "google-map-react";
import Sidebar from "./Sidebar";
import ProfileCard from "./ProfileCard";  // Adjust the path if necessary

import { Pagination, Button } from "react-bootstrap";
import {
  PiNameSearchEndPoint,
  FilterEndPoint,
  CountrySearchEndPoint,
  OrganizationearchEndPoint,
  SleaderSearchEndPoint,
  DleaderearchEndPoint,
  IncrementalMatchEndpoint,
  PInameProfileEndpoint
} from "../../common/api-config";
import GraphUI from "../Graph/GraphUI";
import { object } from "@google/maps/lib/internal/validate";
import { type } from "@testing-library/user-event/dist/type";
const ScientificProfilesPage = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [profiles, setProfiles] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [profilesPerPage, setProfilesPerPage] = useState(8);
  const [isMapView, setIsMapView] = useState(false); // State to track map or grid view
  const [countriesFlags, setCountriesFlags] = useState([]);
  const [searchQuery, setSearchQuery] = useState(""); // State to store the search query
  const [searchResults, setSearchResults] = useState([]); // State to store the search results

  const [countrySearchResults, setCountrySearchResults] = useState([]); // State to store country search results
  const [organizationSearchResults, setOrganizationSearchResults] = useState(
    []
  ); // State to store organization search results
  const [scientificLeaderSearchResults, setScientificLeaderSearchResults] =
    useState([]); // State to store scientific leader search results
  const [digitalLeaderSearchResults, setDigitalLeaderSearchResults] = useState(
    []
  ); // State to store digital leader search results
  const [selectedCountry, setSelectedCountry] = useState([]);
  const [selectedOrganization, setSelectedOrganization] = useState([]);
  const [selectedSleader, setSelectedSleader] = useState([]);
  const [selectedDleader, setSelectedDleader] = useState([]);
  const [countrycode, setCountrycode] = useState([]);
  const [selectedProfileData, setSelectedProfileData] = useState(null);
  const [selectedGraphUser, setSelectedGraphUser] = useState(null);
  const [scientificReachOptions, setScientificReachOptions] = useState([
    { value: "local", label: "Local Reach" },
    { value: "national", label: "National Reach" },
    { value: "regional", label: "Regional Reach" },
    { value: "global", label: "Global Reach" },
  ]);
  const [emergingOptions, setEmergingOptions] = useState([
    { value: "Y", label: "Yes" },
    { value: "N", label: "No" },
  ]);

  const [selectedSleaders, setSelectedSleaders] = useState([]); // State for selected scientific leaders
  const [selectedDleaders, setSelectedDleaders] = useState([]); // State for selected digital leaders
  const [selectedScientificReach, setSelectedScientificReach] = useState([]); // State for selected scientific leaders
  const [emergingExpert, setEmergingExpert] = useState("");
  const [scientificReach, setScientificReach] = useState([]);
  const [payloadObject, setPayloadObject] = useState({});
  const [booleanCountry, setBooleanCountry] = useState(false);

  
  useEffect(() => {
    axios
      .get(ScientificProfileData(), {})
      .then((response) => {
        const countrycode = response.data.map((profile) => profile.COUNTRY);
        // Construct countriesFlags array
        const countriesFlags = response.data.map(
          (profile) => profile.COUNTRY_FLAG_LINK
        );

        setCountrycode(countrycode);
        setProfiles(response.data);
        setCountriesFlags(countriesFlags); // Set the countriesFlags state
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
      });
    if (booleanCountry) {
      incrementFilters();
      setBooleanCountry(false);
    }
  }, [payloadObject, booleanCountry]);

  const handleSearchChange = (event) => {
    const { value } = event.target;
    setSearchQuery(value);
  
    if (value) {
      axios
        .get(PiNameSearchEndPoint(), { params: { full_name: value } }) // Change the query parameter to 'fst_name'
        .then((response) => {
          setSearchResults(response.data); // Update search results state
        })
        .catch((error) => {
          console.error("Error fetching search results:", error);
        });
    } else {
      setSearchResults([]);
    }
  };
  
  const handleNameSelect = (name) => {
    // Call the API to fetch profile data based on the selected name
    axios
      .get(PInameProfileEndpoint(), { params: { full_name: name } })
      .then((response) => {
        setSelectedProfileData(response.data); // Update selected profile data state
        setSearchQuery(""); // Clear the search query
        setSearchResults([]); // Clear the search results
        console.log(response.data, "search response");
      })
      .catch((error) => {
        console.error("Error fetching profile data:", error);
      });
  };


  const handleCountrySearch = (value) => {
    setSelectedCountry(value);
    axios
      .get(CountrySearchEndPoint(), { params: { cntry_name: value } })
      .then((response) => {
        setCountrySearchResults(response.data); // Update country search results state
      })
      .catch((error) => {
        console.error("Error fetching country search results:", error);
      });
  };
  // Function to handle organization search
  const handleOrganizationSearch = (value) => {
    // Call the API to fetch organization search results based on the input value
    if (organizationSearchResults.length <= 0) {
      setSelectedOrganization(value);
      axios
        .get(OrganizationearchEndPoint(), { params: { org_name: value } })
        .then((response) => {
          setOrganizationSearchResults(response.data); // Update organization search results state
        })
        .catch((error) => {
          console.error("Error fetching organization search results:", error);
        });
    }
  };
  // Function to handle scientific leader search
  const handleScientificLeaderSearch = (value) => {
    // Call the API to fetch scientific leader search results based on the input value
    if (scientificLeaderSearchResults.length <= 0) {
      setSelectedSleader(value);
      axios
        .get(SleaderSearchEndPoint(), { params: { sl_name: value } })
        .then((response) => {
          setScientificLeaderSearchResults(response.data); // Update scientific leader search results state
        })
        .catch((error) => {
          console.error(
            "Error fetching scientific leader search results:",
            error
          );
        });
    }
  };
  // Function to handle digital leader search
  const handleDigitalLeaderSearch = (value) => {
    // Call the API to fetch digital leader search results based on the input value
    if (digitalLeaderSearchResults.length <= 0) {
      setSelectedDleader(value);
      axios
        .get(DleaderearchEndPoint(), { params: { dl_name: value } })
        .then((response) => {
          setDigitalLeaderSearchResults(response.data); // Update digital leader search results state
        })
        .catch((error) => {
          console.error("Error fetching digital leader search results:", error);
        });
    }
  };
  const handleCountrySelect = async (type, country) => {
    //console.log("type", country, type);
    // Handle the selection of a country from the autocomplete dropdown
    setSelectedCountry(country); // Assuming you have a state variable for selected country
    setCountrySearchResults([]); // Clear the search results after selection
    setPayloadObject((prevPayload) => {
      const newPayload = {
        ...prevPayload,
        [type]: country,
      };
      setBooleanCountry(true);
      return newPayload;
    });

    // incrementFilters();
  };

  const handleOrganizationSelect = (type, organization) => {
    setPayloadObject((prevPayload) => {
      const newPayload = {
        ...prevPayload,
        [type]: organization,
      };
      setBooleanCountry(true);
      return newPayload;
    });
    if (type === "AFFILIATION") {
      setSelectedOrganization(organization); // Update the selected organization state
    }
  };
  
  const handleScientificLeaderSelect = (type, sleader) => {
    // Handle the selection of an organization from the autocomplete dropdown
    setSelectedSleader(sleader); // Assuming you have a state variable for selected organization
    setScientificLeaderSearchResults([]); // Clear the search results after selection
    setPayloadObject((prevPayload) => ({
      ...prevPayload,
      [type]: sleader,
    }));
    incrementFilters();
  };
  const handleDigitalLeaderSelect = (type, dleader) => {
    // Handle the selection of an organization from the autocomplete dropdown
    setSelectedDleader(dleader); // Assuming you have a state variable for selected organization
    setDigitalLeaderSearchResults([]); // Clear the search results after selection
    setPayloadObject((prevPayload) => ({
      ...prevPayload,
      [type]: dleader,
    }));
    incrementFilters();
  };
  const incrementFilters = (type, value) => {
    console.log("payload", payloadObject);
    let payload = { [type]: value };

    {
      Object.keys(payloadObject).length > 0 &&
        axios
          .post(IncrementalMatchEndpoint(), payloadObject)
          .then((response) => {
            console.log(response?.data, "response");
            // setSearchResults(response.data);
            const keyValuePair = response?.data?.key_value_pairs;

            setCountrySearchResults(keyValuePair?.COUNTRY_NAME);
            setOrganizationSearchResults(keyValuePair?.AFFILIATION);
            setScientificLeaderSearchResults(keyValuePair?.SCIENTIFIC_LEADER);
            setDigitalLeaderSearchResults(keyValuePair?.DIGITAL_LEADER);
            const options = keyValuePair?.SCIENTIFIC_REACH;

            const filteredOptions = scientificReachOptions.filter(
              (OptionItem) => options.includes(OptionItem.value)
            );

            setScientificReachOptions(filteredOptions);
            const optionsEmerging = keyValuePair?.EMERGING_EXPERT;

            const filteredEmergingOptions = emergingOptions.filter(
              (emergingOptionItem) =>
                optionsEmerging.includes(emergingOptionItem.value)
            );

            setEmergingOptions(filteredEmergingOptions);
          })
          .catch((error) => {
            console.error("Error fetching search results:", error);
          });
    }
  };

  const handleFilterApply = () => {
    // Construct the payload with filter values
    const payload = {
      DIGITAL_LEADER: selectedDleaders,
      SCIENTIFIC_LEADER: selectedSleaders,
      AFFILIATION: selectedOrganization,
      COUNTRY_NAME: selectedCountry,
      EMERGING_EXPERT: emergingExpert, // Replace with the actual value for emerging expert filter
      SCIENTIFIC_REACH: scientificReach,
    };

    // Make the API call to fetch filtered data
    axios
      .post(FilterEndPoint(), payload)
      .then((response) => {
        // Update the profiles state with the filtered data
        setProfiles(response.data);
        // Close the sidebar
        setIsSidebarOpen(false);
      })
      .catch((error) => {
        console.error("Error fetching filtered data:", error);
      });
  };

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  const toggleView = () => {
    setIsMapView(!isMapView);
  };
  const paginate = (newPage) => {
    setCurrentPage(newPage);
    // Add any additional logic for handling pagination, e.g., fetching data for the new page.
  };
  const CustomMarker = ({ lat, lng, profileName }) => {
    const [showTooltip, setShowTooltip] = useState(false);
  
  
    return (
      <div
        style={{
          position: "absolute",
          width: "20px",
          height: "20px",
          backgroundColor: "red",
          borderRadius: "50%",
          border: "2px solid white",
          textAlign: "center",
          color: "white",
          fontSize: "16px",
          fontWeight: "bold",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          transform: "translate(-50%, -50%)",
          cursor: "pointer", // Add cursor pointer for hover effect
        }}
        lat={lat}
        lng={lng}
        onMouseEnter={() => setShowTooltip(true)}
        onMouseLeave={() => setShowTooltip(false)}
      >
        {/* Tooltip */}
        {showTooltip && (
          <div
            style={{
              position: "absolute",
              backgroundColor: "rgba(0, 0, 0, 0.7)",
              color: "white",
              padding: "5px",
              borderRadius: "5px",
              fontSize: "12px",
              zIndex: "999",
            }}
          >
            {profileName}
          </div>
        )}
      </div>
    );
  };

 // Logic to get profiles for the current page
const indexOfLastProfile = currentPage * profilesPerPage;
const indexOfFirstProfile = indexOfLastProfile - profilesPerPage;
const currentProfiles = profiles.slice(indexOfFirstProfile, indexOfLastProfile);

// Total number of pages for currentProfiles
const totalPages = Math.ceil(profiles.length / profilesPerPage);
const [selectedGraphUserId,setSelectedGraphUserId]=useState(null);

  return (
    <div className="container">
      {selectedGraphUser !== null ? (
        <GraphUI
          scientistsName={selectedGraphUser}
          setSelectedGraphUser={setSelectedGraphUser}
          seid={selectedGraphUserId}
        />
      ) : (
        <>
          <h4>Scientific Experts</h4>
          <div className="search-filter">
          <input
            type="text"
            placeholder="Search Scientists"
            className="search-bar"
            value={searchQuery}
            onChange={handleSearchChange}
          />
            {/* Display autocomplete dropdown */}
            {searchResults.length > 0 && (
            <div className="autocomplete-dropdown">
              {searchResults.map((name, index) => (
                <div
                  key={index}
                  className="autocomplete-item"
                  onClick={() => handleNameSelect(name)}
                >
                  {name}
                </div>
              ))}
            </div>
          )}
            <div className="gap"></div>
            <button className="filter-option" onClick={toggleSidebar}>
              Go To Filters
            </button>
            <button className="view-map-btn" onClick={toggleView}>
              <CiLocationOn /> {isMapView ? "View on Grid" : "View on Map"}
            </button>
          </div>
          {isMapView ? (
            <div className="Gmap">
              <GoogleMapReact
                bootstrapURLKeys={{ key: "AIzaSyDx1t1xehKETxiCv0KPsGUGVzo0YXra8ZU" }}
                defaultCenter={{ lat: 0, lng: 0 }}
                defaultZoom={1}
              >
                {selectedProfileData ? (
                  <CustomMarker
                    key={selectedProfileData[0].LINK_ID}
                    lat={parseFloat(selectedProfileData[0].ARCGISLATITUDE)}
                    lng={parseFloat(selectedProfileData[0].ARCGISLONGITUDE)}
                    profileName={
                      selectedProfileData[0].FIRST_NAME +
                      " " +
                      selectedProfileData[0].LAST_NAME
                    }
                  />
                ) : (
                  currentProfiles.map((profile) => (
                    <CustomMarker
                      key={profile.LINK_ID}
                      lat={parseFloat(profile.ARCGISLATITUDE)}
                      lng={parseFloat(profile.ARCGISLONGITUDE)}
                      profileName={profile.FIRST_NAME + " " + profile.LAST_NAME}
                    />
                  ))
                )}
              </GoogleMapReact>
    </div>
          ) : (
            <div className="card-container">
            {selectedProfileData ? (
            <ProfileCard
              key={selectedProfileData.id}
              sid={selectedProfileData.sd}
              name={selectedProfileData.name}
              degree={selectedProfileData.degree}
              profession={selectedProfileData.profession}
              scientificReach={selectedProfileData.scientificReach}
              emergingExpert={selectedProfileData.emergingExpert}
              congressContributions={selectedProfileData.congressContributions}
              publications={selectedProfileData.publications}
              clinicalTrials={selectedProfileData.clinicalTrials}
              digitalEngagement={selectedProfileData.digitalEngagement}
              setSelectedGraphUser={setSelectedGraphUser}
              selectedProfileData={selectedProfileData}
              selectedGraphUserId={selectedGraphUserId}
              setSelectedGraphUserId={setSelectedGraphUserId}
              setSelectedProfileData={setSelectedProfileData}
            />
          ) : (
            currentProfiles.map((profile) => (
             <ProfileCard
               key={profile.LINK_ID} // Assuming LINK_ID is a unique identifier
               sid={profile.SE_ID}
               name={`${profile.FIRST_NAME} ${profile.LAST_NAME}`}
               degree={profile.DEGREE_S_}
               profession={profile.PROFESSION}
               scientificReach={profile.SCIENTIFIC_REACH}
               emergingExpert={profile.EMERGING_EXPERT}
               congressContributions={profile.CONGRESS_CONTRIBUTIONS}
               publications={profile.PUBLICATIONS}
               clinicalTrials={profile.CLINICAL_TRIALS}
               digitalEngagement={profile.DIGITAL_ENGAGEMENT}
               setSelectedGraphUser={setSelectedGraphUser}
           selectedGraphUserId={selectedGraphUserId}
           setSelectedGraphUserId={setSelectedGraphUserId}
               selectedProfileData={selectedProfileData} setSelectedProfileData={setSelectedProfileData}
           />
            ))
          )}
                {!selectedProfileData  && (
              <div className="d-flex justify-content-center mt-4">
                <pre>
                  {currentPage > 1 && (
                    <Button onClick={() => paginate(currentPage - 1)}>
                      {"Prev"}
                    </Button>
                  )}
                  &nbsp;
                  {currentPage} / {totalPages}  {""}
                {currentPage < totalPages && (
                  <Button onClick={() => paginate(currentPage + 1)}>
                    {"Next"}
                  </Button>
                )}
                </pre>
              </div>
            )}
            </div>
          )}

          <Sidebar
            isOpen={isSidebarOpen}
            emergingExpert={emergingExpert}
            setEmergingExpert={setEmergingExpert}
            scientificReach={scientificReach}
            setScientificReach={setScientificReach}
            toggleSidebar={toggleSidebar}
            countrycode={countrycode}
            selectedSleaders={selectedSleaders}
            selectedDleaders={selectedDleaders}
            setSelectedDleaders={setSelectedDleaders}
            setSelectedSleaders={setSelectedSleaders}
            selectedScientificReach={selectedScientificReach}
            setSelectedScientificReach={setSelectedScientificReach}
            selectedCountry={selectedCountry}
            payloadObject={payloadObject}
            booleanCountry={booleanCountry}
            handleCountrySearch={handleCountrySearch}
            handleCountrySelect={handleCountrySelect}
            handleScientificLeaderSearch={handleScientificLeaderSearch}
            incrementFilters={incrementFilters}
            setPayloadObject={setPayloadObject}
            setBooleanCountry={setBooleanCountry}
            handleScientificLeaderSelect={handleScientificLeaderSelect}
            handleDigitalLeaderSearch={handleDigitalLeaderSearch}
            handleDigitalLeaderSelect={handleDigitalLeaderSelect}
            handleOrganizationSelect={handleOrganizationSelect}
            setSelectedCountry={setSelectedCountry}
            setselectedDleader={setSelectedDleader}
            selectedDleader={selectedDleader}
            selectedSleader={selectedSleader}
            setSelectedSleader={setSelectedSleader}
            countriesFlags={countriesFlags}
            countrySearchResults={countrySearchResults}
            selectedOrganization={selectedOrganization}
            setSelectedOrganization={setSelectedOrganization}
        
            handleOrganizationSearch={handleOrganizationSearch}
            organizationSearchResults={organizationSearchResults}
            scientificLeaderSearchResults={scientificLeaderSearchResults}
            digitalLeaderSearchResults={digitalLeaderSearchResults}
            scientificReachOptions={scientificReachOptions}
            emergingOptions={emergingOptions}
            handleFilterApply={handleFilterApply}
          />
        </>
      )}
    </div>
  );
};




export default ScientificProfilesPage;
