import React, { useState, useEffect, useRef } from "react";
import "./ScientificProfilesPage.css"; // You can define your styles in this CSS file
import { CiLocationOn, CiSearch } from "react-icons/ci";
import { MdClose } from "react-icons/md"; // Import close icon
import axios from "axios"; // Import axios for HTTP requests
import { FaUser } from "react-icons/fa";
import GoogleMapReact from "google-map-react";

import { Pagination, Button } from "react-bootstrap";
import {
  PiNameSearchEndPoint,
  ScientificProfileData,
  FilterEndPoint,
  CountrySearchEndPoint,
  OrganizationearchEndPoint,
  SleaderSearchEndPoint,
  DleaderearchEndPoint,
  IncrementalMatchEndpoint,
} from "../../common/api-config";
import GraphUI from "../Graph/GraphUI";
import { object } from "@google/maps/lib/internal/validate";
import { type } from "@testing-library/user-event/dist/type";
const ScientificProfilesPage = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [profiles, setProfiles] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [profilesPerPage, setProfilesPerPage] = useState(8);
  const [isMapView, setIsMapView] = useState(false); // State to track map or grid view
  const [countriesFlags, setCountriesFlags] = useState([]);
  const [searchQuery, setSearchQuery] = useState(""); // State to store the search query
  const [searchResults, setSearchResults] = useState([]); // State to store the search results
  const [selectedProfile, setSelectedProfile] = useState(null);
  const [countrySearchResults, setCountrySearchResults] = useState([]); // State to store country search results
  const [organizationSearchResults, setOrganizationSearchResults] = useState(
    []
  ); // State to store organization search results
  const [scientificLeaderSearchResults, setScientificLeaderSearchResults] =
    useState([]); // State to store scientific leader search results
  const [digitalLeaderSearchResults, setDigitalLeaderSearchResults] = useState(
    []
  ); // State to store digital leader search results
  const [selectedCountry, setSelectedCountry] = useState([]);
  const [selectedOrganization, setSelectedOrganization] = useState([]);
  const [selectedSleader, setSelectedSleader] = useState([]);
  const [selectedDleader, setSelectedDleader] = useState([]);
  const [countrycode, setCountrycode] = useState([]);
  const [selectedGraphUser, setSelectedGraphUser] = useState(null);
  const [scientificReachOptions, setScientificReachOptions] = useState([
    { value: "local", label: "Local Reach" },
    { value: "national", label: "National Reach" },
    { value: "regional", label: "Regional Reach" },
    { value: "global", label: "Global Reach" },
  ]);
  const [emergingOptions, setEmergingOptions] = useState([
    { value: "Y", label: "Yes" },
    { value: "N", label: "No" },
  ]);

  const [selectedSleaders, setSelectedSleaders] = useState([]); // State for selected scientific leaders
  const [selectedDleaders, setSelectedDleaders] = useState([]); // State for selected digital leaders
  const [selectedScientificReach, setSelectedScientificReach] = useState([]); // State for selected scientific leaders
  const [emergingExpert, setEmergingExpert] = useState("");
  const [scientificReach, setScientificReach] = useState([]);
  const [payloadObject, setPayloadObject] = useState({});
  const [booleanCountry, setBooleanCountry] = useState(false);

  useEffect(() => {
    axios
      .get(ScientificProfileData(), {})
      .then((response) => {
        const countrycode = response.data.map((profile) => profile.COUNTRY);
        // Construct countriesFlags array
        const countriesFlags = response.data.map(
          (profile) => profile.COUNTRY_FLAG_LINK
        );

        setCountrycode(countrycode);
        setProfiles(response.data);
        setCountriesFlags(countriesFlags); // Set the countriesFlags state
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
      });
    if (booleanCountry) {
      incrementFilters();
      setBooleanCountry(false);
    }
  }, [payloadObject, booleanCountry]);

  const handleSearchChange = (event) => {
    const { value } = event.target;
    setSearchQuery(value);

    // Call the API to fetch search results based on the input value
    axios
      .get(PiNameSearchEndPoint(), { params: { full_name: value } }) // Change the query parameter to 'fst_name'
      .then((response) => {
        setSearchResults(response.data); // Update search results state
      })
      .catch((error) => {
        console.error("Error fetching search results:", error);
      });
  };

  const handleNameSelect = (profile) => {
    setSearchQuery(profile.name);
    setSearchResults([]); // Clear search results after selection
    setSelectedProfile(profile); // Set the selected profile with full data
  };
  
  const handleCountrySearch = (value) => {
    setSelectedCountry(value);
    axios
      .get(CountrySearchEndPoint(), { params: { cntry_name: value } })
      .then((response) => {
        setCountrySearchResults(response.data); // Update country search results state
      })
      .catch((error) => {
        console.error("Error fetching country search results:", error);
      });
  };
  // Function to handle organization search
  const handleOrganizationSearch = (value) => {
    // Call the API to fetch organization search results based on the input value
    if (organizationSearchResults.length <= 0) {
      setSelectedOrganization(value);
      axios
        .get(OrganizationearchEndPoint(), { params: { org_name: value } })
        .then((response) => {
          setOrganizationSearchResults(response.data); // Update organization search results state
        })
        .catch((error) => {
          console.error("Error fetching organization search results:", error);
        });
    }
  };
  // Function to handle scientific leader search
  const handleScientificLeaderSearch = (value) => {
    // Call the API to fetch scientific leader search results based on the input value
    if (scientificLeaderSearchResults.length <= 0) {
      setSelectedSleader(value);
      axios
        .get(SleaderSearchEndPoint(), { params: { sl_name: value } })
        .then((response) => {
          setScientificLeaderSearchResults(response.data); // Update scientific leader search results state
        })
        .catch((error) => {
          console.error(
            "Error fetching scientific leader search results:",
            error
          );
        });
    }
  };
  // Function to handle digital leader search
  const handleDigitalLeaderSearch = (value) => {
    // Call the API to fetch digital leader search results based on the input value
    if (digitalLeaderSearchResults.length <= 0) {
      setSelectedDleader(value);
      axios
        .get(DleaderearchEndPoint(), { params: { dl_name: value } })
        .then((response) => {
          setDigitalLeaderSearchResults(response.data); // Update digital leader search results state
        })
        .catch((error) => {
          console.error("Error fetching digital leader search results:", error);
        });
    }
  };
  const handleCountrySelect = async (type, country) => {
    console.log("type", country, type);
    // Handle the selection of a country from the autocomplete dropdown
    setSelectedCountry(country); // Assuming you have a state variable for selected country
    setCountrySearchResults([]); // Clear the search results after selection
    setPayloadObject((prevPayload) => {
      const newPayload = {
        ...prevPayload,
        [type]: country,
      };
      setBooleanCountry(true);
      return newPayload;
    });

    // incrementFilters();
  };

  const handleOrganizationSelect = (type, organization) => {
    setPayloadObject((prevPayload) => {
      const newPayload = {
        ...prevPayload,
        [type]: organization,
      };
      setBooleanCountry(true);
      return newPayload;
    });
    if (type === "AFFILIATION") {
      setSelectedOrganization(organization); // Update the selected organization state
    }
  };
  
  const handleScientificLeaderSelect = (type, sleader) => {
    // Handle the selection of an organization from the autocomplete dropdown
    setSelectedSleader(sleader); // Assuming you have a state variable for selected organization
    setScientificLeaderSearchResults([]); // Clear the search results after selection
    setPayloadObject((prevPayload) => ({
      ...prevPayload,
      [type]: sleader,
    }));
    incrementFilters();
  };
  const handleDigitalLeaderSelect = (type, dleader) => {
    // Handle the selection of an organization from the autocomplete dropdown
    setSelectedDleader(dleader); // Assuming you have a state variable for selected organization
    setDigitalLeaderSearchResults([]); // Clear the search results after selection
    setPayloadObject((prevPayload) => ({
      ...prevPayload,
      [type]: dleader,
    }));
    incrementFilters();
  };
  const incrementFilters = (type, value) => {
    console.log("payload", payloadObject);
    let payload = { [type]: value };

    {
      Object.keys(payloadObject).length > 0 &&
        axios
          .post(IncrementalMatchEndpoint(), payloadObject)
          .then((response) => {
            console.log(response?.data, "response");
            // setSearchResults(response.data);
            const keyValuePair = response?.data?.key_value_pairs;

            setCountrySearchResults(keyValuePair?.COUNTRY_NAME);
            setOrganizationSearchResults(keyValuePair?.AFFILIATION);
            setScientificLeaderSearchResults(keyValuePair?.SCIENTIFIC_LEADER);
            setDigitalLeaderSearchResults(keyValuePair?.DIGITAL_LEADER);
            const options = keyValuePair?.SCIENTIFIC_REACH;

            const filteredOptions = scientificReachOptions.filter(
              (OptionItem) => options.includes(OptionItem.value)
            );

            setScientificReachOptions(filteredOptions);
            const optionsEmerging = keyValuePair?.EMERGING_EXPERT;

            const filteredEmergingOptions = emergingOptions.filter(
              (emergingOptionItem) =>
                optionsEmerging.includes(emergingOptionItem.value)
            );

            setEmergingOptions(filteredEmergingOptions);
          })
          .catch((error) => {
            console.error("Error fetching search results:", error);
          });
    }
  };
/* 
  const handleFilterApply = () => {
    // Construct the payload with filter values
    const payload = {
      DIGITAL_LEADER: selectedDleaders,
      SCIENTIFIC_LEADER: selectedSleaders,
      AFFILIATION: selectedOrganization,
      COUNTRY_NAME: selectedCountry,
      EMERGING_EXPERT: emergingExpert, // Replace with the actual value for emerging expert filter
      SCIENTIFIC_REACH: scientificReach,
    };

    // Make the API call to fetch filtered data
    axios
      .post(FilterEndPoint(), payload)
      .then((response) => {
        // Update the profiles state with the filtered data
        setProfiles(response.data);
        // Close the sidebar
        setIsSidebarOpen(false);
      })
      .catch((error) => {
        console.error("Error fetching filtered data:", error);
      });
  };
 */
  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  const toggleView = () => {
    setIsMapView(!isMapView);
  };
  const paginate = (newPage) => {
    setCurrentPage(newPage);
    // Add any additional logic for handling pagination, e.g., fetching data for the new page.
  };
  const CustomMarker = ({ lat, lng, profileName }) => {
    const [showTooltip, setShowTooltip] = useState(false);

    return (
      <div
        style={{
          position: "absolute",
          width: "20px",
          height: "20px",
          backgroundColor: "red",
          borderRadius: "50%",
          border: "2px solid white",
          textAlign: "center",
          color: "white",
          fontSize: "16px",
          fontWeight: "bold",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          transform: "translate(-50%, -50%)",
          cursor: "pointer", // Add cursor pointer for hover effect
        }}
        lat={lat}
        lng={lng}
        onMouseEnter={() => setShowTooltip(true)}
        onMouseLeave={() => setShowTooltip(false)}
      >
        {/* Tooltip */}
        {showTooltip && (
          <div
            style={{
              position: "absolute",
              backgroundColor: "rgba(0, 0, 0, 0.7)",
              color: "white",
              padding: "5px",
              borderRadius: "5px",
              fontSize: "12px",
              zIndex: "999",
            }}
          >
            {profileName}
          </div>
        )}
      </div>
    );
  };

  // Logic to get profiles for the current page
  const indexOfLastProfile = currentPage * profilesPerPage;
  const indexOfFirstProfile = indexOfLastProfile - profilesPerPage;
  const currentProfiles = profiles.slice(
    indexOfFirstProfile,
    indexOfLastProfile
  );

  return (
    <div className="container">
      {selectedGraphUser !== null ? (
        <GraphUI
          scientistsName={selectedGraphUser}
          setSelectedGraphUser={setSelectedGraphUser}
        />
      ) : (
        <>
          <h4>Scientific Experts</h4>
          <div className="search-filter">
            <input
              type="text"
              placeholder="Search Scientists"
              className="search-bar"
              value={searchQuery}
              onChange={handleSearchChange}
            />
            {/* Display autocomplete dropdown */}
            {searchResults.length > 0 && (
              <div className="autocomplete-dropdown">
                {searchResults.map((name, index) => (
                  <div
                    key={index}
                    className="autocomplete-item"
                    onClick={() => handleNameSelect(name)}
                  >
                    {name}
                  </div>
                ))}
              </div>
            )}
            <div className="gap"></div>
            <button className="filter-option" onClick={toggleSidebar}>
              Go To Filters
            </button>
            <button className="view-map-btn" onClick={toggleView}>
              <CiLocationOn /> {isMapView ? "View on Grid" : "View on Map"}
            </button>
          </div>
          {isMapView ? (
            <div className="Gmap">
              <GoogleMapReact
                // Set your Google Maps API key here
                bootstrapURLKeys={{
                  key: "AIzaSyDx1t1xehKETxiCv0KPsGUGVzo0YXra8ZU",
                }}
                defaultCenter={{ lat: 0, lng: 0 }}
                defaultZoom={1}
              >
                {/* Add markers for each profile */}
                {currentProfiles.map((profile) => (
                  <CustomMarker
                    key={profile.LINK_ID}
                    lat={profile.ARCGISLATITUDE}
                    lng={profile.ARCGISLONGITUDE}
                    profileName={profile.FIRST_NAME + " " + profile.LAST_NAME}
                  />
                ))}
              </GoogleMapReact>
            </div>
          ) : (
            <div className="card-container">
              {currentProfiles.map((profile) => (
                <ProfileCard
                  key={profile.SE_ID}
                  name={`${profile.FIRST_NAME} ${profile.LAST_NAME}`}
                  degree={profile.DEGREE_S_}
                  profession={profile.PROFESSION}
                  speciality={profile.SPECIALTY}
                  scientificReach={profile.SCIENTIFIC_REACH}
                  emergingExpert={profile.EMERGING_EXPERT}
                  congressContributions={profile.CONGRESS_CONTRIBUTIONS}
                  publications={profile.PUBLICATIONS}
                  clinicalTrials={profile.CLINICAL_TRIALS}
                  digitalEngagement={profile.DIGITAL_ENGAGEMENT}
                  selectedProfile={selectedProfile}
                  setSelectedGraphUser={setSelectedGraphUser}
                />
              ))}
              <div className="d-flex justify-content-center mt-4">
                <pre>
                  {currentPage > 1 && (
                    <Button onClick={() => paginate(currentPage - 1)}>
                      {"Prev"}
                    </Button>
                  )}
                  &nbsp;
                  {currentPage} (current Page){" "}
                  <Button onClick={() => paginate(currentPage + 1)}>
                    {"Next"}
                  </Button>
                </pre>
              </div>
            </div>
          )}

          <Sidebar
            isOpen={isSidebarOpen}
            emergingExpert={emergingExpert}
            setEmergingExpert={setEmergingExpert}
            scientificReach={scientificReach}
            setScientificReach={setScientificReach}
            toggleSidebar={toggleSidebar}
            countrycode={countrycode}
            selectedSleaders={selectedSleaders}
            selectedDleaders={selectedDleaders}
            setSelectedDleaders={setSelectedDleaders}
            setSelectedSleaders={setSelectedSleaders}
            selectedScientificReach={selectedScientificReach}
            setSelectedScientificReach={setSelectedScientificReach}
            selectedCountry={selectedCountry}
            payloadObject={payloadObject}
            booleanCountry={booleanCountry}
            handleCountrySearch={handleCountrySearch}
            handleCountrySelect={handleCountrySelect}
            handleScientificLeaderSearch={handleScientificLeaderSearch}
            incrementFilters={incrementFilters}
            setPayloadObject={setPayloadObject}
            setBooleanCountry={setBooleanCountry}
            handleScientificLeaderSelect={handleScientificLeaderSelect}
            handleDigitalLeaderSearch={handleDigitalLeaderSearch}
            handleDigitalLeaderSelect={handleDigitalLeaderSelect}
            handleOrganizationSelect={handleOrganizationSelect}
            setSelectedCountry={setSelectedCountry}
            setselectedDleader={setSelectedDleader}
            selectedDleader={selectedDleader}
            selectedSleader={selectedSleader}
            setSelectedSleader={setSelectedSleader}
            countriesFlags={countriesFlags}
            countrySearchResults={countrySearchResults}
            selectedOrganization={selectedOrganization}
            setSelectedOrganization={setSelectedOrganization}
            selectedProfile={selectedProfile}
            setSelectedProfile={setSelectedProfile}
            handleOrganizationSearch={handleOrganizationSearch}
            organizationSearchResults={organizationSearchResults}
            scientificLeaderSearchResults={scientificLeaderSearchResults}
            digitalLeaderSearchResults={digitalLeaderSearchResults}
            scientificReachOptions={scientificReachOptions}
            emergingOptions={emergingOptions}
           /*  handleFilterApply={handleFilterApply} */
          />
        </>
      )}
    </div>
  );
};

const ProfileCard = ({
  name,
  speciality,
  degree,
  profession,
  scientificReach,
  emergingExpert,
  congressContributions,
  publications,
  clinicalTrials,
  digitalEngagement,
  selectedProfile,
  setSelectedGraphUser,
}) => {
  // Function to generate filled and unfilled dots based on the provided value
  const generateDots = (filledCount, label) => {
    const maxDots = 5;
    const filledDots = Math.min(filledCount, maxDots);
    const unfilledDots = maxDots - filledDots;

    const dots = [];

    // Push filled dots
    for (let i = 0; i < filledDots; i++) {
      dots.push(<span className="filled-dot" key={`filled-dot-${i}`} />);
    }

    // Push unfilled dots
    for (let i = 0; i < unfilledDots; i++) {
      dots.push(<span className="unfilled-dot" key={`unfilled-dot-${i}`} />);
    }

    return (
      <div className="dots">
        {dots}
        <p>
          <strong>{label}</strong>
        </p>
      </div>
    );
  };

  const handleNameClick = (name) => {
    setSelectedGraphUser(name);
  };

  // Render all profile details by default if no profile is selected
  if (!selectedProfile) {
    return (
      <div className="profile-card">
        {" "}
        <h6
          className="profile-name"
          onClick={() => {
            handleNameClick(name);
          }}
        >
          {name}
        </h6>
        <div className="profile-info">
          <FaUser className="profile-image" /> &nbsp;&nbsp;
          <p className="degree">
            {" "}
            {degree}
            <br />
          </p>
          <p className="speciality">{profession}</p>
        </div>
        <div className="additional-info">
          <div className="reach-expert">
            <p>
              <span className="Sreach">{scientificReach} Reach</span>{" "}
              &nbsp;&nbsp;
              {emergingExpert === "Y" && (
                <span className="emerging-expert">Emerging Expert</span>
              )}
            </p>
          </div>
          <div className="activities">
            <h5>Activities:</h5>
            <div className="activity-line">
              {generateDots(digitalEngagement, "Digital Engagement")}
              {generateDots(clinicalTrials, "Clinical Trials")}
            </div>
            <div className="activity-line2">
              {generateDots(congressContributions, "Congress Contributions")}
              {generateDots(publications, "Publications")}
            </div>
          </div>
        </div>
      </div>
    );
  } else {
    // Render only the selected profile data if a profile is selected
    return (
      <div className="profile-card">
        {" "}
        <h6
          className="profile-name"
          onClick={() => {
            handleNameClick(selectedProfile);
          }}
        >
          {selectedProfile}
        </h6>
        <div className="profile-info">
          <FaUser className="profile-image" /> &nbsp;&nbsp;
          <p className="degree">
            {" "}
            {degree}
            <br />
          </p>{" "}
          <span className="speciality">{profession}</span>
        </div>
        <div className="additional-info">
          <div className="reach-expert">
            <p>
              <span className="Sreach">{scientificReach} Reach</span>{" "}
              &nbsp;&nbsp;
              {emergingExpert === "Y" && (
                <span className="emerging-expert">Emerging Expert</span>
              )}
            </p>
          </div>
          <div className="activities">
            <h5>Activities:</h5>
            <div className="activity-line">
              {generateDots(digitalEngagement, "Digital Engagement")}
              {generateDots(clinicalTrials, "Clinical Trials")}
            </div>
            <div className="activity-line2">
              {generateDots(congressContributions, "Congress Contributions")}
              {generateDots(publications, "Publications")}
            </div>
          </div>
        </div>
      </div>
    );
  }
};

const Sidebar = ({
  isOpen,
  toggleSidebar,
  selectedCountry,
  countryPayload,
  organizationPayload,
  scientificLeaderPayload,
  digitalLeaderPayload,
  emergingExpertPayload,
  scientificReachPayload,
  payloadObject,
  setPayloadObject,
  booleanCountry,
  setBooleanCountry,
  incrementFilters,
  selectedOrganization,
  emergingExpert,
  setEmergingExpert,
  scientificReach,
  setScientificReach,
  countriesFlags,
  handleCountrySearch,
  handleCountrySelect,
  handleOrganizationSearch,
  handleOrganizationSelect,
  countrySearchResults = [], // Initialize with an empty array
  organizationSearchResults = [], // Initialize with an empty array
  scientificLeaderSearchResults = [],
  digitalLeaderSearchResults = [],
  scientificReachOptions = [],
  emergingOptions = [],
  handleDigitalLeaderSearch,
  handleDigitalLeaderSelect,
  handleScientificLeaderSearch,
  handleScientificLeaderSelect,
  handleFilterApply,
  selectedSleaders,
  setSelectedSleaders,
  selectedScientificReach,
  setSelectedScientificReach,
  selectedDleaders,
  setSelectedDleaders,
}) => {
  const scientificDropdownRef = useRef(null);
  const digitalDropdownRef = useRef(null);
  const countryDropdownRef = useRef(null);
  const organizationDropdownRef = useRef(null);

  const [scientificSearchValue, setScientificSearchValue] = useState("");
  const [digitalSearchValue, setDigitalSearchValue] = useState("");
  const [showScientificDropdown, setShowScientificDropdown] = useState(false);
  const [showDigitalDropdown, setShowDigitalDropdown] = useState(false);
  const [showCountryDropdown, setShowCountryDropdown] = useState(false);
  const [showOrganizationDropdown, setShowOrganizationDropdown] = useState(false);

  const handleEmergingExpertChange = (event, type) => {
    setEmergingExpert(event.target.value);
    setPayloadObject((prevPayload) => {
      const newPayload = {
        ...prevPayload,
        [type]: event?.target?.value,
      };
      setBooleanCountry(true);
      return newPayload;
    });
  };

  const toggleSelection = (selectedList, item, setSelected, type) => {
    let listItems;
    if (selectedList.includes(item)) {
      setSelected(selectedList.filter((i) => i !== item));
      listItems = selectedList.filter((i) => i !== item);
    } else {
      setSelected([...selectedList, item]);
      listItems = [...selectedList, item];
    }
    setPayloadObject((prevPayload) => {
      const newPayload = {
        ...prevPayload,
        [type]: listItems,
      };
      setBooleanCountry(true);
      return newPayload;
    });
  };

  const handleScientificReachChange = (e, selectedScientificReach, setSelectedScientificReach, type) => {
    const value = e.target.value;
    let itemList;
    if (selectedScientificReach.includes(value)) {
      itemList = selectedScientificReach.filter((i) => i !== value);
    } else {
      itemList = [...selectedScientificReach, value];
    }
    setSelectedScientificReach(itemList);
    setPayloadObject((prevPayload) => {
      const newPayload = {
        ...prevPayload,
        [type]: itemList,
      };
      setBooleanCountry(true);
      return newPayload;
    });
  };

  const handleOutsideClick = (event) => {
    if (
      scientificDropdownRef.current &&
      !scientificDropdownRef.current.contains(event.target)
    ) {
      setShowScientificDropdown(false);
    }
    if (
      digitalDropdownRef.current &&
      !digitalDropdownRef.current.contains(event.target)
    ) {
      setShowDigitalDropdown(false);
    }
    if (
      countryDropdownRef.current &&
      !countryDropdownRef.current.contains(event.target)
    ) {
      setShowCountryDropdown(false);
    }
    if (
      organizationDropdownRef.current &&
      !organizationDropdownRef.current.contains(event.target)
    ) {
      setShowOrganizationDropdown(false);
    }
  };

  useEffect(() => {
    document.addEventListener("mousedown", handleOutsideClick);
    return () => {
      document.removeEventListener("mousedown", handleOutsideClick);
    };
  }, [payloadObject]);

  return (
    <div className={`sidebarRight ${isOpen ? "open" : ""}`}>
      <div className="sidebar-content">
        <h5>Filters</h5>

        <h6>Country</h6>
        <input
          type="text"
          placeholder="Search for Country"
          className="filter-search"
          onChange={(e) => handleCountrySearch(e.target.value)}
          value={selectedCountry}
          onClick={() => setShowCountryDropdown(true)}
        />
        {showCountryDropdown && countrySearchResults.length > 0 && (
          <div className="autocomplete-country" ref={countryDropdownRef}>
            {countrySearchResults.map((country, index) => (
              <div
                key={index}
                className="autocomplete-item"
                onClick={() => {
                  handleCountrySelect("COUNTRY_NAME", country);
                  setShowCountryDropdown(false);
                }}
              >
                <img src={countriesFlags[index]} width={15} height={10} />
                &nbsp;&nbsp; {country}
              </div>
            ))}
          </div>
        )}

<h6>Organization</h6>
<input
  type="text"
  placeholder="Search for Organization"
  className="filter-search"
  onChange={(e) => handleOrganizationSearch(e.target.value)}
  value={selectedOrganization}
  onClick={() => setShowOrganizationDropdown(true)}
/>
{showOrganizationDropdown && organizationSearchResults.length > 0 && (
  <div className="autocomplete-org" ref={organizationDropdownRef} style={{ maxHeight: '200px', overflowY: 'scroll' }}>
    {organizationSearchResults.map((organization, index) => (
      <div
        key={index}
        className="autocomplete-item"
        onClick={() => {
          handleOrganizationSelect("AFFILIATION", organization);
          setShowOrganizationDropdown(false);
        }}
      >
        {organization}
      </div>
    ))}
  </div>
)}
<div className="selected-items">
{selectedOrganization && (
      <div className="selected-items">
        <div className="selected-item">
          {selectedOrganization}
          <MdClose
            onClick={() => {
              handleOrganizationSelect("AFFILIATION", ""); // Deselect the organization
            }}
          />
        </div>
      </div>
    )}
</div>


        <h6>Scientific Leader</h6>
        <input
          type="text"
          placeholder="Search for Scientific Leader"
          className="filter-search"
          onChange={(e) => {
            setScientificSearchValue(e.target.value);
            handleScientificLeaderSearch(e.target.value);
            setShowScientificDropdown(true);
          }}
          value={scientificSearchValue}
          onClick={() => setShowScientificDropdown(true)}
        />
        {showScientificDropdown && scientificLeaderSearchResults.length > 0 && (
          <div className="autocomplete-sl" ref={scientificDropdownRef}>
            {scientificLeaderSearchResults.map((sleader, index) => (
              <div
                key={index}
                className="autocomplete-item"
                onClick={() =>
                  toggleSelection(
                    selectedSleaders,
                    sleader,
                    setSelectedSleaders,
                    "SCIENTIFIC_LEADER"
                  )
                }
              >
                <input
                  type="checkbox"
                  checked={selectedSleaders.includes(sleader)}
                  onChange={() =>
                    toggleSelection(
                      selectedSleaders,
                      sleader,
                      setSelectedSleaders,
                      "SCIENTIFIC_LEADER"
                    )
                  }
                />
                &nbsp; {sleader}
              </div>
            ))}
          </div>
        )}
        <div className="selected-items">
          {selectedSleaders.map((sleader, index) => (
            <div key={index} className="selected-item">
              {sleader}
              <MdClose
                onClick={() =>
                  toggleSelection(
                    selectedSleaders,
                    sleader,
                    setSelectedSleaders,
                    "SCIENTIFIC_LEADER"
                  )
                }
              />
            </div>
          ))}
        </div>

        <h6>Digital Leader</h6>
        <input
          type="search"
          title="Digital Leader Search"
          placeholder="Find Topics"
          className="filter-search"
          onChange={(e) => {
            setDigitalSearchValue(e.target.value);
            handleDigitalLeaderSearch(e.target.value);
            setShowDigitalDropdown(true);
          }}
          value={digitalSearchValue}
          onClick={() => setShowDigitalDropdown(true)}
        />
        {showDigitalDropdown && digitalLeaderSearchResults.length > 0 && (
          <div className="autocomplete-dl" ref={digitalDropdownRef}>
            {digitalLeaderSearchResults.map((dleader, index) => (
              <div
                key={index}
                className="autocomplete-item"
                onClick={() =>
                  toggleSelection(
                    selectedDleaders,
                    dleader,
                    setSelectedDleaders,
                    "DIGITAL_LEADER"
                  )
                }
              >
                <input
                  type="checkbox"
                  checked={selectedDleaders.includes(dleader)}
                  onChange={() =>
                    toggleSelection(
                      selectedDleaders,
                      dleader,
                      setSelectedDleaders,
                      "DIGITAL_LEADER"
                    )
                  }
                />
                &nbsp; {dleader}
              </div>
            ))}
          </div>
        )}
        <div className="selected-items">
          {selectedDleaders.map((dleader, index) => (
            <div key={index} className="selected-item">
              {dleader}
              <MdClose
                onClick={() =>
                  toggleSelection(
                    selectedDleaders,
                    dleader,
                    setSelectedDleaders,
                    "DIGITAL_LEADER"
                  )
                }
              />
            </div>
          ))}
        </div>

        <h6>Emerging Expert</h6>
        {emergingOptions?.map((emergingOption) => (
          <div className="radio" key={emergingOption?.value}>
            <input
              type="radio"
              id={emergingOption?.value}
              name="emergingExpert"
              value={emergingOption?.value}
              checked={emergingExpert === emergingOption?.value}
              onChange={(e) => handleEmergingExpertChange(e, "EMERGING_EXPERT")}
            />
            <label htmlFor={emergingOption?.value} className="emerging">
              {emergingOption?.label}
            </label>
          </div>
        ))}

        <h6>Scientific Reach</h6>
        {scientificReachOptions?.map((option) => (
          <div className="check-box" key={option?.value}>
            <input
              type="checkbox"
              id={option?.value}
              value={option?.value}
              checked={selectedScientificReach.includes(option?.value)}
              onChange={(e) =>
                handleScientificReachChange(
                  e,
                  selectedScientificReach,
                  setSelectedScientificReach,
                  "SCIENTIFIC_REACH"
                )
              }
            />
            <label htmlFor={option?.value}>{option?.label}</label>
          </div>
        ))}
       
        <button className="btn-apply" type="submit" onClick={handleFilterApply}>
          Apply Filters
        </button>
      </div>

      <MdClose className="close-icon" onClick={toggleSidebar} />
      
    </div>
  );
};


export default ScientificProfilesPage;
