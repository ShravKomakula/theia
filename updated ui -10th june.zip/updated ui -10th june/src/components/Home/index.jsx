import React from "react";
import "./HomePage.css"; // Assuming you have a CSS file for styling
import globe from "../../assets/globe.svg";
import wm from "../../assets/WM.svg";
import robot from "../../assets/robot.svg";
import animatedGlobe from "../../assets/animated-globe.svg";

function HomePage() {
  return (
    <div className="HomePage">
      <div className="home-content">
        <h6>
          WMS x GMG - Independent Grants and <br />
          Medical Activities Intelligence Platform
        </h6>
      </div>
      <div className="section">
        <div className="first-block">
          <div className="cards-container">
            <div className="card gmgcard">
              <h6>GMG Self service & Automated</h6>
              <img src={robot} alt="Robot" />
            </div>
            <div className="card gmgcard">
              <h6>Organization & PI Intelligence</h6>
              <img src={globe} alt="Globe" />
            </div>
          </div>
          <div className="additional-content">
            <div className="leftcontent">
            <h5>Explore Pfizer Scientific Footprint</h5>
            <ul>
              <li>
                This platform connects you with scientific experts worldwide,
                facilitating access to a diverse pool of knowledge and
                expertise.
              </li>
              <li>
                Through comprehensive networking and collaboration tools, it
                empowers professionals to discover, engage, and leverage
                insights from leading minds across the globe.
              </li>
            </ul>
           
            </div>
            <div className="map">
              <img src={wm} alt="map" />
            </div>
          </div>
        </div>
        <div className="second-block">
          <div className="rightcontent">
          
            <p> Pioneering widespeed Medical initiatives
              Our mission is to transform healthcare on a monumental level,
              catalyzing advancements and innovations in the field.
            </p>
            <img src={animatedGlobe} alt="globe" />
          </div>
        </div>
      </div>
    </div>
  );
}

export default HomePage;
