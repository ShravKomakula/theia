import React, { useState, useEffect } from 'react';
import './MapContainer.css';
import { FetchSnowFlakeData } from '../../common/api-config';
const MapWithAutocomplete = () => {
  const [map, setMap] = useState(null);
  const [autocomplete, setAutocomplete] = useState(null);
  const [infowindow, setInfowindow] = useState(null);
  const [marker, setMarker] = useState(null);
  const [input, setInput] = useState('');
  const [markers, setMarkers] = useState([]);

  useEffect(() => {
    const loadMapScript = () => {
      const script = document.createElement('script');
      script.src = `https://maps.googleapis.com/maps/api/js?key=AIzaSyDx1t1xehKETxiCv0KPsGUGVzo0YXra8ZU&libraries=places&v=weekly`;
      script.defer = true;
      script.onload = initMap;
      document.head.appendChild(script);
    };

    loadMapScript();
  }, []);

  useEffect(() => {
    if (infowindow) {
      document.getElementById('place-name').textContent = infowindow.name || '';
      document.getElementById('place-address').textContent = infowindow.formatted_address || '';
    }
  }, [infowindow]);

  useEffect(() => {
    if (map && markers.length) {
      markers.forEach((markerData) => {
        new window.google.maps.Marker({
          position: markerData,
          map: map,
        });
      });
    }
  }, [map, markers]);

  const initMap = () => {
    const mapInstance = new window.google.maps.Map(document.getElementById('map'), {
      center: { lat: 40.749933, lng: -73.98633 },
      zoom: 3,
      mapTypeControl: false,
    });
    setMap(mapInstance);
  
    const autocompleteInstance = new window.google.maps.places.Autocomplete(document.getElementById('pac-input'), {
      fields: ['formatted_address', 'geometry', 'name'],
      strictBounds: false,
    });
    setAutocomplete(autocompleteInstance);
    autocompleteInstance.bindTo('bounds', mapInstance);
  
    const infowindowInstance = new window.google.maps.InfoWindow();
    setInfowindow(infowindowInstance);
    const markerInstance = new window.google.maps.Marker({
      map: mapInstance,
      anchorPoint: new window.google.maps.Point(0, -29),
    });
    setMarker(markerInstance);
  
    autocompleteInstance.addListener('place_changed', () => {
      infowindowInstance.close();
      markerInstance.setVisible(false);
    
      const place = autocompleteInstance.getPlace();
    
      if (!place.geometry || !place.geometry.location) {
        window.alert(`No details available for input: '${place.name}'`);
        return;
      }
    
      if (place.geometry.viewport) {
        mapInstance.fitBounds(place.geometry.viewport);
      } else {
        mapInstance.setCenter(place.geometry.location);
        mapInstance.setZoom(17);
      }
    
      markerInstance.setPosition(place.geometry.location);
      markerInstance.setVisible(true);
      markerInstance.setTitle(place.name); // Set the name of the place as the marker's title
    
      infowindowInstance.setContent(place.name); // Set the name of the place in the info window
      infowindowInstance.open(mapInstance, markerInstance);
    });
    
    // Fetch data from Snowflake API and set markers
    const fetchData = async () => {
      try {
        const response = await fetch(FetchSnowFlakeData(),{});
        const data = await response.json();
        const fetchedMarkers = data.results.map(result => ({
          lat: parseFloat(result[16]),
          lng: parseFloat(result[17]),
        }));
        setMarkers(fetchedMarkers);
      } catch (error) {
        console.error('Error fetching data from Snowflake API:', error);
      }
    };
    fetchData();
  };
  
  const handleInputChange = (event) => {
    setInput(event.target.value);
  };

  return (
    <div>
      <div className="pac-card" id="pac-card">
        <div>
          <div id="pac-container">
            <input id="pac-input" type="text" placeholder="Enter a location" value={input} onChange={handleInputChange} />
          </div>
        </div>
      </div>
      <div id="map" style={{ height: '400px', width: '80%' }}></div>
      <div id="infowindow-content">
        <span id="place-name" className="title"></span>
        <br />
        <span id="place-address"></span>
      </div>
    </div>
  );
};

export default MapWithAutocomplete;
