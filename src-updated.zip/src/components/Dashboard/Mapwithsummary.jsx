import React, { useState } from "react";
import {
  GoogleMap,
  LoadScript,
  Marker,
  InfoWindow,
} from "@react-google-maps/api";
import "./Mapwithsummary.css";
import Globe from "../../assets/images/globeIcon.svg";
import usericon from "../../assets/images/user.svg";
import handwave from "../../assets/images/handwave.svg";
import bullets from "../../assets/images/bulletpoints.svg";
import diseaseicon from "../../assets/diseaseicon.svg";
const apiKey = "AIzaSyDx1t1xehKETxiCv0KPsGUGVzo0YXra8ZU"; // Replace with your Google Maps API key

const Mapwithsummary = ({ data, userCountryCode }) => {
  const user = JSON.parse(localStorage.getItem("access_token"));
  const [selectedMarker, setSelectedMarker] = useState(null);

  const handleMarkerClick = (marker) => {
    setSelectedMarker(marker);
  };

  return (
    <div className="container summary-container">
      <div className="column summary">
        <div className="column-summary">
          {/* Profile summary content */}

          <div className="profile-header">
            <h2>Summary</h2>
          </div>

          <div className="summary-row">
            <div className="summary-column">
              {/* Content for column 1 */}
              <div className="summary-item">
                <img src={Globe} alt="country" />
                <div className="summary-text">
                <h3>country</h3>
                <strong>Country</strong>
                </div>
              </div>
            </div>

            <div className="summary-column">
              {/* Content for column 2 */}
              <div className="summary-item">
              <img src={diseaseicon} alt="disease icon" />
              <div className="summary-text">
              <h3>Pfizer BU and Disease</h3>
              <strong>Disease</strong>
              </div>
            </div>
</div>
            <div className="summary-column">
              {/* Content for column 3 */}
              <div className="summary-item">
              <img src={usericon} alt="user icon" />
              <div className="summary-text">
              <h3>Role</h3>
              <strong>Dentist</strong>
              </div>
            </div>
            </div>
          </div>
        </div>

        <div className="profile-summary">
          <h5>High Level Summary</h5>
          <hr />
          <h6>
            <img src={handwave} className="imgicon" alt="Handwave" />
            Hi {localStorage.getItem("userName")}, Welcome back
          </h6>
          <p className="small">Here are the latest updates</p>
          <ul>
            <li>
              <img src={bullets} className="imgicon" alt="Bullet points" />
              In the last week 12 grants have been approved with the funding
              total of $2.3M.
            </li>
            <li>
              <img src={bullets} className="imgicon" alt="Bullet points" />
              There are 4 grants that closed last week with outcomes report and
              publications below.
            </li>
            <li>
              <img src={bullets} className="imgicon" alt="Bullet points" />
              Currently 5 grants ongoing need your attention and are flagged by
              our AI for your review.
            </li>
          </ul>
        </div>
      </div>
      <div className="column map">
        <h5>MapView</h5>
        <LoadScript googleMapsApiKey={apiKey}>
          <GoogleMap
            mapContainerStyle={{ width: "100%", height: "100%" }}
            center={{
              lat: data[0] ? parseFloat(data[0][16]) : 0,
              lng: data[0] ? parseFloat(data[0][17]) : 0,
            }}
            zoom={2}
          >
            {data.map((row, index) => (
              <Marker
                key={index}
                position={{
                  lat: parseFloat(row[16]),
                  lng: parseFloat(row[17]),
                }}
                onClick={() => handleMarkerClick(row)}
              />
            ))}
            {selectedMarker && (
              <InfoWindow
                position={{
                  lat: parseFloat(selectedMarker[16]),
                  lng: parseFloat(selectedMarker[17]),
                }}
                onCloseClick={() => setSelectedMarker(null)}
              >
                <div>{selectedMarker[0]}</div>
              </InfoWindow>
            )}
          </GoogleMap>
        </LoadScript>
      </div>
    </div>
  );
};

export default Mapwithsummary;
