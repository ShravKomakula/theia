import React, { useState, useEffect } from "react";
import "./Dashboard.css";
import axios from "axios";
import Mapwithsummary from "./Mapwithsummary";
import { CiGrid2H } from "react-icons/ci";
import { MdGridOn } from "react-icons/md";
import { DataGrid } from '@mui/x-data-grid';
import { FetchSnowFlakeData, mainsearchEndpoint } from "../../common/api-config";
import { format, isValid } from 'date-fns';
import TileView from "./TileView";
import Overview from "./Overview";

function Dashboard() {
  const [grantedViewActive, setGrantedViewActive] = useState(true);
  const [allViewActive, setAllViewActive] = useState(false);
  const [data, setData] = useState({});
  const [rows, setRows] = useState([]);
  const [columns, setColumns] = useState([]);
  const [isGridView, setIsGridView] = useState(false);
  const [searchResults, setSearchResults] = useState([]);
  const [query, setQuery] = useState({
    pi_name: '',
    organization_name: '',
    primary_area_of_interest_disease: '',
    top_k: 3
  });

  const [searchCriterion, setSearchCriterion] = useState('pi_name');
  const userC = JSON.parse(localStorage.getItem('access_token'));
  const userCountryCode = userC.userInfo.LOCATION_CODE_ISO2;

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const response = await fetch(FetchSnowFlakeData());
      const result = await response.json();

      const columnNames = result.columns;
      const excludedColumns = ['LATITUDE', 'LONGITUDE', 'LOGO_URL', 'COUNTRY_CODE', 'CITY', 'COUNTRY'];
      const filteredColumns = columnNames
        .filter((fieldName) => !excludedColumns.includes(fieldName))
        .map((fieldName) => ({
          field: fieldName,
          headerName: fieldName
            .replace(/_/g, ' ')
            .toLowerCase()
            .replace(/\b(\w)/g, (char) => char.toUpperCase()),
          width: 150,
          valueFormatter: (params) => {
            const value = params.value;
            if (fieldName === 'LAST_UPDATE' || fieldName === 'NEXT_MILESTONE') {
              const date = new Date(value);
              return isValid(date) ? format(date, 'MM/dd/yyyy') : '';
            }
            if (fieldName === 'APPROVED_AMOUNT' || fieldName === 'PAYMENT_REMAINING') {
              return `$${value != null ? value.toFixed(2) : '0.00'}`;
            }
            return value;
          },
        }));

      setColumns(filteredColumns);

      const formattedRows = result.results.map((row, index) => {
        const rowObject = {};
        columnNames.forEach((name, i) => {
          rowObject[name] = row[i];
        });
        rowObject.id = index;  // Ensure each row has a unique id
        return rowObject;
      });

      setData(result);
      setRows(formattedRows);
      console.log("All rows", result.results);
      console.log("Formatted rows", formattedRows);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  const formatRows = (dataRows, columnList, columnNames) => {
    return dataRows.map((row, index) => {
      const rowObject = { id: index }; // Assigning the index as the id
      columnList.forEach((column) => {
        const columnName = column.field;
        const columnIndex = columnNames.indexOf(columnName);
        if (columnIndex !== -1) {
          rowObject[columnName] = row[columnIndex];
        }
      });
      return rowObject;
    });
  };

  const handleGrantedViewClick = () => {
    setGrantedViewActive(true);
    setAllViewActive(false);
  };

  const handleAllViewClick = () => {
    setGrantedViewActive(false);
    setAllViewActive(true);
  };

  const handleTileViewClick = () => {
    setIsGridView(false);
  };

  const handleGridViewClick = () => {
    setIsGridView(true);
  };

  const filteredData = (data.results && grantedViewActive)
    ? data.results.filter(row => row[data.columns.indexOf('COUNTRY_CODE')] === userCountryCode)
    : data.results || [];

  const formattedFilteredData = formatRows(filteredData, columns, data.columns || []);

  const handleSearch = async () => {
    try {
      console.log("Query Parameters:", query);
      const response = await axios.post(mainsearchEndpoint(), null, {
        params: query
      });
      console.log("Search Response:", response.data);
  
      if (response.data && response.data.results) {
        const formattedResults = formatRows(response.data.results, columns, response.data.columns);
        console.log("Formatted Search Results:", formattedResults);
        setSearchResults(formattedResults);
      } else {
        console.warn("Search response is empty or incorrectly formatted", response.data);
        setSearchResults([]);
      }
    } catch (error) {
      console.error('Error fetching search data:', error);
    }
  };
  

  const handleCriterionChange = (e) => {
    setSearchCriterion(e.target.value);
    setQuery({
      ...query,
      pi_name: '',
      organization_name: '',
      primary_area_of_interest_disease: ''
    });
  };

  return (
    <div className="Dashboard">
      <h4>Grants Dashboard</h4>
      <Overview />
      <div className="section1">
        <div className="buttons-section">
          <button
            type="button"
            className={`btn rbtn ${grantedViewActive ? "active" : ""}`}
            onClick={handleGrantedViewClick}
          >
            Recommended View
          </button>
          <button
            type="button"
            className={`btn abtn ${allViewActive ? "active" : ""}`}
            onClick={handleAllViewClick}
          >
            All View
          </button>
        </div>
        {allViewActive && (
          <div className="inputsection">
            <select value={searchCriterion} onChange={handleCriterionChange}>
              <option value="pi_name">PI Name</option>
              <option value="organization_name">Organization Name</option>
              <option value="primary_area_of_interest_disease">Primary Area of Interest/Disease</option>
            </select>
            <input
              type="text"
              placeholder={`Search by ${searchCriterion.replace('_', ' ')}`}
              value={query[searchCriterion]}
              onChange={(e) => setQuery({ ...query, [searchCriterion]: e.target.value })}
            />
            <button onClick={handleSearch}>Search</button>
          </div>
        )}
        <div className="section2">
          <Mapwithsummary data={filteredData} userCountryCode={userCountryCode} />
        </div>
        <div className="section3">
          <div className="icon-section">
            <CiGrid2H
              className={`Tileview ${!isGridView ? "active" : ""}`}
              onClick={handleTileViewClick}
            />
            <MdGridOn
              className={`Gridview ${isGridView ? "active" : ""}`}
              onClick={handleGridViewClick}
            />
          </div>
          <div className="content-section">
            {!isGridView && <TileView data={searchResults.length > 0 ? searchResults : filteredData} userCountryCode={userCountryCode} />}
            {isGridView && (
              <div style={{ width: '100%', height: '400px', maxWidth: 1000, margin: 'auto' }}>
                <DataGrid
                  rows={searchResults.length > 0 ? searchResults : formattedFilteredData}
                  columns={columns}
                  pageSize={5}
                  className="gridtable"
                  rowsPerPageOptions={[5, 10, 20]}
                />
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;
