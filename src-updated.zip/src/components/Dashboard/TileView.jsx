import React, { useState } from "react";
import "./TileView.css"; // Your CSS file for styling
import totalpayment from "../../assets/totalpayment.svg";
import pendingpayment from "../../assets/pendingpayment.svg";
import method from "../../assets/method.svg";
import disease from "../../assets/disease.svg";
import drug from "../../assets/drug.svg";
import duration from "../../assets/durations.svg";
import pending from "../../assets/pending.svg";
import success from "../../assets/success.svg";
import location from "../../assets/location.svg";
import { IoIosArrowDropdownCircle } from "react-icons/io";
import { GoDotFill } from "react-icons/go";
const ITEMS_PER_PAGE = 3; // Number of items to display per page

function TileView({ data, userCountryCode }) {
  const [currentPage, setCurrentPage] = useState(0);

  // Filter the data based on the user's country code
  const filteredData = data;

  const startIndex = currentPage * ITEMS_PER_PAGE;
  const endIndex = startIndex + ITEMS_PER_PAGE;
  const currentItems = filteredData.slice(startIndex, endIndex);

  const [expandedCard, setExpandedCard] = useState(null);
  const toggleCard = (index) => {
    setExpandedCard(expandedCard === index ? null : index);
  };

  const handlePrev = () => {
    setCurrentPage((prevPage) => Math.max(prevPage - 1, 0));
  };

  const handleNext = () => {
    setCurrentPage((prevPage) =>
      Math.min(
        prevPage + 1,
        Math.ceil(filteredData.length / ITEMS_PER_PAGE) - 1
      )
    );
  };

  return (
    <>
      <div className="tile-container">
        {currentItems.map((item, index) => (
          <div
            key={index}
            className="card"
            style={{
              width: "100%",
              padding: "10px",
              borderRadius: "10px",
              border: "none",
              marginBottom: "20px",
            }}
          >
            <div className="card-body tile-body">
              {/* 1st row */}
              <div className="row align-items-center">
                <div className="col-1 logo">
                  {/* Logo */}
                  <img src={item[15]} alt="Logo" style={{ width: "100%" }} />
                </div>
                <div className="col-6 project-title">
                  {/* Project Title */}
                  <strong>{item[1]}</strong>
                </div>
                <div className="col-3 location">
                  <p>
                    <img
                      src={location}
                      alt="location"
                      style={{ width: "20px", marginRight: "5px" }}
                    />{" "}
                    {item[26]},{item[27]}
                  </p>
                </div>
              </div>

              {/* 2nd row */}
              <div className="row align-items-center secondrow">
                <div className="col-1.5">
                  <div className="d-flex flex-column align-items-center">
                    <img
                      src={totalpayment}
                      alt="total payment"
                      className="tileicon"
                    />
                    Total Payment :<br />
                    {`$${item[3]}`}
                  </div>
                </div>
                <div className="col-1.5">
                  <div className="d-flex flex-column align-items-center">
                    <img
                      src={pendingpayment}
                      alt="pending payment"
                      className="tileicon"
                    />
                    Pending Payment :<br />
                    {`$${item[4]}`}
                  </div>
                </div>
                <div className="col-2">
                  <div className="d-flex flex-column align-items-center">
                    <img src={method} alt="method" className="tileicon" />
                    Method: <br />
                    {`${item[19]}`}
                  </div>
                </div>
                <div className="col-2">
                  <div className="d-flex flex-column align-items-center">
                    <img src={disease} alt="disease" className="tileicon" />
                    Disease: <br />
                    {`${item[18]}`}
                  </div>
                </div>
                <div className="col-2">
                  <div className="d-flex flex-column align-items-center">
                    <img src={drug} alt="drug" className="tileicon" />
                    Drug Name:
                    <br /> {`${item[20]}`}
                  </div>
                </div>
                <div className="col-2">
                  <div className="d-flex flex-column align-items-center">
                    <img src={duration} alt="duration" className="tileicon" />
                    Duration:
                    <br />
                    {`${item[21]}`}
                  </div>
                </div>
              </div>

              {/* 3rd row */}
              <div className="row align-items-center">
                <div className="col-3">
                  {/* Study Design */}
                  <div className="input-group-prepend">
                    <span
                      className="input-group-text"
                      id="inputGroup-sizing-sm"
                    >
                      Study Design
                    </span>
                    <input
                      type="text"
                      className="form-control custom-input"
                      aria-label="Small"
                      aria-describedby="inputGroup-sizing-sm"
                      value={item[30]}
                      readOnly
                    />
                  
                  </div>
                </div>
                <div className="col-3">
                  {/* PT Clinical */}
                  <div className="input-group-prepend">
                    <span
                      className="input-group-text"
                      id="inputGroup-sizing-sm"
                    >
                      Population
                    </span>
                    <input
                      type="text"
                      className="form-control custom-input"
                      aria-label="Small"
                      aria-describedby="inputGroup-sizing-sm"
                      value={item[28]}
                      readOnly
                    />
                  </div>
                </div>
                <div className="col-4">
                  {/* Patients Enrolled */}
                  <div className="input-group-prepend">
                    <span
                      className="input-group-text"
                      id="inputGroup-sizing-sm"
                    >
                      Patients Enrolled
                    </span>
                    <div className="progress" style={{ width: "100%" }}>
                      <div
                        className="progress-bar"
                        role="progressbar"
                        style={{
                          width: item[22] ? `${item[22]}` : "0",
                          backgroundColor: item[22] ? "blue" : "#f3f3f3",
                        }}
                        aria-valuenow={item[22]}
                        aria-valuemin="0"
                        aria-valuemax="10000"
                      >
                        {item[22] ? `${item[22]}` : "0"}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* 4th row */}
              <div
                className="row align-items-center"
                style={{ paddingTop: "20px" }}
              >
                <div className="col-2 status">
                  {/* Status */}
                  <p>{`Status Insights: ${item[22]}`}</p>
                </div>
                <div className="col-2 status">
                  {/* Insight */}
                  <p>{`Enrollment Insight: ${item[24]}`}</p>
                </div>
                <div className="col-2 status">
                  {/* Completed */}
                  <p>{`Upcoming: ${item[5]}`}</p>
                </div>
                <div className="col-1.5 link">
                  {/* Outcome Report */}
                  <a href="#">Outcome Report </a>
                </div>
                <div className="col-1.5 link">
                  {/* Publication Link */}
                  <a href="#">Publication Link</a>
                </div>
                <div className="col-2 link">
  <a href="#" onClick={(e) => { e.preventDefault(); toggleCard(index); }}>
    View GenAI Summary <IoIosArrowDropdownCircle />
  </a>
</div>

                
              </div>
              {expandedCard === index && (
                    <div className="genAI-Summary">
                      <div className="row">
                        <div className="col-6 leftsummary">
                          <h6><GoDotFill className="icon-blue"/> Research Summary</h6>
                          <p>
                            Research Summary Current therapies for Transthyretin
                            amyloidosis (ATTR) target the misfolded protein but
                            do not address tissue damage by the already
                            deposited amyloid. We have demonstrated that
                            increased abundance of proteins within cardiac (and
                            renal) amyloid plaques is associated with improved
                            outcomes, which suggests that the amount of
                            deposited proteins, may merely be a surrogate for
                            indolent disease biology.
                          </p>
                          <div className="btn-group buttonblock">
<button type="button" className="btn bluebg mr-2 rounded-pill">Data Gaps</button>
<button type="button" className="btn bluebg mr-2 rounded-pill">Health Quality</button>
<button type="button" className="btn bluebg mr-2 rounded-pill">Digital Health & AI</button>
<button type="button" className="btn greenbg rounded-pill">Higher Learners Reached</button>
</div>
                        </div>
                        <div className="col-5 rightsummary">
                          <h6><GoDotFill className="icon-blue"/> Outcomes Heilights</h6>
                          <p>
                            Current therapies for Transthyretin amyloidosis
                            (ATTR) target the misfolded protein but do not
                            address tissue damage by the already deposited
                            amyloid. We have demonstrated that increased
                            abundance of proteins within cardiac (and renal)
                            amyloid plaques is associated with improved
                            outcomes, which suggests that the amount of
                            deposited proteins, may merely be a surrogate for
                            indolent disease biology.
                          </p>
                        </div>
                      </div>
                    </div>
                  )}
            </div>
          </div>
        ))}
      </div>
      {/* Pagination Controls */}
      <div className="pagination-controls">
        <button onClick={handlePrev} disabled={currentPage === 0}>
          Prev
        </button>
        <button onClick={handleNext} disabled={endIndex >= filteredData.length}>
          Next
        </button>
      </div>
    </>
  );
}

export default TileView;
