import React, { useState, useEffect } from 'react';
import { DataGrid } from '@mui/x-data-grid';
import axios from 'axios';
import Chart from 'react-apexcharts';
import Topbar from '../../common/Topbar';
import Footer from '../../common/Footer/Footer';
import { InsightsEndPoint } from '../../common/api-config';
import './insights.css';

const Insights = () => {
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(true);
    const [columns, setColumns] = useState([]);
    const [totalRows, setTotalRows] = useState(0);
    const pageSize = 5;
    const [currentPage, setCurrentPage] = useState(0);
    const [donutChartData, setDonutChartData] = useState([]);
    const [barChartData, setBarChartData] = useState([]);
    useEffect(() => {
        const fetchInsightsData = async () => {
            try {
                setLoading(true);
                const offset = currentPage * pageSize;
                const response = await axios.get(InsightsEndPoint(), {
                    params: { offset, limit: pageSize }
                });
                const jsonData = response.data.map((row, index) => ({
                    id: offset + index + 1,
                    ...row,
                }));
                setData(jsonData);
                setLoading(false);
                processDonutChartData(jsonData);
                processBarChartData(jsonData);
                setTotalRows(response.data.length);
                if (jsonData.length > 0) {
                    const firstItem = jsonData[0];
                    const columnNames = Object.keys(firstItem).map(key => ({
                        field: key,
                        headerName: key
                            .split('_') // Split by underscore
                            .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()) // Capitalize each word
                            .join(' '), // Join with space
                        
                        flex: 1,
                        sortable: true,
                        headerClassName: 'bold-header', // Add a class for bold headers
                         
                    }));
                    setColumns(columnNames);
                }
                
            } catch (error) {
                console.error('Error fetching data:', error);
                setLoading(false);
            }
        };
    
        fetchInsightsData();
    }, [currentPage]);
    

    const onPageChangeHandler = (page) => {
        setCurrentPage(page - 1);
    };

    const processDonutChartData = (insightsData) => {
        // Process donut chart data
        // Example:
        // Replace this with your actual data processing logic
        const statusCounts = {};
        insightsData.forEach(row => {
            // Process each row and count occurrences of each status
            Object.keys(row).forEach(key => {
                if (key.endsWith('_STATUS')) {
                    const status = row[key];
                    statusCounts[status] = (statusCounts[status] || 0) + 1;
                }
            });
        });
        const donutChartData = Object.keys(statusCounts).map(status => ({
            x: status,
            y: statusCounts[status]
        }));
        setDonutChartData(donutChartData);
    };

    const processBarChartData = (insightsData) => {
        const statusCounts = { OK: 0, 'NOT OK': 0 };
    
        insightsData.forEach(row => {
            const mappDatesStatus = row['MAPP_DATES_STATUS'];
            const mappSectionStatus = row['MAPP_SECTION_STATUS'];
    
            // If both statuses are 'OK', count as 'OK'; otherwise, count as 'NOT OK'
            if (mappDatesStatus === 'OK' && mappSectionStatus === 'OK') {
                statusCounts['OK']++;
            } else {
                statusCounts['NOT OK']++;
            }
        });
    
        const barData = Object.keys(statusCounts).map(status => ({
            x: status,
            y: statusCounts[status]
        }));
    
        setBarChartData(barData);
    };
    const barChartOptions = {
        chart: {
            type: 'bar',
            height: 350,
        },
        plotOptions: {
            bar: {
                horizontal: false,
                columnWidth: '30%',
                endingShape: 'rounded'
            },
        },
        dataLabels: {
            enabled: false
        },
        stroke: {
            show: true,
            width: 2,
            colors: ['transparent']
        },
        xaxis: {
            categories: barChartData.map(data => data.x)
        },
        yaxis: {
            title: {
                text: 'Count'
            }
        },
        fill: {
            opacity: 1
        },
        tooltip: {
            enabled: true,
            followCursor: false,
            y: {
                formatter: function (val) {
                    return "Total Count: " + val;
                }
            },
            style: {
                fontSize: '12px',
                fontFamily: 'Helvetica, Arial, sans-serif'
            },
            formatter: function (series, { seriesIndex, dataPointIndex, w }) {
                return '<div class="tooltip">' +
                    '<span>Total Count: ' + series[seriesIndex][dataPointIndex] + '</span>' +
                    '</div>';
            }
        }
    };
    

    const donutChartOptions = {
        labels: donutChartData.map(data => data.x)
    };

    return (
        <div style={{ backgroundColor: '#f2f2f2' }}>
            <Topbar />
            <div className='d-flex flex-column p-5 insights-section'>
                <div className='chart-section-container'>
                    <div className='donut-chart chart-section'>
                        {/* Donut chart */}
                        <Chart
                            options={donutChartOptions}
                            series={donutChartData.map(data => data.y)}
                            type='donut'
                            
                            height={600}
                            width={600}
                        />
                    </div>
                    <div className='bar-chart chart-section'>
                        {/* Bar chart */}
                        <Chart
                            options={barChartOptions}
                            series={[{ data: barChartData }]}
                            type='bar'
                            height={400}
                            width={400}
                        />
                    </div>
                </div>
       
                <div className='data-grid-container' style={{ height: '600px', marginLeft: '20px' }}>
                    {/* Data grid */}
                    <DataGrid 
    rows={data}
    columns={columns}
    loading={loading}
    pageSize={pageSize}
    rowsPerPageOptions={[pageSize]}
    onPageChange={onPageChangeHandler}
    pagination
    rowCount={totalRows}
    getRowClassName={(params) => (params.index % 2 === 0 ? 'even-row' : 'odd-row')}
/>

                </div>
            </div>
            <Footer />
        </div>
    );
};

export default Insights;
