const BASIC_GATEWAY="http://127.0.0.1:8015/";
//const BASIC_GATEWAY = "http://localhost:5005/";


export const QuestionEndPoint = () => (`${BASIC_GATEWAY}query_rag`)
export const GetPastQuesriesEndPoint = () => (`${BASIC_GATEWAY}get_question_list`)
export const GetAnswerEndPoint = () => (`${BASIC_GATEWAY}get_answer`)
export const DownloadEndPoint = (document_key) => (`${BASIC_GATEWAY}download/${document_key}`)
export const ViewEndpoint = (document_key) => (`${BASIC_GATEWAY}view/${document_key}`)
export const LikeEndPoint = () => (`${BASIC_GATEWAY}like`)
export const DisLikeEndPoint = () => (`${BASIC_GATEWAY}dislike`)
export const CommentEndPoint = () => (`${BASIC_GATEWAY}comment`)
