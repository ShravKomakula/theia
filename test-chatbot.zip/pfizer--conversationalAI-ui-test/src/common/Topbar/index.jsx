import React from 'react';
import logo from '../../assets/images/Logo_3-removebg-preview 1 (1).svg';
import profilePic from '../../assets/images/Ellipse 2.svg';
// import robot from '../../assets/images/chatgpt robot sad.svg';
import './topbar.css';
import { useNavigate } from "react-router-dom";

import signOut from "../../assets/images/SignOut.svg";
import { useAuth } from '../../components/AuthContext';
import Ellipse from "../../assets/images/Ellipse.svg";
const Topbar = () => {
    const navigate = useNavigate();


    const { logout } = useAuth();

    const handleLogout = () => {
        logout()
    }
    return (
        <div className='d-flex flex-row p-2 justify-content-between align-items-center topbar-container' style={{ position: 'fixed', top: 0, width: '100%', zIndex: 1000 }}>
            <div className='d-flex flex-row align-items-center'>
                <img src={logo} alt="logo" />
                {/* <img src={robot} alt="robot" className='ml-2'/> */}
            </div>
            {/* <div className='d-flex flex-row align-items-center'>
                <div className='topbar-text'>John Doe</div>
                <img src={profilePic} alt="profile" className='ml-2'/>
            </div> */}
            <div className="user-account" style={{ display: "flex", }}>
                <div style={{ marginTop: "3px", marginRight: "5px" }}>{localStorage.getItem("userName")}</div>
                <div><img src={Ellipse} alt="User Icon" />
                    <img style={{ marginLeft: "10px", cursor: "pointer" }} src={signOut} onClick={() => handleLogout()} alt="User Icon" />
                </div>
            </div>
        </div>
    )
}

export default Topbar;