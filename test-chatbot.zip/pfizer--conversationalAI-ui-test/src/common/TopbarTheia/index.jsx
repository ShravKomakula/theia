import React from 'react';
import imageTheia from '../../assets/images/theia.png';
import Ellipse from "../../assets/images/Ellipse.svg";
import logo from '../../assets/images/Logo_3-removebg-preview 1 (1).svg';
import '../../components/LandingpageTheia/LandingTheia.css';


const TopbarTheia = () => {
    <div className='header w-100 justify-content-between p-1'>
    <div className='logo-section d-flex flex-row align-items-center'>
      <img src={logo} alt='Logo'/>
      <img src={imageTheia} alt="imageTheia" className="ml-3" style={{height:"50px"}}/>
      {/* <span className='ml-3'>Centar Theia</span> */}
    </div>
    <div className='d-flex flex-row align-items-center'>
      <span>GMG Program & Overview</span>
      <div className='vertical-line ml-3'></div>
      <span className='ml-3'>Operators</span>
      <div className='vertical-line ml-3'></div>
      <span className='ml-3'>Help & FAQ</span>
      <div className='ml-3 mr-2'>
        <span>John Doe</span>
        <img alt='User' src={Ellipse} className='ml-1' />
      </div>
    </div>
  </div>
}

export default TopbarTheia;