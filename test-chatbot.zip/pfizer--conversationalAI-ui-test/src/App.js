import React from 'react';
import LandingPage from '../src/components/LandingPage';
import LandingTheia from '../src/components/LandingpageTheia';
import Login from '../src/components/LoginPage';
import Queries from '../src/components/Queries';
import Topbar from '../src/common/Topbar';
import LoginView from './components/LoginView/LoginView';
import { ToastContainer } from 'react-toastify';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'react-toastify/dist/ReactToastify.css';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import './App.css';
import Insights from './components/Insights';
import { AuthProvider } from './components/AuthContext';
import AuthWrapper from './components/AuthWrapper';
import LandingPageNew from './components/LandingPageNew';


import MyDashboard from './components/MyDashboard/MyDashboard';
function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/landing-page" element={
            <AuthWrapper>
              <LandingPageNew />
            </AuthWrapper>
          } />

          <Route path="/" element={
            <AuthWrapper>
              <LoginView />
            </AuthWrapper>
          } />
          <Route path="/queries" element={

            <AuthWrapper>
              <Queries />
            </AuthWrapper>
          } />
          <Route path="/my-dashboard" element={
            <AuthWrapper>
              <MyDashboard />
            </AuthWrapper>
          } />

          <Route path="/insights" element={
            <AuthWrapper>
              <Insights />
            </AuthWrapper>
          } />
          {/* <Route path="/login" element={<Login />} /> */}
          {/* <Route path="/landing-theia" element={
            <AuthWrapper>
              <LandingPage />
            </AuthWrapper>
          } /> */}
          {/* <Route path="/landing-page-new" element={
            <AuthWrapper>
              <LandingTheia />
            </AuthWrapper>
          } /> */}


        </Routes>
        <ToastContainer />
      </Router>
    </AuthProvider>
  );
}

export default App;
