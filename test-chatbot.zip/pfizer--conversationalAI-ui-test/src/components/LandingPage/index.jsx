import React, {useState} from 'react';
import './landingPage.css';
import Select, { components } from 'react-select';
import { Link } from 'react-router-dom';
import { toast } from "react-toastify";
import { useNavigate } from 'react-router-dom';
import dropdown from '../../assets/images/CaretDown.svg';
import search from '../../assets/images/Vector (3).svg';
import document from '../../assets/images/Frame 9214 (1).svg';
import gen from '../../assets/images/Frame 9214 (2).svg';
import support from '../../assets/images/Frame 9214.svg';
import logo from '../../assets/images/Logo_3-removebg-preview 1 (1).svg';
import robot from '../../assets/images/chatgpt robot sad.svg';

const LandingPage = () => {
    const navigate = useNavigate()
    const [question, setQuestion] = useState("")
    const [source, setSource] = useState(null)


    const influencers = [
        { value: "Document", label: "Document" },
        { value: "DB", label: "DB" }
    ];

    const ValueContainer = ({ children, ...props }) => {
        return (
            components.ValueContainer && (
                <components.ValueContainer {...props}>
                    <div className='landing-dropdownIndicator'>
                        <img src={search} alt="Search" className='landing-searchIcon' />
                        {children}
                    </div>
                </components.ValueContainer>
            )
        );
    };

    const DropdownIndicator = props => {
        return (
            components.DropdownIndicator && (
                <components.DropdownIndicator {...props}>
                    <div className='landing-dropdownIndicator'>
                        <div>Select Source</div>
                        <img src={dropdown} alt="search" className='landing-ml10' />
                    </div>

                </components.DropdownIndicator>
            )
        );
    };

    const cardsData = [
        {
            img: support,
            text: "Select documents and Q&A",
            link: "Generate"
        },
        {
            img: document,
            text: "Get Better answers with Gen AI",
            link: "Generate"
        },
        {
            img: gen,
            text: "Support Resources & Tutorials",
            link: "Generate"
        }
    ]
    const styles = {
        option: (provided, state) => ({
            ...provided,
            backgroundColor: state.isSelected ? '#3366ff' : 'white',
            color: state.isSelected ? 'white' : 'black'
          }),
        valueContainer: base => ({
            ...base,
            paddingLeft: 24
        }),
        control: base => ({
            ...base,
            minHeight: 50,
            width: 200,
            // borderRadius: 8,
            // borderLeftRadius: 5,
            border: "1px solid #ccc",
        }),
        indicatorSeparator: base => ({
            ...base,
        }),
        dropdownIndicator: base => ({
            ...base,
            color: "grey"
        })
    };
    const selectQuestion = (event) => {
        setQuestion(event.target.value)
    }
    const selectAnswer = (event) => {
        setSource(event.label)
        localStorage.setItem('selectedSource', event.label);
    }
    const searchQuestions=()=> {
        if (source !== null && question.trim() !== '') {
            console.log(question)
           navigate("/queries", { state: { question } })
        } else {
            toast.warning('Please select a document and enter a question.', { position: toast.POSITION.TOP_CENTER });
        } 
    }
    return (
        <div className="landing-page-container">
            <div className="content-wrapper">
                <img src={logo} alt="logo" className="logo" />
                <div className="landingPage-font-400">
                    Discover the best of&nbsp;
                    <span className='landingPage-font-600 landing-hr'>Pfizer</span> &nbsp;
                    with&nbsp;
                    <span className='landingPage-font-600 landing-hr'>Pfizer search</span>&nbsp;
                    <img src={robot} alt="robot" className="robot-icon" />
                </div>
                <div className='landingPage-font-300'>
                    The AI Assistant that guides you to be faster, stronger and better
                </div>
                <div className="search-section" style={{backgroundColor:"#0271EF", borderRadius:"5px",padding: "10px"}}>
                    <div className="search-container d-flex justify-content-between col-12 pl-0 pr-0">
                        <div className='d-flex flex-row col-10 pr-0 pl-0'>
                        <input className='col-9 pl-0 pr-0 pl-4' onChange={(event)=> selectQuestion(event)}placeholder="Type the question"style={{height:"50px"}}/>
                        <Select
                            options={influencers}
                            isMulti={false}
                            isSearchable={true}
                            onChange={(event) => selectAnswer(event)}
                            className=''
                            // components={{ DropdownIndicator, ValueContainer }}
                            classNamePrefix="vyrill"
                            placeholder="Select Source"
                            styles={styles}
                        />
                        </div>
                        <div>
                        <button className='button-search' onClick={()=> searchQuestions()}>Search AI</button>
                        </div>
                    </div>
                </div>
                <div className="cards-container">
                    {
                        cardsData.map((card, index) => (
                            <div className="card mr-2" key={index}>
                                <img className="card-img-top" src={card.img} alt="Card" style={{ width: "100%" }} />
                                <div className="card-body card-body-view p-0 pl-2">
                                    <div className="card-text1 mt-1">{card.text}</div>
                                    <Link className='card-link mt-0'>{card.link}</Link>
                                </div>
                            </div>
                        ))
                    }
                </div>
            </div>
            <div className="background-section">
                <div className="background-top-landingpage"></div>
                <div className="background-bottom-landingpage"></div>
            </div>
        </div>
    );
};

export default LandingPage;
