import React, { useState } from 'react';
import { toast } from "react-toastify";
import imageTheia from '../../assets/images/theia.png';
import { useNavigate, Link } from 'react-router-dom';
import search from '../../assets/images/Vector (3).svg';
import Ellipse from "../../assets/images/Ellipse.svg";
import logo from '../../assets/images/Logo_3-removebg-preview 1 (1).svg';
import './LandingTheia.css';
import signOut from "../../assets/images/SignOut.svg";
import { useAuth } from '../../components/AuthContext';
import document from '../../assets/images/Frame 9214 (1).svg';
import gen from '../../assets/images/Frame 9214 (2).svg';
import support from '../../assets/images/Frame 9214.svg';



const LandingTheia = () => {
  const navigate = useNavigate()
  const { logout } = useAuth();

  const handleLogout = () => {
    logout()
  }
  const [question, setQuestion] = useState("")
  const [displayDropdown, setDisplayDropdown] = useState(false)

  const selectQuestion = (event) => {
    setQuestion(event.target.value)
  }

  const searchQuestions = () => {
    if (question.trim() !== '') {
      navigate("/queries", { state: { question } })
      //  const queryData = [
      //   {
      //     "query": question,
      //     "ansresultwer": "",
      //     "source": []
      //   }
      // ]
      localStorage.setItem("queryQuestion", JSON.stringify(question))
    } else {
      toast.warning('Please enter a question.', { position: toast.POSITION.TOP_CENTER });
    }
  }

  const handleDropdownFocus = () => {
    setDisplayDropdown(true);
  }

  const handleDropdownBlur = () => {
    setDisplayDropdown(true)
  }

  const handleDownItemClick = (value) => {
    setQuestion(value);
    setDisplayDropdown(false);
  }

  const cardsData = [
    {
        img: support,
        text: "Select documents and Q&A",
        link: "Generate"
    },
    {
        img: document,
        text: "Get Better answers with Gen AI",
        link: "Generate"
    },
    {
        img: gen,
        text: "Support Resources & Tutorials",
        link: "Generate"
    }
]
  return (
    <div className='d-flex flex-column justify-content-center align-items-center m-2'>
      <div className='header w-100 justify-content-between p-1'>
        <div className='logo-section d-flex flex-row align-items-center'>
          <img src={logo} alt='Logo' />
          <img src={imageTheia} alt="imageTheia" className="ml-3" style={{ height: "50px" }} />
          {/* <span className='ml-3'>Centar Theia</span> */}
        </div>
        <div className='d-flex flex-row align-items-center'>
          <span>GMG Program & Overview</span>
          <div className='vertical-line ml-3'></div>
          <span className='ml-3'>Operators</span>
          <div className='vertical-line ml-3'></div>
          <span className='ml-3'>Help & FAQ</span>
          <div className="user-account" style={{ display: "flex", }}>
            <div className="ml-3" style={{ marginTop: "3px", marginRight: "5px" }}>{localStorage.getItem("userName")}</div>
            <div><img src={Ellipse} alt="User Icon" />
              <img style={{ marginLeft: "10px", cursor: "pointer" }} src={signOut} onClick={() => handleLogout()} alt="User Icon" />
            </div>
          </div>
        </div>
      </div>
      <div className='input-section d-flex flex-column mt-5 w-100 justify-content-center align-items-center'>
        <h3>Theia</h3>
        <div className='mt-5 position-relative'>
          <div className='position-relative'>
            <input type="text" className='input-box pl-3' value={question} onFocus={handleDropdownFocus} onBlur={handleDropdownBlur} onChange={selectQuestion} />
            <img src={search} alt='Search' className='search-icon' onClick={() => searchQuestions()} />
          </div>
          {displayDropdown && (
              <div className="dropdown-list">
                <div onClick={() => handleDownItemClick("What do outcomes of these grants have in common?")}>What do outcomes of these grants have in common? </div>
                <div onClick={() => handleDownItemClick("Which grants had better outcomes for patient safety for Covid 19 vaccines?")}>Which grants had better outcomes for patient safety for Covid 19 vaccines?</div>
                <div onClick={() => handleDownItemClick("Based upon these outcomes - what is the next most logical path forward to improve knowledge, improve outcomes, improve science?")}>Based upon these outcomes - what is the next most logical path forward to improve knowledge, improve outcomes, improve science?</div>
                <div onClick={() => handleDownItemClick("Recommendations of similar/past grants if searched for specific therapy area, or patient population type (American, African American, Asian…) ")}>Recommendations of similar/past grants if searched for specific therapy area, or patient population type (American, African American, Asian…) </div>
                <div onClick={() => handleDownItemClick("How to target/structure education/medical engagement to HealthCare Providers (Physicians_?)")}>How to target/structure education/medical engagement to HealthCare Providers (Physicians_?)</div>
                <div onClick={() => handleDownItemClick("How would you organize the areas of greatest need or widest disparities by state, by nation, by region, by country, by continent (insert geography here).")}>How would you organize the areas of greatest need or widest disparities by state, by nation, by region, by country, by continent (insert geography here).</div>
                <div onClick={() => handleDownItemClick("Which grants recently approved in the last 2 years, focus on off-label research of Pfizer drugs?")}>Which grants recently approved in the last 2 years, focus on off-label research of Pfizer drugs?</div>
                <div onClick={() => handleDownItemClick("What type and how much money has this organizations/Investigation received from Pfizer? (Grants/Pfizer Sponsored Research)")}>What type and how much money has this organizations/Investigation received from Pfizer? (Grants/Pfizer Sponsored Research)</div>

              </div>
          )}
        </div>
      </div>
      <div className="cards-container">
                    {
                        cardsData.map((card, index) => (
                            <div className="card mr-2" key={index}>
                                <img className="card-img-top" src={card.img} alt="Card" style={{ width: "100%" }} />
                                <div className="card-body card-body-view p-0 pl-2">
                                    <div className="card-text1 mt-1">{card.text}</div>
                                    <Link className='card-link mt-0'>{card.link}</Link>
                                </div>
                            </div>
                        ))
                    }
                </div>
    </div>
  )
}

export default LandingTheia;
