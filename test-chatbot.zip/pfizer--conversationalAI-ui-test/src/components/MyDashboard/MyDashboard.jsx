import React, { useState, useEffect } from 'react'
import { toast } from "react-toastify";
import './../MyDashboard/MyDashboard.css'
import search from '../../assets/images/Vector (3).svg';
import Select, { components } from "react-select";
import refreshIcon from "../../assets/images/Refresh.svg";
import funnelSimpleWhite from "../../assets/images/FunnelSimple.svg";
import Ellipse from "../../assets/images/Ellipse.svg";
import eyeIconClose from '../../assets/images/closeEye.png';
import downloadSimple from "../../assets/images/DownloadSimple.svg";
import logo from '../../assets/images/Logo_3-removebg-preview 1 (1).svg';
import demoimg from './../../assets/images/CaretCircleDoubleLeft.svg'
import signOut from "../../assets/images/SignOut.svg";
import imageTheia from '../../assets/images/theia.png';
import { default as ReactSelect } from "react-select";
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../../components/AuthContext';
import Card from "react-bootstrap/Card";
import Button from 'react-bootstrap/Button';
import elipse from '../../assets/images/Ellipse 2.svg';
import { Nav, Tab, Row, Col } from 'react-bootstrap';
import DataTable from "react-data-table-component";
import home from './../../assets/images/Rectangle 1494.svg'
import tower from './../../assets/images/Rectangle 1494 (1).svg'
import rect from './../../assets/images/Rectangle.svg'
import ashrect from "./../../assets/images/Rext.svg"
import gridwind from "./../../assets/images/GridFourwind.svg"
import tileviewimg from "./../../assets/images/Vector (1).svg"
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet'
import 'leaflet/dist/leaflet.css'
import { Icon } from 'leaflet'
import voicesearch from './../../assets/images/voicesearch.png'



function MyDashboard() {
    const [hideRequestId, setHideRequestId] = useState(false)
    const [hideStatus, setHideStatus] = useState(false)
    const [hideApprovedAmount, setHideApprovedAmount] = useState(false)
    const [hidePaymentsRemaining, setHidePaymentsRemaining] = useState(false)
    const [hideOrgName, setHideOrgName] = useState(false)
    const [hidePIName, setHidePIName] = useState(false)
    const [hideAbstract, setHideAbstract] = useState(false)
    const [hideInternalNotes, setHideInternalNotes] = useState(false)
    const [hideLastUpdate, setHideLastUpdate] = useState(false)
    const [hideLatestReportBarrier, setHideLatestReportBarrier] = useState(false)
    const [hideLink, setHideLink] = useState(false)

    const data2 = [
        {
            title: 'Pepiris-DB',
            version: '2',
            stage: 'archived',
            type: 'classification',
            framework: 'Prod',
            train: 'Url Details',
            source: '10',
            last: '10/9/2023',
            details: 'Classification',
            aa: 'aaaa',
            bb: 'bbbb',
            cc: 'cccc'
        },
        {
            title: 'Pepiris-DB',
            version: '3',
            stage: 'staged',
            type: 'classification',
            framework: 'Prod',
            train: 'Url Details',
            source: '10',
            last: '10/9/2023',
            details: 'Classify'
        },
        {
            title: 'Pepiris-DB',
            version: '1',
            stage: 'archived',
            type: 'classification',
            framework: 'Prod',
            train: 'Url Details',
            source: '10',
            last: '10/9/2023',
            details: 'Classify'
        },
        {
            title: 'Pepiris-DB',
            version: '4',
            stage: 'archived',
            type: 'classification',
            framework: 'Prod',
            train: 'Url Details',
            source: '10',
            last: '10/9/2023',
            details: 'Classification',
            aa: 'aaaa',
            bb: 'bbbb',
            cc: 'cccc'
        },
        {
            title: 'Pepiris-DB',
            version: '5',
            stage: 'archived',
            type: 'classification',
            framework: 'Prod',
            train: 'Url Details',
            source: '10',
            last: '10/9/2023',
            details: 'Classification',
            aa: 'aaaa',
            bb: 'bbbb',
            cc: 'cccc'
        },

    ]
    const navigate = useNavigate()
    const [columnsView, setColumns1] = useState([])
    const [dropdownSelectedValue, setDropdownSelectedValue] = useState("")
    const [filteredTableData, setFilteredTableData] = useState(data2);
    const [dropdownStatus, setDropdownStatus] = useState(false)
    const { logout } = useAuth();

    const handleLogout = () => {
        logout()
    }
    const [question, setQuestion] = useState("")
    const [hideColumnStatus, setHideColumnStatus] = useState(false)
    const [hideProjectTitle, setHideProjectTitle] = useState(false)
    const [displayDropdown, setDisplayDropdown] = useState(false)

    const selectQuestion = (event) => {
        setQuestion(event.target.value)
    }
    const gotoDashboardView = () => {
        navigate("/my-dashboard")

    }
    const gotoInSightsView = () => {
        navigate("/insights")

    }
    const goToLanding = () => {
        navigate("/landing-page")

    }

    useEffect(() => {
        const columns1 = [
            {
                name: (
                    <div className="dataTable-header-bold d-flex flex-row">
                        <div>Request ID</div><img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("RequestId")} alt="User Icon" />
                        <div><img src={eyeIconClose} alt="imaeg" style={{ cursor: "pointer", marginLeft: "5px" }} height="15px" width="15px" onClick={() => hideColumn("details", "RequestId")} /></div>
                    </div>
                ),
                selector: row => row.details,
                omit: hideRequestId,
                width: "150px"
            },
            {
                name:
                    (
                        <div className="dataTable-header-bold d-flex flex-row">
                            <div>Project Title</div><img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("ProjectTitle")} alt="User Icon" />
                            <div><img src={eyeIconClose} alt="imaeg" style={{ cursor: "pointer", marginLeft: "5px" }} height="15px" width="15px" onClick={() => hideColumn("version", "ProjectTitle")} /></div>
                        </div>
                    ),
                selector: row => row.version,
                omit: hideProjectTitle,
                width: "150px"
            },
            {
                name:
                    (
                        <div className="dataTable-header-bold d-flex flex-row">
                            <div>Status</div><img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("Status")} alt="User Icon" />
                            <div><img src={eyeIconClose} alt="imaeg" style={{ cursor: "pointer", marginLeft: "5px" }} height="15px" width="15px" onClick={() => hideColumn("stage", "Status")} /></div>
                        </div>
                    ),
                selector: row => row.stage,
                omit: hideStatus
            },
            {
                name:
                    (
                        <div className="dataTable-header-bold d-flex flex-row">
                            <div>Approved Amount</div><img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("ApprovedAmount")} alt="User Icon" />
                        </div>
                    ),
                selector: row => row.last,
                omit: hideApprovedAmount
            },
            {
                name:
                    (
                        <div className="dataTable-header-bold d-flex flex-row">
                            <div>Payments Remaining</div><img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("PaymentsRemaining")} alt="User Icon" />
                        </div>
                    ),
                selector: row => row.framework,
                omit: hidePaymentsRemaining
            },
            {
                name:
                    (
                        <div className="dataTable-header-bold d-flex flex-row">
                            <div>Org Name</div><img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("OrgName")} alt="User Icon" />
                        </div>
                    ),
                selector: row => row.version,
                omit: hideOrgName
            },
            {
                name:
                    (
                        <div className="dataTable-header-bold d-flex flex-row">
                            <div>PI Name</div><img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("PIName")} alt="User Icon" />
                        </div>
                    ),
                selector: row => row.stage,
                omit: hidePIName
            },
            {
                name:
                    (
                        <div className="dataTable-header-bold d-flex flex-row">
                            <div>Abstract/Summary</div><img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("Abstract")} alt="User Icon" />
                        </div>
                    ),
                selector: row => row.last,
                omit: hideAbstract
            },
            {
                name:
                    (
                        <div className="dataTable-header-bold d-flex flex-row">
                            <div>Internal Notes</div><img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("InternalNotes")} alt="User Icon" />
                        </div>
                    ),
                selector: row => row.framework,
                omit: hideInternalNotes
            },

            {
                name:
                    (
                        <div className="dataTable-header-bold d-flex flex-row">
                            <div>Last Update</div><img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("LastUpdate")} alt="User Icon" />
                        </div>
                    ),
                selector: row => row.stage,
                omit: hideLastUpdate
            },
            {
                name:
                    (
                        <div className="dataTable-header-bold d-flex flex-row">
                            <div>Latest Reported Barrier</div><img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("LatestReportBarrier")} alt="User Icon" />
                        </div>
                    ),
                selector: row => row.last,
                omit: hideLatestReportBarrier
            },
            {
                name:
                    (
                        <div className="dataTable-header-bold d-flex flex-row">
                            <div>Link</div><img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("Link")} alt="User Icon" />
                        </div>
                    ),
                selector: row => row.framework,
                omit: hideLink
            },
        ]
        setColumns1(columns1);
    }, [hideRequestId, hideStatus, hideProjectTitle, hideApprovedAmount, hidePaymentsRemaining, hideOrgName, hidePIName, hideAbstract, hideInternalNotes, hideLastUpdate, hideLatestReportBarrier, hideLink])


    const handleDropdownFocus = () => {
        setDisplayDropdown(true);
    }

    const handleDropdownBlur = () => {
        setDisplayDropdown(true)
    }

    const handleDownItemClick = (value) => {
        setQuestion(value);
        setDisplayDropdown(false);
    }
    const openMultiDropdown = (e) => {
        setDropdownSelectedValue(e)
    }

    const conditionallyOmit = (value) => {
        switch (value) {
            case "RequestId":
                setHideRequestId(true)
                break;
            case "ProjectTitle":
                setHideProjectTitle(true)
                break;
            case "Status":
                setHideStatus(true)
                break;
            case "ApprovedAmount":
                setHideApprovedAmount(true)
                break;
            case "PaymentsRemaining":
                setHidePaymentsRemaining(true)
                break;
            case "OrgName":
                setHideOrgName(true)
                break;
            case "PIName":
                setHidePIName(true)
                break;
            case "Abstract":
                setHideAbstract(true)
                break;
            case "InternalNotes":
                setHideInternalNotes(true)
                break;
            case "LastUpdate":
                setHideLastUpdate(true)
                break;
            case "LatestReportBarrier":
                setHideLatestReportBarrier(true)
                break;
            case "Link":
                setHideLink(true)
                break;
            default:
                break
        }
    }

    const hideColumn = (keyName, value) => {
        // setHideColumnStatus(true)
        // const updatedData = data2.map(item => {
        //     const { [keyName]: removedKey, ...rest } = item;
        //     return rest;
        // });
        conditionallyOmit(value)
        // setFilteredTableData(updatedData)
    }
    const data1 = [

        {
            title: 'Study Title-A reseatch study in',
            version: '$50,000',
            stage: 'Approved',
            details: 'PI-John Smit',
            type: 'Oncology',
            framework: 'Talozoprib',
            train: '% milestone payment',
            source: tower,
            last: '3',
            bgc: '#B5F3BB',
            research: "Research"
        },
        {
            title: 'Study Title-A reseatch study in',
            version: '$50,000',
            stage: 'Approved',
            details: '',
            type: 'Oncology',
            framework: '',
            train: 'Lead Medical Review',
            source: home,
            last: '3',
            bgc: '#F6C82D',
            research: "MedEd"
        },
        {
            title: 'Study Title-A reseatch study in',
            version: '$50,000',
            stage: 'Approved',
            details: 'PI-John Smit',
            type: 'Oncology',
            framework: 'Talozoprib',
            train: '% milestone payment',
            source: tower,
            last: '3',
            bgc: '#B5F3BB',
            research: "Research"
        },
        {
            title: 'Study Title-A reseatch study in',
            version: '$50,000',
            stage: 'Approved',
            details: 'PI-John Smit',
            type: 'Oncology',
            framework: 'Talozoprib',
            train: '% milestone payment',
            source: tower,
            last: '3',
            bgc: '#AAC7FF',
            research: "Research"
        },
        {
            title: 'Study Title-A reseatch study in',
            version: '$50,000',
            stage: 'Approved',
            details: 'PI-John Smit',
            type: 'Oncology',
            framework: 'Talozoprib',
            train: '% milestone payment',
            source: rect,
            last: '3',
            bgc: '#B5F3BB',
            research: "Research"
        },
        {
            title: 'Study Title-A reseatch study in',
            version: '$50,000',
            stage: 'Approved',
            details: 'PI-John Smit',
            type: 'Oncology',
            framework: 'Talozoprib',
            train: '% milestone payment',
            source: tower,
            last: '3',
            bgc: '#AAC7FF',
            research: "Research"
        },
        {
            title: 'Study Title-A reseatch study in',
            version: '$50,000',
            stage: 'Approved',
            details: 'PI-John Smit',
            type: 'Oncology',
            framework: 'Talozoprib',
            train: '% milestone payment',
            source: tower,
            last: '3',
            bgc: '#AAC7FF',
            research: "Research"
        },
        {
            title: 'Study Title-A reseatch study in',
            version: '$50,000',
            stage: 'Approved',
            details: 'PI-John Smit',
            type: 'Oncology',
            framework: 'Talozoprib',
            train: '% milestone payment',
            source: rect,
            last: '3',
            bgc: '#B5F3BB',
            research: "Research"
        },
        {
            title: 'Study Title-A reseatch study in',
            version: '$50,000',
            stage: 'Approved',
            details: 'PI-John Smit',
            type: 'Oncology',
            framework: 'Talozoprib',
            train: '% milestone payment',
            source: tower,
            last: '3',
            bgc: '#AAC7FF',
            research: "Research"
        },

    ]
    const [activeKey, setActiveKey] = useState('first');
    const center = [40.7128, -74.0060];
    const markers = [
        {
            geocode: [31.51096794051346, -99.03833706014998],
            popUp: 'Texas'
        }, {
            geocode: [42.36711792830373, -71.0096704355786],
            popUp: 'Boston Logan International Airport'
        }, {
            geocode: [42.34198643984433, -71.08339654713436],
            popUp: 'Museum of Fine Arts, Boston'
        },
        {
            geocode: [33.5207, -86.8025],
            popUp: 'Albama'
        }, {
            geocode: [61.0169, -149.7375],
            popUp: 'Alaska'
        }, {
            geocode: [33.4484, -112.0740],
            popUp: 'Arizona'
        },
        {
            geocode: [34.0522, -118.2437],
            popUp: 'California'
        }, {
            geocode: [39.7392, -104.9903],
            popUp: 'Colorado'
        }, {
            geocode: [25.7617, -80.1918],
            popUp: 'Florida'
        },
        {
            geocode: [36.1699, -115.1398],
            popUp: 'Las-Vegas'
        }
    ]
    const customicon = new Icon({
        iconUrl: 'https://cdn-icons-png.flaticon.com/256/684/684908.png',
        iconSize: [38, 38]
    })
    const { Option } = components;

    const CustomOption = (props) => {
        return (
            <Option {...props}>
                {props.label}
            </Option>
        );
    };

    const conditionalDataTableData = (event, uniqueKey) => {
        if (event.length >= 1) {
            setDropdownStatus(true)
            const filteredTable = filteredTableData?.filter((item) =>
                event.some(dataItem => dataItem.value === item[uniqueKey])
            )
            setFilteredTableData(filteredTable)
        } else {
            setDropdownStatus(false)
            setFilteredTableData(data2)
        }
    }

    const conditionalOptions = (value) => {
        switch (value) {
            case "details":
                return data2.map((item) => (
                    {
                        value: item[value],
                        label: item[value]
                    }
                ))
            case "version":
                return data2.map((item) => (
                    {
                        value: item[value],
                        label: item[value]
                    }
                ))
            case "stage":
                return data2.map((item) => (
                    {
                        value: item[value],
                        label: item[value]
                    }
                ))
            case "last":
                return data2.map((item) => (
                    {
                        value: item[value],
                        label: item[value]
                    }
                ))
            case "framework":
                return data2.map((item) => (
                    {
                        value: item[value],
                        label: item[value]
                    }
                ))
            default:
                return null;

        }

    }

    const conditionalRendering = (value) => {
        switch (value) {
            case "RequestId":
                return (
                    <ReactSelect
                        options={conditionalOptions("details")}
                        components={{ Option: CustomOption }}
                        isMulti
                        closeMenuOnSelect={false}
                        hideSelectedOptions={false}
                        onChange={(event) => conditionalDataTableData(event, "details")}
                        allowSelectAll={true}
                        placeholder={"Filter by requestId"}
                    />
                )
            case "ProjectTitle":
                return (
                    <ReactSelect
                        options={conditionalOptions("version")}
                        isMulti
                        closeMenuOnSelect={false}
                        hideSelectedOptions={false}
                        components={{
                            Option
                        }}
                        onChange={(event) => conditionalDataTableData(event, "version")}
                        allowSelectAll={true}
                        placeholder={"Filter by projectTitle"}
                    />
                )
            case "Status":
                return (
                    <ReactSelect
                        options={conditionalOptions("stage")}
                        isMulti
                        closeMenuOnSelect={false}
                        hideSelectedOptions={false}
                        components={{
                            Option
                        }}
                        onChange={(event) => conditionalDataTableData(event, "stage")}
                        allowSelectAll={true}
                        placeholder={"Filter by status"}
                    />
                )
            case "ApprovedAmount":
                return (
                    <ReactSelect
                        options={conditionalOptions("last")}
                        isMulti
                        closeMenuOnSelect={false}
                        hideSelectedOptions={false}
                        components={{
                            Option
                        }}
                        onChange={(event) => conditionalDataTableData(event, "last")}
                        allowSelectAll={true}
                        placeholder={"Filter by approvedAmmount"}
                    />
                )
            case "PaymentsRemaining":
                return (
                    <ReactSelect
                        options={conditionalOptions("framework")}
                        isMulti
                        closeMenuOnSelect={false}
                        hideSelectedOptions={false}
                        components={{ Option: CustomOption }}
                        onChange={(event) => conditionalDataTableData(event, "framework")}
                        allowSelectAll={true}
                        placeholder={"Filter by paymentRemaining"}
                    />
                )
            case "OrgName":
                return (
                    <ReactSelect
                        options={conditionalOptions("version")}
                        isMulti
                        closeMenuOnSelect={false}
                        hideSelectedOptions={false}
                        components={{
                            Option
                        }}
                        onChange={(event) => conditionalDataTableData(event, "version")}
                        allowSelectAll={true}
                        placeholder={"Filter by orgName"}
                    />
                )
            case "PIName":
                return (

                    <ReactSelect
                        options={conditionalOptions("stage")}
                        isMulti
                        closeMenuOnSelect={false}
                        hideSelectedOptions={false}
                        components={{
                            Option
                        }}
                        onChange={(event) => conditionalDataTableData(event, "stage")}
                        allowSelectAll={true}
                        placeholder={"Filter by pIname"}
                    />
                )
            case "Abstract":
                return (
                    <ReactSelect
                        options={conditionalOptions("last")}
                        isMulti
                        closeMenuOnSelect={false}
                        hideSelectedOptions={false}
                        components={{
                            Option
                        }}
                        onChange={(event) => conditionalDataTableData(event, "last")}
                        allowSelectAll={true}
                        placeholder={"Filter by abstract"}
                    />

                )
            case "InternalNotes":
                return (
                    <ReactSelect
                        options={conditionalOptions("framework")}
                        isMulti
                        closeMenuOnSelect={false}
                        hideSelectedOptions={false}
                        components={{
                            Option
                        }}
                        onChange={(event) => conditionalDataTableData(event, "framework")}
                        allowSelectAll={true}
                        placeholder={"Filter by internalNotes"}
                    />
                )
            case "LastUpdate":
                return (
                    <ReactSelect
                        options={conditionalOptions("stage")}
                        isMulti
                        closeMenuOnSelect={false}
                        hideSelectedOptions={false}
                        components={{
                            Option
                        }}
                        onChange={(event) => conditionalDataTableData(event, "stage")}
                        allowSelectAll={true}
                        placeholder={"Filter by lastUpdate"}
                    />
                )
            case "LatestReportBarrier":
                return (
                    <ReactSelect
                        options={conditionalOptions("last")}
                        isMulti
                        closeMenuOnSelect={false}
                        hideSelectedOptions={false}
                        components={{
                            Option
                        }}
                        onChange={(event) => conditionalDataTableData(event, "last")}
                        allowSelectAll={true}
                        placeholder={"Filter by lastReportBarrier"}
                    />
                )
            case "Link":
                return (
                    <ReactSelect
                        options={conditionalOptions("framework")}
                        isMulti
                        closeMenuOnSelect={false}
                        hideSelectedOptions={false}
                        components={{
                            Option
                        }}
                        onChange={(event) => conditionalDataTableData(event, "framework")}
                        allowSelectAll={true}
                        placeholder={"Filter by link"}
                    />
                )
            default:
                return <></>
        }
    }

    const onRefresh = () => {
        setHideStatus(false)
        setHideApprovedAmount(false)
        setHidePaymentsRemaining(false)
        setHideLastUpdate(false)
        setHideLatestReportBarrier(false)
        setHideLink(false)
        setHideProjectTitle(false)
        setHideOrgName(false)
        setHidePIName(false)
        setHideAbstract(false)
        setHideRequestId(false)
        setHideInternalNotes(false)
    }
    return (
        <div className='d-flex flex-column justify-content-center align-items-center' style={{ backgroundColor: '#f2f2f2' }}>
            <div className='header w-100 justify-content-between p-1'>
                <div className='logo-section d-flex flex-row align-items-center'>
                    <img src={logo}  onClick={goToLanding}  style={{cursor:"pointer"}} alt='Logo' />
                    <img src={imageTheia} alt="imageTheia" className="ml-3" onClick={goToLanding} style={{ height: "50px", cursor:"pointer" }} />
                </div>
                <div className='d-flex flex-row align-items-center'>
                    <span style={{ cursor: "pointer" }}>Search</span>
                    <div className='vertical-line ml-3'></div>
                    <span style={{ cursor: "pointer" }} className='ml-3' onClick={() => gotoDashboardView()}>My Dashboard</span>
                    <span style={{ cursor: "pointer" }} className='ml-5' onClick={() => gotoInSightsView()}>In Sights</span>
                    <div className='vertical-line ml-3'></div>
                    <span className='ml-3' style={{ cursor: "pointer" }}>Help & FAQ</span>
                    <div className="user-account" style={{ display: "flex", }}>
                        <div className="ml-3" style={{ marginTop: "3px", marginRight: "5px" }}>{localStorage.getItem("userName")}</div>
                        <div><img src={Ellipse} alt="User Icon" />
                            <img style={{ marginLeft: "10px", cursor: "pointer" }} src={signOut} onClick={() => handleLogout()} alt="User Icon" />
                        </div>
                    </div>
                </div>
            </div>
            <div className='input-section d-flex flex-column mt-5 w-100 justify-content-center align-items-center'>
                <div className='mt-5 position-relative'>
                    <div className='position-relative'>
                        <input type="text" className='input-box pl-3' value={question} onFocus={handleDropdownFocus} onBlur={handleDropdownBlur} onChange={selectQuestion} />
                        <img src={search} alt='Search' className='search-icon'/>
                        <img src={voicesearch} className='voice-icon' width={'35px'}></img>
                    </div>

                </div>
            </div>
            {/* <div style={{height:"500px"}}> */}


            <MapContainer
                center={center}
                zoom={10}
                attributionControl={false}
            >
                <TileLayer
                    url="https://api.maptiler.com/maps/basic-v2/256/{z}/{x}/{y}.png?key=UimObR3ryVqOOQ2rlTg6"
                    attribution='<a href="https://www.maptiler.com/copyright/" target="_blank">&copy; MapTiler</a> <a href="https://www.openstreetmap.org/copyright" target="_blank">&copy; OpenStreetMap contributors</a>'
                />
                {
                    markers.map(marker => (
                        <Marker position={marker.geocode} icon={customicon}>
                            <Popup><h2>{marker.popUp}</h2></Popup>
                        </Marker>
                    ))
                }

            </MapContainer>
            {/* </div> */}
            <Tab.Container id="left-tabs-example" defaultActiveKey="first">
                <div className='rightalign ml-auto p-3'>
                    <Row style={{ marginRight: "20px" }}>
                        <div className='navitem' >
                            <Nav variant="pills">

                                <Nav.Item >
                                    <Nav.Link eventKey="first">
                                        <img src={gridwind}></img>&nbsp;
                                        Tile View
                                    </Nav.Link>
                                </Nav.Item>

                                <Nav.Item>
                                    <Nav.Link eventKey="second">
                                        <img src={tileviewimg}></img>&nbsp;
                                        Grid View
                                    </Nav.Link>
                                </Nav.Item>

                            </Nav>
                        </div>

                    </Row>
                </div>
                {/* <Row style={{width:"80%", marginBottom:"20px"}}>
                    <Col className="col-12 col-lg-12">
                        <Row className="mx-0">
                            {data1.map((item, index) => (
                                <Col className="col-12 col-md-4 ps-0 pe-2">
                                    <Card style={{ width: '100%', height: '300px', padding:"10px", borderRadius:"10px", border:"none" }}
                                        // className="carddash"
                                        key={index}
                                    >
                                        <Card.Body style={{ background: '#fff' }}>
                                            <div className='row'>
                                                <div className='col-2'>
                                                    <img src={item.source}></img>
                                                </div>
                                                <div className='col-10'>
                                                    <h6>{item.title}</h6>
                                                </div>
                                            </div>
                                            <div className='row justify-content-between pt-4' >
                                                {item.version}
                                                <Button style={{ background: item.bgc, color: "black", border: 'none' }} className='borrad'>{item.stage}</Button>{' '}
                                            </div>
                                            <div className='row justify-content-between pt-4' >
                                                <div >
                                                    {item.details}
                                                </div>
                                                {item.type}
                                            </div>

                                            <div className='row justify-content-between ashcol pt-2'>
                                                <div>{item.research}</div>
                                                <img src={ashrect}></img>
                                                {item.framework}
                                            </div>
                                            <div className='row pt-4'>
                                                <h6 className='p-1'>UpNext  </h6>&nbsp;
                                                <div >
                                                    {item.train}
                                                </div>
                                            </div>
                                        </Card.Body>
                                    </Card>
                                </Col>
                            ))}

                        </Row>

                    </Col>
                </Row> */}
                <Row style={{ width: "100%", marginBottom: "20px" }}>
                    <Tab.Content style={{ width: "100%" }}>
                        <Tab.Pane eventKey="first">
                            <Col className="col-12 col-lg-12">
                                <Row className="mx-0">
                                    {data1.map((item, index) => (
                                        <Col className="col-12 col-md-4 ps-0 pe-2">
                                            <Card style={{ width: '100%', height: '300px', padding: "10px", borderRadius: "10px", border: "none" }}
                                                // className="carddash"
                                                key={index}
                                            >
                                                <Card.Body style={{ background: '#fff' }}>
                                                    <div className='row'>
                                                        <div className='col-2'>
                                                            <img src={item.source}></img>
                                                        </div>
                                                        <div className='col-10'>
                                                            <h6>{item.title}</h6>
                                                        </div>
                                                    </div>
                                                    <div className='row justify-content-between pt-4' >
                                                        {item.version}
                                                        <Button style={{ background: item.bgc, color: "black", border: 'none' }} className='borrad'>{item.stage}</Button>{' '}
                                                    </div>
                                                    <div className='row justify-content-between pt-4' >
                                                        <div >
                                                            {item.details}
                                                        </div>
                                                        {item.type}
                                                    </div>

                                                    <div className='row justify-content-between ashcol pt-2'>
                                                        <div>{item.research}</div>
                                                        <img src={ashrect}></img>
                                                        {item.framework}
                                                    </div>
                                                    <div className='row pt-4'>
                                                        <h6 className='p-1'>UpNext  </h6>&nbsp;
                                                        <div >
                                                            {item.train}
                                                        </div>
                                                    </div>
                                                </Card.Body>
                                            </Card>
                                        </Col>
                                    ))}

                                </Row>

                            </Col>
                        </Tab.Pane>
                        <Tab.Pane eventKey="second">
                            <div className=' mb-3 mt-3 d-flex flex-row ml-3 align-items-center'>
                                <div className='col-11'>{conditionalRendering(dropdownSelectedValue)}</div>
                                <div><img src={downloadSimple} style={{ cursor: "pointer", marginRight: "10px" }} height="30px" width="30px" alt="User Icon" /></div>
                                <div><img src={refreshIcon} style={{ cursor: "pointer" }} height="30px" width="30px" alt="User Icon" onClick={() => onRefresh()} /></div>
                            </div>
                            <div style={{ margin: "30px", borderRadius: "4px", marginBottom: "40px" }}>
                                <DataTable
                                    columns={columnsView}
                                    data={dropdownStatus || hideColumnStatus ? filteredTableData : data2} />
                            </div>
                        </Tab.Pane>
                    </Tab.Content>
                </Row>
            </Tab.Container>
        </div>
    )
}

export default MyDashboard