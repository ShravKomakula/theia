import React, { useState } from 'react';
import { toast } from "react-toastify";
import imageTheia from '../../assets/images/theia.png';
import { useNavigate, Link } from 'react-router-dom';
import search from '../../assets/images/Vector (3).svg';
import Ellipse from "../../assets/images/Ellipse.svg";
import logo from '../../assets/images/Logo_3-removebg-preview 1 (1).svg';
import signOut from "../../assets/images/SignOut.svg";
import { useAuth } from '../../components/AuthContext';
import document from '../../assets/images/Frame 9214 (1).svg';
import gen from '../../assets/images/Frame 9214 (2).svg';
import support from '../../assets/images/Frame 9214.svg';
import './LandingPageNew.css'
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import globeIcon from '../../assets/images/world.svg'
import microscopeIcon from '../../assets/images/telescope.svg'
import doctorIcon from '../../assets/images/doctor 1.svg'
import voicesearch from './../../assets/images/voicesearch.png'



const LandingPageNew = () => {
    const navigate = useNavigate()
    const { logout } = useAuth();

    const handleLogout = () => {
        logout()
    }
    const [question, setQuestion] = useState("")
    const [displayDropdown, setDisplayDropdown] = useState(false)

    const selectQuestion = (event) => {
        setQuestion(event.target.value)
    }

    const searchQuestions = () => {
        if (question.trim() !== '') {
            navigate("/queries", { state: { question } })
            //  const queryData = [
            //   {
            //     "query": question,
            //     "ansresultwer": "",
            //     "source": []
            //   }
            // ]
            localStorage.setItem("queryQuestion", JSON.stringify(question))
        } else {
            toast.warning('Please enter a question.', { position: toast.POSITION.TOP_CENTER });
        }
    }

    const handleDropdownFocus = () => {
        setDisplayDropdown(true);
    }
    const gotoDashboardView = () => {
        navigate("/my-dashboard")

    }
    const gotoInSightsView = () => {
        navigate("/insights")

    }

    const handleDropdownBlur = () => {
        setDisplayDropdown(true)
    }

    const handleDownItemClick = (value) => {
        setQuestion(value);
        setDisplayDropdown(false);
    }

    const cardsData = [
        {
            img: support,
            text: "Select documents and Q&A",
            link: "Generate"
        },
        {
            img: document,
            text: "Get Better answers with Gen AI",
            link: "Generate"
        },
        {
            img: gen,
            text: "Support Resources & Tutorials",
            link: "Generate"
        }
    ]
    const goToLanding = () => {
        navigate("/landing-page")

    }

    return (
        <div className='d-flex flex-column align-items-center' style={{ backgroundColor:"#e8e8ff",
        //  height: '100vh'
          }}>
            <div className='header w-100 justify-content-between p-1'>
                <div className='logo-section d-flex flex-row align-items-center'>
                    <img src={logo} onClick={goToLanding} style={{cursor:"pointer"}} alt='Logo' />
                    <img src={imageTheia} alt="imageTheia" className="ml-3" onClick={goToLanding} style={{ height: "50px", cursor:"pointer"}} />
                    {/* <span className='ml-3'>Centar Theia</span> */}
                </div>
                <div className='d-flex flex-row align-items-center'>
                    {/* <span>GMG Program & Overview</span> */}
                    <span style={{cursor: "pointer" }}>Search</span>
                    <div className='vertical-line ml-3'></div>
                    <span className='ml-3' onClick={() => gotoDashboardView()} style={{cursor: "pointer" }}>My Dashboard</span>
                    <span className='ml-5' onClick={() => gotoInSightsView()} style={{cursor: "pointer" }}>In Sights</span>
                    <div className='vertical-line ml-3'></div>
                    <span className='ml-3' style={{cursor: "pointer" }}>Help & FAQ</span>
                    <div className="user-account" style={{ display: "flex", }}>
                        <div className="ml-3" style={{ marginTop: "3px", marginRight: "5px" }}>{localStorage.getItem("userName")}</div>
                        <div><img src={Ellipse} alt="User Icon" />
                            <img style={{ marginLeft: "10px", cursor: "pointer" }} src={signOut} onClick={() => handleLogout()} alt="User Icon" />
                        </div>
                    </div>
                </div>
            </div>
            <div className='input-section d-flex flex-column mt-5 w-100 justify-content-center align-items-center' style={{position:"fixed"}}>
                <div className='main-container' style={{marginTop:"75px"}}>
                    <Row>
                        <Col className="col-12 col-lg-12">
                            <Row className="mx-0">
                                <Col className="col-12 col-md-12 ps-0 pe-2">
                                    <span className="heading mt-3">WMSxGMG - Independent Grants &</span>
                                    <span className='heading-2'>Medical activities Intelligence Platform</span>
                                    <span className='common-align pb-3'>Currently only trained to search GMG & ITEM </span>
                                </Col>
                                <div className='pb-5 position-relative common-align'>
                                    <div className='position-relative'>
                                        <input type="text" className='input-box pl-3' value={question} onFocus={handleDropdownFocus} onBlur={handleDropdownBlur} onChange={selectQuestion} />
                                        <img src={search} alt='Search' className='search-icon' onClick={() => searchQuestions()} />
                                        <img src={voicesearch} className='voice-icon' width={'35px'}></img>
                                    </div>

                                    {displayDropdown && (
                                        <div className="dropdown-list">
                                            <div onClick={() => handleDownItemClick("Which RFPs were launched with the Mayo Clinc?")}>Which RFPs were launched with the Mayo Clinc? </div>
                                            <div onClick={() => handleDownItemClick("What type of Organizations are eligible to apply for Grants?")}>What type of Organizations are eligible to apply for Grants?</div>
                                            <div onClick={() => handleDownItemClick("What type of objectives have Vaccine Hesistance Grants focused on?")}>What type of objectives have Vaccine Hesistance Grants focused on?</div>
                                            <div onClick={() => handleDownItemClick("Who is a local medical reviewer? ")}>Who is a local medical reviewer? </div>
                                            <div onClick={() => handleDownItemClick("What are impact reports? What are some type of impact reports?")}>What are impact reports? What are some type of impact reports?</div>
                                            <div onClick={() => handleDownItemClick("Which RFPs have focused on Low-to-Middle Income countries?")}>Which RFPs have focused on Low-to-Middle Income countries?</div>
                                            

                                        </div>
                                    )}
                                </div>
                            </Row>
                        </Col>

                    </Row>
                </div>
                <Row>
                    <Col className="col-12 col-lg-12">
                        <Row className="">
                            <Col className="col-12 col-lg-4 mb-3 ps-0 pe-2">
                                <div className="card mb-2 common-align-card" style={{ width: '350px' }}>
                                    <div className="card-body">
                                        <h5 className="card-heading">Organizations & <br></br>PT Intelligence</h5>
                                        <img className="pb-4 pt-4 card-img-" src={globeIcon}></img>
                                    </div>
                                </div>
                            </Col>
                            <Col className="col-12 col-lg-4 mb-3 ps-0 pe-2">
                                <div className="card mb-2 common-align-card" style={{ width: '350px'}}>
                                    <div className="card-body">
                                        <h5 className="card-heading">Explore Pfizer<br></br> Scientific Footprint</h5>
                                        <img className="pb-4 pt-2 card-img-" style={{ height: '220px' }} src={microscopeIcon}></img>
                                    </div>
                                </div>
                            </Col>
                            <Col className="col-12 col-lg-4 mb-3 ps-0 pe-2">
                                <div className="card mb-2 common-align-card" style={{ width: '350px'}}>
                                    <div className="card-body">
                                        <h5 className="card-heading pb-3">Worldwide Medical & Safety Insights</h5>
                                        <img className="pb-4 pt-2 card-img-" style={{ height: '190px' }} src={doctorIcon}></img>
                                    </div>
                                </div>
                            </Col>
                        </Row>
                    </Col>
                </Row>


            </div>

        </div>
    )
}

export default LandingPageNew