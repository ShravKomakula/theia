import React, { useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../AuthContext';

const AuthWrapper = ({ children }) => {
  const { authenticated } = useAuth();
  const location = useLocation()
  const navigate = useNavigate();

  useEffect(() => {
    if (!authenticated) {
      navigate('/');
    } else if (authenticated === true && location.pathname === "/"){
      navigate('/landing-page')
    }
  }, [authenticated, navigate, location]);

  return <>{children}</>;
};

export default AuthWrapper;
