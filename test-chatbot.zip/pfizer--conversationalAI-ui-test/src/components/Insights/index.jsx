import React, { useState } from 'react';
import Chart from 'react-apexcharts';
import Ellipse from "../../assets/images/Ellipse.svg";
import imageTheia from '../../assets/images/theia.png';
import { useAuth } from '../AuthContext';
import DataTable from "react-data-table-component";
import logo from '../../assets/images/Logo_3-removebg-preview 1 (1).svg';
import signOut from "../../assets/images/SignOut.svg";
import {useNavigate } from 'react-router-dom';





const Insights = () => {
    const [input, setInput] = useState([
        {
            requestId: "12345",
            budget: "true",
            mapp: "question",
            contract: "false",
            payments: "true",
            impactReport: "false",
            status: "true"
        },
        {
            requestId: "12385",
            budget: "true",
            mapp: "question",
            contract: "false",
            payments: "true",
            impactReport: "false",
            status: "true"
        },
        {
            requestId: "55463",
            budget: true,
            mapp: "question",
            contract: false,
            payments: true,
            impactReport: false,
            status: "true"
        },
        {
            requestId: "23456",
            budget: true,
            mapp: "question",
            contract: false,
            payments: true,
            impactReport: false,
            status: "true"
        },
        {
            requestId: "87654",
            budget: true,
            mapp: "question",
            contract: false,
            payments: true,
            impactReport: false,
            status: "true"
        }
    ])
    const { logout } = useAuth();
    const navigate = useNavigate()

    const gotoDashboardView = () => {
        navigate("/my-dashboard")

    }
    const gotoInSightsView = () => {
        navigate("/insights")

    }
    const handleLogout = () => {
        logout()
    }
    const changeInput = (requestId, event) => {
        setInput(prevData =>
            prevData.map(item =>
                item.requestId === requestId ? { ...item, status: event.target.value } : item
            )
        );
    }
    const columns = [
        {
            name: "Request ID",
            selector: row => row.requestId,
            center: true
        },
        {
            name: "Budget",
            selector: row => row.budget,
            center: true
        },
        {
            name: "MAPP",
            selector: row => row.mapp,
            center: true
        },
        {
            name: "Contract",
            selector: row => row.contract,
            center: true
        },
        {
            name: "Payments",
            selector: row => row.payments,
            center: true
        },
        {
            name: "Impact Report",
            selector: row => row.impactReport,
            center: true
        },
        {
            name: "Status",
            selector: row => (
                <div>
                    <input type="text" value={row.status} onChange={(event) => changeInput(row.requestId, event)} style={{ border: "none", maxWidth: "100%", width: "100%" }} className='p-1' />
                </div>
            ),
            center: true
        }
    ]

    const heatmapChartOptions = {
        chart: {
            type: 'heatmap',
        },
        colors: ["#008FFB"],
        dataLabels: {
            enabled: false,
        },
        stroke: {
            width: 1,
        },
        title: {
            text: 'Heatmap Chart',
        },
    };

    const heatmapChartSeries = [
        {
            name: 'Metric 1',
            data: [
                { x: 'x1', y: 5 },
                { x: 'x2', y: 10 },
                { x: 'x3', y: 15 },
                { x: 'x4', y: 20 },
                { x: 'x5', y: 25 },
                { x: 'x6', y: 30 },
                { x: 'x7', y: 35 },
            ],
        },
        {
            name: 'Metric 2',
            data: [
                { x: 'x1', y: 5 },
                { x: 'x2', y: 10 },
                { x: 'x3', y: 15 },
                { x: 'x4', y: 20 },
                { x: 'x5', y: 25 },
                { x: 'x6', y: 30 },
                { x: 'x7', y: 35 },
            ],
        },
        {
            name: 'Metric 3',
            data: [
                { x: 'x1', y: 5 },
                { x: 'x2', y: 10 },
                { x: 'x3', y: 15 },
                { x: 'x4', y: 20 },
                { x: 'x5', y: 25 },
                { x: 'x6', y: 30 },
                { x: 'x7', y: 35 },
            ],
        },
    ];

    const donutChart = {
        options: {},
        series: [44, 55, 41, 17, 15],
        labels: ['A', 'B', 'C', 'D', 'E']
    }
    const cardInfo = [
        {
            title: "Card1",
            value: "80%"
        },
        {
            title: "Card2",
            value: "11%"
        },
        {
            title: "Card3",
            value: "9%"
        }
    ]
    const customStyles = {
        rows: {
            style: {
                border: "1px solid lightgrey",
                ':nth-of-type(even)': {
                    backgroundColor: "#E1E1E1"
                },
                ':nth-of-type(odd)': {
                    backgroundColor: "#F0F0F0"
                },
            },
        },
        headCells: {
            style: {
                border: "1px solid lightgrey",
                background: "#9DC3E6",
                color: "#5A7186"
            },
        },
    }
    const goToLanding = () => {
        navigate("/landing-page")

    }
    return (
        <div style={{backgroundColor: '#f2f2f2'}}>
            <div className='header w-100 justify-content-between p-1'>
                <div className='logo-section d-flex flex-row align-items-center'>
                    <img src={logo} onClick={goToLanding} style={{cursor:"pointer"}} alt='Logo' />
                    <img src={imageTheia} alt="imageTheia" className="ml-3" onClick={goToLanding} style={{ height: "50px", cursor: "pointer" }} />
                </div>
                <div className='d-flex flex-row align-items-center'>
                    {/* <span>GMG Program & Overview</span> */}
                    {/* <div className='vertical-line ml-3'></div>
                    <span className='ml-3'>Operators</span> */}
                      <span style={{cursor: "pointer" }}>Search</span>
                    <div className='vertical-line ml-3'></div>
                    <span className='ml-3' onClick={() => gotoDashboardView()} style={{cursor: "pointer" }}>My Dashboard</span>
                    <span className='ml-5' onClick={() => gotoInSightsView()} style={{cursor: "pointer" }}>In Sights</span>
                    <div className='vertical-line ml-3'></div>
                    <span className='ml-3' style={{cursor: "pointer" }}>Help & FAQ</span>
                    <div className="user-account" style={{ display: "flex", }}>
                        <div className="ml-3" style={{ marginTop: "3px", marginRight: "5px" }}>{localStorage.getItem("userName")}</div>
                        <div><img src={Ellipse} alt="User Icon" />
                            <img style={{ marginLeft: "10px", cursor: "pointer" }} src={signOut} onClick={() => handleLogout()} alt="User Icon" />
                        </div>
                    </div>
                </div>
            </div>
            <div className='d-flex flex-column p-5'>
                <div className='d-flex flex-row justify-content-around align-items-center'>
                    <div className="donut">
                        <Chart options={donutChart.options} series={donutChart.series} type="donut" width="380" />
                    </div>
                    <div className='d-flex flex-column'>
                        <div className='d-flex'>
                            {
                                cardInfo.map((item) => (
                                    <div className='card pb-0 d-flex flex-row justify-content-center ml-3' style={{ width: "10rem", background: "#fff", borderRadius: "5px" }}>
                                        <div class="card-body d-flex justify-content-center flex-column align-items-center">
                                            <h6>{item.title}</h6>
                                            <h6>{item.value}</h6>
                                        </div>
                                    </div>
                                ))
                            }
                        </div>
                        <div className='mt-3'>
                            <Chart
                                options={heatmapChartOptions}
                                series={heatmapChartSeries}
                                type="heatmap"
                                width="500"
                            />
                        </div>
                    </div>
                </div>
                <div className='mt-2'>
                    <DataTable
                        columns={columns}
                        data={input}
                    />
                </div>
            </div>
        </div>
    )
}

export default Insights