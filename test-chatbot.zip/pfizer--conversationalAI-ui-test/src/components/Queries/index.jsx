import React, { useState, useEffect, useRef } from "react";
import "./queries.css";
import TopbarTheia from "../../common/TopbarTheia";
import Select from "react-select";
import axios from "axios";
import imageTheia from "../../assets/images/theia.png";
import Ellipse from "../../assets/images/Ellipse.svg";
import logo from "../../assets/images/Logo_3-removebg-preview 1 (1).svg";
import { ToastContainer, toast } from "react-toastify";
import { useLocation, Link } from "react-router-dom";
import person from "../../assets/images/chatBot.svg";
import robot from "../../assets/images/chatgpt robot sad.svg";
import thumsDown from "../../assets/images/ThumbsDown-black.svg";
import thumsDownRed from "../../assets/images/ThumbsDown-red.svg";
import questionImg from "../../assets/images/ThumbsUp-black.svg";
import thumsupWhite from "../../assets/images/ThumbsUp-white.svg";
import ThumsdownWhite from "../../assets/images/ThumbsDown-white.svg";
import thumbsUp from "../../assets/images/Copy-black.svg";
import ThumbsUpGreen from "../../assets/images/ThumbsUpGreen.svg";
import elipse from "../../assets/images/Ellipse 27.svg";
import dots from "../../assets/images/ChatCircleDots-black.svg";
import ModalPopUpTable from "../../common/QueriesModal";
import {
  QuestionEndPoint,
  DownloadEndPoint,
  GetPastQuesriesEndPoint,
  GetAnswerEndPoint,
  ViewEndpoint,
  LikeEndPoint,
  DisLikeEndPoint
} from "../../common/api-config";
import Popup from "../../common/CommentPopup";
import CaretCircleDoubleLeft from "../../assets/images/CaretCircleDoubleLeft.svg";
import CaretCircleDoubleRight from "../../assets/images/CaretCircleDoubleRight.svg";
import signOut from "../../assets/images/SignOut.svg";
import { useAuth } from "../../components/AuthContext";
import TypingEffect from "../../common/TypingEffect";
import { useNavigate } from 'react-router-dom';


const Queries = (item) => {
  const navigate = useNavigate()
  const [disliked, setDisliked] = useState(false);
  const [liked, setLiked] = useState(false);
  const [likedItems, setLikedItems] = useState([]);
  const [color, setColor] = useState('');
  const [question, setQuestion] = useState("");
  const [responseData, setResponseData] = useState("");
  const [passedQuery, setPassedQuery] = useState("");
  const [sourceFiles, setSourceFiles] = useState([]);
  const [questionsList, setQuestionList] = useState([]);
  const [pastQueries, setPastQueries] = useState([]);
  const [displayPastQueries, setDisplayPastQueries] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isCommentOpen, setIsCommentOpen] = useState(false);
  const [selectedDocumentOption, setSelectedDocumentOption] = useState(null);
  const [displayQuery, setDisplayQuery] = useState({});
  const [isChatLoading, setChatLoading] = useState(false);
  const location = useLocation();
  const selectedSource = localStorage.getItem("selectedSource");
  const [queryList, setQueryList] = useState([]);
  const [assignMargin, setAssignMargin] = useState(0);
  const latestQuestionRef = useRef(null);
  // const upcommingQuery = localStorage.getItem("QueryData") && JSON.parse(localStorage.getItem("QueryData"));
  const latestChatLoaderRef = useRef(null);
  const { logout } = useAuth();
  const isLiked = likedItems.includes(item.query)
  const handleLogout = () => {
    logout();
  };

  function download(data) {
    console.log("data", data);
    const url = URL.createObjectURL(data.data);
    const a = document.createElement("a");
    a.download = "test.pdf";
    a.href = url;
    a.target = "_self";

    a.click();
  }

  const downloadDocument = async (sourcePDF) => {
    const grantDocuments = "grants_documents/";
    const sourceFile = grantDocuments.concat(sourcePDF);
    console.log("sourceFile", sourceFile);

    let response = await axios.get(DownloadEndPoint(sourceFile), {
      responseType: "blob", // THIS is very important, because we need Blob object in order to download PDF
    });
    download(response);

    // axios
    // .get(DownloadEndPoint(sourcePDF))
    // .then((response) => {

    //     let blob = new Blob([response?.data],{
    //         type: "application/pdf"

    //     });
    //     //  FileSaver.saveAs(blob, "invoice.pdf")

    //     console.log(response)

    //     // InvoiceService.downloadPdf(response)
    //     //     .then(({ data }) => {
    //     //         let blob = new Blob([data], {
    //     //             type: "application/pdf"
    //     //         }); FileSaver.saveAs(blob, "invoice.pdf");
    //     //     }).catch(error => {
    //     //         throw new Error(error);
    //     //     });

    // })
    // .catch((error) => {
    //     console.error('Error occurred:', error);

    // });
  };
  const viewDocument = async (sourcePDF) => {
    const grantDocuments = "grants_documents/";
    const sourceFile = grantDocuments.concat(sourcePDF);
    console.log("sourceFile", sourceFile);
    await axios.get(ViewEndpoint(sourceFile), {}).then((response) => {
      console.log("response", response?.data);
      openPdfInNewTab(response?.data);
    });
    // openPdfInNewTab(response?.data)
  };
  const openPdfInNewTab = (response) => {
    const base64PdfData = response;
    const byteCharacters = atob(base64PdfData);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    const blob = new Blob([byteArray], { type: "application/pdf" });

    // Create a Blob URL for the PDF Blob
    const blobUrl = URL.createObjectURL(blob);

    // Open the PDF in a new tab
    window.open(blobUrl, "_blank");
  };
  const scrollToLatestQuestion = () => {
    console.log("heyyy");
    if (latestQuestionRef.current) {
      latestQuestionRef.current.scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
    }
  };
  const scrollToLatestChatLoader = () => {

    if (latestChatLoaderRef.current) {
      latestChatLoaderRef.current.scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
    }
  };

  useEffect(
    () => {
      if (
        queryList?.length == 0 &&
        location.state &&
        location.state.question !== undefined
      ) {
        const { question } = location.state;
        setQuestion(question);
        search(question);

        // const filteredQuery = questions.filter((data) => data.question === question)
        // setQuestionList(filteredQuery)
      }

      if (queryList.current != queryList) {
        scrollToLatestQuestion();
      }

      if (isChatLoading.current != isChatLoading) {
        scrollToLatestChatLoader();
        // scrollToLatestQuestion()
      }
      if (selectedSource) {
        setSelectedDocumentOption({
          value: selectedSource,
          label: selectedSource,
        });
      }
    },
    [queryList],
    isChatLoading
  );


  const closeModal = () => {
    setIsModalOpen(false);
  };

  const closeCommentModal = () => {
    setIsCommentOpen(false);
  };


  const CustomToast = ({ message, feedback, icon }) => (
    <div
      style={{ backgroundColor: "rgba(103, 187, 110, 1)", borderRadius: "5px" }}
      className="p-3"
    >
      <div className="d-flex flex-row pb-2 align-items-center">
        <img src={icon} alt="" />
        <span className="ml-2 toast-view-color">{feedback}</span>
      </div>
      <span className="mt-3 ml-2 mb-5 toast-view-subtext">{message}</span>
    </div>
  );

  const styles = {
    option: (provided, state) => ({
      ...provided,
      backgroundColor: state.isSelected ? "#3366ff" : "white",
      color: state.isSelected ? "white" : "black",
    }),
    valueContainer: (base) => ({
      ...base,
      paddingLeft: 24,
    }),
    control: (base) => ({
      ...base,
      minHeight: 50,
      // width: 380,
      borderRadius: "0px 8px 8px 0px",
      border: "1px solid #ccc",
      borderLeftColor: "white",
    }),
    indicatorSeparator: (base) => ({
      ...base,
    }),
    dropdownIndicator: (base) => ({
      ...base,
      color: "grey",
    }),
  };

  const answerView = (text) => {
    // if (text === "question1") {
    return (
      <div>
        {text}

        {/* <p>
                        Based on the provided context, the Applicant Eligibility Criteria for Independent Medical Education Grants are:
                    </p>
                    <div class="numbered-list">
                        <div class="numbered-item">
                            <span>1.</span> Medical, nursing, allied health, and/or pharmacy professional schools
                        </div>
                        <div class="numbered-item">
                            <span>2.</span> Healthcare institutions both large and small
                        </div>
                        <div class="numbered-item">
                            <span>3.</span> Professional associations and medical societies
                        </div>
                        <div class="numbered-item">
                            <span>4.</span> Patient advocacy groups
                        </div>
                        <div class="numbered-item">
                            <span>5.</span> Medical education companies
                        </div>
                        <div class="numbered-item">
                            <span>6.</span> Other entities with a mission related to healthcare professional education and/or healthcare improvement.
                        </div>
                    </div>
                    <p className='mt-3'>
                        It is important to note that the grant requester and ultimately the grantee are responsible for the design, implementation, and conduct of the independent initiative supported by the grant. Pfizer and Lilly must not be involved in any aspect of project development, nor the conduct of the independent education program.
                    </p> */}
      </div>
    );
    // }
  };

  const getAnswer = async (query) => {
    if (query.trim() !== "") {
      setChatLoading(true);
      await axios
        .post(GetAnswerEndPoint(), { query })
        .then((response) => {
          setChatLoading(false);
          const paragraphs = response?.data?.answer.split(/\n\n|\n/);
          setQueryList([
            {
              query: query,
              result: response?.data?.answer,
              source: response?.data?.source,
            },
          ]);
        })
        .catch((error) => {
          setChatLoading(false);
          console.error("Error occurred:", error);

        });
    }
  };

  const addToQueryListAndScroll = async (newQuery, response) => {
    const queryids = newQuery.map(({ query }) => query);
    const filtered = newQuery.filter(
      ({ query }, index) => !queryids.includes(query, index + 1)
    );
    scrollToLatestQuestion();
    setQuestion("");
    setChatLoading(false);
  };
  const search = (question) => {

    setChatLoading(true);
    if (question.trim() !== "") {

      axios
        .post(QuestionEndPoint(), {
          query: question,
        })
        .then((response) => {
          setChatLoading(false);
          const responseData = response?.data?.result;
          if (responseData) {
            setResponseData(responseData.result);
            queryList.push({
              query: question,
              result: responseData.result,
              source: responseData.source,
              likes: responseData.likes,
              dislikes: responseData.dislikes,
              comments: responseData.comments,
            });
          } else {
            console.log("invalid response structure", responseData.data);
          }

          const queryids = queryList.map(({ query }) => query);
          const filtered = queryList.filter(
            ({ query }, index) => !queryids.includes(query, index + 1)
          );
          setQueryList(filtered);
          addToQueryListAndScroll(queryList, response);

          const sourceDocs = responseData.source;

          const fileNames = sourceDocs.map((url) => {
            const parts = url.split("/");
            const fileNameWithExtension = parts[parts.length - 1];
            return fileNameWithExtension;
          });
          setSourceFiles(fileNames);
          setPassedQuery(response?.data?.query);
        })
        .catch((error) => {
          console.error("Error occurred:", error);

        });
    } else {
      toast.warning("Please type something.", {
        position: toast.POSITION.TOP_CENTER,
      });
    }

    setQuestion("");
  };

  const selectQuestion = (event) => {
    setQuestion(event.target.value);
  };

  const changeView = async () => {
    await axios
      .get(GetPastQuesriesEndPoint(), {})
      .then((response) => {
        setChatLoading(false);
        setPastQueries(response?.data);
      })
      .catch((error) => {
        setChatLoading(false);
        console.error("Error occurred:", error);
      });
    setDisplayPastQueries((prevDisplayPastQueries) => !prevDisplayPastQueries);
  };



 
  const selectLike = (query) => {

    axios
      .post(LikeEndPoint(), {
        query: query,
      })
      .then((likeResponse) => {
        console.log("like response", likeResponse.data);
        // const updatedLikes=likeResponse.data.likes;
        const updateQuerylist = queryList.map((item) =>
          item.query === query
            ? { ...item, likes: item.likes + 1, liked: true }
            : item
        );
        setQueryList(updateQuerylist);

      })
      .catch((likeError) => {
        console.error("error occured while liking", likeError);
      })

    toast(
      <CustomToast
        message="Your feedback will help us to improve"
        icon={thumsupWhite}
        feedback="Thanks for your feedback"
      />,
      {
        position: toast.POSITION.BOTTOM_CENTER,
        autoClose: 3000,
        hideProgressBar: true,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        closeButton: false,
        progress: undefined,
        style: {
          backgroundColor: "rgba(103, 187, 110, 1)",
          padding: "5px",
          borderRadius: "10px",
          boxShadow: "0 4px 8px rgba(0,0,0,0.2)",
        },
        bodyClassName:
          "d-flex flex-row align-items-center justify-content-between",
      }
    );
  };
  const selectDislike = (query) => {

    axios
      .post(DisLikeEndPoint(), {
        query: query,
      })
      .then((dislikeResponse) => {
        console.log("dislike response", dislikeResponse.data);
        const updateQuerylist = queryList.map((item) =>
          item.query === query
            ? { ...item, dislikes: item.dislikes + 1, disliked: true }
            : item
        );
        setQueryList(updateQuerylist);

      })
      .catch((dislikeError) => {
        console.error("error occured while disliking", dislikeError);
      });
    toast(
      <CustomToast
        message="Your feedback will help us to improve"
        icon={ThumsdownWhite}
        feedback="Thanks for your feedback"
      />,
      {
        position: toast.POSITION.BOTTOM_CENTER,
        autoClose: 3000,
        hideProgressBar: true,
        closeOnClick: true,
        pauseOnHover: true,
        closeButton: false,
        draggable: true,
        progress: undefined,
        style: {
          backgroundColor: "rgba(103, 187, 110, 1)",
          padding: "5px",
          borderRadius: "10px",
          boxShadow: "0 4px 8px rgba(0,0,0,0.2)",
        },
        bodyClassName:
          "d-flex flex-row align-items-center justify-content-between",
      }
    );
  };

  const commentSection = () => {
    setIsCommentOpen(true);
  };
  const handleCopyToClipboard = (text) => {
    navigator.clipboard
      .writeText(text)
      .then(() => {
        alert(`Copied to clipboard: ${text}`);
      })
      .catch((error) => {
        console.error("Failed to copy:", error);
        alert("Failed to copy to clipboard. Please try again.");
      });
  };

  const gotoDashboardView = () => {
    navigate("/my-dashboard")

  }
  const gotoInSightsView = () => {
    navigate("/insights")

  }
  const goToLanding = () => {
    navigate("/landing-page")

  }
  return (
    <>
      {/* <TopbarTheia /> */}
      <div className='header w-100 justify-content-between p-1'>
        <div className='logo-section d-flex flex-row align-items-center'>
          <img src={logo} onClick={goToLanding} style={{ cursor: "pointer" }} alt='Logo' />
          <img src={imageTheia} alt="imageTheia" className="ml-3" onClick={goToLanding} style={{ height: "50px", cursor: "pointer" }} />

        </div>
        <div className='d-flex flex-row align-items-center'>

          <span style={{ cursor: "pointer" }}>Search</span>
          <div className='vertical-line ml-3'></div>
          <span className='ml-3' onClick={() => gotoDashboardView()} style={{ cursor: "pointer" }}>My Dashboard</span>
          <span className='ml-5' onClick={() => gotoInSightsView()} style={{ cursor: "pointer" }}>In Sights</span>
          <div className='vertical-line ml-3'></div>
          <span className='ml-3' style={{ cursor: "pointer" }}>Help & FAQ</span>
          <div className="user-account" style={{ display: "flex", }}>
            <div className="ml-3" style={{ marginTop: "3px", marginRight: "5px" }}>{localStorage.getItem("userName")}</div>
            <div><img src={Ellipse} alt="User Icon" />
              <img style={{ marginLeft: "10px", cursor: "pointer" }} src={signOut} onClick={() => handleLogout()} alt="User Icon" />
            </div>
          </div>
        </div>
      </div>
      <div
        className="col-12 d-flex justify-content-between queries-container"
        style={{ padding: "16px 16px 0px 16px" }}
      >
        <div
          className="d-flex flex-column justify-content-between w-100"
          style={{ paddingRight: "16px" }}
        >
          <div className="d-flex flex-column queries-widget mb-3">
            {queryList?.map((item, index) => {
              return (
                <>
                  <div
                    className="d-flex flex-column mr-3 mb-4"
                    style={{ marginBottom: `${assignMargin}px` }}
                    ref={
                      index === queryList.length - 1
                        ? latestChatLoaderRef
                        : null
                    }
                  >
                    <div
                      className={
                        displayPastQueries
                          ? "max-width-100 d-flex flex-row w-100"
                          : "max-width-100 d-flex flex-row w-100"
                      }
                    >
                      <img src={person} alt="person" />
                      <div className="d-flex flex-row p-1 align-items-center mt-2 queries-box-top w-100">
                        <div className="ml-3">{item.query}</div>
                      </div>
                    </div>

                    <div
                      className={
                        displayPastQueries
                          ? "max-width-100 d-flex flex-column mt-2"
                          : "max-width-100 d-flex flex-column mt-2"
                      }
                    >
                      <div className="d-flex flex-row">

                        <div className="d-flex flex-column queries-box-bottom w-100 p-2">
                          <div
                            className="text-wrap p-2 mb-5"
                            style={{ marginLeft: "50px" }}
                          >
                            {/* {item.result} */}

                            <div>
                              {item.result != "" ? (
                                <TypingEffect text={item.result} delay={10} />
                              ) : null}
                            </div>
                          </div>

                          <div
                            className="d-flex flex-row"
                            style={{ marginLeft: "50px" }}
                          >
                            <img
                              src={item.liked ? ThumbsUpGreen : questionImg}
                              alt=""
                              style={{ cursor: 'pointer' }}
                              onClick={() => selectLike(item.query)}
                            />
                            <img
                              src={item.disliked ? thumsDownRed : thumsDown}
                              style={{
                                cursor: 'pointer'
                              }}
                              alt=""
                              className="ml-3"
                              onClick={() => selectDislike(item.query)}
                            />
                            <img
                              src={dots}
                              alt=""
                              className="ml-3"
                              style={{ cursor: "pointer" }}
                              onClick={() => commentSection(item.query)}
                            />
                            <img
                              src={thumbsUp}

                              alt=""
                              className="ml-3"
                              style={{ cursor: "pointer" }}
                              onClick={() =>
                                handleCopyToClipboard(responseData)
                              }
                            />
                          </div>
                          <div
                            className={
                              displayPastQueries
                                ? "max-width-100 d-flex flex-row flex-wrap mt-3"
                                : "max-width-100 d-flex flex-row flex-wrap mt-3"
                            }
                            style={{
                              alignSelf: "flex-start",
                              marginLeft: "50px",
                            }}
                          >
                            {sourceFiles.map((data, index) => {
                              return (

                                <div
                                  className="suggestions-border"
                                  key={index}
                                  onClick={() => viewDocument(data)}
                                >
                                  {data}
                                </div>

                              );
                            })}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </>
              );
            })}

            {queryList.length == 0 && isChatLoading ? (
              <div className="bouncing-loader" ref={latestChatLoaderRef}>
                <div></div>
                <div></div>
                <div></div>
              </div>
            ) : null}
          </div>
          {queryList.length !== 0 && isChatLoading ? (
            <div className="bouncing-loader" ref={latestChatLoaderRef}>
              <div></div>
              <div></div>
              <div></div>
            </div>
          ) : null}
          <div className="d-flex flex-row align-items-center justify-content-between flex-wrap query-color-input mt-2">
            <div className="d-flex flex-row flex-wrap col-10 pl-0 pr-0">
              <input
                placeholder="Type the question"
                className="pl-3 queries-input col-12 pl-0 pr-0"
                onChange={(event) => selectQuestion(event)}
                value={question}
              />
            </div>
            <div>
              <button
                className="queries-button"
                onClick={() => search(question)}
              >
                Send
              </button>
            </div>
          </div>
        </div>
        {displayPastQueries ? (
          <div className="col-3 query-tabs pl-0 pr-0">
            <ul
              className="nav nav-tabs justify-content-around p-1"
              id="myTab"
              role="tablist"
              style={{ backgroundColor: "#E6E6FA", borderRadius: "5px" }}
            >
              <li className="nav-item" role="presentation">
                <button
                  className="nav-link active"
                  id="post-tab"
                  data-bs-toggle="tab"
                  data-bs-target="#post"
                  type="button"
                  role="tab"
                  aria-controls="post"
                  aria-selected="true"
                >
                  My Past Queries
                </button>
              </li>
            </ul>
            <div className="tab-content" id="myTabContent">
              <div
                className="tab-pane fade show active"
                id="post"
                role="tabpanel"
                aria-labelledby="post-tab"
              >
                <div className="d-flex flex-column">
                  {pastQueries.map((item, index) => (
                    <>
                      <div
                        className="d-flex flex-row align-items-center"
                        style={{
                          backgroundColor:
                            index % 2 === 0 ? "#F6F6F6" : "#FFFFFF",
                          padding: "15px 10px 15px 10px",
                          cursor: "pointer",
                        }}

                        onClick={() => search(item.query)}
                      >
                        <img src={elipse} style={{ height: "10px" }} />
                        <div className="ml-3 pastQuery-color">{item.query}</div>
                      </div>
                      <div className="pastQuery-hr"></div>
                    </>
                  ))}
                </div>
              </div>
              <div
                className="tab-pane fade"
                id="popular"
                role="tabpanel"
                aria-labelledby="popular-tab"
              >
                2
              </div>
            </div>
          </div>
        ) : (
          <></>
        )}
        <div onClick={() => changeView()}>
          {displayPastQueries ? (
            <img src={CaretCircleDoubleLeft} alt="CaretIcon" />
          ) : (
            <img src={CaretCircleDoubleRight} alt="CaretIcon" />
          )}
        </div>
      </div>
      <ToastContainer autoClose={false} draggable={false} />
 
      <Popup
        openModal={isCommentOpen}
        popupWidth={"600px"}
        buttonTop={"4px"}
        close={closeCommentModal}
        type="info"
      />
    </>
  );
};

export default Queries;
