import React, { useEffect, useState } from 'react';

const TypingEffect = ({ text, delay = 10 }) => {
    const [displayText, setDisplayText] = useState('');

    useEffect(() => {
        if (!text || text.length === 0) {
          // Handle the case where text is undefined or empty
          return;
        }
      
        let index = -1;
        const timer = setInterval(() => {
          index++;
          if (index < text.length) {
            setDisplayText((prev) => prev + text[index]);
          }
      
          if (index === text.length - 1) {
            clearInterval(timer);
          }
        }, delay);
      
        return () => clearInterval(timer);
      }, [text, delay]);
      
    return (
        <div style={{whiteSpace:"pre-line"}}>
            {displayText}
        </div>
    )
}

export default TypingEffect;
