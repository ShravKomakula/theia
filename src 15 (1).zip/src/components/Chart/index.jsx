

import React, { useState } from 'react';
import Dropdown from 'react-bootstrap/Dropdown';
import Form from 'react-bootstrap/Form';
import './index.css'
import msgChatPerson from "../../assets/images/icons/person-icon.svg";
import msgChatRobot from "../../assets/images/icons/robot-icon.svg";
import snowFlakeIcon from "../../assets/images/icons/snowflake-icon.svg";
import azureIcon from "../../assets/images/icons/azure-icon.svg";
import icon from "../../assets/images/icons/azure-icon.svg";
import likeIcon from "../../assets/images/icons/like-icon.svg";
import dislikeIcon from "../../assets/images/icons/dislike-icon.svg";
import copyIcon from "../../assets/images/icons/copy-icon.svg";
import postgresqlIcon from "../../assets/images/icons/postgresql-img.svg";
import groupIcon from "../../assets/images/icons/group-icon.svg";
import searchIcon from "../../assets/images/icons/search-icon-grey.svg";
import micIcon from "../../assets/images/icons/mic-icon.svg";
import uploadIcon from "../../assets/images/icons/upload-icon.svg";
import sendIcon from "../../assets/images/icons/send-icon.svg";
import dropdownIcon from "../../assets/images/dropdown-2.svg";
import openAiIcon from "../../assets/images/icons/openai-icon.svg";
import infoIconCircle from "../../assets/images/icons/info-icon-circle.svg";
import { Col,Nav,Card,Tab,Row } from 'react-bootstrap';



let Chart = () => {

    const [selectedItem, setSelectedItem] = useState('Open AI');


    const handleSelect = (eventKey) => {
        setSelectedItem(eventKey);
      };


    return (
      <div className="wrapper">
        <div className="layout-wrapper main-wrapper-body d-flex">
          <Col xs={12} lg={8} md={8}>
            <div className="main-content py-3 ">
              <div className="page-content">
                <div class="chat-wrapper-box">
                  <div className="chat-flex-content d-flex flex-wrap">
                    <div className="chat-flex--column position-relative">
                      <div className="chat-header-wigit d-flex flex-wrap align-items-center justify-content-between p-2">
                        <div className="chat-title-section">
                          <h1 className="heading-top-h1 mb-0">Chat</h1>
                        </div>
                      </div>
                      <div className="chat-body-wrapper">
                        <div className="chat-middle-content">
                          <div className="chatright-layout">
                            <div className="chatuser-img">
                              <img src={msgChatPerson} />
                            </div>
                            <div className="d-flex flex-wrap chatlst-content">
                              <div className="chat-msgmtr">
                                <p className="msgwgt-txtcont-wt">
                                  What is Large language model?
                                </p>
                              </div>
                            </div>
                          </div>
                          <div className="chatright-layout">
                            <div className="chatuser-img">
                              <img src={msgChatRobot} />
                            </div>
                            <div className="d-flex flex-wrap chatlst-content-robot">
                              <div className="chat-msgmtr">
                                <p className="msgwgt-txtcont-wt">
                                  Large language models (LLM) are very large
                                  deep learning models that are pre-trained on
                                  vast amounts of data. The underlying
                                  transformer is a set of neural networks that
                                  consist of an encoder and a decoder with
                                  self-attention capabilities.
                                </p>
                                <div className="chat-file-view mt-3">
                                  <ul className="itemlst--cht">
                                    <li className="list-file-elemnt">
                                      <button
                                        type="button"
                                        className="btn btn-file-mtr chat-button-data"
                                      >
                                        Budget2020.pdf
                                      </button>
                                    </li>
                                    <li className="list-file-elemnt">
                                      <button
                                        type="button"
                                        className="btn btn-file-mtr chat-button-data"
                                      >
                                        Grant2020.pdf
                                      </button>
                                    </li>
                                  </ul>
                                </div>
                                <hr></hr>
                                <div className="d-flex flex-wrap">
                                  <span className="wrt-rm-button">
                                    <button
                                      type="button"
                                      className="btn btn-shr-web"
                                    >
                                      <img src={likeIcon} alt="icon" />
                                    </button>
                                  </span>
                                  <span className="wrt-rm-button">
                                    <button
                                      type="button"
                                      className="btn btn-shr-web"
                                    >
                                      <img src={dislikeIcon} alt="icon" />
                                    </button>
                                  </span>
                                  <span className="wrt-rm-button">
                                    <button
                                      type="button"
                                      className="btn btn-shr-web"
                                    >
                                      <img src={copyIcon} alt="icon" />
                                    </button>
                                  </span>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="chatright-layout">
                            <div className="chatuser-img">
                              <img src={msgChatPerson} />
                            </div>
                            <div className="d-flex flex-wrap chatlst-content">
                              <div className="chat-msgmtr">
                                <p className="msgwgt-txtcont-wt">
                                  What is Large language model?
                                </p>
                              </div>
                            </div>
                          </div>
                          <div className="chatright-layout">
                            <div className="chatuser-img">
                              <img src={msgChatRobot} />
                            </div>
                            <div className="d-flex flex-wrap chatlst-content-robot">
                              <div className="chat-msgmtr">
                                <p className="msgwgt-txtcont-wt">
                                  Large language models (LLM) are very large
                                  deep learning models that are pre-trained on
                                  vast amounts of data. The underlying
                                  transformer is a set of neural networks that
                                  consist of an encoder and a decoder with
                                  self-attention capabilities.
                                </p>
                                <div className="chat-file-view mt-3">
                                  <ul className="itemlst--cht">
                                    <li className="list-file-elemnt">
                                      <button
                                        type="button"
                                        className="btn btn-file-mtr chat-button-data"
                                      >
                                        Budget2020.pdf
                                      </button>
                                    </li>
                                    <li className="list-file-elemnt">
                                      <button
                                        type="button"
                                        className="btn btn-file-mtr chat-button-data"
                                      >
                                        Grant2020.pdf
                                      </button>
                                    </li>
                                  </ul>
                                </div>
                                <hr></hr>
                                <div className="d-flex flex-wrap">
                                  <span className="wrt-rm-button">
                                    <button
                                      type="button"
                                      className="btn btn-shr-web"
                                    >
                                      <img src={likeIcon} alt="icon" />
                                    </button>
                                  </span>
                                  <span className="wrt-rm-button">
                                    <button
                                      type="button"
                                      className="btn btn-shr-web"
                                    >
                                      <img src={dislikeIcon} alt="icon" />
                                    </button>
                                  </span>
                                  <span className="wrt-rm-button">
                                    <button
                                      type="button"
                                      className="btn btn-shr-web"
                                    >
                                      <img src={copyIcon} alt="icon" />
                                    </button>
                                  </span>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="chatright-layout">
                            <div className="chatuser-img">
                              <img src={msgChatPerson} />
                            </div>
                            <div className="d-flex flex-wrap chatlst-content">
                              <div className="chat-msgmtr">
                                <p className="msgwgt-txtcont-wt">
                                  What is Large language model?
                                </p>
                              </div>
                            </div>
                          </div>
                          <div className="chatright-layout">
                            <div className="chatuser-img">
                              <img src={msgChatRobot} />
                            </div>
                            <div className="d-flex flex-wrap chatlst-content-robot">
                              <div className="chat-msgmtr">
                                <p className="msgwgt-txtcont-wt">
                                  Large language models (LLM) are very large
                                  deep learning models that are pre-trained on
                                  vast amounts of data. The underlying
                                  transformer is a set of neural networks that
                                  consist of an encoder and a decoder with
                                  self-attention capabilities.
                                </p>
                                <div className="chat-file-view mt-3">
                                  <ul className="itemlst--cht">
                                    <li className="list-file-elemnt">
                                      <button
                                        type="button"
                                        className="btn btn-file-mtr chat-button-data"
                                      >
                                        Budget2020.pdf
                                      </button>
                                    </li>
                                    <li className="list-file-elemnt">
                                      <button
                                        type="button"
                                        className="btn btn-file-mtr chat-button-data"
                                      >
                                        Grant2020.pdf
                                      </button>
                                    </li>
                                  </ul>
                                </div>
                                <hr></hr>
                                <div className="d-flex flex-wrap">
                                  <span className="wrt-rm-button">
                                    <button
                                      type="button"
                                      className="btn btn-shr-web"
                                    >
                                      <img src={likeIcon} alt="icon" />
                                    </button>
                                  </span>
                                  <span className="wrt-rm-button">
                                    <button
                                      type="button"
                                      className="btn btn-shr-web"
                                    >
                                      <img src={dislikeIcon} alt="icon" />
                                    </button>
                                  </span>
                                  <span className="wrt-rm-button">
                                    <button
                                      type="button"
                                      className="btn btn-shr-web"
                                    >
                                      <img src={copyIcon} alt="icon" />
                                    </button>
                                  </span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <Col className="suggest-chat-items py-2 px-4 mb-2">
                        <span className="sugstbutton-chat">
                          <button className="btn btn-suggest-view">
                            How grant Works?
                          </button>
                        </span>
                        <span className="sugstbutton-chat">
                          <button className="btn btn-suggest-view">
                            How to implement them in real time?
                          </button>
                        </span>
                        <span className="sugstbutton-chat">
                          <button className="btn btn-suggest-view">
                            Examples of grants
                          </button>
                        </span>
                      </Col>

                      <div className="chat-footer-wapper">
                        <div className="txt-msgbox py-2 px-4">
                          <div className="d-flex flex-wrap msg--input-wgtyt">
                            <div className="input-chatmsg-filed position-relative">
                              <input
                                type="text"
                                className="form-control msgwrite-txt-field"
                                placeholder="Type the question"
                              />
                              <button
                                type="button"
                                className="btn btn-search-chatmsg"
                              >
                                <img src={searchIcon} alt="icon" />
                              </button>
                            </div>
                            <div className="d-flex flex-wrap align-items-center button-chat-action justify-content-end">
                            <div className=''>
                          <Dropdown className='dropselect-ai'>
                            <Dropdown.Toggle variant="light" className='select-opti-ai' onSelect={handleSelect}>
                              {selectedItem} <img src={dropdownIcon}></img>
                            </Dropdown.Toggle>

                            <Dropdown.Menu className='multi-ai-dropdown'>
                              <Dropdown.Item eventKey="Open AI" href="#/action-1">Open AI</Dropdown.Item>
                              <Dropdown.Item eventKey="Another action" href="#/action-2">Another action</Dropdown.Item>
                              <Dropdown.Item eventKey="Something else" href="#/action-3">Something else</Dropdown.Item>
                            </Dropdown.Menu>
                          </Dropdown>
                        </div>
                            <span className="chatcol-button-items">
                                <button
                                  type="button"
                                  className="btn btn-chat-btnview"
                                >
                                  <img src={micIcon} alt="icon" />
                                </button>
                              </span>
                              <span className="chatcol-button-items">
                                <button
                                  type="button"
                                  className="btn btn-chat-btnview"
                                >
                                  <img src={sendIcon} alt="icon" />
                                </button>
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </Col>
          <Col xs={12} lg={4} md={4}>
            <div className="flex-modal-configure">
              <div className="mdl-elemnt-areawgt">
                <Card className="card-items-boxes ">
                  <Tab.Container
                    id="left-tabs-example"
                    defaultActiveKey="tabpanel1"
                  >
                    <Card.Title
                      as="div"
                      bsPrefix="cardtab-header"
                      className="past.card-title "
                    >
                      <Nav
                        variant="pills"
                        className="tabpanel-pill justify-content-around custom-nav"
                      >
                        <Nav.Item>
                          <Nav.Link
                            eventKey="tabpanel1"
                            className="item-navtab-menu custom-nav-link"
                          >
                            Past Queries
                          </Nav.Link>
                        </Nav.Item>
                        <Nav.Item>
                          <Nav.Link
                            eventKey="tabpanel2"
                            className="item-navtab-menu custom-nav-link"
                          >
                            Popular Queries
                          </Nav.Link>
                        </Nav.Item>
                      </Nav>
                      <div></div>
                    </Card.Title>
                    <Card.Body>
                      <Tab.Content>
                        <Tab.Pane eventKey="tabpanel1">
                          <div className="content-ytn-waper">
                            <Row className="mb-4">
                              {/* <Col xs="12" md="12"> */}
                                <div className="question-list">
                                  <div className="question-item active">
                                    <div className="dot"></div>
                                    <p>
                                      What is Large language model? What is
                                      Large language model?
                                    </p>
                                  </div>
                                  <div className="question-item">
                                    <div className="dot"></div>
                                    <p>
                                      What is Large language model? What is
                                      Large language model?
                                    </p>
                                  </div>
                                  <div className="question-item active">
                                    <div className="dot"></div>
                                    <p>
                                      What is Large language model? What is
                                      Large language model?
                                    </p>
                                  </div>
                                  <div className="question-item">
                                    <div className="dot"></div>
                                    <p>
                                      What is Large language model? What is
                                      Large language model?
                                    </p>
                                  </div><div className="question-item active">
                                    <div className="dot"></div>
                                    <p>
                                      What is Large language model? What is
                                      Large language model?
                                    </p>
                                  </div>
                                  <div className="question-item">
                                    <div className="dot"></div>
                                    <p>
                                      What is Large language model? What is
                                      Large language model?
                                    </p>
                                  </div>
                                  <div className="question-item active">
                                    <div className="dot"></div>
                                    <p>
                                      What is Large language model? What is
                                      Large language model?
                                    </p>
                                  </div>
                                </div>
                              {/* </Col> */}
                            </Row>
                          </div>
                        </Tab.Pane>
                        <Tab.Pane eventKey="tabpanel2">
                        <div className="content-ytn-waper">
                            <Row className="mb-4">
                              {/* <Col xs="12" md="12"> */}
                                <div className="question-list">
                                  <div className="question-item active">
                                    <div className="dot"></div>
                                    <p>
                                      What is Large language model? What is
                                      Large language model?
                                    </p>
                                  </div>
                                  <div className="question-item">
                                    <div className="dot"></div>
                                    <p>
                                      What is Large language model? What is
                                      Large language model?
                                    </p>
                                  </div>
                                </div>
                              {/* </Col> */}
                            </Row>
                          </div>
                        </Tab.Pane>
                      </Tab.Content>
                    </Card.Body>
                  </Tab.Container>
                </Card>
              </div>
            </div>
          </Col>
        </div>
      </div>
    );
}

export default Chart;
