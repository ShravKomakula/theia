import React from 'react';
import Chart from 'react-apexcharts';
import './index.css'

const BarChart = () => {
  const chartData = {
    series: [{
      data: [30, 40, 45, 50, 49, 60, 70, 91, 125]
    }],
    options: {
      chart: {
        type: 'bar',
        height: 350,
        toolbar: {
            show: false
          },
      },
      plotOptions: {
        bar: {
          horizontal: false,
          columnWidth: '55%',
          endingShape: 'rounded'
        },
      },
      dataLabels: {
        enabled: false
      },
      stroke: {
        show: true,
        width: 2,
        colors: ['transparent']
      },
      xaxis: {
        categories: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September'],
      },
      yaxis: {
        title: {
          text: 'Revenue (in thousands)',
        },
      },
      fill: {
        opacity: 1
      },
      tooltip: {
        y: {
          formatter: function (val) {
            return "$" + val + "k"
          }
        }
      }
    },
  };

  return (
    <div className="bar-chart">
      <Chart options={chartData.options} series={chartData.series} type="bar" height={360} />
    </div>
  );
};

export default BarChart;