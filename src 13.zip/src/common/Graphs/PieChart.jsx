import React, { useState } from 'react';
import Chart from 'react-apexcharts';
import './index.css'
import { Col } from 'react-bootstrap';

const PieChart = () => {
  const [chartData, setChartData] = useState({
    series: [44, 55, 13, 33, 44, 55, 13, 33, 5, 55],
    options: {
      chart: {
        type: 'donut',
      },
      labels: [
        'TAC Different than requested amount',
        'Placeholder',
        'Total Budget Error',
        'Rejected: Status Error',
        'Final Report Returned',
        'Contract Signed before med approval',
        'Incorrect Final report available date',
        'Wrong Payment Status',
        'OK',
        'Pie group name',
      ],
      legend: {
        position: 'bottom',
        horizontalAlign: 'center',
      },
      responsive: [
        {
          breakpoint: 480,
          options: {
            chart: {
              width: 400,
            },
            legend: {
                position: 'bottom',
                horizontalAlign: 'center',
              },
          },
        },
      ],
      dataLabels: {
        enabled: false,
      },
      plotOptions: {
        pie: {
          donut: {},
        },
      },
      colors: ['#6E7EFD', '#F0B621', '#68ADFE', '#F448D9', '#FA898B', '#F4DC9D', '#BFCD13', '#BE4FF3', '#29BBAA', '#48C988'],
    },
  });

  return (
    <Col xs="12" md="6" className="donut-chart-container">
      <Chart options={chartData.options} series={chartData.series} type="donut" width={500} />
    </Col>
  );
};

export default PieChart;
