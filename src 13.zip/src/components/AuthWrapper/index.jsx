import React, { useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../AuthContext';
import { RevokeTokenEndPoint } from '../../common/api-config';
import axios from 'axios';
const AuthWrapper = ({ children }) => {
  const { authenticated } = useAuth();
  const location = useLocation()
  const navigate = useNavigate();

  useEffect(() => {
    if (!authenticated) {
      navigate('/');
    } else if (authenticated === true && location.pathname === "/"){
      navigate('/landing-page')
    }
  }, [authenticated, navigate, location]);
/* const refreshToken = async () => {
        try {
          console.log(JSON.parse(localStorage.access_token).tokenInfo.refresh_token,"access")
            const refreshToken = JSON.parse(localStorage.access_token).tokenInfo.refresh_token;
            const response = await axios.post(`http://10.11.185.89:8011/refresh_oauth2?refresh_token=${refreshToken}`, { refresh_token: refreshToken });
            // Update access token in localStorage or wherever you store tokens
            localStorage.setItem("access_token", response.data.access_token);
            console.log(response)
            return response.data.access_token;
            
        } catch (error) {
            console.error("Error refreshing token", error);
            throw error; // Throw the error to handle it in the calling function
        }
    };
 useEffect(() => {
        const interval = setInterval(() => {
            refreshToken();
        }, 1800); // Refresh token every 30 minutes

        return () => clearInterval(interval); // Clean up the interval on component unmount
    }, []);  
 
  
     */
    return (
      <>
        {children}
     
      </>
    );
  };
  
  export default AuthWrapper;
  
