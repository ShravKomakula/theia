import React, { useState, useEffect, useRef,useReducer } from "react";
import "./queries.css";
import { FaThumbsUp,FaRegUserCircle,FaCog, FaRegThumbsUp ,FaRegCopy,FaCopy, FaThumbsDown, FaRegThumbsDown, FaUserCheck } from "react-icons/fa";
import { Dropdown, DropdownDivider } from "react-bootstrap";
import Select from "react-select";
import axios from "axios";
import { FcDocument } from "react-icons/fc";
import { ToastContainer, toast } from "react-toastify";
import { useLocation, Link } from "react-router-dom";
import person from "../../assets/images/chatBot.svg";
import robot from "../../assets/images/chatgpt robot sad.svg";
import thumsDown from "../../assets/images/ThumbsDown-black.svg";
import thumsDownRed from "../../assets/images/ThumbsDown-red.svg";
import questionImg from "../../assets/images/ThumbsUp-black.svg";
import thumsupWhite from "../../assets/images/ThumbsUp-white.svg";
import ThumsdownWhite from "../../assets/images/ThumbsDown-white.svg";
import thumbsUp from "../../assets/images/Copy-black.svg";
import ThumbsUpGreen from "../../assets/images/ThumbsUpGreen.svg";
import elipse from "../../assets/images/Ellipse 27.svg";
import dots from "../../assets/images/ChatCircleDots-black.svg";
import ModalPopUpTable from "../../common/QueriesModal";
import {
  QuestionEndPoint,
  DownloadEndPoint,
  GetPastQuesriesEndPoint,
  GetAnswerEndPoint,
  ViewEndpoint,
  LikeEndPoint,
  DisLikeEndPoint,
  TextToSql
} from "../../common/api-config";
import Footer from "../../common/Footer/Footer";
import Popup from "../../common/CommentPopup";
import CaretCircleDoubleLeft from "../../assets/images/CaretCircleDoubleLeft.svg";
import CaretCircleDoubleRight from "../../assets/images/CaretCircleDoubleRight.svg";
import { useAuth } from "../../components/AuthContext";
import TypingEffect from "../../common/TypingEffect";
import { useNavigate } from "react-router-dom";
import voicesearch from "./../../assets/images/voicesearch.png";
import AnimatedMic from "../../assets/images/animatesmic.svg";
import Topbar from "../../common/Topbar";
const Queries = (item) => {

  const [sqlQuery, setSqlQuery] = useState("");
  const [table, setTable] = useState("");
  const [selectedQuery, setSelectedQuery] = useState("");
  const [alreadyLiked, setAlreadyLiked] = useState(false);
  const [alreadyDisliked, setAlreadyDisliked] = useState(false);
  const navigate = useNavigate();
  const [disliked, setDisliked] = useState(false);
  const [liked, setLiked] = useState(false);
  const [likedItems, setLikedItems] = useState([]);
  const [disLikedItems, setDisLikedItems] = useState([]);
  const [color, setColor] = useState("");
  const [question, setQuestion] = useState("");
  const [responseData, setResponseData] = useState("");
  const [passedQuery, setPassedQuery] = useState("");
  const [sourceFiles, setSourceFiles] = useState([]);
  const [questionsList, setQuestionList] = useState([]);
  const [pastQueries, setPastQueries] = useState([]);
  const [displayPastQueries, setDisplayPastQueries] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isCommentOpen, setIsCommentOpen] = useState(false);
  const [selectedDocumentOption, setSelectedDocumentOption] = useState(null);
  const [displayQuery, setDisplayQuery] = useState({});
  const [isChatLoading, setChatLoading] = useState(false);
  const location = useLocation();
  const {sourceType}=location.state;
  const selectedSource = localStorage.getItem("selectedSource");
  const [queryList, setQueryList] = useState([]);
  const [assignMargin, setAssignMargin] = useState(0);
  const latestQuestionRef = useRef(null);
  const latestChatLoaderRef = useRef(null);
  const { logout } = useAuth();
  const isLiked = likedItems.includes(item.query);
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [selectedDropdown, setSelectedDropdown] = useState(sourceType ?? "Source");
  const handleLogout = () => {
    logout();
  };
  const [showSettingsDropdown, setShowSettingsDropdown] = useState(false);

  const [isDocumentPopupOpen, setDocumentPopupOpen] = useState(false);
  function download(data) {
    console.log("data", data);
    const url = URL.createObjectURL(data.data);
    const a = document.createElement("a");
    a.download = "test.pdf";
    a.href = url;
    a.target = "_self";

    a.click();
  }
  const [selectedTemparature, setSelectedTemparature] = useState(0.1);
  const [seletedTopp, setSelectedTopp] = useState(0.1);
  const [selectedLength,setSelectedLenth] = useState(400);
  const [selectedDoc, setSelectedDoc] = useState(3);
  const [, forceUpdate] = useReducer((x) => x + 1, 0);
  const handleTemparature = (event) => {
    const newValue = parseFloat(event.target.value);
    setSelectedTemparature(newValue);
    forceUpdate();
    console.log("Updated Temperature:", newValue);
  };

  const handleTop = (event) => {
    const newValue = parseFloat(event.target.value);
    setSelectedTopp(newValue);
  };
  const handleLenth = (event) => {
    const newValue = parseFloat(event.target.value);
    setSelectedLenth(newValue);
  };
  const handleDoc = (event) => {
    const newValue = parseFloat(event.target.value);
    setSelectedDoc(newValue);
  };
  const openDocumentPopup = () => {
    setDocumentPopupOpen(true);
  };

  const closeDocumentPopup = () => {
    setDocumentPopupOpen(false);
  };
  const downloadDocument = async (sourcePDF) => {
    const grantDocuments = "grants_documents/";
    const sourceFile = grantDocuments.concat(sourcePDF);
    console.log("sourceFile", sourceFile);

    let response = await axios.get(DownloadEndPoint(sourceFile), {
      responseType: "blob", // THIS is very important, because we need Blob object in order to download PDF
    });
    download(response);

  }; 
  const stopListening = () => {
    setIsListening(false);
    if (transcript.trim() !== "") {
      setQuestion(transcript);
      setQuestion();
    } else {
      toast.warning("Please enter a question.", {
        position: toast.POSITION.TOP_CENTER,
      });
    }
  }; 
  const startListening = () => {
    setIsListening(true);

    const recognition = new (window.SpeechRecognition ||
      window.webkitSpeechRecognition)();

    recognition.continuous = false;

    recognition.interimResults = false;

    recognition.onresult = (event) => {
      const result = event.results[0];

      setTranscript(result[0].transcript);
    };

    recognition.onend = () => {
      setIsListening(false);

      setQuestion();
    };

    recognition.start();
  };

  const viewDocument = async (sourcePDF) => {
    //alert('Clicked URL:', sourcePDF);
    const grantDocuments = "grants_documents/";
    const sourceFile = grantDocuments.concat(sourcePDF);
    console.log("sourceFile", sourceFile);
    //console.log('Blob URL:', blobUrl);
    await axios.get(ViewEndpoint(sourceFile), {}).then((response) => {
      console.log("response", response?.data);
      openPdfInNewTab(response?.data);
    });
    // openPdfInNewTab(response?.data)
  }; 
  const openPdfInNewTab = (response) => {
    const base64PdfData = response;
    const byteCharacters = atob(base64PdfData);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    const blob = new Blob([byteArray], { type: "application/pdf" });

    // Create a Blob URL for the PDF Blob
    const blobUrl = URL.createObjectURL(blob);

    // Open the PDF in a new tab
    window.open(blobUrl, "_blank");
  };
  const scrollToLatestQuestion = () => {
    // console.log("hey its working");
    if (latestQuestionRef.current) {
      latestQuestionRef.current.scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
    }
  };
  /* console.log(sourceType,'sourcetype'); */
  const scrollToLatestChatLoader = () => {
    if (latestChatLoaderRef.current) {
      latestChatLoaderRef.current.scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
    }
  };

  useEffect(
    () => {
      // Load liked items from localStorage on component mount
      const storedLikedItems = localStorage.getItem("likedItems");
      if (storedLikedItems) {
        setLikedItems(JSON.parse(storedLikedItems));
      }
      if (
        queryList?.length == 0 &&
        location.state &&
        location.state.question !== undefined
      ) {
        const { question,sourceType } = location.state;
        setQuestion(question);
        search(question);

        // const filteredQuery = questions.filter((data) => data.question === question)
        // setQuestionList(filteredQuery)
      }

      if (queryList.current != queryList) {
        scrollToLatestQuestion();
      }

      if (isChatLoading.current != isChatLoading) {
        scrollToLatestChatLoader();
        // scrollToLatestQuestion()
      }
      if (selectedSource) {
        setSelectedDocumentOption({
          value: selectedSource,
          label: selectedSource,
        });
      }
    },
    [queryList],
    isChatLoading,
    []
  );

  const closeModal = () => {
    setIsModalOpen(false);
  };
  console.log(location,"loc")

  const closeCommentModal = () => {
    setIsCommentOpen(false);
    
  };
  
  const CustomToast = ({ message, feedback, icon }) => (
    <div
      style={{ backgroundColor: "rgba(103, 187, 110, 1)", borderRadius: "5px" }}
      className="p-3"
    >
      <div className="d-flex flex-row pb-2 align-items-center">
        <img src={icon} alt="" />
        <span className="ml-2 toast-view-color">{feedback}</span>
      </div>
      <span className="mt-3 ml-2 mb-5 toast-view-subtext">{message}</span>
    </div>
  );
  const DocumentPopup = ({ closePopup, pageContent, pageNames }) => {
    return (
      <div className="document-popup">
        {/* Popup content goes here */}
        <div className="document-popup-content">
          {/* Displaying key content and page content */}
          <div className="page-content">
            {/* Displaying content for each page */}
            {pageContent.map((content, index) => (
              <div key={index} className="page-content-item">
                <h2 className="pdf-name">{pageNames[index]}</h2>
                <div className="horizontal-line"></div>
                <p className="justified-text">{content}</p>
              </div>
            ))}
          </div>
          {/* White background, OK button, and close icon */}
          <button onClick={closePopup} className="OkButton">
            OK
          </button>
          <span onClick={closePopup} className="close-icon">
            &times;
          </span>
        </div>
      </div>
    );
  };
  


  const styles = {
    option: (provided, state) => ({
      ...provided,
      backgroundColor: state.isSelected ? "#3366ff" : "white",
      color: state.isSelected ? "white" : "black",
    }),
    valueContainer: (base) => ({
      ...base,
      paddingLeft: 24,
    }),
    control: (base) => ({
      ...base,
      minHeight: 50,
      // width: 380,
      borderRadius: "0px 8px 8px 0px",
      border: "1px solid #ccc",
      borderLeftColor: "white",
    }),
    indicatorSeparator: (base) => ({
      ...base,
    }),
    dropdownIndicator: (base) => ({
      ...base,
      color: "grey",
    }),
  };

  const answerView = (text) => {
    // if (text === "question1") {
    return (
      <div>
        {text}

      </div>
    );
    // }
  };

 const search = (question) => {
    setChatLoading(true);
  
    if (question.trim() === "") {
      setChatLoading(false);
      toast.warning("Please type something.", {
        position: toast.POSITION.TOP_CENTER,
      });
      return;
    }
  
    let endpoint = TextToSql(); // Use the TextToSql endpoint for both cases
  
    const payload = {
      query: question,
      source: selectedDropdown,
      k_similarity_docs: selectedDoc,
      temperature: selectedTemparature,
      top_p: seletedTopp,
      max_new_tokens: selectedLength,
      user: localStorage.getItem("userName"),
    };
  
    axios
      .post(endpoint, payload)
      .then((response) => {
        setChatLoading(false);
  
        if (selectedDropdown === "GNT01 SOPs and JobAids") {
          const responseData = response?.data;
  
          if (responseData) {
            const newEntry = {
              query: question,
              result: responseData.result || '', // Handle SOPs response structure
              source: selectedDropdown,
              page_content: responseData.page_content,
              sources: responseData.source_links || '',
              likes: responseData.likes,
              dislikes: responseData.dislikes,
              comments: responseData.comments,
            };
   // Add the new entry without modifying the existing state
          addToQueryListAndScroll(newEntry, response);

          const sourceDocs = newEntry.sources;
          const fileNames = sourceDocs.map((url) => {
            const parts = url.split("/");
            const fileNameWithExtension = parts[parts.length - 1];
            return fileNameWithExtension;
          });

          // Update sourceFiles for the current query
          setSourceFiles((prevSourceFiles) => [
            ...prevSourceFiles,
            { query: question, sourceFiles: fileNames },
          ]);
        } else {
          console.log("Invalid response structure for SOPs", responseData);
        }
        } else if (selectedDropdown === "Grant Details") {
          const responseData = response?.data;
  
          if (responseData) {
            const newEntry = {
              query: question,
         result: responseData.result !== undefined  ?  responseData.result  :  '',
               sqlQuery: responseData.sql || '',
              table: responseData.table || '', 
              result_text:responseData.result_text || '',
              source: selectedDropdown,
              likes: responseData.likes,
              dislikes: responseData.dislikes,
              comments: responseData.comments,
            };
  
            // Add the new entry without modifying the existing state
            addToQueryListAndScroll(newEntry, response);
          } else {
            console.log("Invalid response structure for Grants", responseData);
          }
        }
      })
      .catch((error) => {
        setChatLoading(false);
        console.error("Error occurred:", error);
      });
  
    setQuestion("");
  };
 
  // Function to add new entry to the state and scroll
  const addToQueryListAndScroll = (newEntry, response) => {
    setQueryList((prevQueryList) => [...prevQueryList, newEntry]);

    // Your scroll logic here
  };

  const selectQuestion = (event) => {
    setQuestion(event.target.value);
  };
  const handleDropdownChange = (eventKey) => {
    setSelectedDropdown(eventKey);
  };
  const changeView = async () => {
    await axios
      .get(GetPastQuesriesEndPoint(), {})
      .then((response) => {
        setChatLoading(false);
        setLiked(true);
        setPastQueries(response?.data);
      })
      .catch((error) => {
        setChatLoading(false);
        console.error("Error occurred:", error);
      });
    setDisplayPastQueries((prevDisplayPastQueries) => !prevDisplayPastQueries);
  };

  const selectLike = (query) => {
    if (likedItems.includes(query)) {
        // Show a popup indicating that the user has already liked this query
        // You can use a library like react-toastify to display the popup
        toast.warning("You already liked this query", {
            position: toast.POSITION.BOTTOM_CENTER,
            autoClose: 3000,
            // ... (other toast options)
        });
        return;
    }

    // The user has not already liked the query, proceed with the API call
    axios
        .post(LikeEndPoint(), {
            query: query,
            source: selectedDropdown,
            k_similarity_docs: selectedDoc,
            temperature: selectedTemparature,
            top_p: seletedTopp,
            max_new_tokens: selectedLength,

        })
        .then((likeResponse) => {
            console.log("like response", likeResponse.data);
            const updateQuerylist = queryList.map((item) =>
                item.query === query
                    ? {
                        ...item,
                        likes: item.likes + 1,
                        liked: true,
                        disliked: false,
                    }
                    : item
            );
            setQueryList(updateQuerylist);

            // Update likedItems state
            setLikedItems((prevLikedItems) => [...prevLikedItems, query]);
        })
        .catch((likeError) => {
            console.error("Error occurred while liking", likeError);
        });

    // Display a success message using toastify or any other notification library
    toast(
        <CustomToast
            message="Your feedback will help us to improve"
            icon={thumsupWhite}
            feedback="Thanks for your feedback"
        />,
        {
            position: toast.POSITION.BOTTOM_CENTER,
            autoClose: 3000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            closeButton: false,
            progress: undefined,
            style: {
                backgroundColor: "rgba(103, 187, 110, 1)",
                padding: "5px",
                borderRadius: "10px",
                boxShadow: "0 4px 8px rgba(0, 0, 0, 0.2)",
            },
            bodyClassName:
                "d-flex flex-row align-items-center justify-content-between",
        }
    );
};

  const selectDislike = (query) => {
 
    if (disLikedItems.includes(query)) {
      // Show a popup indicating that the user has already disliked this query
      // You can use a library like react-toastify to display the popup
      toast.warning("You already Disliked this query", {
        position: toast.POSITION.BOTTOM_CENTER,
        autoClose: 3000,
        // ... (other toast options)
      });
      return;
    }

    // The user has not already disliked the query, proceed with the API call
    axios
      .post(DisLikeEndPoint(), {
        query: query,
        source: selectedDropdown,
        k_similarity_docs: selectedDoc,
        temperature: selectedTemparature,
        top_p: seletedTopp,
        max_new_tokens: selectedLength,
      })
      .then((dislikeResponse) => {
        console.log("dislike response", dislikeResponse.data);
        const updateQuerylist = queryList.map((item) =>
          item.query === query
            ? {
                ...item,
                dislikes: item.dislikes + 1,
                liked: false,
                disliked: true,
              }
            : item
        );
        setQueryList(updateQuerylist);

        setAlreadyDisliked(true); // Set the flag indicating that the user has disliked
      })
      .catch((dislikeError) => {
        console.error("Error occurred while disliking", dislikeError);
      });

 
      // Open the comment section
      commentSection(query);
  };

  const commentSection = (query) => {
    console.log(query);
    setIsCommentOpen(true);
    setSelectedQuery(query);
  };
  const handleCopyToClipboard = (text) => {
  //  console.log("Copying to clipboard:", text);
  
    navigator.clipboard
      .writeText(text)
      .then(() => {
        toast.success("Copied successfully:");
       // alert(`Copied to clipboard: ${text}`);
      })
      .catch((error) => {
        console.error("Failed to copy:", error);
        alert("Failed to copy to clipboard. Please try again.");
      });
  };
  
  const renderResultText = (text) => {
    return (
      <div>
        {text.split('\n').map((paragraph, index) => (
          <p key={index}>{paragraph}</p>
        ))}
      </div>
    );
  };
  
  return (
    <>
        <Topbar />
      <div
        className="col-12 d-flex justify-content-between queries-container"
        style={{ padding: "16px 16px 0px 16px" }}
      >
         <div onClick={() => setShowSettingsDropdown(!showSettingsDropdown)}style={{ padding: "0px 16px 0px 16px" }}>
          {showSettingsDropdown ? (
            <img src={CaretCircleDoubleLeft} alt="CaretIcon" />
          ) : (
            <img src={CaretCircleDoubleRight} alt="CaretIcon" />
          )}
        </div>
 
   
    {showSettingsDropdown && (
   <div className="sidebar-content">
     <h4 className="settings-header">Settings</h4>
     <hr></hr>
      <div className="progress-bar-container">
       
  <div>
    <label>Temparature:</label><br></br>
    <label>0</label>
  <input type="range" min={0} max={1} step={0.1}
  onChange={handleTemparature} className="price-range-slider" value={selectedTemparature}
  
  ></input>
  <label>1</label><br></br>
  selected: {selectedTemparature}
  </div>
  <hr></hr>
  <div>
    <label>Top_p:</label><br></br>
    <label>0</label>
    <input type="range" min={0} max={1} step={0.1} className="price-range-slider" value={seletedTopp}
    onChange={handleTop}></input>
    <label>1</label><br></br>
    selected: {seletedTopp} 
  </div>
  <hr></hr>
  <div>
    <label>Max Length:</label><br></br>
  <label>100</label>
    <input type="range" min={100} max={2000} step={100} className="price-range-slider"
    onChange={handleLenth} value={selectedLength}></input>
    <label>2000</label><br></br>
    selected : {selectedLength}
  </div>
  <hr></hr>
  <div>
    <label>Similar Docs</label><br></br>
    <label>1</label>
    <input type="range" min={1} max={10} className="price-range-slider"
    value={selectedDoc} onChange={handleDoc}></input>
    <label>10</label><br></br>
    selected : {selectedDoc}
  </div>
  
</div>
</div>
)}


        <div
          className="d-flex flex-column justify-content-between w-100"
          style={{ paddingRight: "16px" }}
        >
          <div className="d-flex flex-column queries-widget mb-3">
            
            {queryList?.map((item, index) => {
            
              return (
                <>
                  <div
                    className="d-flex flex-column mr-3 mb-4"
                    style={{ marginBottom: `${assignMargin}px` }}
                    ref={
                      index === queryList.length - 1
                        ? latestChatLoaderRef
                        : null
                    }
                  >
                    <div
                      className={
                        displayPastQueries
                          ? "max-width-100 d-flex flex-row w-100"
                          : "max-width-100 d-flex flex-row w-100"
                      }
                    >
                     <FaUserCheck size={40} color="#0000C9"/>
                      <div className="d-flex flex-row p-1 align-items-center mt-2 queries-box-top w-100">
                        <div className="ml-3">{item.query}</div>
                      </div>
                    </div>

                    <div
                      className={
                        displayPastQueries
                          ? "max-width-100 d-flex flex-column mt-2"
                          : "max-width-100 d-flex flex-column mt-2"
                      }
                    >
                      <div className="d-flex flex-row">
                        <div className="d-flex flex-column queries-box-bottom w-100 p-2">
                          <div
                            className="text-wrap p-2 mb-5"
                            style={{ marginLeft: "50px" }}
                          >


<div>
  {item.result !== "" ? (
    <TypingEffect text={item.result} delay={10} />
  ) : (
    <>
  {/*   {item.result_text && (
        <div className="code-snippet">
  <code>    {item.sqlQuery}</code>
          
        </div>
      )}

      {item.table && (
        <div className="table-view">
          <span>Table:</span>
          <table>
            <tbody>
              {item.table.split('\n').map((row, index) => (
                <tr key={index}>
                  {row.split(/\s+/).map((cell, cellIndex) => (
                    <td key={cellIndex}>{cell}</td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}  */}
   <div>
    {item.result_text && (
      <div className="result-text-container">
        {renderResultText(item.result_text)}
      </div>
    )}
  </div>
    </>
  )}
</div>

                          </div>

                          <div
                            className="d-flex flex-row"
                            style={{ marginLeft: "50px" }}
                          >
                            {item.liked ? (
                              <FaThumbsUp
                                style={{
                                  cursor: "pointer",
                                  color: "#43A047",
                                }}
                              />
                            ) : (
                              <FaRegThumbsUp
                                style={{
                                  cursor: "pointer",
                                }}
                                onClick={() => selectLike(item.query)}
                              />
                            )}

                            {item.disliked ? (
                              <FaThumbsDown
                                style={{
                                  cursor: "pointer",
                                  color: "red",
                                }}
                                className="ml-3"
                              />
                            ) : (
                              <FaRegThumbsDown
                                style={{
                                  cursor: "pointer",
                                }}
                                className="ml-3"
                                onClick={() => selectDislike(item.query)}
                              />
                            )}

                       {item.source==="GNT01 SOPs and JobAids" ?
                       <FaRegCopy
                       className="ml-3"
                       style={{ cursor: "pointer" }}
                       onClick={() =>
                         handleCopyToClipboard(item.result)
                       }
                     />:<FaRegCopy
                     className="ml-3"
                     style={{ cursor: "pointer" }}
                     onClick={() =>
                       handleCopyToClipboard(item.result_text)
                     }
                   />}
{item.source==="GNT01 SOPs and JobAids" ? 
    <> 
<FcDocument
 className="ml-3"
 style={{ cursor: "pointer" }}
 onClick={() => openDocumentPopup(item.result)}
/> </>:null

}

{isDocumentPopupOpen && (
  <DocumentPopup
    closePopup={closeDocumentPopup}
    pageContent={item.page_content}
    pageNames={item.sources.map((url) => {
      const parts = url.split("/");
      return parts[parts.length - 1]; // Extracting the PDF name
    })}
  />
)}


</div>
                          <div
                            className={
                              displayPastQueries
                                ? "max-width-100 d-flex flex-row flex-wrap mt-3"
                                : "max-width-100 d-flex flex-row flex-wrap mt-3"
                            }
                            style={{
                              alignSelf: "flex-start",
                              marginLeft: "50px",
                            }}
                          >{sourceFiles
                            .find((entry) => entry.query === item.query)
                            ?.sourceFiles?.map((url, index) => {
                              
    const parts = url.split('/');
    const fileNameWithExtension = parts[parts.length - 1];

    return (
      <div
        className="suggestions-border"
        key={index}
        onClick={() => viewDocument(url)}
      >
        {fileNameWithExtension}
      </div>
    );
})}

                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </>
              );
            })}

            {queryList.length == 0 && isChatLoading ? (
              <div className="bouncing-loader" ref={latestChatLoaderRef}>
                <div></div>
                <div></div>
                <div></div>
              </div>
            ) : null}
          </div>
          {queryList.length !== 0 && isChatLoading ? (
            <div className="bouncing-loader" ref={latestChatLoaderRef}>
              <div></div>
              <div></div>
              <div></div>
            </div>
          ) : null}
          <div className="d-flex flex-row align-items-center justify-content-between flex-wrap query-color-input mt-2">
            <div className="d-flex flex-row flex-wrap col-10 pl-0 pr-0 ">
              <input
                placeholder="Type the question"
                className="col-lg-12 col-md-12 col-sm-12 searchbar"id="searchbar" type="text" title="Search" width={600}
                value={transcript || question }
                onChange={(event) => selectQuestion(event)}
                onKeyPress={(event) => {
                  if (event.key === "Enter") {
                    search(question);
                  }
                }}
              

              />
<div onClick={isListening ? stopListening : startListening}  >
     <img className="voice-icon" src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e8/Google_mic.svg/716px-Google_mic.svg.png" title="Search by Voice" />
     </div>




<Dropdown onSelect={handleDropdownChange} className="dropdownlist1">
      <Dropdown.Toggle id="dropdown-basic">
        {selectedDropdown}
      </Dropdown.Toggle>

      <Dropdown.Menu>
        <Dropdown.Item eventKey="Select Source">Select Source</Dropdown.Item>
        <DropdownDivider />
        <Dropdown.Item eventKey="GNT01 SOPs and JobAids">GNT01 SOPs and JobAids</Dropdown.Item>
        <Dropdown.Item eventKey="Grant Details">Grant Details</Dropdown.Item>
        <Dropdown.Item eventKey="Grant Uploads">Grant Uploads</Dropdown.Item>
        
        <Dropdown.Item eventKey="Org and HCP Intelligence">Org & HCP Intelligence</Dropdown.Item>
        <Dropdown.Item eventKey="placeholder- DFO">placeholder- DFO</Dropdown.Item>
        <Dropdown.Item eventKey="Placeholder-MedInfo">Placeholder-MedInfo</Dropdown.Item>
      </Dropdown.Menu>
    </Dropdown>
    
            </div>
            <button
                className="queries-button"
                onClick={() => search(question)}
              >
                Send
              </button>
            <div>
            
            </div>
          </div>
        </div>
        {displayPastQueries ? (
          <div className="col-3 query-tabs pl-0 pr-0">
            <ul
              className="nav nav-tabs justify-content-around p-1"
              id="myTab"
              role="tablist"
              style={{ backgroundColor: "#E6E6FA", borderRadius: "5px" }}
            >
              <li className="nav-item" role="presentation">
                <button
                  className="nav-link active"
                  id="post-tab"
                  data-bs-toggle="tab"
                  data-bs-target="#post"
                  type="button"
                  role="tab"
                  aria-controls="post"
                  aria-selected="true"
                >
                  My Past Queries
                </button>
              </li>
            </ul>
            <div className="tab-content" id="myTabContent">
              <div
                className="tab-pane fade show active"
                id="post"
                role="tabpanel"
                aria-labelledby="post-tab"
              >
                <div className="d-flex flex-column">
                  {pastQueries.map((item, index) => (
                    <>
                      <div
                        className="d-flex flex-row align-items-center"
                        style={{
                          backgroundColor:
                            index % 2 === 0 ? "#F6F6F6" : "#FFFFFF",
                          padding: "15px 10px 15px 10px",
                          cursor: "pointer",
                        }}
                        onClick={() => search(item.query)}
                      >
                        <img src={elipse} style={{ height: "10px" }} />
                        <div className="ml-3 pastQuery-color">{item.query}</div>
                      </div>
                      <div className="pastQuery-hr"></div>
                    </>
                  ))}
                </div>
              </div>
              <div
                className="tab-pane fade"
                id="popular"
                role="tabpanel"
                aria-labelledby="popular-tab"
              >
                2
              </div>
            </div>
          </div>
        ) : (
          <></>
        )}
        <div onClick={() => changeView()}>
          {displayPastQueries ? (
            <img src={CaretCircleDoubleLeft} alt="CaretIcon" />
          ) : (
            <img src={CaretCircleDoubleRight} alt="CaretIcon" />
          )}
        </div>
      </div>
      <ToastContainer autoClose={false} draggable={false} />

      <Popup
        openModal={isCommentOpen}
        popupWidth={"600px"}
        buttonTop={"4px"}
        close={closeCommentModal}
        closeForm={closeModal}
        type="info"
        toast={CustomToast}
        question={selectedQuery}
        source= {selectedDropdown}
        k_similarity_docs= {selectedDoc}
        temperature={selectedTemparature}
        top_p ={seletedTopp}
        max_new_tokens= {selectedLength}
      />
      <Footer />
    </>
  );
};

export default Queries;
