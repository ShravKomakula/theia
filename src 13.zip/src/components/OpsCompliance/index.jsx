
import React, { useState, useEffect } from 'react';
import Container from 'react-bootstrap/Container';
import './index.css'
import { Col, Row } from 'react-bootstrap';
import Table from 'react-bootstrap/Table';
import downArrow from '../../assets/images/arrow-down.svg'
import checkCircle from '../../assets/images/CheckCircle (1).svg'
import rejectedIcon from '../../assets/images/rejectedIcon.svg'
import pendingIcon from '../../assets/images/Hourglass.svg'
import PieChart from '../../common/Graphs/PieChart';
import BarChart from '../../common/Graphs/BarChart';


const truncateText = (element, maxLength = 5) => {
  const img = element.querySelector('img');
  const text = element.textContent.trim();

  if (text.length > maxLength) {
    if (element.classList.contains('tableHeadingText')) {
      element.innerHTML = `${text.substring(0, maxLength)}... ${img ? img.outerHTML : ''}`;
    } else {
      element.innerHTML = `${img ? img.outerHTML : ''}${text.substring(0, maxLength)}...`;
    }
  }
};
let OpsCompliance = () => {
  useEffect(() => {
    const headers = document.querySelectorAll('.tableHeadingText');
    headers.forEach(header => truncateText(header));

    const cells = document.querySelectorAll('.tbody-element--wp td');
    cells.forEach(cell => truncateText(cell));
  }, []);

  return (
    <div className='wrapper'>
      <div className="layout-wrapper main-wrapper-body d-flex">
        <div className="main-content py-3">
          <div className='page-content'>
            <Container fluid>
              <h1 className='heading-top-h1'>
                Ops Compliance
              </h1>
              <Row className='d-flex'>
                <Col xs="12" md="6">
                  <div className='map-img-wp card-box-area mb-3 card p-4'>
                    <h5 className='mainText-Heading'>
                      Name of this section or heading
                    </h5>
                    <PieChart/>
                  </div>
                </Col>
                <Col xs="12" md="6">
                  <div className='map-img-wp card-box-area mb-3 card p-4'>
                    <h5 className='mainText-Heading'>
                      Name of this section or heading
                    </h5>
                    <BarChart/>
                  </div>
                </Col>
              </Row>
                <div className="table-list map-img-wp card-box-area" >
                  <Table responsive className='table-lits-wap-pground mb-0'>
                    <thead className='thead-md-wp'>
                      <tr>
                        <th className='tableHeadingText'>ID <img src={downArrow} alt="downArrow" /></th>
                        <th className='tableHeadingText'>Request ID <img src={downArrow} alt="downArrow" /></th>
                        <th className='tableHeadingText'>Owner Name <img src={downArrow} alt="downArrow" /></th>
                        <th className='tableHeadingText'>Owner Title <img src={downArrow} alt="downArrow" /></th>
                        <th className='tableHeadingText'>Budgt Section <img src={downArrow} alt="downArrow" /></th>
                        <th className='tableHeadingText'>Final Report <img src={downArrow} alt="downArrow" /></th>
                        <th className='tableHeadingText'>Map Dates <img src={downArrow} alt="downArrow" /></th>
                        <th className='tableHeadingText'>Map Section <img src={downArrow} alt="downArrow" /></th>
                        <th className='tableHeadingText'>Payment Section <img src={downArrow} alt="downArrow" /></th>
                        <th className='tableHeadingText'>Project Closure <img src={downArrow} alt="downArrow" /></th>
                        <th className='tableHeadingText'>Payment Status <img src={downArrow} alt="downArrow" /></th>
                        <th className='tableHeadingText'>Satus <img src={downArrow} alt="downArrow" /></th>
                      </tr>
                    </thead>
                    <tbody className='tbody-element--wp'>
                      <tr>
                        <td>1</td>
                        <td>7609855</td>
                        <td>Veronica</td>
                        <td>Grant Administration</td>
                        <td>TAC Administration</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={rejectedIcon} alt="rejectedIcon" />Cancel</td>
                      </tr>
                      <tr>
                        <td>2</td>
                        <td>7609855</td>
                        <td>Veronica</td>
                        <td>Grant Administration</td>
                        <td>TAC Administration</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={rejectedIcon} alt="rejectedIcon" />Cancel</td>
                      </tr>
                      <tr>
                        <td>3</td>
                        <td>7609855</td>
                        <td>Veronica</td>
                        <td>Grant Administration</td>
                        <td>TAC Administration</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={rejectedIcon} alt="rejectedIcon" />Rejected</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={rejectedIcon} alt="rejectedIcon" />Rejected</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={checkCircle} alt="checkCircle" />Completed</td>
                      </tr>
                      <tr>
                        <td>4</td>
                        <td>7609855</td>
                        <td>Veronica</td>
                        <td>Grant Administration</td>
                        <td>TAC Administration</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={rejectedIcon} alt="rejectedIcon" />Rejected</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={rejectedIcon} alt="rejectedIcon" />Rejected</td>
                        <td><img src={pendingIcon} alt="pendingIcon" />pending</td>
                      </tr>
                      <tr>
                        <td>5</td>
                        <td>7609855</td>
                        <td>Veronica</td>
                        <td>Grant Administration</td>
                        <td>TAC Administration</td>
                        <td><img src={rejectedIcon} alt="rejectedIcon" />Rejected</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={rejectedIcon} alt="rejectedIcon" />Rejected</td>
                        <td><img src={pendingIcon} alt="pendingIcon" />Pending</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={checkCircle} alt="checkCircle" />completed</td>
                      </tr>
                      <tr>
                        <td>6</td>
                        <td>7609855</td>
                        <td>Veronica</td>
                        <td>Grant Administration</td>
                        <td>TAC Administration</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={checkCircle} alt="checkCircle" />OK</td>
                        <td><img src={rejectedIcon} alt="rejectedIcon" />Cancel</td>
                      </tr>
                    </tbody>
                  </Table>
                </div>
            </Container>
          </div>
        </div>
      </div>
    </div>
  );
}

export default OpsCompliance;